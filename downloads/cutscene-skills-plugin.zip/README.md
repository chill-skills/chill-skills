# Cutscene skills — shareable bundle

Method by **fwjelaa (FWJ STUDIOS)**. Preserve attribution and the included third-party licenses.

## Start here

1. Extract the entire bundle. Keep all folders inside `skills/` together; `make-cutscene` depends on sibling skills, especially `make-anim`.
2. Open this folder in your coding assistant and ask it to read `skills/make-cutscene/SKILL.md`, then follow its referenced instructions. This works as a file-based starting point; slash-command registration depends on your assistant.
3. For connected authoring, the supplied workflow expects Python 3.11+, Blender 5.x, Roblox Studio, the appropriate Blender/Studio MCP connections, and FFmpeg/ffprobe. yt-dlp is optional for supported video links. These are not included or installed by this bundle.
4. Start with planning or Studio-only previews. Before publishing, set your own `user_id` or `group_id` in `skills/make-cutscene/config.json`. The blank `work_dir` defaults to `~/make-cutscene`; set it or `MAKE_CUTSCENE_WORK` if you want another working folder.
5. From `skills/make-cutscene`, run `python kit/run.py bundle` to regenerate the Studio installer scripts. Read the skill's safety and file-transfer instructions before sending anything to Studio.

Example request:

> Read skills/make-cutscene/SKILL.md and its required sibling skills. Help me plan a short Roblox cutscene, then author and verify it in my chosen Studio place. Do not upload assets or access credentials without permission.

## Included

- Cutscene authoring kit, Roblox runtime, tests, fixtures, examples, VFX and reference guidance.
- Animation and map-building siblings, R6/R15 directors, cinematic direction/editing, and Blender production guidance.
- Existing attribution, credits and third-party notices. External rig downloads remain external; consult their licenses and the provided fetch workflow.

## Removed from this share copy

- Development `project/` archive, old planning logs, captures, previews and project reference media.
- Python caches, stale generated `make-cutscene/out/` installers and the old copy manifest.
- Original creator ID and machine-specific working-folder configuration.
- Links into the excluded development archive were converted to explicit provenance notes.

The original source folder was left unchanged. This is a skills bundle, not a finished Roblox place or a collection of published animation permissions. Example asset IDs may need replacement or permission in your own experience.

## Important limits

Read `skills/make-cutscene/SKILL.md` before the legacy `CLAUDE.md`: corrected capability references take precedence where that manual conflicts. The legacy reconciliation warning is preserved. Sound/voice/facial playback and other unsupported features are not enabled by packaging.

The legacy `python kit/run.py check` probes locally configured credentials. Do not run it in a no-credential scope. Never include API keys, `.secrets`, `.env`, session files or your generated working projects when resharing.

Package checks do not certify Blender rendering, Studio playback or published-game compatibility. Those require the connected workflow and real R6/R15 tests.


## Repackaged for Claude upload

Repackaged by Chill Skills so it can be uploaded as a Claude plugin: added `.claude-plugin/plugin.json` and `marketplace.json`, and the nested Blender add-on zip now ships as `rbx_anims_v2.6.3.zip.b64` (restored byte-for-byte by `skills/animate-roblox-characters/scripts/addon_bundle.py`, SHA-256 checked). Nothing else was changed. All credit to fwjelaa (FWJ STUDIOS).
