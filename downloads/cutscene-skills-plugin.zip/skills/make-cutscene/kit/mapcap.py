"""Map capture: check the chunks Studio returned and merge them into map.json (spec 5.2). Method by fwjelaa (FWJ STUDIOS).

roblox/authoring/Capture.luau (the studio step `map`) stores the capture in ServerStorage.CutsceneCapture_<id> as text
chunks. Each comes back through execute_luau as one string; Claude saves chunk n, exactly as returned, to
cutscenes/<id>/studio/map_<n>.txt. `py kit/run.py map <id>` checks every chunk's length and Adler-32 before merging, so
a chunk copied wrong is named and fetched again instead of becoming a wall in the wrong place.

Box x, y, z = centre relative to the anchor; rx, ry, rz = CFrame:ToOrientation() in degrees, so the rotation is
Ry * Rx * Rz (CFrame.fromOrientation). Studs and degrees in Roblox axes (X right, Y up, Z back).
"""
import json
import re
import zlib
from pathlib import Path

import clip
import workspace

HEADER = re.compile(r"^MAPCAP (\S+) (\d+)/(\d+) ([0-9a-f]{8}) ([0-9a-f]{8}) (\d+)$")
STALE = "delete studio/map_*.txt from an older capture first"
FILE = re.compile(r"^map_(\d+)\.txt$")
# box faces over corners() (index = ix*4 + iy*2 + iz), each wound counter-clockwise seen from outside
FACES = ((0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3))
INVISIBLE = 0.98  # a stand-in at least this transparent can't be seen (play-bound walls)


def visible(box):
    """False for a box nobody can see: its optional 11th value is its Transparency (older captures have none)."""
    return (box[10] if len(box) > 10 else 0) < INVISIBLE


class ChunkError(ValueError):
    pass


def adler(text):
    return f"{zlib.adler32(text.encode('utf-8')) & 0xffffffff:08x}"


def make_chunk(name, index, total, payload, nonce="00000000"):
    """What Capture.storeMap writes (the tests build chunks with it). The nonce is one per capture."""
    return f"MAPCAP {name} {index}/{total} {nonce} {adler(payload)} {len(payload.encode('utf-8'))}\n{payload}"


def parse_chunk(text, label="chunk"):
    head, sep, payload = text.replace("\r\n", "\n").partition("\n")
    m = HEADER.match(head.strip())
    if not m or not sep:
        raise ChunkError(f"{label}: no MAPCAP header line (save the whole returned string, header included)")
    name, index, total, nonce = m.group(1), int(m.group(2)), int(m.group(3)), m.group(4)
    check, size = m.group(5), int(m.group(6))
    payload = payload.rstrip("\n")
    if len(payload.encode("utf-8")) != size or adler(payload) != check:
        raise ChunkError(f"chunk {index} ({label}) doesn't match what Studio sent (length {len(payload.encode('utf-8'))} "
                         f"of {size}, checksum {adler(payload)} of {check}): fetch chunk {index} again and save it exactly")
    return name, index, total, payload, nonce


def merge(texts):
    chunks, labels, parsed = {}, {}, []
    for label, text in texts:
        name, index, total, payload, nonce = parse_chunk(text, label)
        parsed.append((label, name, total, nonce))
        if index in chunks:
            raise ChunkError(f"chunk {index} is in both {labels[index]} and {label}, twice: {STALE}")
        if index >= total:
            raise ChunkError(f"{label} says chunk {index} of {total}, which can't be: {STALE}")
        chunks[index] = (name, total, payload)
        labels[index] = label
    if not chunks:
        raise ChunkError("no chunks: run the map step in Studio, then fetch every chunk")
    names, totals, nonces = {p[1] for p in parsed}, {p[2] for p in parsed}, {}
    for label, _, _, nonce in parsed:
        nonces.setdefault(nonce, []).append(label)
    if len(nonces) > 1 or len(names) > 1 or len(totals) > 1:
        who = "; ".join(f"capture {n}: {', '.join(ls)}" for n, ls in sorted(nonces.items()))
        raise ChunkError(f"these chunks come from different captures ({who}): capture again, and {STALE}")
    total = totals.pop()
    missing = [i for i in range(total) if i not in chunks]
    if missing:
        raise ChunkError("missing chunks " + ", ".join(map(str, missing)) + ": fetch them")
    head = json.loads(chunks[0][2])
    boxes, cells = [], []
    for i in range(1, total):
        for rec in chunks[i][2].split(";"):
            f = rec.split(",")
            if f[0] == "b" and len(f) in (11, 12):
                # the optional 12th field is the part's Transparency in percent; no field means visible
                boxes.append([*(int(v) / 10 for v in f[1:10]), f[10], *([int(f[11]) / 100] if len(f) == 12 else [])])
            elif f[0] == "t" and len(f) == 4:
                cells.append([int(f[1]), int(f[2]), int(f[3]) / 10])
            elif rec:
                raise ChunkError(f"chunk {i}: a record makes no sense ({rec[:40]!r}): fetch chunk {i} again")
    if len(boxes) != head["boxes"] or len(cells) != head["cells"]:
        raise ChunkError(f"expected {head['boxes']} boxes and {head['cells']} terrain samples, got {len(boxes)} and "
                         f"{len(cells)}: capture again")
    return {"v": head["v"], "name": head["name"], "anchor": head["anchor"], "radius": head["radius"], "boxes": boxes,
            "terrain": {"step": head["terrain"]["step"], "n": head["terrain"]["n"], "cells": cells},
            "skipped": head["skipped"], "found": head["found"]}


def orient(rx, ry, rz):
    """CFrame.fromOrientation(rad(rx), rad(ry), rad(rz)) = Ry * Rx * Rz, degrees in."""
    return clip.matmul(clip.matmul(clip.rot_xyz(0, ry, 0), clip.rot_xyz(rx, 0, 0)), clip.rot_xyz(0, 0, rz))


def corners(box):
    x, y, z, sx, sy, sz, rx, ry, rz = box[:9]
    r = orient(rx, ry, rz)
    out = []
    for hx in (-sx / 2, sx / 2):
        for hy in (-sy / 2, sy / 2):
            for hz in (-sz / 2, sz / 2):
                out.append(tuple(c + r[i][0] * hx + r[i][1] * hy + r[i][2] * hz for i, c in enumerate((x, y, z))))
    return out


def merge_folder(root):
    root = Path(root)
    files = []
    for p in (root / "studio").glob("map_*.txt"):
        m = FILE.match(p.name)
        if not m:
            raise ChunkError(f"{p.name} is not a chunk file (they are map_0.txt, map_1.txt ...): {STALE}")
        files.append((int(m.group(1)), p))
    texts = []
    for _, p in sorted(files):
        try:
            texts.append((p.name, p.read_bytes().decode("utf-8")))
        except UnicodeDecodeError:
            raise ChunkError(f"{p.name} is not UTF-8 text: save the returned string exactly, with the Write tool") from None
    data = merge(texts)
    if data["name"] != root.name:
        raise ChunkError(f"these chunks are from {data['name']}, not {root.name}: capture this scene's map")
    path = workspace.write_json(root / "map.json", data)
    # skipped = tiny parts plus those over the box cap (found counts only parts in range), so kept + skipped = all considered
    return path, (f"{len(data['boxes'])} stand-ins ({data['skipped']} left out of {len(data['boxes']) + data['skipped']}), "
                  f"{len(data['terrain']['cells'])} terrain samples, radius {data['radius']} studs")
