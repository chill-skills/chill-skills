"""Cast overlap check (RS-1): a limb inside another cast member's body fails the export, frame by frame, except on
the contacts the beat sheet plans. Method by fwjelaa (FWJ STUDIOS).

Roblox body parts are rigid blocks, so each part is tested as its own box (exact, not a proxy guess) with the
separating-axis test; the depth is the smallest overlap over the 15 axes. A box wholly inside another counts too
(a triangle-intersection test such as BVHTree.overlap misses that case). Pure Python: the export feeds it the part
frames it samples anyway, and the tests run without Blender.

A shot plans its contacts in beats.json:
  "contacts": [[seconds into the shot, "player.RightHand", "npc1.UpperTorso", frames], ...]
which lets that pair touch from that frame for `frames` frames (the hit-stop and the reaction; default HOLD). A part
name may be a wildcard pattern ("npc1.Left*" = the left limbs, "npc1.*Torso" = both torso parts).
"""
import fnmatch
import math

TOL = 0.1  # studs: deeper than this counts as inside (blocky parts brushing in a clinch stay under it)
HOLD = 6  # frames a planned contact stays allowed when the beat sheet gives no count
FPS = 60


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def box(matrix, size):
    """A box from a 4x4 (rows, like mathutils.Matrix or nested lists: rotation columns + translation in column 3) and
    the part's size: (centre, (x axis, y axis, z axis), half sizes)."""
    m = [list(matrix[i]) for i in range(3)]
    centre = (m[0][3], m[1][3], m[2][3])
    axes = tuple((m[0][k], m[1][k], m[2][k]) for k in range(3))
    return centre, axes, (size[0] / 2, size[1] / 2, size[2] / 2)


def _reach(b):
    return math.sqrt(sum(h * h for h in b[2]))


def depth(a, b):
    """How deep two boxes overlap (0 when apart): the smallest projection overlap over the separating axes."""
    ca, ua, ha = a
    cb, ub, hb = b
    d = (cb[0] - ca[0], cb[1] - ca[1], cb[2] - ca[2])
    if _dot(d, d) > (_reach(a) + _reach(b)) ** 2:
        return 0.0
    axes = list(ua) + list(ub)
    for x in ua:
        for y in ub:
            c = _cross(x, y)
            n = math.sqrt(_dot(c, c))
            if n > 1e-6:  # parallel edges give no new axis
                axes.append((c[0] / n, c[1] / n, c[2] / n))
    best = math.inf
    for ax in axes:
        ra = sum(ha[i] * abs(_dot(ua[i], ax)) for i in range(3))
        rb = sum(hb[i] * abs(_dot(ub[i], ax)) for i in range(3))
        gap = ra + rb - abs(_dot(d, ax))
        if gap <= 0:
            return 0.0
        best = min(best, gap)
    return best


def _match(pattern, role, part):
    want_role, _, want = pattern.partition(".")
    return want_role == role and fnmatch.fnmatchcase(part, want)


def allowed(b, fps=FPS):
    """{frame: [(pattern a, pattern b), ...]} from every shot's "contacts" (frames from the scene start)."""
    out = {}
    for s in b.get("shots") or []:
        for c in (s.get("contacts") or []) if isinstance(s, dict) else []:
            t, pa, pb = c[0], c[1], c[2]
            n = int(c[3]) if len(c) > 3 else HOLD
            f0 = round((s["start"] + t) * fps)
            for f in range(f0, f0 + max(1, n)):
                out.setdefault(f, []).append((pa, pb))
    return out


def problems(b):
    """What is wrong with the shots' "contacts" lists (they must name two different cast roles)."""
    cast = set(b["cast"].keys()) if isinstance(b.get("cast"), dict) else set()
    out = []
    shots = b.get("shots") if isinstance(b.get("shots"), list) else []
    for i, s in enumerate(shots, 1):
        if not isinstance(s, dict):
            continue  # beats.validate names a shot that isn't an object
        found = s.get("contacts") or []
        if not isinstance(found, list):
            out.append(f"shot {i}: contacts must be a list of [seconds into the shot, \"role.Part\", \"role.Part\", frames]")
            continue
        for c in found:
            ok = (isinstance(c, list) and len(c) in (3, 4) and isinstance(c[0], (int, float))
                  and all(isinstance(p, str) and "." in p for p in c[1:3])
                  and (len(c) == 3 or (isinstance(c[3], int) and c[3] >= 1)))
            if not ok:
                out.append(f"shot {i}: contact {c!r} must be [seconds into the shot, \"role.Part\", \"role.Part\", frames]")
                continue
            roles = {c[1].split(".")[0], c[2].split(".")[0]}
            if not roles <= cast or len(roles) != 2:
                out.append(f"shot {i}: contact {c!r} must join two different roles of the cast")
            elif not -1e-3 <= c[0] <= s.get("length", 0) + 1e-3:
                out.append(f"shot {i}: contact at {c[0]} s is outside the shot")
    return out


def _excused(pairs, ra, pa, rb, pb):
    for x, y in pairs:
        if (_match(x, ra, pa) and _match(y, rb, pb)) or (_match(y, ra, pa) and _match(x, rb, pb)):
            return True
    return False


def _ranges(frames):
    out, start, prev = [], None, None
    for f in frames:
        if start is None:
            start = prev = f
        elif f == prev + 1:
            prev = f
        else:
            out.append(f"{start}-{prev}" if prev != start else f"{start}")
            start = prev = f
    if start is not None:
        out.append(f"{start}-{prev}" if prev != start else f"{start}")
    return ", ".join(out)


def scan(frames, excused=None, tol=TOL):
    """frames: one {role: {part: box}} per frame. excused: allowed() output. -> issue lines, one per part pair, with
    the deepest overlap and the frames (the export fails on any)."""
    excused = excused or {}
    bad = {}
    for f, cast in enumerate(frames):
        roles = sorted(cast)
        for i, ra in enumerate(roles):
            for rb in roles[i + 1:]:
                for pa, ba in cast[ra].items():
                    for pb, bb in cast[rb].items():
                        d = depth(ba, bb)
                        if d > tol and not _excused(excused.get(f, ()), ra, pa, rb, pb):
                            key = (f"{ra}.{pa}", f"{rb}.{pb}")
                            worst, fs = bad.get(key, (0.0, []))
                            fs.append(f)
                            bad[key] = (max(worst, d), fs)
    return [f"{a} goes {worst:.2f} studs into {b} on frames {_ranges(fs)} (plan it as a contact in beats.json, or "
            f"pull it out)" for (a, b), (worst, fs) in sorted(bad.items(), key=lambda kv: kv[1][1][0])]
