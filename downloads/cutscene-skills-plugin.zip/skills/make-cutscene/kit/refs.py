"""Reference -> draft beat sheet: a video (file or link) or manga/manhwa panels (spec 5.1). Words go through
beats.from_words. Anime clips can't be motion-captured: they are read for timing, key poses and the shot list.
Method by fwjelaa (FWJ STUDIOS).

    py kit/run.py ref video <id> <file|link> [--from s] [--to s]
    py kit/run.py ref panels <id> <image|folder> [...]

Writes into cutscenes/<id>/ref/: clip.mp4 (the trimmed reference), shot_NN.png (frames across each shot, labelled
with time and frame), contact.png (one frame per shot), timing.json and timing.md (length, holds, speed, held frames
per shot), and a draft beats.json (beats.draft.json when beats.json already exists, so edits are never lost).
"""
import shutil
import tempfile
from pathlib import Path

import beats
import media
import paths
import schema
import workspace

FRAMES_PER_SHOT = 6
CELL = (320, 180)
STILL, FAST = 0.002, 0.02  # mean per-frame scene score: under = still, over = fast
TWOS = 0.35  # a shot with this share of held frames is animated on twos (or threes)
MAX_SHOT = 4.0  # one long take is split into beats of about this length
IMAGE = (".png", ".jpg", ".jpeg", ".webp", ".bmp")


def is_link(src):
    return str(src).startswith(("http://", "https://"))


def _edges(cut_times, duration):
    """(the shot edges, the cuts joined away). A shot shorter than the shortest beat (beats.MIN_SHOT) joins the shot
    before it (the first joins the next): the draft would stretch it to MIN_SHOT and shift every later beat."""
    edges = [0.0] + [t for t in sorted(cut_times) if 0.05 < t < duration - 0.05] + [duration]
    joined, k = [], 1
    while k < len(edges) and len(edges) > 2:
        if edges[k] - edges[k - 1] < beats.MIN_SHOT - 1e-9:
            joined.append(edges.pop(k if k == 1 else k - 1))
            k = max(1, k - 1)
        else:
            k += 1
    return edges, sorted(joined)


def joined_cuts(cut_times, duration):
    """The cuts shot_spans leaves out because a shot between them would be shorter than beats.MIN_SHOT."""
    return _edges(cut_times, duration)[1]


def shot_spans(cut_times, duration, max_shot=MAX_SHOT):
    """(start, end) between cuts; a take longer than max_shot is split evenly into beats of about that length, a shot
    shorter than beats.MIN_SHOT joins its neighbour (_edges)."""
    edges, _ = _edges(cut_times, duration)
    spans = []
    for a, b in zip(edges, edges[1:]):
        n = max(1, round((b - a) / max_shot)) if b - a > max_shot else 1
        step = (b - a) / n
        spans += [(round(a + i * step, 3), round(a + (i + 1) * step, 3)) for i in range(n)]
    return spans


def sample_times(span, n, fps):
    """n times across a shot for its sheet, each on one of the shot's own frames. A seek past the clip's last frame
    writes no picture (FFmpeg exits 0), so no sample is later than half a frame before the shot's last frame: a last
    shot of a few frames (cut with --to) used to crash the sheet."""
    a, b = span
    last = max(a, b - 1.5 / (fps or 30))
    return [round(min(a + (b - a) * (k + 0.5) / n, last), 4) for k in range(n)]


def timing(span, scores, frz, fps):
    a, b = span
    inside = [s for t, s in scores if a + 1e-6 < t < b - 1e-6]
    motion = sum(inside) / len(inside) if inside else 0.0
    held = sum(1 for s in inside if s < media.DUP_SCORE) / len(inside) if inside else 0.0
    still = motion < STILL
    holds = [(round(max(a, s), 3), round(min(b, e), 3)) for s, e in frz
             if e > a and s < b and min(b, e) - max(a, s) >= 0.15]
    return {"start": a, "end": b, "length": round(b - a, 3), "frames": round((b - a) * fps),
            "speed": "still" if still else "fast" if motion > FAST else "medium",
            "motion": round(motion, 5), "held_share": round(held, 2), "on_twos": held >= TWOS and not still, "holds": holds}


def timing_table(report):
    rows = [f"# Reference timing: {report['source']} ({report['from']}-{report['to'] or 'end'} s, {report['fps']} fps, "
            f"{report['size'][0]}x{report['size'][1]})", "",
            "| shot | start | end | length | frames | speed | held | on twos | holds |", "|---|---|---|---|---|---|---|---|---|"]
    for s in report["shots"]:
        holds = ", ".join(f"{a:.2f}-{b:.2f}" for a, b in s["holds"]) or "-"
        rows.append(f"| {s['n']} | {s['start']:.2f} | {s['end']:.2f} | {s['length']:.2f} | {s['frames']} | {s['speed']} "
                    f"| {s['held_share']:.2f} | {'yes' if s['on_twos'] else 'no'} | {holds} |")
    return "\n".join(rows) + "\n"


def _length_note(seconds):
    if seconds > schema.MAX_LENGTH:
        return [f"the reference runs {seconds:.1f} s; a scene is at most {schema.MAX_LENGTH} s: run again with "
                "--from <s> --to <s> around the part to recreate"]
    return []


def from_video(cid, src, start=0.0, end=None, env=None, force=False):
    paths.check_id(cid)
    source = {"type": "video", "from": start, "to": end}
    if is_link(src):
        source["url"] = str(src)
        # fetched first, into a temp folder: a dead link must not leave a cutscene folder behind
        with tempfile.TemporaryDirectory() as tmp:
            downloaded = Path(media.fetch(str(src), tmp))
            root = workspace.create(cid, env=env)
            (root / "ref" / "download").mkdir(parents=True, exist_ok=True)
            src = Path(shutil.copyfile(downloaded, root / "ref" / "download" / downloaded.name))
    else:
        src = Path(src)
        if not src.exists():
            raise SystemExit(f"no such video: {src}")
        root = workspace.create(cid, env=env)
    ref = root / "ref"
    source["path"] = str(src)
    clip = media.trim(src, ref / "clip.mp4", start, end)
    info = media.probe(clip)
    fps = info["fps"] or 30
    cut_times = media.cuts(clip)
    spans, joined = shot_spans(cut_times, info["duration"]), joined_cuts(cut_times, info["duration"])
    scores, frz = media.frame_scores(clip), media.freezes(clip)
    shots, contact = [], []
    for i, span in enumerate(spans, 1):
        tm = timing(span, scores, frz, fps)
        cells = []
        for k, t in enumerate(sample_times(span, FRAMES_PER_SHOT, fps)):
            cells.append(media.cell(clip, ref / f"_cell_{i:02d}_{k}.png", f"shot {i}  {t:.2f}s  f{round(t * fps)}",
                                    CELL, t))
        media.sheet(cells, ref / f"shot_{i:02d}.png", cols=3)
        mid = round((span[0] + span[1]) / 2, 3)
        contact.append(media.cell(clip, ref / f"_mid_{i:02d}.png", f"shot {i}  {tm['length']:.2f}s  {tm['speed']}",
                                  CELL, sample_times(span, 1, fps)[0]))
        for c in cells:
            c.unlink(missing_ok=True)
        tm.update({"n": i, "sheet": f"ref/shot_{i:02d}.png", "mid": mid})
        shots.append(tm)
    media.sheet(contact, ref / "contact.png", cols=4)
    for c in contact:
        c.unlink(missing_ok=True)
    report = {"source": src.name, "from": start, "to": end, "fps": info["fps"], "size": [info["width"], info["height"]],
              "duration": info["duration"], "shots": shots}
    workspace.write_json(ref / "timing.json", report)
    (ref / "timing.md").write_text(timing_table(report), encoding="utf-8", newline="\n")
    twos = sum(1 for s in shots if s["on_twos"])
    draft = beats.draft(cid, source, [
        {"type": "ACTION", "length": s["length"],
         "ref": {"sheet": s["sheet"], "mid": s["mid"], "start": s["start"], "end": s["end"], "on_twos": s["on_twos"]}}
        for s in shots], look="anime" if twos * 2 >= len(shots) else "live")
    path = beats.save_draft(root, draft, force)
    lines = [f"{len(shots)} shots from {src.name} ({info['duration']:.2f} s, {info['fps']} fps); "
             f"{twos} animated on twos -> look {draft['look']}"] + _length_note(info["duration"])
    if joined:
        lines.append(f"{len(joined)} cut{'' if len(joined) == 1 else 's'} joined ("
                     f"{', '.join(f'{t:.2f} s' for t in joined)}): a shot there was shorter than a beat can be "
                     f"({beats.MIN_SHOT} s), so it is part of its neighbour")
    return lines, path


def panel_length(w, h):
    if w >= 1.6 * h:
        return 2.0  # a wide panel: an establishing beat
    if h >= 1.6 * w:
        return 1.0  # a tall manhwa strip: a quick action beat
    return 1.5


def from_panels(cid, sources, env=None, force=False):
    root = workspace.create(cid, env=env)
    ref = root / "ref"
    files = []
    for s in sources:
        p = Path(s)
        files += sorted(q for q in p.iterdir() if q.suffix.lower() in IMAGE) if p.is_dir() else [p]
    files = [f for f in files if f.exists()]
    if not files:
        raise SystemExit("no panel images found (png, jpg, webp, bmp)")
    shots, cells = [], []
    for i, f in enumerate(files, 1):
        info = media.probe(f)
        length = panel_length(info["width"], info["height"])
        dst = ref / f"panel_{i:02d}.png"
        media.ffmpeg("-i", f, "-frames:v", "1", "-vf", "scale='min(960,iw)':-2", dst)
        cells.append(media.cell(dst, ref / f"_cell_{i:02d}.png", f"panel {i}  ~{length:.1f}s", CELL))
        shots.append({"type": "ACTION", "length": length, "ref": {"panel": f"ref/panel_{i:02d}.png", "file": f.name}})
    media.sheet(cells, ref / "panels.png", cols=4)
    for c in cells:
        c.unlink(missing_ok=True)
    draft = beats.draft(cid, {"type": "panels", "files": [f.name for f in files]}, shots, look="anime")
    path = beats.save_draft(root, draft, force)
    return [f"{len(shots)} panels -> {beats.length(draft):.2f} s (estimated: wide 2.0 s, tall 1.0 s, else 1.5 s)"] + \
        _length_note(beats.length(draft)), path
