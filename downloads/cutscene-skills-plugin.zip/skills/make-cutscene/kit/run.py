"""make-cutscene kit. Method by fwjelaa (FWJ STUDIOS). Run every command from this skill's folder (PACK).

  Setup and the working folder
    py kit/run.py check                          is this PC ready? lists exact fixes, exit 1 if something must change
    py kit/run.py new <id> [--kind story]        make cutscenes/<id>/ in the working folder
  Reference -> beat sheet
    py kit/run.py ref video <id> <file|link> [--from s] [--to s] [--force]
    py kit/run.py ref panels <id> <image|folder> [...] [--force]
    py kit/run.py ref words <id> "<what happens>" --line "Name: text" [--line ...] [--speaker npc1]
                                                 [--trigger zone|prompt|api] [--dialogue anime] [--model default] [--force]
    py kit/run.py beats <id> [--retime] [--go]   check and show the beat sheet; --go marks it approved
    py kit/run.py script <id> <file.md> [--kind awakening] [--fit seconds] [--speaker player] [--trigger api]
                                                 [--dialogue anime] [--force]   a numbered shot script in words -> draft beat sheet
  Studio: each step writes cutscenes/<id>/studio/<step>.luau to send with execute_luau (Edit)
    py kit/run.py studio <id> <step> [options]   anchor [--from camera|selection | --at x,y,z,yaw], map, chunk --n N,
                                                 rig --role R, install [--clips] [--rig R15|R6|both] [--trigger T],
                                                 remove, playtest-on, playtest-off, record-on, record-off,
                                                 costume-look [--at x,y,z,yaw], costume-look-off
    py kit/run.py map <id>                       check and merge studio/map_<n>.txt into map.json
    py kit/run.py rig <id> <role>                check studio/rig_<role>.txt and save rigs/<role>.json
    py kit/run.py costume <id> [--new <role> --kind humanoid|creature --character "Name" --source "credit line"]
                                                 adapted characters (spec 14): check cast/*.json, write creature rigs
    py kit/run.py costume search "keyword" [--type shirt|pants|hair|hat|...]  search the public avatar catalog (read-only): id, type, price, name
  Export, upload, checks
    py kit/run.py scene <id>                     data module export/<id>.luau from export/scene.json
    py kit/run.py testscene [--hide PATH] [--costume]  the Fixture_Scene working folder (Studio tests without
                                                 Blender); --costume dresses the player and the guard (spec 14)
    py kit/run.py upload <id>                    upload changed clips with your Open Cloud key, rewrite the data module
    py kit/run.py gates <id>                     kit checks (spec 8 gate 1)
    py kit/run.py expect <id> <seconds>          where the camera must be at that time (play-test probe)
  Preview and review
    py kit/run.py record <id> [--seconds N]      screen-record Studio (borrows the screen)
    py kit/run.py preview <id>                   raw recording -> preview MP4, frames, contact sheet
    py kit/run.py sidebyside <id> [--rig R15|R6] reference vs ours at matching beats
    py kit/run.py record|preview <id> --rig R6   the R6 cast's take and preview (spec 14: every scene is shown twice)
    py kit/run.py likeness <id>                  adapted characters: the reference beside our R15 and R6 cast
    py kit/run.py playtest <id> --set KEY=pass|fail [--set ...]
    py kit/run.py review <id> --round N          blind-review packet
    py kit/run.py score <id> --round N <reply files...>
  Kit development
    py kit/run.py test | fixture | bundle [--budget N] | upload Fixture_Walkin
    py kit/run.py luau                           parse-check every roblox/**/*.luau with the real Luau (no Studio)
    py kit/run.py delta <Module>... [--tests A,B]  out/delta.luau: rebuild the kit with only these modules/tests changed
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import paths  # noqa: E402


def take(args, name, cast=str, default=None):
    """Pop `--name value` out of args."""
    if name in args:
        i = args.index(name)
        if i + 1 >= len(args):
            raise SystemExit(f"{name} needs a value")
        value = cast(args[i + 1])
        del args[i:i + 2]
        return value
    return default


def take_all(args, name):
    out = []
    while name in args:
        out.append(take(args, name))
    return out


def flag(args, name):
    if name in args:
        args.remove(name)
        return True
    return False


def need(args, n, usage):
    if len(args) < n:
        raise SystemExit("usage: py kit/run.py " + usage)
    return args


def cmd_test(args):
    suite = unittest.defaultTestLoader.discover(str(paths.KIT / "tests"), top_level_dir=str(paths.KIT))
    return 0 if unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful() else 1


def cmd_fixture(args):
    import fixture
    print(f"wrote {fixture.build()}")
    return 0


def cmd_bundle(args):
    budget = take(args, "--budget", int)  # a smaller payload budget forces parts (to test them in Studio)
    import bundle
    for path in bundle.write_all(budget=budget):
        print(f"wrote {path}")
    return 0


def cmd_upload(args):
    need(args, 1, "upload <id>")
    import cloud
    import fixture
    if args[0] == fixture.NAME:
        _, lines = cloud.upload_fixture(args[0])
    else:
        _, lines = cloud.upload_scene(args[0])
    print("\n".join(lines))
    return 0 if not any("FAILED" in x for x in lines) else 1


def cmd_check(args):
    import setup_check
    ok, lines = setup_check.run()
    print("\n".join(lines))
    return 0 if ok else 1


def cmd_new(args):
    need(args, 1, "new <id> [--kind story]")
    kind = take(args, "--kind", default="story")
    import workspace
    print(f"cutscene folder: {workspace.create(args[0], kind=kind)}")
    return 0


def cmd_beats(args):
    need(args, 1, "beats <id> [--retime] [--go]")
    redo, go = flag(args, "--retime"), flag(args, "--go")
    import beats
    import workspace
    root = workspace.open_(args[0])
    b = beats.load(root)
    if redo:
        beats.retime_sheet(b)
        beats.save(b, root)
    print(beats.table(b))
    questions, problems = beats.asks(b), beats.validate(b)
    if questions:
        print("\nAsk the viewer:\n" + "\n".join(f"  - {q}" for q in questions))
    if problems:
        print("\nNot ready:\n" + "\n".join(f"  - {p}" for p in problems))
    if go:
        if problems:
            print("\nNOT APPROVED: fix the problems above first")
            return 1
        b["approved"] = True
        beats.save(b, root)
        print("\nAPPROVED: the viewer said go")
    return 0 if not problems else 1


def cmd_ref(args):
    need(args, 3, "ref video|panels|words <id> ...")
    kind, cid = args[0], args[1]
    force = flag(args, "--force")
    start = end = None
    raw, speaker, trigger, dialogue, model = [], "npc1", None, None, None
    if kind == "video":
        start, end = take(args, "--from", float, 0.0), take(args, "--to", float)
    elif kind == "words":
        raw = take_all(args, "--line")
        speaker = take(args, "--speaker", default="npc1")
        trigger, dialogue, model = take(args, "--trigger"), take(args, "--dialogue"), take(args, "--model")
    need(args, 3, "ref video <id> <file|link> [--from s] [--to s] | ref panels <id> <image|folder> ... | "
                  'ref words <id> "<what happens>" --line "Name: text"')
    import beats
    import media
    import refs
    import workspace
    try:
        if kind == "video":
            lines, path = refs.from_video(cid, args[2], start, end, force=force)
        elif kind == "panels":
            lines, path = refs.from_panels(cid, args[2:], force=force)
        elif kind == "words":
            said = [tuple(x.strip() for x in r.split(":", 1)) if ":" in r else ("", r.strip()) for r in raw]
            b = beats.from_words(cid, args[2], said, speaker=speaker)
            if trigger:
                b["trigger"] = {"type": trigger, "size": list(beats.ZONE)} if trigger == "zone" else {"type": trigger}
            if dialogue:
                b["dialogue"] = dialogue
            if model:
                b["cast"][speaker]["model"] = model
            path = beats.save_draft(workspace.create(cid, kind=b["kind"]), b, force)
            lines = [f"{len(b['shots'])} shots from the words ({beats.length(b):.2f} s)"]
        else:
            raise SystemExit("ref kind must be video, panels or words")
    except media.MediaError as e:
        print(f"REFERENCE FAILED: {e}")
        return 1
    print("\n".join(lines))
    print(f"wrote {path}")
    if Path(path).name == "beats.json":
        print(f"next: read the sheets in ref/, edit the beat sheet, then  py kit/run.py beats {cid}")
    else:
        print(f"{Path(path).name} was written because beats.json already exists (yours is untouched). Review "
              f"{Path(path).name}, then copy it over beats.json (or run this again with --force), then  "
              f"py kit/run.py beats {cid}")
    return 0


def cmd_studio(args):
    need(args, 2, "studio <id> <step> [--from camera|selection|keep] [--at x,y,z,yaw] [--n N] [--role R] [--clips] "
                  "[--rig R15|R6|both] [--trigger zone|prompt|api] [--radius studs] [--key G]")
    opts = {"from": take(args, "--from"), "at": take(args, "--at"), "n": take(args, "--n", int, 0),
            "role": take(args, "--role"), "rig": take(args, "--rig"), "trigger": take(args, "--trigger"),
            "radius": take(args, "--radius", float), "clips": flag(args, "--clips"), "key": take(args, "--key")}
    import studio
    print("\n".join(studio.run_step(args[0], args[1], opts)))
    return 0


def cmd_map(args):
    need(args, 1, "map <id>")
    import mapcap
    import workspace
    root = workspace.open_(args[0])
    try:
        path, summary = mapcap.merge_folder(root)
    except mapcap.ChunkError as e:
        print(f"MAP NOT MERGED: {e}")
        return 1
    print(f"{summary}\nwrote {path}")
    print(f'clean up in Studio (Edit): game:GetService("ServerStorage"):FindFirstChild("CutsceneCapture_{args[0]}"):Destroy()')
    return 0


def cmd_rig(args):
    need(args, 2, "rig <id> <role>")
    import rigcap
    import workspace
    root = workspace.open_(args[0])
    src = root / "studio" / f"rig_{args[1]}.txt"
    if not src.exists():
        raise SystemExit(f"save the string the rig step returned to {src} first")
    path, summary = rigcap.save(root, args[1], src.read_text(encoding="utf-8"))
    print(f"{summary}\nwrote {path}")
    return 0


def cmd_record(args):
    need(args, 1, "record <id> [--seconds N] [--place NAME] [--rig R15|R6]")
    seconds = take(args, "--seconds", float, 25.0)
    rig = take(args, "--rig", str, "R15")
    if rig not in ("R15", "R6"):
        raise SystemExit(f"--rig takes R15 or R6, not {rig}")
    import record
    import workspace
    place = take(args, "--place", str, record.PLACE_NAME)
    out = record.record(seconds, workspace.open_(args[0]) / "preview" / ("raw_R6.mp4" if rig == "R6" else "raw.mp4"),
                        find=lambda: record.find_studio(place))
    print(f"recorded {out}\nnext:  py kit/run.py preview {args[0]}" + (" --rig R6" if rig == "R6" else ""))
    return 0


def cmd_preview(args):
    need(args, 1, "preview <id> [--rig R15|R6]")
    rig = take(args, "--rig", str, "R15")
    import review
    import takes
    import workspace
    root = workspace.open_(args[0])
    print("\n".join(takes.make(root, rig=rig)))
    review.stamp_preview(root, rig)  # which export this preview shows, so the blind score can refuse an older one
    return 0


def cmd_scene(args):
    need(args, 1, "scene <id>")
    import scenefile
    import workspace
    root = workspace.open_(args[0])
    path = scenefile.write(root)
    ids = scenefile.current_ids(root)
    names = scenefile.clip_names(workspace.read_json(root / "export" / "scene.json"))
    print(f"wrote {path}\n{sum(1 for n in names if n in ids)} of {len(names)} clips by asset id"
          + ("" if all(n in ids for n in names) else " (the rest are Studio-only until  py kit/run.py upload " + args[0] + ")"))
    return 0


def cmd_testscene(args):
    hide = take(args, "--hide")
    dressed = flag(args, "--costume")  # spec 14: the player and the guard in costume
    import fixture
    print(f"wrote {fixture.write_scene(hide=hide, costume=dressed)}")
    return 0


def cmd_gates(args):
    need(args, 1, "gates <id>")
    import gates
    import workspace
    issues, lines = gates.run(workspace.open_(args[0]))
    print("\n".join(lines))
    return 0 if not issues else 1


def cmd_expect(args):
    need(args, 2, "expect <id> <seconds>")
    import gates
    import workspace
    print(gates.expect(workspace.open_(args[0]), float(args[1])))
    return 0


def cmd_playtest(args):
    need(args, 1, "playtest <id> --set KEY=pass|fail [--set ...]")
    items = take_all(args, "--set")
    import review
    import workspace
    print("\n".join(review.set_playtest(workspace.open_(args[0]), items)))
    return 0


def cmd_review(args):
    n = take(args, "--round", int, 1)
    need(args, 1, "review <id> --round N")
    import review
    import workspace
    outs = review.packet(workspace.open_(args[0]), n)
    results = outs[0].parent.parent / "cutscenes" / args[0] / "review" / "results" / f"round{n}"
    print("\n".join(f"packet {i}: {o}" for i, o in enumerate(outs, 1)))
    print("Give each of 3 fresh reviewer agents exactly one packet and only this: \"Read <packet>/README.md and "
          "follow it exactly; the files it names are in <packet>.\" Never give a reviewer any other path.")
    print(f"Save each reply to {results}/reply_<n>.txt (outside the packets), then  py kit/run.py score {args[0]} "
          f"--round {n} <reply1> <reply2> <reply3>")
    return 0


def cmd_score(args):
    n = take(args, "--round", int, 1)
    force = flag(args, "--force")
    need(args, 4, "score <id> --round N <reply1> <reply2> <reply3> [--force]")
    import review
    import workspace
    replies = [Path(p).read_text(encoding="utf-8") for p in args[1:]]
    result, lines = review.record(workspace.open_(args[0]), n, replies, force=force)
    print("\n".join(lines))
    return 0 if result["passed"] else 1


def cmd_sidebyside(args):
    rig, preview = take(args, "--rig"), take(args, "--preview")
    need(args, 1, "sidebyside <id> [--rig R15|R6] [--preview path]")
    import sheets
    import workspace
    for p in sheets.side_by_side(workspace.open_(args[0]), rig=rig, preview=preview):
        print(f"wrote {p}")
    return 0


COMMANDS = {
    "playtest": cmd_playtest, "review": cmd_review, "score": cmd_score,
    "gates": cmd_gates, "expect": cmd_expect,
    "test": cmd_test, "fixture": cmd_fixture, "bundle": cmd_bundle, "upload": cmd_upload,
    "check": cmd_check, "new": cmd_new, "beats": cmd_beats, "ref": cmd_ref,
    "studio": cmd_studio, "map": cmd_map, "rig": cmd_rig, "record": cmd_record, "preview": cmd_preview,
    "scene": cmd_scene, "testscene": cmd_testscene, "sidebyside": cmd_sidebyside,
}


def cmd_costume(args):
    if args and args[0] == "search":
        import costume
        words = args[1:]
        usage = ('costume search "keyword" [--type shirt|pants|tshirt|hair|hat|face|...] [--limit '
                 + "|".join(str(n) for n in costume.SEARCH_LIMITS) + "]")
        try:
            limit = take(words, "--limit", cast=int, default=10)
            kind = take(words, "--type")
        except ValueError:
            raise SystemExit("usage: py kit/run.py " + usage)
        need(words, 1, usage)
        costume.emit("\n".join(costume.search_lines(costume.search(words[0], limit=limit, type=kind))))
        return 0
    role = take(args, "--new")
    kind = take(args, "--kind", default="humanoid")
    character, source = take(args, "--character"), take(args, "--source")
    need(args, 1, 'costume <id> [--new <role> --kind humanoid|creature --character "Name" --source "credit line"]'
                  ' | costume search "keyword"')
    import beats
    import costume
    import workspace
    root = workspace.open_(args[0])
    if role:
        if not character or not source:
            raise SystemExit('--new needs --character "Name" and --source "credit line" (spec 14: credit the reference)')
        print(f"wrote {costume.new(root, beats.load(root), role, kind, character, source)}: dress it (colours, catalog "
              "items, built parts for creatures only), then run this again")
    problems, lines = costume.run(root, beats.load(root))
    print("\n".join(lines))
    return 0 if not problems else 1


COMMANDS.update({"costume": cmd_costume})


def cmd_luau(args):
    import luaurun
    if not luaurun.find():
        print("luau is not installed: rokit add luau-lang/luau (or put luau on PATH). Studio stays the real test.")
        return 1
    bad = luaurun.parse_all()
    print("\n".join(f"FIX  {path}: {err}" for path, err in bad) or "every .luau file parses")
    return 0 if not bad else 1


def cmd_delta(args):
    tests = [t for t in (take(args, "--tests") or "").split(",") if t]
    if not args and not tests:
        raise SystemExit("usage: py kit/run.py delta <Module> [<Module> ...] [--tests Name,Name]")
    import bundle
    for path in bundle.write_delta(args, tests):
        print(f"wrote {path}")
    print("send it (and its parts, in order) with execute_luau (Edit); the canonical bundles still go at the milestones")
    return 0


COMMANDS.update({"luau": cmd_luau, "delta": cmd_delta})


def cmd_likeness(args):
    need(args, 1, "likeness <id>")
    import sheets
    import workspace
    print(f"wrote {sheets.likeness(workspace.open_(args[0]))}")
    return 0


COMMANDS.update({"likeness": cmd_likeness})


def cmd_vfx(args):
    import vfxlib
    problems, lines = vfxlib.report()
    print("\n".join(lines))
    return 0 if not problems else 1


COMMANDS.update({"vfx": cmd_vfx})


def cmd_script(args):
    need(args, 2, "script <id> <file.md> [--kind awakening] [--fit seconds] [--speaker player] [--trigger api] "
                  "[--dialogue anime] [--force]")
    kind, fit = take(args, "--kind", default="story"), take(args, "--fit", float)
    speaker, trigger = take(args, "--speaker", default="player"), take(args, "--trigger")
    dialogue, force = take(args, "--dialogue"), flag(args, "--force")
    import beats
    import shotscript
    import workspace
    root = workspace.open_(args[0]) if paths.cutscene_dir(args[0]).exists() else workspace.create(args[0], kind=kind)
    b = shotscript.draft(args[0], args[1], kind=kind, speaker=speaker, fit_to=fit, trigger=trigger, dialogue=dialogue)
    path = beats.save_draft(root, b, force=force)
    print(beats.table(b))
    print(f"{chr(10)}wrote {path}")
    return 0


COMMANDS.update({"script": cmd_script})


def main(argv):
    if len(argv) < 2 or argv[1] not in COMMANDS:
        print(__doc__)
        return 2
    return COMMANDS[argv[1]](list(argv[2:])) or 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
