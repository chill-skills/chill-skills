"""`py kit/run.py check`: is this PC ready to make cutscenes? Lists exact fixes, then stops (spec 10).
Method by fwjelaa (FWJ STUDIOS)."""
import os
import shutil
import sys
import tempfile

import paths

FIX = {
    "ffmpeg": "install FFmpeg (winget install Gyan.FFmpeg), then open a new terminal",
    "ffprobe": "install FFmpeg (winget install Gyan.FFmpeg), then open a new terminal",
    "yt-dlp": "install yt-dlp (winget install yt-dlp.yt-dlp) for links; a video file works without it",
}
MCP = [
    "Blender MCP: call get_addon_status. It must say \"up_to_date\": true. If not, tell the viewer: run  uvx "
    "mcp-for-blender install-addon , then in Blender Preferences > Add-ons turn 'Interface: Blender MCP' off and on, "
    "and press Start MCP Server (protocol mismatch, seen 2026-10-21).",
    "Roblox Studio MCP: call list_roblox_studios. It must list the viewer's place (Studio open, the MCP switched on in "
    "Studio's Assistant settings). Only work in the place the viewer named.",
]


def run(which=shutil.which, version=None, env=None, key_files=None, pack=paths.PACK, make_anim=paths.MAKE_ANIM):
    version = tuple(version or sys.version_info)[:2]
    env = os.environ if env is None else env
    lines, fixes = [], []

    def ok(msg):
        lines.append("OK   " + msg)

    def fix(msg):
        fixes.append(msg)
        lines.append("FIX  " + msg)

    def warn(msg):
        lines.append("WARN " + msg)

    if version >= (3, 11):
        ok(f"Python {version[0]}.{version[1]}")
    else:
        fix(f"Python {version[0]}.{version[1]} is too old: install Python 3.11 or newer from python.org, run it with py")
    for exe in ("ffmpeg", "ffprobe", "yt-dlp"):
        found = which(exe)
        if found:
            ok(f"{exe}: {found}")
        elif exe == "yt-dlp":
            warn(f"yt-dlp not found: {FIX[exe]}")
        else:
            fix(f"{exe} not found: {FIX[exe]}")
    if (make_anim / "kit" / "animkit.py").exists():
        ok(f"make-anim kit: {make_anim / 'kit'}")
    else:
        fix(f"make-anim not found at {make_anim}: reinstall the fwjelaa plugin (make-cutscene uses make-anim's kit)")
    files = paths.key_files(pack) if key_files is None else key_files
    # only whether load_key finds a non-empty key is used; the value is dropped at once and never shown
    try:
        found_key = bool(paths.load_key(env, files))
    except (SystemExit, OSError, ValueError):
        found_key = False
    if found_key:
        ok("Open Cloud key found (value not shown)")
    else:
        warn("no Open Cloud key. " + paths.KEY_HELP + " Without it, cutscenes preview in Studio only and won't play in "
             "a published game until they are uploaded.")
    try:
        ok(f"uploads will be owned by {paths.load_creator(pack)}")
    except SystemExit as e:
        warn(f"{e} (needed for uploads)")
    try:
        work = paths.work_dir(env, pack)
        probe = work
        while not probe.exists() and probe.parent != probe:
            probe = probe.parent
        # a diagnostic must not change the PC: a missing folder is probed at its nearest existing parent
        with tempfile.TemporaryFile(dir=probe):
            pass
        ok(f"working folder: {work}" + ("" if work.exists() else " (will be created)"))
    except (OSError, SystemExit) as e:
        fix(f"the working folder can't be written ({e}): set \"work_dir\" in config.json or MAKE_CUTSCENE_WORK")
    lines += ["", "Then, in Claude:"] + [f"  - {m}" for m in MCP]
    if fixes:
        lines += ["", f"{len(fixes)} thing(s) to fix before making a cutscene. Fix them, then run this again."]
    return not fixes, lines
