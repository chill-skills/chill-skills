"""Uploads clips to Roblox with the viewer's Open Cloud key and rewrites the data module with the asset ids (spec 3:
an animation only plays in a game owned by the same user or group). Method by fwjelaa (FWJ STUDIOS).

    py kit/run.py upload <id>                a cutscene: every clip in export/manifest.json
    py kit/run.py upload Fixture_Walkin      Plan 1's test cutscene

Uses make-anim's kit/upload.py (Assets API; animations accepted since 2025-10-23). The key comes from paths.load_key()
and is only ever sent as the x-api-key header; nothing here prints it, and every failure line is redacted.
ids.json keeps each clip's asset id with the SHA-256 of the .rbxmx it came from, so a later run uploads only clips that
changed (uploaded assets can't be replaced, spec 3); it is written atomically. A 429 or 5xx is retried with backoff
(2, 4, 8 s); a poll that fails that way can leave one unused duplicate asset behind, which is harmless.
"""
import hashlib
import importlib.util
import json
import os
import time
from pathlib import Path

import fixture
import paths

RETRIES = 4
BACKOFF = 2.0


def make_anim_uploader():
    spec = importlib.util.spec_from_file_location("make_anim_upload", paths.MAKE_ANIM / "kit" / "upload.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.upload


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_ids(path):
    path = Path(path)
    if not path.exists():
        return {}
    raw = json.loads(path.read_text(encoding="utf-8"))
    return {k: (v if isinstance(v, dict) else {"id": str(v), "sha": None}) for k, v in raw.items()}


def save_ids(path, ids):
    path = Path(path)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(ids, indent=1, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    os.replace(tmp, path)


def _redact(text, key):
    return text.replace(key, "[redacted]") if key else text


def _transient(status):
    return isinstance(status, int) and not isinstance(status, bool) and (status == 429 or status >= 500)


def upload_clips(folder, names, ids_path, uploader, key, creator, sleep=time.sleep, prefix=""):
    ids = load_ids(ids_path)
    lines = []
    for name in names:
        path = Path(folder) / f"{name}.rbxmx"
        digest = sha(path)
        have = ids.get(name)
        if have and (have["sha"] is None or have["sha"] == digest):
            lines.append(f"{name}: already uploaded ({have['id']})")
            continue
        result, failure, status, network = {}, None, None, False
        for attempt in range(RETRIES):
            failure = None
            try:
                result = uploader(path, f"{prefix}{name}"[:50], f"{name} (make-cutscene by fwjelaa)", creator, key)
            except Exception as err:  # class name only: the message could carry the key or a path
                failure = type(err).__name__
                network = isinstance(err, OSError)
                if network:  # URLError, timeouts and dropped connections are worth another try
                    if attempt + 1 < RETRIES:
                        sleep(BACKOFF * 2 ** attempt)
                        continue
                break
            if not isinstance(result, dict):
                failure = "bad uploader result"
                break
            status = result.get("status", 0)
            if "assetId" in result or not _transient(status):
                break
            if attempt + 1 < RETRIES:
                sleep(BACKOFF * 2 ** attempt)
        kept = f"(the file is kept: {path.name})"
        if failure:
            tries = f" after {RETRIES} tries" if network else ""
            line = f"{name}: FAILED {failure}{tries} {kept}"
        elif "assetId" in result:
            ids[name] = {"id": str(result["assetId"]), "sha": digest}
            save_ids(ids_path, ids)
            line = f"{name}: ok {ids[name]['id']}"
        else:
            tries = f" after {RETRIES} tries" if _transient(status) else ""
            error = result.get("error")
            error = error if isinstance(error, str) else json.dumps(error, default=str)
            line = f"{name}: FAILED {status}{tries} {error} {kept}"
        lines.append(_redact(line, key))
    return {k: v["id"] for k, v in ids.items()}, lines


def upload_fixture(name, uploader=None, key=None, creator=None, sleep=time.sleep):
    if name != fixture.NAME:
        raise SystemExit(f"only {fixture.NAME} can be uploaded this way; a cutscene is uploaded by its id")
    folder = paths.FIXTURES / name
    manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    uploader = uploader or make_anim_uploader()
    key = key or paths.load_key()
    creator = creator or paths.load_creator()
    ids, lines = upload_clips(folder, manifest["clips"], folder / "ids.json", uploader, key, creator, sleep)
    fixture.build(folder, ids)
    return ids, lines


def upload_scene(cid, uploader=None, key=None, creator=None, sleep=time.sleep, env=None, prefix=None):
    import scenefile
    import workspace
    root = workspace.open_(cid, env)
    out = root / "export"
    manifest = workspace.read_json(out / "manifest.json")
    uploader = uploader or make_anim_uploader()
    key = key or paths.load_key()
    creator = creator or paths.load_creator()
    prefix = str(paths.config().get("name_prefix") or "") if prefix is None else prefix
    ids, lines = upload_clips(out, manifest["clips"], out / "ids.json", uploader, key, creator, sleep, prefix)
    failed = [x.split(":", 1)[0] for x in lines if ": FAILED" in x]
    if failed:
        lines.append(f"data module NOT rewritten: {len(failed)} clip(s) did not upload ({', '.join(failed)}); "
                     f"run  py kit/run.py upload {cid}  again")
        return ids, lines
    try:
        lines.append(f"data module rewritten: {scenefile.write(root)}")
    except SystemExit as err:  # a stale export: the clip lines above must still reach the viewer
        lines.append(f"data module: FAILED {err}")
    return ids, lines
