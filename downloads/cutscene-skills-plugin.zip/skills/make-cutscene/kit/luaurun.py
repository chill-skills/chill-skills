"""Luau outside Studio, for checks that need no engine: parse every roblox/**/*.luau file, and run the data-module
contract (CutsceneKit.Data.validate) on the same examples as kit/schema.py. Uses luau.exe from rokit's tool storage
or PATH; the tests that need it skip when it is missing (Studio stays the real test). Method by fwjelaa (FWJ STUDIOS).

    py kit/run.py luau        parse-check every .luau file under roblox/
"""
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import clip
import paths
from payload import long_string

SEP = "\x1f"  # between the problem lists Data.validate prints


def find():
    """The luau binary, or None. rokit's shim refuses to run outside a project, so its tool storage comes first."""
    store = Path.home() / ".rokit" / "tool-storage" / "luau-lang" / "luau"
    if store.exists():
        found = sorted(list(store.glob("*/luau.exe")) + list(store.glob("*/luau")), key=_version_key)
        if found:
            return found[-1]
    # an explicit PATH search: shutil.which(cmd) alone would try the current directory first on Windows
    exe = shutil.which("luau", path=os.environ.get("PATH", ""))
    return Path(exe) if exe else None


def _version_key(path):
    """0.99.0 sorts before 0.733.0: compare the version folder's numbers, not its text."""
    return tuple(int(x) if x.isdigit() else 0 for x in re.split(r"[.\-]", path.parent.name))


def run(code, exe=None, timeout=120):
    exe = exe or find()
    if not exe:
        raise SystemExit("luau is not installed (rokit add luau-lang/luau, or put luau on PATH)")
    with tempfile.TemporaryDirectory() as d:
        script = Path(d) / "check.luau"
        script.write_text(code, encoding="utf-8", newline="\n")
        try:
            done = subprocess.run([str(exe), str(script)], capture_output=True, text=True, encoding="utf-8",
                                  timeout=timeout)
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"luau did not finish within {timeout} s") from None
    if done.returncode != 0:
        raise RuntimeError(f"luau failed: {done.stderr.strip() or done.stdout.strip()}")
    return done.stdout


def parse_texts(texts, exe=None):
    """[(name, error)] for every {name: Luau source} that doesn't compile."""
    lines = ["local bad = {}"]
    for name, src in texts.items():
        # the message names the chunk (file) and line; a multi-line message is folded onto one output line
        lines.append(f"do local fn, err = loadstring({long_string(src)}, {clip.luau_value(name)})"
                     f" if not fn then table.insert(bad, {clip.luau_value(name)} .. '\\t' .. "
                     "(tostring(err):gsub('\\n', ' | '))) end end")
    lines.append("print(#bad) for _, b in ipairs(bad) do print(b) end")
    out = run("\n".join(lines), exe).splitlines()
    return [tuple(line.split("\t", 1)) for line in out[1:int(out[0]) + 1]]


def parse_all(root=None, exe=None):
    """[(path, error)] for every .luau file under root (default roblox/) that doesn't compile."""
    root = Path(root or paths.ROBLOX)
    return parse_texts({f.relative_to(root).as_posix(): f.read_bytes().decode("utf-8").replace("\r\n", "\n")
                        for f in sorted(root.rglob("*.luau"))}, exe)


def data_problems(examples, exe=None):
    """Runs roblox/CutsceneKit/Data.luau's validate on each example dict; returns its problem lists."""
    import vfxlib  # Plan 3's VFX library; Plan 2b never calls this
    data_src = (paths.ROBLOX / "CutsceneKit" / "Data.luau").read_text(encoding="utf-8")
    lib = vfxlib.load()
    presets = {"Textures": lib["textures"], "Elements": lib["elements"], "Presets": lib["presets"], "Auras": lib["auras"],
               "Manga": vfxlib.manga()}
    code = [
        "local VfxPresets = " + clip.luau_value(presets),
        "local script = { Parent = { VfxPresets = VfxPresets } }",
        "local function require(m) return m end",
        "local Data = (function() " + data_src + " end)()",
        "local out = {}",
    ]
    for ex in examples:
        code.append("do local ok, problems = Data.validate(" + clip.luau_value(ex) + ") "
                    "table.insert(out, table.concat(problems, '\\n')) end")
    code.append(f"print(table.concat(out, '{SEP}'))")
    text = run("\n".join(code), exe)
    return [[p for p in chunk.split("\n") if p] for chunk in text.rstrip("\n").split(SEP)]
