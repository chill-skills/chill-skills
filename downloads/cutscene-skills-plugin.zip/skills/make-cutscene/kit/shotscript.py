"""Shot scripts written in words (like refs/words/*.md) -> a draft beat sheet (spec 5.1, words). Method by fwjelaa
(FWJ STUDIOS).

    py kit/run.py script <id> <file.md> [--kind awakening] [--fit 10] [--speaker player] [--trigger api]
                                        [--dialogue anime] [--force]

One numbered item per shot:
    6. MEDIUM / 35mm, quick push-in, 1.2s. Hero stands; aura column erupts upward. VFX: light pillar, camera shake.
The framing words pick the shot type, the lens the starting field of view (camtrack.vfov), the seconds the length,
VFX words suggest markers (VFX_WORDS, SCREEN_WORDS), and a quoted line ( HERO (whisper): "Now I remember." ) becomes
a Line. --fit retimes every beat to a total length, keeping all of them in order (spec 6: an awakening is kept to
about 4-10 s). The draft is a start: Claude places the markers on the right frames and edits the cues, then the viewer
says go.
"""
import re
from pathlib import Path

import beats
import camtrack

ITEM = re.compile(r"^\s*(\d+)\.\s+(.+?)\s*$")
SECS = re.compile(r"(\d+(?:\.\d+)?)\s*s\.(?:\s|$)")
LENS = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*mm\b(.*)$", re.I)
SAID = re.compile(r"([A-Z][A-Za-z ]*?)\s*(?:\(([^)]*)\))?:\s*\"([^\"]+)\"")
WORD_START = r"\b"  # a VFX word must start a word: "ember" finds embers, not remember
TYPES = (("SHOCKWAVE", "IMPACT"), ("IMPACT", "IMPACT"), ("HERO", "HERO"), ("EXTREME CLOSE", "INSERT"),
         ("CLOSE", "INSERT"), ("OVER", "OTS"), ("LOW ANGLE", "ACTION"), ("MEDIUM", "ACTION"), ("WIDE", "ESTABLISH"))
VFX_WORDS = (("light pillar", "Pillar"), ("column", "Pillar"), ("pillar", "Pillar"), ("shockwave", "Shockwave"),
             ("dust ring", "Dust"), ("dust cloud", "Dust"), ("debris lift", "Lift"), ("chunks float", "Lift"),
             ("crater", "Crater"), ("crack", "Cracks"),
             ("ember", "Embers"), ("wisp", "Wisps"), ("spark", "Spark"), ("lightning", "Lightning"), ("wind", "Wind"),
             ("charge", "Charge"), ("burst", "Burst"), ("ignite", "EyeFlare"))
SCREEN_WORDS = (("flash", "Flash"), ("shake", "Shake"), ("impact frame", "Impact"))
SLOW = ("SLOW-MOTION", "SLOW MOTION")
MIN_SHOT = 0.35  # s: the shortest beat a fitted script keeps (a shot shorter than this doesn't read)
RETURN = beats.RETURN  # s: the RETURN beat


def vfov(lens):
    return round(camtrack.vfov(lens), 1)


def _type(frame, first):
    up = frame.upper()
    for word, kind in TYPES:
        if word in up:
            return "ESTABLISH" if kind == "ESTABLISH" and first else ("ACTION" if kind == "ESTABLISH" else kind)
    return "ACTION"


def _suggest(text):
    low = text.lower()
    vfx, seen = [], set()
    for word, preset in VFX_WORDS:
        if re.search(WORD_START + re.escape(word), low) and preset not in seen:
            seen.add(preset)
            vfx.append(preset)
    screen = [name for word, name in SCREEN_WORDS if re.search(WORD_START + re.escape(word), low)]
    if "flash frame" in low and "Impact" not in screen:
        screen.append("Impact")
    return vfx, screen


def parse(text):
    """[{n, frame, type, lens, fov, move, length, action, vfx, screen, slow, line}] from a numbered shot script."""
    shots = []
    for raw in text.splitlines():
        m = ITEM.match(raw)
        if not m or "/" not in m.group(2):
            continue
        n, body = int(m.group(1)), m.group(2)
        frame, after = body.split("/", 1)
        secs = SECS.search(after + " ")
        if not secs:
            raise SystemExit(f"shot {n}: no length like 1.2s. in {raw.strip()!r}")
        head, rest = after[: secs.start()], after[secs.end():].strip()
        parts = [p.strip() for p in head.split(",") if p.strip()]
        lens_m = LENS.match(parts[0]) if parts else None
        if not lens_m:
            raise SystemExit(f"shot {n}: no lens like 35mm in {raw.strip()!r}")
        lens = float(lens_m.group(1))
        move = ", ".join([lens_m.group(2).strip()] + parts[1:]).strip(", ")
        notes = re.split(r"\b(VFX|SFX):", rest)
        action = notes[0].strip()
        vfx_note = " ".join(notes[i + 1] for i in range(1, len(notes) - 1, 2) if notes[i] == "VFX")
        said = SAID.search(rest)
        vfx, screen = _suggest(action + " " + vfx_note)
        if "shake" in move.lower() and "Shake" not in screen:
            screen.append("Shake")
        shots.append({"n": n, "frame": frame.strip(), "type": _type(frame, not shots), "lens": lens, "fov": vfov(lens),
                      "move": move, "length": float(secs.group(1)), "action": action, "vfx": vfx, "screen": screen,
                      "slow": any(w in frame.upper() for w in SLOW),
                      "line": (said.group(1).strip(), said.group(3).strip(), (said.group(2) or "").strip()) if said else None})
    if not shots:
        raise SystemExit("no shots found: number each shot like  6. MEDIUM / 35mm, quick push-in, 1.2s. What happens.")
    return shots


def fit(lengths, total, min_shot=MIN_SHOT):
    """Lengths scaled to sum to total, none under min_shot, order and proportions kept as far as the floor allows."""
    if total < min_shot * len(lengths) - 1e-9:
        raise SystemExit(f"{len(lengths)} shots can't fit in {total} s with {min_shot} s each at least")
    out = [max(min_shot, v * total / sum(lengths)) for v in lengths]
    for _ in range(50):
        excess = sum(out) - total
        if abs(excess) < 1e-9:
            break
        free = [i for i, v in enumerate(out) if v > min_shot + 1e-9]
        room = sum(out[i] - min_shot for i in free)
        if room <= 0:
            break
        for i in free:
            out[i] -= excess * (out[i] - min_shot) / room
            out[i] = max(min_shot, out[i])
    out = [round(v, 4) for v in out]
    longest = out.index(max(out))
    out[longest] = round(out[longest] + total - sum(out), 4)  # the rounding remainder goes on the longest shot
    return out


def draft_shots(parsed, speaker="player", fit_to=None, kind="story"):
    """(beats shots, lines) for beats.draft: markers suggested inside each shot, a Line for each quoted line, Slowmo on
    the slow-motion shots, and a RETURN beat at the end."""
    lengths = [p["length"] for p in parsed]
    if fit_to:
        lengths = fit(lengths, fit_to - RETURN)
    shots, lines, slow = [], {}, False
    for p, length in zip(parsed, lengths):
        marks = []
        for i, preset in enumerate(p["vfx"]):
            marks.append([round(min(length * (0.2 + 0.15 * i), length - 0.05), 3), "VFX", preset])
        for name in p["screen"]:
            at = round(min(length * 0.2, length - 0.05), 3)
            marks.append([at, name, {"Shake": "0.6", "Flash": "0.9"}.get(name, "")])
        if p["slow"] != slow:
            marks.append([0.0, "Slowmo", "0.25" if p["slow"] else "1"])
            slow = p["slow"]
        if p["line"]:
            lid = str(len(lines) + 1)
            who, text, how = p["line"]
            lines[lid] = {"speaker": who.title(), "text": text}
            marks.append([0.15, "Line", lid])
        camera = f"{p['frame']} / {p['lens']:g} mm (fov {p['fov']:g}), {p['move'] or 'static'}"
        shots.append({"type": p["type"], "length": length, "subject": speaker, "camera": camera, "action": p["action"],
                      "markers": sorted(marks, key=lambda m: m[0]), "cut": bool(shots), "ref": {"shot": p["n"]}})
    if slow:
        shots[-1]["markers"].append([round(shots[-1]["length"] - 0.05, 3), "Slowmo", "1"])
    shots.append({"type": "RETURN", "length": RETURN, "subject": speaker, "camera": "ease toward behind the player",
                  "action": "back to play", "markers": [], "cut": False, "ref": None})
    return shots, lines


def draft(cid, path, kind="story", speaker="player", fit_to=None, trigger=None, dialogue=None):
    text = Path(path).read_text(encoding="utf-8")
    shots, lines = draft_shots(parse(text), speaker, fit_to, kind)
    b = beats.draft(cid, {"type": "words", "text": text.strip(), "file": Path(path).name}, shots, kind=kind)
    b["lines"] = lines
    if trigger:
        b["trigger"] = {"type": trigger, "size": list(beats.ZONE)} if trigger == "zone" else {"type": trigger}
    if dialogue:
        b["dialogue"] = dialogue
    return b
