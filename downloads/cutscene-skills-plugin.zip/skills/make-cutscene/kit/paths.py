"""Where the pack's files live, the viewer's working folder, and the Open Cloud key and owner.
Method by fwjelaa (FWJ STUDIOS)."""
import json
import os
import re
from pathlib import Path

KIT = Path(__file__).resolve().parent
PACK = KIT.parent
OUT = PACK / "out"
FIXTURES = KIT / "fixtures"
ROBLOX = PACK / "roblox"
RUBRICS = PACK / "rubrics"
MAKE_ANIM = PACK.parent / "make-anim"
# the runtime finds scenes by this name (Server.play allows letters, digits and _); start with a letter
ID_RULE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,59}\Z")  # what the runtime accepts
# Blender names are at most 63 bytes. Kit names are <id> + one of these (filmset: <id>_<role>_<rig>, <id>_<role>_<part>
# materials, <id>_Camera, <id>_Anchor, <id>_Stage, CS_<id>), so authoring ids are shorter than the runtime's 60.
BLENDER_NAME_LIMIT = 63
BLENDER_SUFFIXES = ("_npc99_R15", "_npc99_rig", "_npc99_RightUpperLeg", "_npc99_RightLowerLeg", "_npc99_RightLowerArm",
                    "_Camera", "_Anchor", "_Stage")
MAX_ID = BLENDER_NAME_LIMIT - max(len(s) for s in BLENDER_SUFFIXES)

KEY_HELP = ("No Open Cloud key. Create one at create.roblox.com/credentials (Assets API: Read + Write, owner = the "
            "account or group that owns your game) and save it to %USERPROFILE%\\.fwjelaa\\roblox-open-cloud.key. "
            "It is only ever sent to Roblox and never printed.")


def key_files(pack=PACK):
    return [Path.home() / ".fwjelaa" / "roblox-open-cloud.key", pack / ".secrets" / "roblox-api-key.txt"]


def load_key(env=None, files=None):
    env = os.environ if env is None else env
    key = env.get("ROBLOX_API_KEY", "").strip()
    if key:
        return key
    for path in key_files() if files is None else files:
        if path.exists():
            key = path.read_text(encoding="utf-8").strip()
            if key:
                return key
    raise SystemExit(KEY_HELP)


def config(pack=PACK):
    """PACK/config.json as a dict ({} when there is none)."""
    path = pack / "config.json"
    cfg = {}
    if path.exists():
        try:
            cfg = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            raise SystemExit(f"config.json is not valid JSON: {e}") from None
    if not isinstance(cfg, dict):
        raise SystemExit('config.json must be one JSON object, like {"user_id": "123"}')
    return cfg


def load_creator(pack=PACK):
    cfg = config(pack)
    # JSON null counts as empty, not as the text "None"
    group, user = str(cfg.get("group_id") or "").strip(), str(cfg.get("user_id") or "").strip()
    if group:
        return {"groupId": group}
    if user:
        return {"userId": user}
    raise SystemExit("config.json needs a group_id or a user_id: whoever owns the game the cutscenes play in.")


def work_dir(env=None, pack=PACK):
    """The viewer's working folder: MAKE_CUTSCENE_WORK, else config.json "work_dir", else ~/make-cutscene."""
    env = os.environ if env is None else env
    given = env.get("MAKE_CUTSCENE_WORK", "").strip() or str(config(pack).get("work_dir") or "").strip()
    return Path(given).expanduser() if given else Path.home() / "make-cutscene"


def check_id(cid):
    if not isinstance(cid, str) or not ID_RULE.match(cid):
        raise SystemExit(f"cutscene id {cid!r}: start with a letter and use only letters, digits and _ (at most 60). "
                         "The game finds the scene by this name, e.g. GateGuard or Boss_Intro.")
    if len(cid) > MAX_ID:
        raise SystemExit(f"cutscene id {cid!r} is {len(cid)} characters: at most {MAX_ID} while authoring, because "
                         f"Blender names stop at {BLENDER_NAME_LIMIT} bytes and the kit adds up to "
                         f"{BLENDER_NAME_LIMIT - MAX_ID} characters (e.g. <id>_npc99_RightUpperLeg). Use a shorter id "
                         "with letters, digits and _.")
    return cid


def cutscene_dir(cid, env=None, pack=PACK):
    return work_dir(env, pack) / "cutscenes" / check_id(cid)
