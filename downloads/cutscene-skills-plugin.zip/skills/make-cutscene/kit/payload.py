"""Payloads for Studio: one execute_luau call carries at most MAX_BYTES (everything sent passes through the model), so
a bigger script is sent in parts. Parts 1..n-1 store their text in ServerStorage.CutsceneKitStaging; the last part
joins them into a temporary ModuleScript, requires it (the script's own `return` becomes the result) and cleans up.
A token ties the parts of one bundle together, so a stale part is named instead of run. Method by fwjelaa (FWJ STUDIOS).
"""
import hashlib
import re
from pathlib import Path

MAX_BYTES = 60_000  # the transfer budget for one execute_luau payload (studio.BUDGET)
OVERHEAD = 1_600  # the part wrapper's own bytes, with room to spare
MIN_CHUNK = 1_000  # a budget that leaves less room than this for the payload is refused
STAGE = "CutsceneKitStaging"
METHOD = "Method by fwjelaa (FWJ STUDIOS)."


def long_string(text):
    """A Luau long-bracket literal holding text exactly (Luau drops the newline right after the opening bracket)."""
    level = 0
    # the closing bracket may not appear early, not even made of the text's last characters and its own first ones
    while (text + f"]{'=' * level}]").find(f"]{'=' * level}]") != len(text):
        level += 1
    eq = "=" * level
    return f"[{eq}[\n{text}]{eq}]"


def _payload(part_text):
    """The text a part carries (the inverse of long_string inside a part)."""
    m = re.search(r"\[(=*)\[\n(.*?)\]\1\]", part_text, re.S)
    if not m:
        raise ValueError("no payload in this part")
    return m.group(2)


def _chunks(text, room):
    """Pieces of at most `room` bytes that join back to text exactly. A piece ends on a line break when one is near
    its end; the embedded sources are single long string lines, so most pieces end mid-line (the join is exact)."""
    out, i = [], 0
    while i < len(text):
        j = min(len(text), i + room)
        piece = text[i:j]
        over = len(piece.encode("utf-8")) - room
        while over > 0:  # multi-byte characters: shrink until it fits
            j -= max(1, over // 4)
            piece = text[i:j]
            over = len(piece.encode("utf-8")) - room
        if j < len(text):
            nl = piece.rfind("\n")
            if nl > len(piece) * 0.9:
                piece = piece[: nl + 1]
        out.append(piece)
        i += len(piece)
    return out or [""]


def part_names(name, n):
    stem = name[: -len(".luau")] if name.endswith(".luau") else name
    return [name] + [f"{stem}.{i}.luau" for i in range(2, n + 1)]


def parts(name, text, budget=MAX_BYTES, where="out"):
    """[(file name, text)]: the script itself when it fits, else n parts (name, name.2.luau, ...). `where` is the folder the
    messages name for the files (out for bundles, studio for Studio steps)."""
    if len(text.encode("utf-8")) <= budget:
        return [(name, text)]
    stem = name[: -len(".luau")]
    own_slot = "^" + re.sub(r"(\W)", r"%\1", stem) + "_%d+$"  # a Luau pattern: only this bundle's numbered slots
    if budget < OVERHEAD + MIN_CHUNK:
        raise SystemExit(f"payload budget {budget} B is too small: the part wrapper needs {OVERHEAD} B and a part "
                         f"at least {MIN_CHUNK} B more, so the smallest budget is {OVERHEAD + MIN_CHUNK} B")
    room = budget - OVERHEAD
    chunks = _chunks(text, room)
    n = len(chunks)
    # the token fingerprints this exact build: the joined text, how many parts, and how they were cut
    token = hashlib.sha256(f"{n}|{room}|".encode("utf-8") + text.encode("utf-8")).hexdigest()[:12]
    names = part_names(name, n)
    order = ", ".join(f"{where}/{x}" for x in names)
    out = []
    for i, chunk in enumerate(chunks, 1):
        head = (f"-- {where}/{names[i - 1]} is part {i} of {n} of {where}/{name} (kit/payload.py). One execute_luau payload stays under\n"
                f"-- {budget // 1000} KB, so this script goes in parts: send {order} in that order. {METHOD}\n"
                'local ServerStorage = game:GetService("ServerStorage")\n')
        if i < n:
            body = (f'local stage = ServerStorage:FindFirstChild("{STAGE}")\n'
                    "if not stage then\n"
                    '\tstage = Instance.new("Folder")\n'
                    f'\tstage.Name = "{STAGE}"\n'
                    "\tstage.Parent = ServerStorage\n"
                    "end\n"
                    f'local old = stage:FindFirstChild("{stem}_{i}")\n'
                    "if old then\n\told:Destroy()\nend\n"
                    'local v = Instance.new("StringValue")\n'
                    f'v.Name = "{stem}_{i}"\n'
                    f'v:SetAttribute("Token", "{token}")\n'
                    f"v.Value = {long_string(chunk)}\n"
                    "v.Parent = stage\n"
                    f'return "{where}/{name} part {i}/{n} stored: send {where}/{names[i]} next"\n')
        else:
            body = (f'local stage = ServerStorage:FindFirstChild("{STAGE}")\n'
                    "local pieces = {}\n"
                    f"for i = 1, {n - 1} do\n"
                    f'\tlocal v = stage and stage:FindFirstChild("{stem}_" .. i)\n'
                    f'\tif not v or v:GetAttribute("Token") ~= "{token}" then\n'
                    f'\t\treturn ("{where}/{name}: part %d (slot {stem}_%d) is missing or from another build: send {order} again, in order"):format(i, i)\n'
                    "\tend\n"
                    "\tpieces[i] = v.Value\n"
                    "end\n"
                    f"pieces[{n}] = {long_string(chunk)}\n"
                    'local joined = Instance.new("ModuleScript")\n'
                    f'joined.Name = "{stem}_joined"\n'
                    "joined.Source = table.concat(pieces)\n"
                    "joined.Parent = stage\n"
                    "local ok, result = pcall(require, joined)\n"
                    "joined:Destroy()\n"
                    "for _, slot in stage:GetChildren() do\n"  # only its own slots: dev's join leaves dev_authoring_1
                    f'\tif slot.Name == "{stem}_joined" or string.match(slot.Name, "{own_slot}") then\n'
                    "\t\tslot:Destroy()\n"
                    "\tend\n"
                    "end\n"
                    "if #stage:GetChildren() == 0 then\n\tstage:Destroy()\nend\n"
                    "if not ok then\n\terror(result, 0)\nend\n"
                    "return result\n")
        out.append((names[i - 1], head + body))
    biggest = max(len(body.encode("utf-8")) for _, body in out)
    if biggest > budget:  # OVERHEAD is a measured guess: never hand out a part over the budget
        raise SystemExit(f"a payload part is {biggest} B, over the {budget} B budget (the wrapper grows with the part "
                         f"count): use a bigger budget")
    return out


def write_parts(out_dir, name, text, budget=MAX_BYTES, where="out"):
    """Writes the script (or its parts) and removes parts left from an earlier, bigger bundle. Returns the paths."""
    out_dir = Path(out_dir)
    stem = name[: -len(".luau")]
    for old in out_dir.glob(f"{stem}.*.luau"):
        if re.fullmatch(re.escape(stem) + r"\.\d+\.luau", old.name):
            old.unlink()
    written = []
    for fname, body in parts(name, text, budget, where):
        path = out_dir / fname
        path.write_text(body, encoding="utf-8", newline="\n")
        written.append(path)
    return written


def joined(out_dir, name):
    """The whole script again, from the file or its parts (tests and checks read this)."""
    out_dir = Path(out_dir)
    first = (out_dir / name).read_text(encoding="utf-8")
    m = re.match(r"-- \S+ is part 1 of (\d+) of ", first)
    if not m:
        return first
    return "".join(_payload((out_dir / f).read_text(encoding="utf-8")) for f in part_names(name, int(m.group(1))))
