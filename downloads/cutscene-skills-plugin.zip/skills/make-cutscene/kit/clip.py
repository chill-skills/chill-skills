"""Roblox KeyframeSequence data without Blender. Method by fwjelaa (FWJ STUDIOS).

Same data format as make-anim's kit/export.py (name, loop, priority, fps, length in frames, root, parents, keyframes).
write_rbxmx is a copy of make-anim's export.write_rbxmx: that module imports bpy, so it can't be imported here.
A CFrame is 12 numbers: x, y, z, then the rotation matrix row by row (R00 R01 R02 R10 ... R22), like CFrame.new(...).
"""
import math
import re

IDENTITY = [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]


def matmul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def rot3(cf):
    """The 3x3 rotation of a 12-number CFrame list."""
    return [[cf[3], cf[4], cf[5]], [cf[6], cf[7], cf[8]], [cf[9], cf[10], cf[11]]]


def apply3(m, v):
    return [sum(m[i][k] * v[k] for k in range(3)) for i in range(3)]


def transpose(m):
    return [[m[j][i] for j in range(3)] for i in range(3)]


def rot_xyz(rx=0.0, ry=0.0, rz=0.0):
    """Rotation of CFrame.Angles(rad(rx), rad(ry), rad(rz)) = Rx * Ry * Rz. Degrees in."""
    a, b, c = (math.radians(v) for v in (rx, ry, rz))
    rxm = [[1, 0, 0], [0, math.cos(a), -math.sin(a)], [0, math.sin(a), math.cos(a)]]
    rym = [[math.cos(b), 0, math.sin(b)], [0, 1, 0], [-math.sin(b), 0, math.cos(b)]]
    rzm = [[math.cos(c), -math.sin(c), 0], [math.sin(c), math.cos(c), 0], [0, 0, 1]]
    return matmul(matmul(rxm, rym), rzm)


def cf_from(m, pos=(0.0, 0.0, 0.0)):
    return [round(float(v), 6) + 0.0 for v in (*pos, *m[0], *m[1], *m[2])]


def cframe(x=0.0, y=0.0, z=0.0, rx=0.0, ry=0.0, rz=0.0):
    return cf_from(rot_xyz(rx, ry, rz), (x, y, z))


def conj(r, q):
    """Pose-language rotation q on a joint whose C0 rotation is r (AnimKit.poseCFrame without translation)."""
    return matmul(matmul(transpose(r), q), r)


def _norm(v):
    n = math.sqrt(sum(c * c for c in v))
    return [c / n for c in v]


def _cross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def look_at(eye, target, up=(0.0, 1.0, 0.0)):
    """CFrame.lookAt(eye, target): the LookVector (-Z) points at the target."""
    z = _norm([e - t for e, t in zip(eye, target)])
    x = _norm(_cross(up, z))
    y = _cross(z, x)
    return cf_from([[x[0], y[0], z[0]], [x[1], y[1], z[1]], [x[2], y[2], z[2]]], eye)


def clip_data(name, root, parents, keys, length, fps=60, priority="Action4", loop=False):
    """keys: [{"time": s, "poses": {part: {"cf", "style", "dir"}}, "markers": [[name, value]]}]. Equal times merge.
    Times are rounded DOWN to 1e-5 s like make-anim, so a Constant hold never shows the old pose on its snap frame."""
    merged = {}
    for k in keys:
        t = math.floor(round(k["time"] * 1e5, 3)) / 1e5
        slot = merged.setdefault(t, {"time": t, "poses": {}, "markers": []})
        slot["poses"].update(k.get("poses", {}))
        slot["markers"].extend([list(m) for m in k.get("markers", [])])
    return {
        "name": name, "loop": loop, "priority": priority, "fps": fps, "length": round(length * fps),
        "root": root, "parents": dict(parents), "keyframes": [merged[t] for t in sorted(merged)],
    }


# ---- copied from make-anim kit/export.py -------------------------------------------------------

def _xml_escape(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


_STYLE_TOKEN = {"Linear": 0, "Constant": 1, "Elastic": 2, "Cubic": 3, "Bounce": 4, "CubicV2": 5}
_DIR_TOKEN = {"In": 0, "Out": 1, "InOut": 2}
_PRIORITY_TOKEN = {"Idle": 0, "Movement": 1, "Action": 2, "Action2": 3, "Action3": 4, "Action4": 5, "Core": 1000}


def write_rbxmx(data, path):
    """KeyframeSequence as a Roblox XML model: drag it into Studio or upload it as an Animation."""
    ref = [0]

    def item(cls, props, children):
        ref[0] += 1
        return f'<Item class="{cls}" referent="RBX{ref[0]}"><Properties>{props}</Properties>{children}</Item>'

    def cframe_xml(name, c):
        tags = ["X", "Y", "Z", "R00", "R01", "R02", "R10", "R11", "R12", "R20", "R21", "R22"]
        return f'<CoordinateFrame name="{name}">' + "".join(f"<{t}>{v}</{t}>" for t, v in zip(tags, c)) + "</CoordinateFrame>"

    children_of = {}
    for child, parent in data["parents"].items():
        children_of.setdefault(parent, []).append(child)

    def subtree_keyed(part, poses):
        return part in poses or any(subtree_keyed(c, poses) for c in children_of.get(part, []))

    def pose_xml(part, poses):
        keyed = part in poses
        p = poses.get(part, {"cf": [0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1], "style": "Linear", "dir": "In"})
        kids = "".join(pose_xml(c, poses) for c in children_of.get(part, []) if subtree_keyed(c, poses))
        props = (f'<string name="Name">{_xml_escape(part)}</string>' + cframe_xml("CFrame", p["cf"])
                 + f'<token name="EasingDirection">{_DIR_TOKEN[p["dir"]]}</token>'
                 + f'<token name="EasingStyle">{_STYLE_TOKEN[p["style"]]}</token>'
                 + f'<float name="Weight">{1 if keyed else 0}</float>')
        return item("Pose", props, kids)

    kfs = []
    for k in data["keyframes"]:
        inner = pose_xml(data["root"], k["poses"]) if subtree_keyed(data["root"], k["poses"]) else ""
        for name, value in k["markers"]:
            inner += item("KeyframeMarker", f'<string name="Name">{_xml_escape(name)}</string>'
                          f'<string name="Value">{_xml_escape(value)}</string>', "")
        kfs.append(item("Keyframe", f'<string name="Name">Keyframe</string><float name="Time">{k["time"]}</float>', inner))
    root = item("KeyframeSequence",
                f'<string name="Name">{_xml_escape(data["name"])}</string>'
                f'<bool name="Loop">{"true" if data["loop"] else "false"}</bool>'
                f'<token name="Priority">{_PRIORITY_TOKEN[data["priority"]]}</token>', "".join(kfs))
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write('<roblox xmlns:xmime="http://www.w3.org/2005/05/xmlmime" version="4">' + root + "</roblox>")


# ---- Luau literals for generated data modules ---------------------------------------------------

_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*\Z")
_RESERVED = {"and", "break", "do", "else", "elseif", "end", "false", "for", "function", "if", "in", "local", "nil",
             "not", "or", "repeat", "return", "then", "true", "until", "while", "continue"}


_ESCAPES = {"\\": "\\\\", '"': '\\"', "\n": "\\n", "\r": "\\r", "\t": "\t"}


def _luau_str(s):
    """A Luau literal holding exactly s: nothing is dropped. A tab stays a raw tab (legal in a Luau string, and
    bundle.py embeds tab-indented Luau sources through here: escaping them would push install.luau past 60 KB). Every
    other control character (below 0x20, and 0x7F) becomes a 3-digit decimal escape, so a digit after it can't join
    the escape."""
    return '"' + "".join(_ESCAPES.get(ch) or (f"\\{ord(ch):03d}" if ch < " " or ch == "\x7f" else ch) for ch in s) + '"'


def luau_value(v, indent=0):
    """A Luau literal for v (dicts sorted by key, so the output is stable)."""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        if not math.isfinite(v):
            raise ValueError(f"{v!r} can't go into a Luau data module: a calculation produced NaN or infinity")
        return repr(round(v, 5))
    if isinstance(v, str):
        return _luau_str(v)
    pad, inner = "\t" * indent, "\t" * (indent + 1)
    if isinstance(v, (list, tuple)):
        if all(not isinstance(x, (dict, list, tuple)) for x in v):
            return "{" + ", ".join(luau_value(x) for x in v) + "}"
        return "{\n" + "".join(f"{inner}{luau_value(x, indent + 1)},\n" for x in v) + pad + "}"
    if isinstance(v, dict):
        if not v:
            return "{}"
        lines = []
        for k in sorted(v, key=str):
            key = k if isinstance(k, str) and _IDENT.match(k) and k not in _RESERVED else f"[{luau_value(k)}]"
            lines.append(f"{inner}{key} = {luau_value(v[k], indent + 1)},\n")
        return "{\n" + "".join(lines) + pad + "}"
    raise TypeError(f"no Luau literal for {type(v).__name__}")
