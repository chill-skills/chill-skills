"""Self-contained Luau scripts for Studio: the kit's files go inside the script, so nothing in Studio uses HTTP.
Measured 2026-11-07: the Studio MCP blocks HttpService to 127.0.0.1 ("not in the Assistant HTTP allowlist").
Method by fwjelaa (FWJ STUDIOS).

    py kit/run.py bundle      writes out/install.luau, out/dev.luau, out/dev_authoring.luau, out/fixture.luau,
                              out/fixture_r6.luau, out/fixture_assets.luau: send one with execute_luau (Edit mode).
                              Send dev.luau before dev_authoring.luau. A script over MAX_BYTES, the budget for one
                              execute_luau payload, is written in parts: <name>.luau, <name>.2.luau, ... (kit/payload.py)
"""
import json
from pathlib import Path

import clip
import paths
import payload
import vfxlib

EMBED_LINE = "local EMBED = nil -- filled in by kit/bundle.py"
ROBLOX = paths.PACK / "roblox"
FIXTURE = paths.FIXTURES / "Fixture_Walkin"
AUTHORING = ROBLOX / "authoring"
MAX_BYTES = payload.MAX_BYTES  # one number for the execute_luau budget
# Test.luau and the fixture installer require these from CutsceneKitDev.Authoring, so they ship in dev.luau
CORE_AUTHORING = ("ClipBuilder",)


def _read(path):
    # bytes, not read_text: text mode would quietly turn a lone \r into \n
    text = Path(path).read_bytes().decode("utf-8").replace("\r\n", "\n")
    # a stray control character in a source file is a mistake (clip.luau_value would carry it over escaped, so the
    # installed script would hold it too): refuse instead
    bad = sorted({hex(ord(ch)) for ch in text if ord(ch) < 32 and ch not in "\n\t"})
    if bad:
        raise ValueError(f"{path} has control characters {bad} that cannot be embedded in a Luau string")
    return text


def render(template_path, embed):
    text = _read(template_path)
    if EMBED_LINE not in text.split("\n"):
        raise ValueError(f"{template_path} has no line {EMBED_LINE!r}")
    lines = ["local EMBED = " + clip.luau_value(embed) if ln == EMBED_LINE else ln for ln in text.split("\n")]
    return "\n".join(lines)


def _manifest():
    return json.loads(_read(FIXTURE / "manifest.json"))


def _clips():
    return {name: _read(FIXTURE / f"{name}.json") for name in _manifest()["clips"]}


def authoring_modules():
    """roblox/authoring/*.luau as ModuleScript sources by name (the *.client.luau scripts are not modules)."""
    return {p.stem: _read(p) for p in sorted(AUTHORING.glob("*.luau")) if not p.name.endswith(".client.luau")}


# runtime modules made from data, not kept as .luau files (_index.json "generated")
GENERATED = {"VfxPresets": lambda: vfxlib.luau()}


def _index():
    return json.loads(_read(ROBLOX / "CutsceneKit" / "_index.json"))


def kit_source(path):
    """One installed file's source: roblox/<path>, or the generator's output for a generated module."""
    stem = Path(path).stem
    if path.startswith("CutsceneKit/") and stem in _index().get("generated", []):
        return GENERATED[stem]()
    return _read(ROBLOX / path)


def install_embed():
    index = _index()
    paths_ = ["CutsceneKit/CutsceneKit.luau"] + [f"CutsceneKit/{m}.luau" for m in index["modules"]]
    paths_ += ["scripts/CutsceneServer.server.luau", "scripts/CutsceneClient.client.luau"]
    return {
        "version": index["version"],
        "modules": index["modules"],
        "files": {p: kit_source(p) for p in paths_},
    }


def delta_embed(modules=(), tests=()):
    """Only these modules' and tests' sources: out/delta.luau copies every other module from the installed kit."""
    index = _index()
    unknown = [m for m in modules if m not in index["modules"] and m != "CutsceneKit"]
    test_names = {p.name[: -len(".test.luau")] for p in (ROBLOX / "tests").glob("*.test.luau")}
    unknown += [f"test {t}" for t in tests if t not in test_names]
    if unknown:
        raise SystemExit(f"delta: no such module or test: {', '.join(unknown)}")
    return {
        "version": index["version"],
        "modules": index["modules"],
        "files": {f"CutsceneKit/{m}.luau": kit_source(f"CutsceneKit/{m}.luau") for m in modules},
        "tests": {t: _read(ROBLOX / "tests" / f"{t}.test.luau") for t in tests},
    }


def write_delta(modules, tests, out_dir=None):
    out = Path(out_dir) if out_dir else paths.OUT
    out.mkdir(parents=True, exist_ok=True)
    text = render(ROBLOX / "dev" / "install_delta.luau", delta_embed(modules, tests))
    return payload.write_parts(out, "delta.luau", text, MAX_BYTES)


def _split_authoring():
    mods = authoring_modules()
    core = {n: mods[n] for n in CORE_AUTHORING}
    extra = {n: src for n, src in mods.items() if n not in core}
    tests = {p.name[: -len(".test.luau")]: _read(p) for p in sorted((ROBLOX / "tests").glob("*.test.luau"))}
    extra_tests = {n: tests.pop(n) for n in list(tests) if n in extra}
    return core, tests, extra, extra_tests


def dev_embed():
    core, tests, _, _ = _split_authoring()
    return {
        "files": {"Test": _read(ROBLOX / "dev" / "Test.luau")},
        "authoring": core,
        "tests": tests,
        "clips": _clips(),
    }


def dev_authoring_embed():
    _, _, extra, extra_tests = _split_authoring()
    return {"authoring": extra, "tests": extra_tests}


def fixture_embed(use_clips=True, npc_rig="R15"):
    manifest = _manifest()
    return {
        "manifest": manifest,
        "data": _read(FIXTURE / manifest["data"]),
        "clips": _clips(),
        "useClips": use_clips,
        "npcRig": npc_rig,
    }


def write_all(out_dir=None, budget=None):
    out = Path(out_dir) if out_dir else paths.OUT
    out.mkdir(parents=True, exist_ok=True)
    fixture_tpl = ROBLOX / "dev" / "install_fixture.luau"
    jobs = [
        ("install.luau", ROBLOX / "install.luau", install_embed()),
        ("dev.luau", ROBLOX / "dev" / "install_dev.luau", dev_embed()),
        ("dev_authoring.luau", ROBLOX / "dev" / "install_dev_authoring.luau", dev_authoring_embed()),
        ("fixture.luau", fixture_tpl, fixture_embed(True, "R15")),
        ("fixture_r6.luau", fixture_tpl, fixture_embed(True, "R6")),
        ("fixture_assets.luau", fixture_tpl, fixture_embed(False, "R15")),
    ]
    written = []
    for name, tpl, embed in jobs:
        # a script over the payload budget is written in parts: name, name.2.luau, ... (kit/payload.py)
        written += payload.write_parts(out, name, render(tpl, embed), MAX_BYTES if budget is None else budget)
    return written
