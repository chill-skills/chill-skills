"""A cutscene's working folder: cutscenes/<id>/ in the viewer's working folder (spec 5). Method by fwjelaa (FWJ STUDIOS).

    cutscenes/<id>/
      beats.json  the beat sheet (beats.py)             notes.md   decisions, measured numbers, review rounds
      map.json    stand-ins around the trigger          rigs/      captured rigs, one <role>.json each
      anim/       <role>.py, <role>_R6.py, camera.py    export/    clips, scene.json, framing.json, <id>.luau, ids.json
      ref/        reference frames and sheets           studio/    rendered Studio steps and returned chunks
      preview/    recordings, preview MP4, sheets       review/    blind-review packets, scores, playtest.json
      <id>.blend  the Blender film set (an output: anim/*.py and map.json are the source)
"""
import json
import os
from pathlib import Path

import paths
import schema

FOLDERS = ("ref", "rigs", "anim", "export", "studio", "preview", "review")


def create(cid, kind="story", env=None):
    if kind not in schema.KINDS:
        raise SystemExit(f"kind must be one of {', '.join(schema.KINDS)}")
    root = paths.cutscene_dir(cid, env)
    for name in FOLDERS:
        (root / name).mkdir(parents=True, exist_ok=True)
    notes = root / "notes.md"
    if not notes.exists():
        notes.write_text(f"# {cid}\n\nKind: {kind}\n\n## Decisions\n\n## Measured\n\n## Review rounds\n",
                         encoding="utf-8", newline="\n")
    return root


def open_(cid, env=None):
    root = paths.cutscene_dir(cid, env)
    if not root.is_dir():
        raise SystemExit(f"no cutscene {cid} in {root.parent}: run  py kit/run.py new {cid}")
    return root


def read_json(path):
    path = Path(path)
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise SystemExit(f"missing {path}") from None
    except json.JSONDecodeError as e:
        raise SystemExit(f"{path.name} is not valid JSON: {e}") from None


def write_json(path, data):
    """UTF-8, LF, a final newline; written to a .tmp first so a crash never leaves half a file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=1, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    os.replace(tmp, path)
    return path
