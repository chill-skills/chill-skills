"""Local evidence byte manifests, not playback or reviewer authentication.

Method by fwjelaa (FWJ STUDIOS).
"""
import hashlib
from pathlib import Path

VERSION = 1


def digest(path):
    """Hash nonempty files in chunks, including full continuous clips."""
    try:
        with Path(path).open('rb') as stream:
            h, size = hashlib.sha256(), 0
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(chunk)
                size += len(chunk)
        return h.hexdigest() if size else None
    except OSError:
        return None


def local_name(name):
    # Evidence sets are flat; refuse traversal and platform-specific separators.
    return isinstance(name, str) and bool(name) and name not in ('.', '..') and not any(c in name for c in '/\\:')


def hashes(directory, names):
    return {name: digest(Path(directory) / name) for name in names}


def problems(directory, files, expected=None):
    """Validate a complete filename->SHA256 manifest against actual bytes."""
    if not isinstance(files, dict) or not files:
        return ['missing/legacy file manifest; regenerate evidence']
    if expected is not None and set(files) != set(expected):
        return ['incomplete file manifest; regenerate evidence']
    out = []
    for name, sha in files.items():
        if not local_name(name):
            out.append('invalid evidence filename; regenerate evidence')
        elif not isinstance(sha, str) or len(sha) != 64 or digest(Path(directory) / name) != sha:
            out.append(f'{name}: missing, empty or changed bytes; regenerate evidence')
    return out
