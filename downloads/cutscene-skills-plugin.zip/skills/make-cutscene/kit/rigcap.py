"""Captured rigs: check the JSON Capture.captureRig returned and save it as cutscenes/<id>/rigs/<role>.json with how
the rig stands (spec 5.3: the player stand-in at the game's avatar scale, NPCs as the viewer's own rigs).
Method by fwjelaa (FWJ STUDIOS).

  "stand": the HumanoidRootPart centre's height above the floor where CutsceneKit places it (Director.place):
           R15 = Humanoid.HipHeight + half the root's height, R6 = 3.
  "foot":  how far the lowest foot corner sits below the root at rest, from the joints (C0, C1) and part sizes.
           For a sound rig, foot ~= stand; kit/filmset.py uses stand to place the rig and foot as make-anim's hip_height.
"""
import json
import math
from pathlib import Path

import clip
import workspace

FEET = {"R15": ("RightFoot", "LeftFoot"), "R6": ("Right Leg", "Left Leg")}
NEEDED = {
    "R15": ("HumanoidRootPart", "LowerTorso", "UpperTorso", "Head", "RightUpperArm", "RightLowerArm", "RightHand",
            "LeftUpperArm", "LeftLowerArm", "LeftHand", "RightUpperLeg", "RightLowerLeg", "RightFoot", "LeftUpperLeg",
            "LeftLowerLeg", "LeftFoot"),
    "R6": ("HumanoidRootPart", "Torso", "Head", "Right Arm", "Left Arm", "Right Leg", "Left Leg"),
}


def mul(a, b):
    ra = clip.rot3(a)
    return clip.cf_from(clip.matmul(ra, clip.rot3(b)), [x + y for x, y in zip(clip.apply3(ra, b[:3]), a[:3])])


def inv(a):
    rt = clip.transpose(clip.rot3(a))
    return clip.cf_from(rt, [-v for v in clip.apply3(rt, a[:3])])


def point(a, v):
    return [x + y for x, y in zip(clip.apply3(clip.rot3(a), v), a[:3])]


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def validate(r):
    if not isinstance(r, dict):
        return ["the rig must be one JSON object"]
    problems = []
    kind = r.get("rigType")
    if kind not in FEET:
        return ["rigType must be R15 or R6"]
    parts = r.get("parts") if isinstance(r.get("parts"), dict) else {}
    for name in NEEDED[kind]:
        if name not in parts:
            problems.append(f"part {name} is missing")
    for name, size in parts.items():
        if not (isinstance(size, list) and len(size) == 3 and all(_num(v) and v > 0 for v in size)):
            problems.append(f"part {name}: size must be 3 positive numbers")
    placed = {r.get("root", "HumanoidRootPart")}
    for j in r.get("joints") or []:
        if not (isinstance(j, list) and len(j) == 5 and all(isinstance(x, str) for x in j[:3])):
            problems.append(f"joint {j!r:.60} must be [motor, part0, part1, C0, C1]")
            continue
        for c in (j[3], j[4]):
            if not (isinstance(c, list) and len(c) == 12 and all(_num(v) for v in c)):
                problems.append(f"joint {j[0]}: C0 and C1 must be 12 numbers")
                break
        if j[1] not in placed:
            problems.append(f"joint {j[0]}: {j[1]} has no joint yet (joints must list parents before children)")
        placed.add(j[2])
    for name in NEEDED[kind][1:]:
        if name in parts and name not in placed:
            problems.append(f"part {name} has no joint to the root")
    return problems


def rest_frames(r):
    """Every part's CFrame relative to the root at rest: P1 = P0 * C0 * C1^-1."""
    frames = {r.get("root", "HumanoidRootPart"): list(clip.IDENTITY)}
    for name, p0, p1, c0, c1 in r["joints"]:
        frames[p1] = mul(mul(frames[p0], c0), inv(c1))
    return frames


def foot(r):
    frames = rest_frames(r)
    low = min(point(frames[f], [sx * r["parts"][f][0] / 2, sy * r["parts"][f][1] / 2, sz * r["parts"][f][2] / 2])[1]
              for f in FEET[r["rigType"]] for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1))
    return round(-low, 4)


def stand(r):
    if r["rigType"] == "R6":
        return 3.0
    return round(float(r["hipHeight"]) + r["parts"]["HumanoidRootPart"][1] / 2, 4)


def save(root, role, text):
    try:
        r = json.loads(text)
    except json.JSONDecodeError as e:
        raise SystemExit(f"studio/rig_{role}.txt is not the JSON Studio returned ({e}): run the rig step again and save "
                         "the whole returned string") from None
    problems = validate(r)
    if problems:
        raise SystemExit(f"studio/rig_{role}.txt: " + "; ".join(problems))
    r["role"], r["stand"], r["foot"] = role, stand(r), foot(r)
    path = workspace.write_json(Path(root) / "rigs" / f"{role}.json", r)
    gap = r["stand"] - r["foot"]
    note = "feet on the floor" if abs(gap) < 0.05 else f"feet {abs(gap):.2f} {'above' if gap > 0 else 'below'} the floor"
    return path, f"{role}: {r['rigType']}, {len(r['parts'])} parts, {len(r['joints'])} joints, stands {r['stand']:.2f} ({note})"
