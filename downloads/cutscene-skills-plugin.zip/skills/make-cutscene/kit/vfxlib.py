"""The VFX preset library (spec 7): vfx/presets.json is the one source for the runtime's CutsceneKit.VfxPresets
(kit/bundle.py generates that module into the installer), for the kit checks' budgets and for the format contract's
preset, element and aura names. Method by fwjelaa (FWJ STUDIOS).

    py kit/run.py vfx          check the library and list every preset with its budget

Budget rule (the same in CutsceneKit.Vfx.budget): particles = the emit layers' counts; lights = the light layers;
parts = 1 per ring or shape, `count` per trail or rocks layer, count x segments x 2 per bolt or cracks layer.
"""
import json
import re
from pathlib import Path

import paths
from payload import long_string

PATH = paths.PACK / "vfx" / "presets.json"
MANGA_PATH = paths.PACK / "vfx" / "manga" / "textures.json"  # the uploaded manga textures (vfx/manga/make_manga.py)
FWJELAA_VFX = paths.PACK.parent / "fwjelaa-vfx" / "src" / "FwjelaaVFX.luau"
KINDS = ("emit", "ring", "shape", "trail", "bolt", "rocks", "cracks", "light")
ROLES = ("main", "hot", "dark", "glow", "spark", "debris", "accent", "deep", "white", "black")
DIRS = ("none", "up", "cone", "sphere", "disc", "ringin", "converge")
SHAPES = ("ball", "column", "disc")
MATERIALS = ("Neon", "ForceField", "SmoothPlastic", "Glass")
ORIENT = ("camera", "vpar", "vperp")
ROCK_MODES = ("eject", "rim", "lift")
EASES = ("linear", "in", "out", "inout", "in3", "out3", "hold")
SCREEN = ("grade", "bloom", "flash", "speedlines", "focus", "burst", "word", "backdrop")
FONTS = ("Bangers", "LuckiestGuy", "FredokaOne", "PermanentMarker", "Creepster", "DenkOne")  # Enum.Font's comic faces
WORD_TEXT_MAX = 16  # characters in a sound word (BZZT, POW!!, ?!)
STROKE_MAX = 0.07  # a word's UIStroke as a share of its text size: thicker fills the letters' counters in (vault)
ASSET_ID = re.compile(r"^rbxassetid://[0-9]+\Z")
LOOKS = ("eyes", "outline", "tint")
AURA_POINTS = ("Head", "UpperTorso", "LowerTorso", "LeftHand", "RightHand", "LeftFoot", "RightFoot")
SHARED_ELEMENTS = ("teal", "violet", "fire", "ice", "lightning", "void", "plasma", "holy")
PRESET_PARTICLES = 600  # one preset at quality 1 (research/03 s5: a whole sequence peaks near 1,500 on PC)
PRESET_PARTS = 120
PRESET_LIGHTS = 2  # spec 7: at most 2 lights per effect
PRESET_LIFE = 6.0
AURA_PARTICLES = 60  # research/03 s5: a persistent aura keeps at most ~60 live particles per player
ENGINE_TEXTURE = re.compile(r"^rbxasset://textures/particles/[A-Za-z0-9_]+[.](dds|png)\Z")  # engine textures only (spec 3, 7)
HEX = re.compile(r"^#?[0-9a-fA-F]{6}$")
NAME = re.compile(r"^[A-Z][A-Za-z0-9]{0,31}$")
_cache = {}

# kind -> {field: rule}; a leading "!" marks a required field
SPEC = {
    "emit": {"!count": "int", "!texture": "texture", "!life": "pair", "t": "time", "over": "time", "dir": DIRS,
             "radius": "num", "spread": "num", "up": "num", "at": "vec", "role": "roles", "le": "num",
             "bright": "num", "size": "seq", "transp": "seq", "squash": "seq", "speed": "pair", "drag": "num",
             "acc": "vec", "rot": "pair", "spin": "pair", "orient": ORIENT, "zoff": "num", "decor": "bool"},
    "ring": {"!life": "pos", "!r": "curve", "!width": "curve", "t": "time", "height": "pos", "ease": EASES,
             "role": "role", "alpha": "curve", "at": "vec", "tilt": "num", "spin": "num", "decor": "bool"},
    "shape": {"!life": "pos", "!shape": SHAPES, "!r": "curve", "h": "curve", "t": "time", "material": MATERIALS,
              "role": "role", "alpha": "curve", "at": "vec", "spin": "num", "thick": "pos", "decor": "bool"},
    "trail": {"!life": "pos", "!count": "int", "!radius": "pair", "!height": "pair", "!turns": "num",
              "!width": "pair", "t": "time", "trailLife": "pos", "role": "roles", "le": "num", "alpha": "unit",
              "at": "vec", "decor": "bool"},
    "bolt": {"!life": "pos", "!count": "int", "!radius": "pair", "!segments": "int", "!width": "pos", "t": "time",
             "flicker": "pos", "jitter": "num", "role": "role", "glow": "role", "at": "vec", "decor": "bool"},
    "rocks": {"!life": "pos", "!mode": ROCK_MODES, "!count": "int", "!size": "pair", "!radius": "pair", "t": "time",
              "speed": "pair", "up": "pair", "gravity": "num", "rise": "pos", "tilt": "num", "lift": "pair",
              "hang": "time", "spin": "num", "sink": "time", "material": "material", "at": "vec", "decor": "bool"},
    "cracks": {"!life": "pos", "!count": "int", "!length": "pair", "!segments": "int", "!width": "pos",
               "!grow": "pos", "t": "time", "hold": "time", "fade": "time", "role": "role", "from": "num",
               "jitter": "num", "at": "vec", "decor": "bool"},
    "light": {"!life": "pos", "!brightness": "curve", "!range": "pos", "t": "time", "role": "role", "at": "vec"},
}
SCREEN_SPEC = {"effect": SCREEN, "t": "time", "sat": "num", "contrast": "num", "bright": "num", "tint": "role",
               "mix": "unit", "attack": "time", "hold": "time", "release": "time", "intensity": "num", "size": "num",
               "threshold": "num", "power": "unit", "count": "int", "life": "pos", "alpha": "unit", "dist": "num",
               "radius": "num", "far": "unit", "near": "unit",
               # the manga effects (CutsceneKit.Screen): speedlines, burst, word, backdrop
               "at": "point", "focus": "point", "follow": "follow", "image": "image", "rot": "num", "text": "text",
               "fill": "role", "color": "role", "stroke": "stroke", "density": "unit", "font": FONTS}
FOLLOW = re.compile(r"^(player|target|npc[1-9][0-9]?)(\.[A-Za-z0-9_]+)?\Z")


def load(path=None):
    """The library as a dict (cached until the file changes)."""
    p = Path(path) if path else PATH
    stamp = p.stat().st_mtime_ns
    hit = _cache.get(str(p))
    if hit and hit[0] == stamp:
        return hit[1]
    try:
        lib = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise SystemExit(f"{p.name} is not valid JSON: {e}") from None
    _cache[str(p)] = (stamp, lib)
    return lib


def manga(path=None):
    """The uploaded manga textures as {name: {"id": "rbxassetid://n", "grid": g, "cells": [...]}} (textures.json);
    the bundle puts them in CutsceneKit.VfxPresets.Manga, and a screen cue's image names one of them."""
    p = Path(path) if path else MANGA_PATH
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))["textures"]
    except (OSError, ValueError, KeyError) as e:
        raise SystemExit(f"{p} is missing or broken ({e}): run vfx/manga/make_manga.py and upload again") from None
    return {name: {"id": t["id"], "grid": t["grid"], "cells": t["cells"]} for name, t in raw.items()}


def names(lib=None):
    return sorted((lib or load())["presets"])


def elements(lib=None):
    return sorted((lib or load())["elements"])


def auras(lib=None):
    return sorted((lib or load())["auras"])


def budget(lib, name):
    preset = lib["presets"][name]
    out = {"particles": 0, "lights": 0, "highlights": 0, "parts": 0}
    for layer in preset["layers"]:
        kind = layer["kind"]
        if kind == "emit":
            out["particles"] += layer["count"]
        elif kind == "light":
            out["lights"] += 1
        elif kind in ("ring", "shape"):
            out["parts"] += 1
        elif kind in ("trail", "rocks"):
            out["parts"] += layer["count"]
        elif kind in ("bolt", "cracks"):
            out["parts"] += layer["count"] * layer["segments"] * 2
    return out


def aura_budget(lib, name):
    """Live particles an aura keeps up at full strength: rate x longest life, per emitter."""
    a = lib["auras"][name]
    w, s, e = a["wisps"], a["specks"], a.get("eyes")
    live = len(a["points"]) * w["rate"] * max(w["life"]) + s["rate"] * max(s["life"])
    if e:
        live += 2 * e["rate"] * e["life"]
    return round(live, 2)


def roles_used(lib=None):
    """Every palette role (not #rrggbb) the presets, screen effects and auras ask for."""
    lib = lib or load()
    found = set()

    def add(v):
        for r in (v if isinstance(v, list) else [v]):
            if isinstance(r, str) and not r.startswith("#"):
                found.add(r)

    for p in lib["presets"].values():
        for layer in p["layers"]:
            for key in ("role", "glow"):
                if key in layer:
                    add(layer[key])
        for s in p.get("screen") or []:
            if "tint" in s:
                add(s["tint"])
    for a in lib["auras"].values():
        for part in ("wisps", "specks", "outline", "eyes", "light"):
            if part in a and "role" in a[part]:
                add(a[part]["role"])
    return found


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _check(rule, v, lib):
    """None when v follows the rule, else what is wrong."""
    if isinstance(rule, tuple):
        return None if v in rule else f"must be one of {', '.join(rule)}"
    if rule == "num":
        return None if _num(v) else "must be a number"
    if rule in ("pos", "time"):
        ok = _num(v) and (v > 0 if rule == "pos" else v >= 0)
        return None if ok else ("must be a number > 0" if rule == "pos" else "must be a number of seconds >= 0")
    if rule == "unit":
        return None if _num(v) and 0 <= v <= 1 else "must be a number from 0 to 1"
    if rule == "int":
        return None if isinstance(v, int) and not isinstance(v, bool) and v >= 1 else "must be a whole number >= 1"
    if rule == "bool":
        return None if isinstance(v, bool) else "must be true or false"
    if rule == "vec":
        return None if isinstance(v, list) and len(v) == 3 and all(_num(x) for x in v) else "must be [x, y, z]"
    if rule == "pair":
        return None if isinstance(v, list) and len(v) == 2 and all(_num(x) for x in v) else "must be [from, to]"
    if rule == "texture":
        return None if v in lib["textures"] else f"must be one of the textures ({', '.join(sorted(lib['textures']))})"
    if rule in ("role", "material"):
        if rule == "material" and v == "ground":
            return None
        ok = isinstance(v, str) and (v in ROLES or (v.startswith("#") and HEX.match(v) is not None))
        return None if ok else f"must be a colour role ({', '.join(ROLES)}) or #rrggbb"
    if rule == "roles":
        if isinstance(v, list) and len(v) == 2:
            return _check("role", v[0], lib) or _check("role", v[1], lib)
        return _check("role", v, lib)
    if rule == "point":
        ok = isinstance(v, list) and len(v) in (2, 3) and all(_num(x) for x in v)
        return None if ok else "must be [x, y] (screen, 0-1) or [x, y, z] (studs from the anchor)"
    if rule == "follow":
        return None if isinstance(v, str) and FOLLOW.match(v) else "must be a role or role.Part, like player.Head"
    if rule == "image":
        ok = isinstance(v, str) and (v in manga() or ASSET_ID.match(v) is not None)
        return None if ok else f"must be a manga texture ({', '.join(sorted(manga()))}) or rbxassetid://<number>"
    if rule == "text":
        ok = isinstance(v, str) and 1 <= len(v) <= WORD_TEXT_MAX
        return None if ok else f"must be 1-{WORD_TEXT_MAX} characters"
    if rule == "stroke":
        return None if _num(v) and 0 <= v <= STROKE_MAX else f"must be 0-{STROKE_MAX} of the text size"
    if rule == "seq":
        if _num(v):
            return None
        ok = (isinstance(v, list) and 2 <= len(v) <= 8 and all(isinstance(k, list) and len(k) == 2 and _num(k[0])
                                                                and _num(k[1]) for k in v))
        if not ok:
            return "must be a number or 2-8 keys [[x, v], ...]"
        xs = [k[0] for k in v]
        if xs[0] != 0 or xs[-1] != 1 or xs != sorted(xs):
            return "keys must run from x = 0 to x = 1 in order"
        return None
    if rule == "curve":
        if _num(v) or (isinstance(v, list) and len(v) == 2 and all(_num(x) for x in v)):
            return None
        ok = isinstance(v, list) and len(v) >= 2 and all(
            isinstance(k, list) and len(k) in (2, 3) and _num(k[0]) and _num(k[1]) and (len(k) == 2 or k[2] in EASES)
            for k in v)
        if not ok:
            return "must be a number, [from, to] or keys [[t, v], [t, v, ease], ...]"
        ts = [k[0] for k in v]
        return None if ts == sorted(ts) and ts[0] >= 0 else "key times must start at 0 or later and never go back"
    raise ValueError(f"unknown rule {rule!r}")


def _fields(where, spec, item, lib):
    out = []
    for key, rule in spec.items():
        name = key.lstrip("!")
        if name not in item:
            if key.startswith("!"):
                out.append(f"{where}: {name} is missing")
            continue
        bad = _check(rule, item[name], lib)
        if bad:
            out.append(f"{where}: {name} {bad}")
    known = {k.lstrip("!") for k in spec} | {"kind", "about"}
    out += [f"{where}: unknown field {k!r}" for k in item if k not in known]
    return out


def validate(lib):
    problems = []
    for key in ("textures", "elements", "presets", "auras"):
        if not isinstance(lib.get(key), dict) or not lib[key]:
            return [f"presets.json needs a non-empty {key!r} object"]
    for name, path in lib["textures"].items():
        if not isinstance(path, str) or ENGINE_TEXTURE.match(path) is None:
            users = [f"preset {pn} layer {i} (field texture)" for pn, pr in lib["presets"].items() if isinstance(pr, dict)
                     for i, ly in enumerate(pr.get("layers") or [], 1) if isinstance(ly, dict) and ly.get("texture") == name]
            used = f"; used by {', '.join(users[:4])}" if users else ""
            problems.append(f"texture {name}: {path!r} is not an engine texture (engine textures only: "
                            f"rbxasset://textures/particles/<name>.dds or .png){used}")
    for name, pal in lib["elements"].items():
        for role in ("main", "hot", "dark", "glow", "spark", "debris", "accent"):
            if not (isinstance(pal.get(role), str) and HEX.match(pal[role])):
                problems.append(f"element {name}: {role} must be 6 hex digits")
    for name, p in lib["presets"].items():
        where = f"preset {name}"
        if not NAME.match(name):
            problems.append(f"{where}: names start with a capital and use letters and digits (a marker value)")
        if not (_num(p.get("life")) and 0 < p["life"] <= PRESET_LIFE):
            problems.append(f"{where}: life must be more than 0 and at most {PRESET_LIFE} s")
        if not (isinstance(p.get("extent"), list) and len(p["extent"]) == 2 and all(_num(x) and x > 0 for x in p["extent"])):
            problems.append(f"{where}: extent must be [radius, height] in studs (the film set draws it)")
        layers = p.get("layers")
        if not isinstance(layers, list) or not layers:
            problems.append(f"{where}: needs layers")
            continue
        for i, layer in enumerate(layers, 1):
            kind = layer.get("kind") if isinstance(layer, dict) else None
            if kind not in SPEC:
                problems.append(f"{where} layer {i}: kind must be one of {', '.join(KINDS)}")
                continue
            problems += _fields(f"{where} layer {i} ({kind})", SPEC[kind], layer, lib)
            if kind == "shape" and layer.get("shape") == "column" and "h" not in layer:
                problems.append(f"{where} layer {i} (shape): a column needs h")
            if kind == "rocks":
                need = {"eject": ("speed", "up", "gravity"), "rim": ("rise", "tilt"), "lift": ("lift", "rise", "hang")}
                problems += [f"{where} layer {i} (rocks): {layer.get('mode')} needs {f}"
                             for f in need.get(layer.get("mode"), ()) if f not in layer]
            start = layer.get("t", 0) if _num(layer.get("t", 0)) else 0
            if kind == "emit" and isinstance(layer.get("life"), list) and all(_num(x) for x in layer["life"]):
                end = start + (layer.get("over", 0) if _num(layer.get("over", 0)) else 0) + max(layer["life"])
            else:
                end = start + layer["life"] if _num(layer.get("life")) else 0
            if _num(p.get("life")) and end > p["life"] + 1e-6:
                problems.append(f"{where} layer {i} ({kind}): lasts until {end:g} s, after the preset's life "
                                f"({p['life']:g} s); its particles would vanish early")
        for i, s in enumerate(p.get("screen") or [], 1):
            problems += _fields(f"{where} screen {i}", SCREEN_SPEC, s, lib)
        b = budget(lib, name) if not any(x.startswith(where + " layer") for x in problems) else None
        if b:
            if b["particles"] > PRESET_PARTICLES:
                problems.append(f"{where}: {b['particles']} particles (at most {PRESET_PARTICLES})")
            if b["lights"] > PRESET_LIGHTS:
                problems.append(f"{where}: {b['lights']} lights (spec 7: at most {PRESET_LIGHTS} per effect)")
            if b["parts"] > PRESET_PARTS:
                problems.append(f"{where}: {b['parts']} parts (at most {PRESET_PARTS})")
    for name, a in lib["auras"].items():
        where = f"aura {name}"
        try:
            if not set(a["points"]) <= set(AURA_POINTS):
                problems.append(f"{where}: points must be from {', '.join(AURA_POINTS)}")
            if a["specks"]["point"] not in AURA_POINTS:
                problems.append(f"{where}: specks.point must be one of {', '.join(AURA_POINTS)}")
            for part in ("wisps", "specks"):
                if _check("texture", a[part]["texture"], lib):
                    problems.append(f"{where}: {part}.texture must be one of the textures")
            if a.get("powerDown") not in lib["presets"]:
                problems.append(f"{where}: powerDown must name a preset")
            live = aura_budget(lib, name)
            if live > AURA_PARTICLES:
                problems.append(f"{where}: keeps {live} particles alive (at most {AURA_PARTICLES})")
        except (KeyError, TypeError) as e:
            problems.append(f"{where}: incomplete ({e!r})")
    return problems


def luau(lib=None):
    """The source of CutsceneKit.VfxPresets."""
    lib = lib or load()
    data = {"Textures": lib["textures"], "Elements": lib["elements"], "Presets": lib["presets"], "Auras": lib["auras"],
            "Manga": manga()}
    # compact JSON, decoded once when the module loads: smaller than a Luau table literal, and exactly the numbers in
    # presets.json
    text = json.dumps(data, separators=(",", ":"), sort_keys=True)
    return ("-- VfxPresets: generated from vfx/presets.json by kit/vfxlib.py; edit the JSON, not this module.\n"
            "-- Method by fwjelaa (FWJ STUDIOS).\n"
            'return game:GetService("HttpService"):JSONDecode(' + long_string(text) + ")\n")


def fwjelaa_elements(path=None):
    """fwjelaa-vfx's FwjelaaVFX.Elements as {name: {role: "rrggbb"}} (the drift guard reads it; never edited)."""
    src = Path(path or FWJELAA_VFX).read_text(encoding="utf-8")
    block = src[src.index("FwjelaaVFX.Elements = {"):]
    block = block[:block.index("\n}\n")]
    out = {}
    for line in block.split("\n"):
        m = re.match(r"\s*(\w+) = \{(.*)\},", line)
        if m:
            out[m.group(1)] = {r: "%02x%02x%02x" % (int(a), int(b), int(c))
                               for r, a, b, c in re.findall(r"(\w+) = rgb\((\d+), (\d+), (\d+)\)", m.group(2))}
    return out


def report(lib=None):
    lib = lib or load()
    problems = validate(lib)
    lines = [f"{len(lib['presets'])} presets, {len(lib['auras'])} auras, {len(lib['elements'])} elements, "
             f"{len(lib['textures'])} textures"]
    if not any(p.startswith("preset") for p in problems):
        for name in names(lib):
            b = budget(lib, name)
            lines.append(f"  {name:<10} {lib['presets'][name]['life']:>4} s  particles {b['particles']:>3}  "
                         f"lights {b['lights']}  parts {b['parts']:>3}")
    for name in auras(lib):
        if not any(p.startswith(f"aura {name}") for p in problems):
            lines.append(f"  aura {name}: about {aura_budget(lib, name)} live particles")
    lines += [f"FIX  {p}" for p in problems]
    lines.append("VFX LIBRARY: " + ("ok" if not problems else f"{len(problems)} to fix"))
    return problems, lines
