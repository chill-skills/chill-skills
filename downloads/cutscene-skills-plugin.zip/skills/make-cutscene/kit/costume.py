"""Costumes for adapted characters (spec 14): when a cutscene adapts a character from a reference (anime, manhwa, a
film, a comic), the cast is dressed as that character, in R15 and in R6. Method by fwjelaa (FWJ STUDIOS).

A role wears a costume when beats.json gives it  "model": "costume". For an NPC the costume is the model (built as R15
and R6; a creature is one model). For the player it becomes Config.Costume: the player's local copy wears it for the
scene and their own avatar is never changed. The spec is cutscenes/<id>/cast/<role>.json:

  humanoid  {version, role, character, source, kind: "humanoid",
             body:    {head, torso, left_arm, right_arm, left_leg, right_leg: "#rrggbb"}    BodyColors
             film:    {region: "#rrggbb"}   how a region looks on the film set where clothing covers it (optional)
             scale:   {height, width, depth, head}    R15 only (R6 does not scale)
             catalog: [{slot, id, type, name, creator, why, film?}]    real Roblox avatar-catalog items, by id: found
                      by searching the marketplace (py kit/run.py costume search "keyword"), never bought, never
                      uploaded; type is the item's catalog asset type, why says how it matches the reference, film
                      ("#rrggbb", optional) how it looks on the Blender film set (clothing paints the regions it
                      covers, an accessory is a coarse box on its attachment); film never reaches Studio
             props:   [{name, at, parts, why, film?}]    held objects the catalog doesn't have (a sword, a staff),
                      built from shapes in a hand: at is RightGripAttachment or LeftGripAttachment, parts are shaped
                      like a creature's (with an offset from the grip), why says what it is in the reference, film
                      ("#rrggbb", optional) how it looks on the film set; both rigs hold it, the way a Roblox Tool is
                      held (HOLD)
             likeness: {look: seconds into the scene, ref: [{video: s | panel: "ref/panel_NN.png", crop?: [x0, y0, x1, y1]}]}}
  creature  {version, role, character, source, kind: "creature", stand, root: [x, y, z],
             parts:  {name: {shape, size, color, material?, transparency?, light?}}
             joints: [[motor, parent, child, C0, C1], ...]  parents first, the first one from HumanoidRootPart
             feet: [parts on the floor], core?: [parts], pairs?: [[a, b]], likeness}

Spec 14.3 (TJ): a HUMANOID is dressed only with catalog items. Hair, hats, armour and anything worn built from parts
are refused for a humanoid (the validator says to search the marketplace instead); built parts are for creatures and
props the catalog does not have, such as a dragon or a cat. A humanoid's held prop (ledger 2b) is such a prop: a
catalog item can't sit in a hand, so a sword or a staff in the hand is built from shapes, at a hand grip only.

An offset (C0, C1 too) is [x, y, z] or [x, y, z, rx, ry, rz]: CFrame.new(x, y, z) * CFrame.Angles(rx, ry, rz), studs
and degrees, in the frame of the part (joints: child = parent * C0 * C1^-1, like a Motor6D). Nothing from outside the
place is ever brought in: shapes are Roblox's own, catalog items are referenced by id, and a key that would bring a
mesh, texture, image or file in is refused.

    py kit/run.py costume <id>               check every cast/<role>.json and write the creatures' rigs/<role>.json
    py kit/run.py costume <id> --new <role> --kind humanoid|creature --character "Name" --source "credit line"
    py kit/run.py costume search "samurai helmet"    read-only search of the public catalog: id, type, price, name
"""
import email.utils
import http.client
import json
import math
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

import clip
import rigcap
import schema
import workspace

VERSION = 1
KINDS = ("humanoid", "creature")
# slot -> the catalog asset types an item for it may have (Roblox's AssetType names)
SLOT_TYPES = {
    "hair": ("HairAccessory",), "hat": ("Hat",), "face_acc": ("FaceAccessory",), "neck": ("NeckAccessory",),
    "shoulders": ("ShoulderAccessory",), "front": ("FrontAccessory",), "back": ("BackAccessory",),
    "waist": ("WaistAccessory",), "shirt": ("Shirt",), "pants": ("Pants",), "tshirt": ("TShirt",), "face": ("Face",),
    "layered_shirt": ("TShirtAccessory", "ShirtAccessory"), "layered_pants": ("PantsAccessory", "ShortsAccessory"),
    "layered_jacket": ("JacketAccessory", "SweaterAccessory"), "layered_skirt": ("DressSkirtAccessory",),
    "left_shoe": ("LeftShoeAccessory",), "right_shoe": ("RightShoeAccessory",)}
SLOTS = tuple(SLOT_TYPES)
SINGLE = ("shirt", "pants", "tshirt", "face")  # one item each; the accessory slots take several
# the catalog search API reports assetType as a number
ASSET_TYPE_NAMES = {2: "TShirt", 8: "Hat", 11: "Shirt", 12: "Pants", 18: "Face", 41: "HairAccessory",
                    42: "FaceAccessory", 43: "NeckAccessory", 44: "ShoulderAccessory", 45: "FrontAccessory",
                    46: "BackAccessory", 47: "WaistAccessory", 64: "TShirtAccessory", 65: "ShirtAccessory",
                    66: "PantsAccessory", 67: "JacketAccessory", 68: "SweaterAccessory", 69: "ShortsAccessory",
                    70: "LeftShoeAccessory", 71: "RightShoeAccessory", 72: "DressSkirtAccessory"}
SEARCH_URL = "https://catalog.roblox.com/v1/search/items/details"
# the catalog API takes only these page sizes; measured 2026-11-08: 50, 60, 100 and 120 answer 400 "Allowed values:
# 10, 28, 30" (field "limit")
SEARCH_LIMITS = (10, 28, 30)
USER_AGENT = "fwjelaa-cutscene-kit"
SEARCH_TIMEOUT = 20  # seconds
# a busy catalog (HTTP 429, or a 5xx) is asked again after these waits (seconds); its Retry-After wins when it sends
# one, and a Retry-After over RETRY_AFTER_MAX is not waited for (the search stops and says when to try again)
SEARCH_BACKOFF = (1, 2, 4)
RETRY_AFTER_MAX = 30
# search --type: classic clothing has its own catalog category; the hair/accessory subcategories answer 400, so those
# are searched by keyword and the result is filtered by asset type here
SEARCH_CATEGORY = {"shirt": ("Clothing", "ClassicShirts"), "pants": ("Clothing", "ClassicPants"),
                   "tshirt": ("Clothing", "ClassicTShirts")}
SEARCH_FILTER = {slot: types for slot, types in SLOT_TYPES.items() if slot not in SEARCH_CATEGORY}
# Rules for the Studio builder (Task 5), measured in spike S16/S17: read them from here
BUILD = {
    "handle_attachment_named_like_body_attachment": True,  # an Accessory without a Handle Attachment is re-welded to the Head
    "set_accessories_wipe": False,  # HumanoidDescription:SetAccessories(list, false): true wipes the slot strings
    "note": "give a built Accessory's Handle an Attachment named like the body attachment (AccessoryWeld C0 = its "
            "CFrame, C1 = the body attachment's); call SetAccessories(layered, false), never true"}
SEARCH_MAX_BYTES = 1_000_000  # a catalog page is far smaller; never read more
MAX_ACCESSORIES = 10  # Roblox's avatar limit
# R6 renders only classic 2D clothing: these layered slots need a classic Shirt (torso) or Pants (legs) beside them
LAYERED_TORSO = ("layered_shirt", "layered_jacket")
LAYERED_LEGS = ("layered_pants", "layered_skirt")
LAYERED = LAYERED_TORSO + LAYERED_LEGS + ("left_shoe", "right_shoe")  # worn on R15 only
REGIONS = ("head", "torso", "left_arm", "right_arm", "left_leg", "right_leg")
SCALES = {"height": (0.9, 1.05), "width": (0.7, 1.0), "depth": (0.7, 1.0), "head": (0.95, 1.0)}
SHAPES = ("block", "sphere", "cylinder", "wedge")
MATERIALS = ("SmoothPlastic", "Plastic", "Neon", "Metal", "Foil", "Fabric", "Leather", "Wood", "Slate", "Rock",
             "Granite", "Marble", "Basalt", "Glass", "Ice")
OUTSIDE = ("mesh", "texture", "image", "decal", "file", "url", "upload", "asset")  # words in keys that bring art in
KEYS = {"humanoid": {"version", "role", "character", "source", "kind", "body", "film", "scale", "catalog", "props",
                     "built", "likeness", "notes"},  # "built" is a key only so the validator can refuse it by name
        "creature": {"version", "role", "character", "source", "kind", "stand", "root", "parts", "joints", "feet",
                     "core", "pairs", "likeness", "notes"}}
PART_KEYS = {"shape", "size", "offset", "color", "material", "transparency", "light"}
CATALOG_KEYS = {"slot", "id", "type", "name", "creator", "why", "price", "film"}
# A humanoid's held props (ledger 2b): built shapes, only in a hand, only for held objects (weapons, tools, a staff)
PROP_KEYS = {"name", "at", "parts", "why", "film"}
GRIPS = ("RightGripAttachment", "LeftGripAttachment")
MAX_PROP_PARTS = 12
PROP_SIDE = 8.0  # studs: the longest side of one part of a held prop
PROP_REACH = 8.0  # studs: how far a part's centre may sit from the grip
# A prop is held the way a Roblox Tool is, on both rigs: at the measured grip point, turned (-90, 0, 0) from the hand
# (an R6 Tool's RightGrip C0 is CFrame.new(0, -1, 0) * Angles(-90, 0, 0)). R15's grip attachments are turned so already;
# R6's are not (spike S16), so without this one spec would point the blade forward on R15 and up the arm on R6. A
# prop's +Y runs out of the top of the fist (forward with the arm down), +Z up the forearm.
HOLD = (-90, 0, 0)
MARKET = ("search the marketplace for the real item instead (py kit/run.py costume search \"keyword\"), compare its "
          "thumbnail with the reference, and list it under catalog with its id, type and why")
ROLE = schema.ROLE
HEX = re.compile(r"^#[0-9a-fA-F]{6}\Z")
NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,39}\Z")
ROOT = "HumanoidRootPart"
STAND_TOL = 0.05  # studs a creature's feet may sit off the floor under its stand
MAX_CREATURE = 40
LINEUP = [600, 0, 600, 0]  # where `studio <id> costume-look` stands the models (x, y, z, yaw): far from every demo set

# Accessory attachments of a default R15 and R6 body: (part, (x, y, z), (rx, ry, rz)) from the part's centre. These are
# the positions spike S16 measured (notes/spike-2b.md); only the R15 numbers move with scale (R6 never scales). The film
# set puts stand-ins for a legacy spec's built parts there, Studio uses the model's own.
ATTACH = {  # measured, spike S16b (notes/spike-2b.md): default-scale bodies; the R6 grips are not turned
    "HatAttachment": {"R15": ("Head", (0, 0.59, 0), (0, 0, 0)), "R6": ("Head", (0, 0.6, 0), (0, 0, 0))},
    "HairAttachment": {"R15": ("Head", (0, 0.59, 0), (0, 0, 0)), "R6": ("Head", (0, 0.6, 0), (0, 0, 0))},
    "FaceFrontAttachment": {"R15": ("Head", (0, 0, -0.581), (0, 0, 0)), "R6": ("Head", (0, 0, -0.6), (0, 0, 0))},
    "FaceCenterAttachment": {"R15": ("Head", (0, -0.092, 0), (0, 0, 0)), "R6": ("Head", (0, 0, 0), (0, 0, 0))},
    "NeckAttachment": {"R15": ("UpperTorso", (0, 0.849, 0), (0, 0, 0)), "R6": ("Torso", (0, 1, 0), (0, 0, 0))},
    "BodyFrontAttachment": {"R15": ("UpperTorso", (0, -0.212, -0.502), (0, 0, 0)),
                            "R6": ("Torso", (0, 0, -0.5), (0, 0, 0))},
    "BodyBackAttachment": {"R15": ("UpperTorso", (0, -0.212, 0.502), (0, 0, 0)), "R6": ("Torso", (0, 0, 0.5), (0, 0, 0))},
    "LeftCollarAttachment": {"R15": ("UpperTorso", (-0.972, 0.849, 0), (0, 0, 0)), "R6": ("Torso", (-1, 1, 0), (0, 0, 0))},
    "RightCollarAttachment": {"R15": ("UpperTorso", (0.972, 0.849, 0), (0, 0, 0)), "R6": ("Torso", (1, 1, 0), (0, 0, 0))},
    "WaistFrontAttachment": {"R15": ("LowerTorso", (0, -0.2, -0.502), (0, 0, 0)),
                             "R6": ("Torso", (0, -1, -0.5), (0, 0, 0))},
    "WaistCenterAttachment": {"R15": ("LowerTorso", (0, -0.2, 0), (0, 0, 0)), "R6": ("Torso", (0, -1, 0), (0, 0, 0))},
    "WaistBackAttachment": {"R15": ("LowerTorso", (0, -0.2, 0.502), (0, 0, 0)), "R6": ("Torso", (0, -1, 0.5), (0, 0, 0))},
    "LeftShoulderAttachment": {"R15": ("LeftUpperArm", (0, 0.621, 0), (0, 0, 0)),
                               "R6": ("Left Arm", (0, 1, 0), (0, 0, 0))},
    "RightShoulderAttachment": {"R15": ("RightUpperArm", (0, 0.621, 0), (0, 0, 0)),
                                "R6": ("Right Arm", (0, 1, 0), (0, 0, 0))},
    "LeftGripAttachment": {"R15": ("LeftHand", (0, -0.158, 0), (-90, 0, 0)), "R6": ("Left Arm", (0, -1, 0), (0, 0, 0))},
    "RightGripAttachment": {"R15": ("RightHand", (0, -0.158, 0), (-90, 0, 0)),
                            "R6": ("Right Arm", (0, -1, 0), (0, 0, 0))},
    "LeftFootAttachment": {"R15": ("LeftFoot", (0.018, -0.16, -0.05), (0, 0, 0)), "R6": ("Left Leg", (0, -1, 0), (0, 0, 0))},
    "RightFootAttachment": {"R15": ("RightFoot", (-0.018, -0.16, -0.05), (0, 0, 0)),
                            "R6": ("Right Leg", (0, -1, 0), (0, 0, 0))},
}
# Which BodyColors region colours each part
REGION_PARTS = {
    "R15": {"Head": "head", "UpperTorso": "torso", "LowerTorso": "torso",
            **{f"{s}{p}": f"{s.lower()}_arm" for s in ("Right", "Left") for p in ("UpperArm", "LowerArm", "Hand")},
            **{f"{s}{p}": f"{s.lower()}_leg" for s in ("Right", "Left") for p in ("UpperLeg", "LowerLeg", "Foot")}},
    "R6": {"Head": "head", "Torso": "torso", "Right Arm": "right_arm", "Left Arm": "left_arm",
           "Right Leg": "right_leg", "Left Leg": "left_leg"},
}
# The film set's look of a marketplace-dressed character (spec 14.3: Studio wears the real items, the Blender film set
# only stands in for them, enough to frame and review shots). A catalog item's optional film colour paints the regions
# its clothing covers, in this order (later wins: layered over classic; R6 never builds layered clothing) ...
FILM_COVERS = {"shirt": ("torso",), "tshirt": ("torso",), "pants": ("left_leg", "right_leg"),
               "layered_shirt": ("torso",), "layered_jacket": ("torso", "left_arm", "right_arm"),
               "layered_pants": ("left_leg", "right_leg"), "layered_skirt": ("left_leg", "right_leg")}
# ... and an accessory stands in as one coarse box: slot -> (attachment, size, offset from the attachment [x, y, z])
SILHOUETTE = {
    "hair": ("HairAttachment", (1.3, 0.6, 1.3), (0, -0.15, 0.1)),
    "hat": ("HatAttachment", (1.4, 0.5, 1.4), (0, 0.2, 0)),
    "face_acc": ("FaceFrontAttachment", (0.9, 0.4, 0.15), (0, 0.1, -0.05)),
    "neck": ("NeckAttachment", (1.3, 0.35, 1.0), (0, 0, 0)),
    "shoulders": ("NeckAttachment", (2.3, 0.4, 1.1), (0, -0.1, 0)),
    "front": ("BodyFrontAttachment", (1.4, 1.2, 0.2), (0, 0, -0.1)),
    "back": ("BodyBackAttachment", (1.8, 2.6, 0.12), (0, -0.7, 0.12)),
    "waist": ("WaistCenterAttachment", (2.1, 0.4, 1.15), (0, 0, 0)),
    "left_shoe": ("LeftFootAttachment", (0.8, 0.4, 1.2), (0, 0.2, 0)),
    "right_shoe": ("RightFootAttachment", (0.8, 0.4, 1.2), (0, 0.2, 0)),
}
SILHOUETTE_COLOR = "#7f7f7f"  # an accessory whose item has no film colour


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _hex(v):
    return isinstance(v, str) and HEX.match(v) is not None


def _vec3(v):
    return isinstance(v, list) and len(v) == 3 and all(_num(x) and x > 0 for x in v)


def _offset_ok(o):
    return o is None or (isinstance(o, list) and len(o) in (3, 6) and all(_num(x) for x in o))


def _cf(o):
    """[x, y, z(, rx, ry, rz)] -> a 12-number CFrame (clip.cframe: CFrame.new * CFrame.Angles, degrees)."""
    o = list(o or []) + [0.0] * 6
    return clip.cframe(*o[:6])


def hex3(color):
    """#rrggbb -> 3 hex digits, the film set's material names (filmset._material)."""
    return "".join(f"{round(int(color[i:i + 2], 16) / 17):x}" for i in (1, 3, 5))


def is_costume(c):
    return isinstance(c, dict) and c.get("model") == "costume"


def roles(b):
    """The roles beats.json dresses as an adapted character, in cast order."""
    return [role for role, c in (b.get("cast") or {}).items() if is_costume(c)]


def spec_path(root, role):
    return Path(root) / "cast" / f"{role}.json"


def _brings_in(key):
    """True when a key is one of the OUTSIDE words, whole: meshId, TextureID, image_url, files (not Curly_Tail)."""
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(key))
    for token in re.split(r"[^A-Za-z0-9]+", spaced):
        t = token.lower()
        for word in OUTSIDE:
            if t in (word, word + "s", word + "id", word + "ids", word + "url", word + "uri"):
                return True
    return False


def _outside(v, where):
    """[problems] for any key, at any depth, that would bring art in from outside the place."""
    out = []
    if isinstance(v, dict):
        for k, x in v.items():
            if _brings_in(k):
                out.append(f"{where}.{k}: a costume never brings in meshes, textures, images or files (spec 14: no "
                           "uploaded copies of someone else's art); build it from shapes or use a catalog item by id")
            out += _outside(x, f"{where}.{k}")
    elif isinstance(v, list):
        for i, x in enumerate(v):
            out += _outside(x, f"{where}[{i}]")
    return out


def _part(p, where, keys=PART_KEYS):
    if not isinstance(p, dict):
        return [f"{where} must be an object"]
    out = []
    extra = sorted(set(p) - keys)
    if extra:
        out.append(f"{where}: unknown keys {', '.join(extra)} (allowed: {', '.join(sorted(keys))})")
    if p.get("shape", "block") not in SHAPES:
        out.append(f"{where}.shape must be one of {', '.join(SHAPES)}")
    if not _vec3(p.get("size")):
        out.append(f"{where}.size must be 3 numbers above 0 (studs)")
    if not _offset_ok(p.get("offset")):
        out.append(f"{where}.offset must be [x, y, z] or [x, y, z, rx, ry, rz]")
    if not _hex(p.get("color")):
        out.append(f"{where}.color must be #rrggbb")
    if p.get("material", "SmoothPlastic") not in MATERIALS:
        out.append(f"{where}.material must be one of {', '.join(MATERIALS)}")
    tr = p.get("transparency", 0)
    if not (_num(tr) and 0 <= tr < 1):
        out.append(f"{where}.transparency must be from 0 to under 1")
    light = p.get("light")
    if light is not None:
        ok = (isinstance(light, dict) and set(light) <= {"color", "range", "brightness"} and _hex(light.get("color"))
              and _num(light.get("range", 8)) and 0 < light.get("range", 8) <= 60
              and _num(light.get("brightness", 1)) and 0 < light.get("brightness", 1) <= 10)
        if not ok:
            out.append(f"{where}.light must be {{color: #rrggbb, range: up to 60, brightness: up to 10}}")
    return out


def _colors(v, where):
    if v is None:
        return []
    if not isinstance(v, dict):
        return [f"{where} must be an object of region: #rrggbb"]
    out = [f"{where}.{k}: not a region ({', '.join(REGIONS)})" for k in v if k not in REGIONS]
    out += [f"{where}.{k} must be #rrggbb" for k, c in v.items() if k in REGIONS and not _hex(c)]
    return out


def _humanoid(spec, r6):
    out = _colors(spec.get("body"), "body") + _colors(spec.get("film"), "film")
    scale = spec.get("scale") or {}
    if not isinstance(scale, dict):
        out.append("scale must be an object")
        scale = {}
    for k, v in scale.items():
        if k not in SCALES:
            out.append(f"scale.{k}: not a scale ({', '.join(SCALES)})")
        elif not (_num(v) and SCALES[k][0] <= v <= SCALES[k][1]):
            out.append(f"scale.{k} must be {SCALES[k][0]}-{SCALES[k][1]} (Roblox's avatar limits)")
    catalog = spec.get("catalog") or []
    if not isinstance(catalog, list):
        return out + ["catalog must be a list"]
    singles = {}
    for i, item in enumerate(catalog, 1):
        w = f"catalog[{i}]"
        if not isinstance(item, dict):
            out.append(f"{w} must be an object")
            continue
        if "proxy" in item:
            out.append(f"{w}.proxy: a humanoid is dressed with the catalog item itself, not a stand-in built from "
                       f"parts; {MARKET}")
        extra = sorted(set(item) - CATALOG_KEYS - {"proxy"})
        if extra:
            out.append(f"{w}: unknown keys {', '.join(extra)}")
        slot = item.get("slot")
        if slot not in SLOTS:
            out.append(f"{w}.slot must be one of {', '.join(SLOTS)}")
        elif slot in SINGLE:
            singles[slot] = singles.get(slot, 0) + 1
        kind = item.get("type")
        if kind not in ASSET_TYPE_NAMES.values():
            out.append(f"{w}.type must be the catalog asset type ({', '.join(sorted(set(ASSET_TYPE_NAMES.values())))})")
        elif slot in SLOTS and kind not in SLOT_TYPES[slot]:
            out.append(f"{w}.type is {kind} but a {slot} slot takes {' or '.join(SLOT_TYPES[slot])}")
        if not (isinstance(item.get("id"), int) and not isinstance(item.get("id"), bool) and item["id"] > 0):
            out.append(f"{w}.id must be the catalog item's number")
        if "film" in item and not _hex(item["film"]):
            out.append(f"{w}.film must be #rrggbb (how the item looks on the film set)")
        for k, what in (("name", "what it is"), ("creator", "who made it"),
                        ("why", "how it matches the reference, in a few words")):
            if not (isinstance(item.get(k), str) and item[k].strip()):
                out.append(f"{w}.{k} is needed ({what}, for the notes)")
    out += [f"catalog: {n} {slot} items; a body wears one {slot}" for slot, n in singles.items() if n > 1]
    ids = [c.get("id") for c in catalog if isinstance(c, dict)]
    out += [f"catalog: id {i} is listed twice" for i in sorted({i for i in ids if ids.count(i) > 1}, key=str)]
    worn = [c for c in catalog if isinstance(c, dict) and c.get("slot") in SLOTS and c["slot"] not in SINGLE]
    if len(worn) > MAX_ACCESSORIES:
        out.append(f"catalog: {len(worn)} accessories; a Roblox avatar wears at most {MAX_ACCESSORIES}")
    if r6:
        slots = {c.get("slot") for c in catalog if isinstance(c, dict)}
        for covers, needs, part in ((LAYERED_TORSO, "shirt", "torso"), (LAYERED_LEGS, "pants", "legs")):
            if slots & set(covers) and needs not in slots:
                out.append(f"{part} is covered only by layered clothing ({', '.join(sorted(slots & set(covers)))}). "
                           "R6 doesn't render layered clothing: add a classic Shirt and Pants (search the marketplace "
                           "with type Shirt/Pants); the layered pieces stay as R15 extras. This character is acted on "
                           "R6 (the player always is, in the R6 cast)")
    out += _props(spec)
    built = spec.get("built")
    if built:
        names = [a.get("name") for a in built if isinstance(a, dict)] if isinstance(built, list) else []
        for i, name in enumerate(names, 1):
            out.append(f"built[{i}] ({name}): a humanoid is never dressed with parts built in the place; {MARKET}")
        if not names:
            out.append(f"built: a humanoid is never dressed with parts built in the place; {MARKET}")
    return out


def _props(spec):
    """[problems] for a humanoid's held props: a hand grip only, shapes like a creature's parts within PROP_SIDE and
    PROP_REACH of the grip, a why, an optional film colour, one prop per hand, each name once."""
    props = spec.get("props")
    if props is None:
        return []
    if not isinstance(props, list):
        return ["props must be a list of held props: {name, at, parts, why, film}"]
    out, names, hands = [], [], {}
    taken = set(REGION_PARTS["R15"]) | set(REGION_PARTS["R6"]) | {ROOT, "Humanoid"}  # the model's own children
    for i, prop in enumerate(props, 1):
        if not isinstance(prop, dict):
            out.append(f"props[{i}] must be an object: {{name, at, parts, why, film}}")
            continue
        name = prop.get("name")
        w = f"props[{i}] ({name})"
        extra = sorted(set(prop) - PROP_KEYS)
        if extra:
            out.append(f"{w}: unknown keys {', '.join(extra)} (allowed: {', '.join(sorted(PROP_KEYS))})")
        if not (isinstance(name, str) and NAME.match(name)) or name in taken:
            out.append(f"{w}.name must start with a letter (letters, digits, _) and not be a body part's name")
        names.append(name)
        if prop.get("at") not in GRIPS:
            out.append(f"{w}.at must be RightGripAttachment or LeftGripAttachment: a prop is held in a hand. Anything "
                       f"worn (hair, a hat, armour, a sheathed sword) is a catalog item: {MARKET}")
        else:
            hands.setdefault(prop["at"], []).append(str(name))
        parts = prop.get("parts")
        if not (isinstance(parts, list) and 1 <= len(parts) <= MAX_PROP_PARTS):
            out.append(f"{w}.parts must list 1-{MAX_PROP_PARTS} parts")
            parts = []
        for k, p in enumerate(parts, 1):
            found = _part(p, f"{w}.parts[{k}]")
            out += found
            if found:
                continue
            if max(p["size"]) > PROP_SIDE:
                out.append(f"{w}.parts[{k}].size: a held prop's part is at most {PROP_SIDE:g} studs a side")
            if math.dist((p.get("offset") or [0, 0, 0])[:3], (0, 0, 0)) > PROP_REACH:
                out.append(f"{w}.parts[{k}].offset: a held prop's part sits at most {PROP_REACH:g} studs from the grip")
        if not (isinstance(prop.get("why"), str) and prop["why"].strip()):
            out.append(f"{w}.why is needed (what it is in the reference: a held object the catalog doesn't have)")
        if "film" in prop and not _hex(prop["film"]):
            out.append(f"{w}.film must be #rrggbb (how the prop looks on the film set)")
    out += [f"props: {n} is named twice" for n in sorted({n for n in names if names.count(n) > 1}, key=str)]
    out += [f"props: {at} holds {' and '.join(who)}; a hand holds one prop" for at, who in hands.items() if len(who) > 1]
    return out


def _creature(spec):
    out = []
    if not (_num(spec.get("stand")) and spec["stand"] > 0):
        out.append("stand must be the HumanoidRootPart centre's height above the floor (studs)")
    if not _vec3(spec.get("root")):
        out.append("root must be the HumanoidRootPart's size, 3 numbers above 0")
    parts = spec.get("parts")
    if not (isinstance(parts, dict) and 1 <= len(parts) <= MAX_CREATURE):
        return out + [f"parts must be an object of 1-{MAX_CREATURE} parts"]
    for name, p in parts.items():
        if not NAME.match(str(name)) or name == ROOT:
            out.append(f"parts.{name}: a part name starts with a letter (letters, digits, _) and isn't {ROOT}")
        out += _part(p, f"parts.{name}", PART_KEYS - {"offset"})
    if "Head" not in parts:
        out.append("parts needs a Head: the camera checks frame each role by its Head")
    joints = spec.get("joints")
    if not isinstance(joints, list) or not joints:
        return out + ["joints must list [motor, parent, child, C0, C1] for every part"]
    placed, children = {ROOT}, []
    for i, j in enumerate(joints, 1):
        if not (isinstance(j, list) and len(j) == 5 and all(isinstance(x, str) for x in j[:3])):
            out.append(f"joints[{i}] must be [motor, parent, child, C0, C1]")
            continue
        if not (_offset_ok(j[3]) and _offset_ok(j[4]) and j[3] is not None and j[4] is not None):
            out.append(f"joints[{i}] ({j[0]}): C0 and C1 must be [x, y, z] or [x, y, z, rx, ry, rz]")
        if i == 1 and j[1] != ROOT:
            out.append(f"joints[1] must join {ROOT} to the body (it is the root joint the acting moves)")
        if j[1] not in placed:
            out.append(f"joints[{i}] ({j[0]}): {j[1]} has no joint yet (list parents before children)")
        if j[2] not in parts:
            out.append(f"joints[{i}] ({j[0]}): {j[2]} is not in parts")
        if j[2] in children:
            out.append(f"joints[{i}] ({j[0]}): {j[2]} has two joints")
        placed.add(j[2])
        children.append(j[2])
    out += [f"parts.{n} has no joint (every part needs one)" for n in parts if n not in children]
    feet = spec.get("feet")
    if not (isinstance(feet, list) and feet and all(f in parts for f in feet)):
        out.append("feet must list the parts that stand on the floor")
    for k in ("core",):
        if spec.get(k) is not None and not (isinstance(spec[k], list) and all(f in parts for f in spec[k])):
            out.append(f"{k} must list parts")
    pairs = spec.get("pairs")
    if pairs is not None and not (isinstance(pairs, list) and all(
            isinstance(p, list) and len(p) == 2 and all(x in parts for x in p) for p in pairs)):
        out.append("pairs must list [part, part] pairs that must not pass through each other")
    if not out:
        r = creature_rig(spec)
        gap = spec["stand"] - r["foot"]
        if abs(gap) > STAND_TOL:
            out.append(f"the feet sit {abs(gap):.2f} studs {'above' if gap > 0 else 'below'} the floor: set stand to "
                       f"{r['foot']:.2f}")
    return out


def _likeness(lk):
    if not isinstance(lk, dict):
        return ["likeness must be {look: seconds, ref: [...]}"]
    out = []
    if not (_num(lk.get("look")) and lk["look"] >= 0):
        out.append("likeness.look must be the time (s) where our preview shows this character well")
    refs = lk.get("ref")
    if not (isinstance(refs, list) and 1 <= len(refs) <= 2):
        return out + ["likeness.ref must list 1-2 reference pictures of the character"]
    for i, r in enumerate(refs, 1):
        w = f"likeness.ref[{i}]"
        ok = isinstance(r, dict) and ((_num(r.get("video")) and r["video"] >= 0 and "panel" not in r) or (
            isinstance(r.get("panel"), str) and r["panel"].startswith("ref/") and "video" not in r))
        if not ok:
            out.append(f"{w} must be {{video: seconds}} or {{panel: \"ref/panel_NN.png\"}}")
            continue
        crop = r.get("crop")
        if crop is not None and not (isinstance(crop, list) and len(crop) == 4 and all(_num(x) for x in crop)
                                     and 0 <= crop[0] < crop[2] <= 1 and 0 <= crop[1] < crop[3] <= 1):
            out.append(f"{w}.crop must be [x0, y0, x1, y1], fractions of the picture with x0 < x1 and y0 < y1")
    return out


def validate(spec, role=None, rig=None):
    """[problems] for one costume spec (role: the file's role, cast/<role>.json; rig: the cast's rig for that role).
    The player always counts as R6-capable (the R6 cast swaps the player's rig), so does an NPC whose rig is R6."""
    if not isinstance(spec, dict):
        return ["the costume must be one JSON object"]
    out = []
    if spec.get("version") != VERSION:
        out.append(f"version must be {VERSION}")
    kind = spec.get("kind")
    if kind not in KINDS:
        return out + ["kind must be humanoid or creature"]
    if not (isinstance(spec.get("role"), str) and ROLE.match(spec["role"])):
        out.append("role must be player, target or npc1..npc99")
    elif role is not None and spec["role"] != role:
        out.append(f"role is {spec['role']} but the file is cast/{role}.json")
    if spec.get("role") == "player" and kind != "humanoid":
        out.append("the player wears a humanoid costume (it plays the player's R15 and R6 clips)")
    for k, why in (("character", "the name of the character it adapts"),
                   ("source", "the credit line of the reference: title, author, licence")):
        if not (isinstance(spec.get(k), str) and spec[k].strip()):
            out.append(f"{k} is needed: {why}")
    extra = sorted(set(spec) - KEYS[kind])
    if extra:
        out.append(f"unknown keys for a {kind}: {', '.join(extra)}")
    out += _outside(spec, "costume")
    r6 = True  # every humanoid is built as R15 and R6 (the player and each NPC), and R6 renders only classic clothing
    out += _humanoid(spec, r6) if kind == "humanoid" else _creature(spec)
    if spec.get("likeness") is not None:
        out += _likeness(spec["likeness"])
    return out


def load(root, role, rig=None):
    path = spec_path(root, role)
    if not path.exists():
        raise SystemExit(f"no cast/{role}.json: py kit/run.py costume <id> --new {role} ...")
    spec = workspace.read_json(path)
    problems = validate(spec, role, rig)
    if problems:
        raise SystemExit(f"cast/{role}.json:\n  - " + "\n  - ".join(problems))
    return spec


def foot(r, feet):
    """How far the lowest corner of the feet sits below the root at rest (the creature's real stand)."""
    frames = rigcap.rest_frames(r)
    low = min(rigcap.point(frames[f], [sx * r["parts"][f][0] / 2, sy * r["parts"][f][1] / 2, sz * r["parts"][f][2] / 2])[1]
              for f in feet for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1))
    return round(-low, 4)


def creature_rig(spec):
    """A creature spec -> rigs/<role>.json, in rigcap's captured-rig format plus its own feet, core and pairs, so the
    film set registers it as a make-anim rig (filmset.register) and Studio builds the same joints."""
    parts = {ROOT: list(spec["root"])}
    parts.update({n: list(p["size"]) for n, p in spec["parts"].items()})
    r = {"v": 1, "rigType": "R15", "creature": True, "root": ROOT,
         "hipHeight": round(spec["stand"] - spec["root"][1] / 2, 4), "parts": parts,
         "colors": {n: p["color"].lstrip("#") for n, p in spec["parts"].items()},
         "joints": [[j[0], j[1], j[2], _cf(j[3]), _cf(j[4])] for j in spec["joints"]],
         "feet": list(spec["feet"]), "core": list(spec.get("core") or []),
         "pairs": [list(p) for p in spec.get("pairs") or []], "role": spec["role"], "stand": float(spec["stand"])}
    r["foot"] = foot(r, r["feet"])
    return r


def items_on(spec, rigtype):
    """What the given rig wears and holds: the catalog items of a spec (as written, or from install_specs) that it wears
    (catalog_for), then the held props, which both rigs hold (each marked "held")."""
    items = [dict(c, rigs=item_rigs(c.get("slot"))) for c in spec.get("catalog") or [] if isinstance(c, dict)]
    held = [dict(p, rigs=["R15", "R6"], held=True) for p in spec.get("props") or [] if isinstance(p, dict)]
    return catalog_for({"catalog": items}, rigtype) + held


def hides_default_face(spec, rigtype):
    """True when the rig is meant to wear a face accessory and no classic face: the spec-level intent the film set
    follows (filmset.costume_look hides its R6 stand-in's drawn face). Studio makes the head's default face (the
    classic smile, a Decal) transparent only when the face accessory also arrived on the built model (Costume.humanoid,
    ledger 2b): it showed through a see-through one on R6 (AyanokojiFight). One the catalog left off keeps the face.
    A classic face is always kept."""
    slots = {c.get("slot") for c in items_on(spec, rigtype)}
    return spec.get("kind") == "humanoid" and "face_acc" in slots and "face" not in slots


def colors(spec, rigtype):
    """{part: #rrggbb} for the film set's stand-in parts. A humanoid: body colours, then the regions' film colours,
    then the film colour of each clothing item the rig wears (FILM_COVERS order: R6 shows its classic items only)."""
    if spec.get("kind") == "creature":
        return {n: p["color"] for n, p in spec["parts"].items()}
    look = dict(spec.get("body") or {})
    look.update(spec.get("film") or {})
    items = items_on(spec, rigtype)
    for slot, regions in FILM_COVERS.items():
        for c in items:
            if c.get("slot") == slot and c.get("film"):
                look.update({region: c["film"] for region in regions})
    return {part: look[region] for part, region in REGION_PARTS[rigtype].items() if region in look}


def _held(prop, rigtype, body):
    """A held prop's stand-ins: each of its parts as a box at its offset from the grip, held the way a Tool is (HOLD),
    in the prop's film colour (else the part's own). The grip point moves with the R15 body's scale; the prop keeps its
    size (Studio builds it on the scaled body). Each box names its prop ("prop")."""
    part, pos, _ = ATTACH[prop["at"]][rigtype]
    grip = clip.cframe(*[p * f for p, f in zip(pos, body)], *HOLD)
    return [{"name": f"{prop['name']}_{i}", "part": part, "prop": prop["name"],
             "cf": rigcap.mul(grip, _cf(p.get("offset"))), "size": list(p["size"]),
             "color": prop.get("film") or p["color"], "shape": p.get("shape", "block")}
            for i, p in enumerate(prop["parts"], 1)]


def silhouettes(spec, rigtype):
    """The film set's stand-ins for a marketplace-dressed humanoid's accessories, like proxies(): one coarse box per
    item the rig wears whose slot has a SILHOUETTE, on its attachment, in the item's film colour (else a neutral one).
    Clothing has no box: colors() paints it. On R15 the boxes follow the costume's scale the way Roblox scales the body
    (x by width, y by height, z by depth, the head by head; spike S16); R6 never scales. The SILHOUETTE attachments are
    unturned, so the offset scales the same way. A held prop stands in as its own parts in the hand (_held)."""
    if spec.get("kind") != "humanoid":
        return []
    scale = (spec.get("scale") or {}) if rigtype == "R15" else {}
    body = tuple(scale.get(k, 1.0) for k in ("width", "height", "depth"))
    out = []
    for c in items_on(spec, rigtype):
        if c.get("held"):
            out += _held(c, rigtype, body)
            continue
        if c.get("slot") not in SILHOUETTE or c.get("proxy"):
            continue
        at, size, offset = SILHOUETTE[c["slot"]]
        part, pos, rot = ATTACH[at][rigtype]
        k = (scale.get("head", 1.0),) * 3 if part == "Head" else body
        out.append({"name": f"{c['slot']}_{c.get('id')}", "part": part,
                    "cf": rigcap.mul(clip.cframe(*[p * f for p, f in zip(pos, k)], *rot),
                                     _cf([o * f for o, f in zip(offset, k)])),
                    "size": [s * f for s, f in zip(size, k)], "color": c.get("film") or SILHOUETTE_COLOR,
                    "shape": "block"})
    return out


def proxies(spec, rigtype):
    """The film set's accessory stand-ins: [{name, part, cf (12 numbers from the part's centre), size, color, shape}]."""
    if spec.get("kind") != "humanoid":
        return []
    items = [(a["name"], a["at"], a["parts"]) for a in spec.get("built") or []]
    items += [(f"{c['slot']}_{c['id']}", c["proxy"]["at"], [c["proxy"]]) for c in spec.get("catalog") or []
              if c.get("proxy")]
    out = []
    for name, at, parts in items:
        part, pos, rot = ATTACH[at][rigtype]
        base = clip.cframe(*pos, *rot)
        for i, p in enumerate(parts, 1):
            out.append({"name": f"{name}_{i}", "part": part, "cf": rigcap.mul(base, _cf(p.get("offset"))),
                        "size": list(p["size"]), "color": p["color"], "shape": p.get("shape", "block")})
    return out


def derives_r6(root, role, c):
    """The R15 master gets a derived R6 clip: the player always, and an NPC acting a humanoid costume on R15 (it is
    built as R15 and R6, and the cast follows the player's rig). A creature has one rig, and an NPC whose own rig is R6
    is its R6 master: one clip, <id>_<role>_R6, nothing derived (filmset.clip_plan refuses a derived name that takes a
    master's)."""
    if role == "player":
        return True
    if not is_costume(c) or (c.get("rig") or "R15") != "R15":
        return False
    path = spec_path(root, role)
    return path.exists() and workspace.read_json(path).get("kind") == "humanoid"


def item_rigs(slot):
    """The rigs a catalog item is worn on: layered clothing and shoes only render on R15."""
    return ["R15"] if slot in LAYERED else ["R15", "R6"]


def catalog_for(spec, rig):
    """The catalog items of an install spec (install_specs) that the given rig wears."""
    return [c for c in spec.get("catalog") or [] if rig in c.get("rigs", ["R15", "R6"])]


def install_specs(root, b):
    """{role: spec} for SceneInstall and costume-look: what Studio builds. Credits, likeness, notes, the film look and
    each item's creator, why and film colour stay on disk. Every catalog item gains "rigs": ["R15", "R6"] or ["R15"],
    so the R15 copy wears catalog_for(spec, "R15") and the R6 copy catalog_for(spec, "R6") (classic Shirt/Pants/
    accessories only). Held props go as {name, at, parts} (both rigs hold them); a spec without props sends none."""
    out = {}
    for role in roles(b):
        full = load(root, role, b["cast"][role].get("rig"))
        spec = {k: v for k, v in full.items() if k not in ("likeness", "notes", "source", "film", "props")}
        if spec.get("kind") == "humanoid":
            spec["catalog"] = [dict({k: v for k, v in c.items() if k not in ("why", "creator", "film")},
                                    rigs=item_rigs(c["slot"])) for c in spec.get("catalog") or []]
            props = [{k: v for k, v in p.items() if k not in ("why", "film")} for p in full.get("props") or []]
            if props:
                spec["props"] = props
        out[role] = spec
    return out


def check(root, b):
    root = Path(root)
    out = []
    worn = roles(b)
    for role in worn:
        path = spec_path(root, role)
        if not path.exists():
            out.append(f"{role} wears a costume but cast/{role}.json is missing: py kit/run.py costume {b.get('id')} "
                       f"--new {role} --kind humanoid --character \"Name\" --source \"credit line\"")
            continue
        spec = workspace.read_json(path)
        out += [f"cast/{role}.json: {x}" for x in validate(spec, role, b["cast"][role].get("rig"))]
        if role == "player" and b.get("kind") not in ("story", "intro"):
            out.append("the player wears a costume only in story and intro scenes (Config.Costume: the player acts as "
                       "a local copy there)")
        c = b["cast"][role]
        if role != "player" and spec.get("kind") == "humanoid" and c.get("rig", "R15") != "R15":
            out.append(f"cast.{role}.rig must be R15 (or unset): a humanoid costume is acted on R15 and its R6 clip is "
                       "derived")
        elif spec.get("kind") == "creature" and c.get("rig", "R15") != "R15":
            out.append(f"cast.{role}.rig must be R15 (or unset): Studio builds a creature as one R15-typed rig and "
                       "plays its R15 clip on it")
    folder = root / "cast"
    for p in sorted(folder.glob("*.json")) if folder.exists() else []:
        if p.stem not in worn:
            out.append(f"cast/{p.name} is not worn: set cast.{p.stem}.model to \"costume\" in beats.json, or delete it")
    return out


def gate_problems(root, b, scene):
    """Kit checks (spec 8 gate 1) for costumes: valid specs, a likeness entry for the sheet, R6 clips for humanoids."""
    root = Path(root)
    out = check(root, b)
    length = scene.get("length", 0)
    for role in roles(b):
        path = spec_path(root, role)
        if not path.exists():
            continue
        spec = workspace.read_json(path)
        lk = spec.get("likeness")
        if not isinstance(lk, dict) or not lk.get("ref"):
            out.append(f"cast/{role}.json has no likeness (a look time and 1-2 reference pictures): the likeness sheet "
                       "needs it")
        elif not (_num(lk.get("look")) and 0 <= lk["look"] <= length):
            out.append(f"cast/{role}.json likeness.look must be a time inside the scene (0-{length} s)")
        if spec.get("kind") == "humanoid" and not spec.get("catalog"):
            out.append(f"cast/{role}.json has no catalog items: a character is dressed from the marketplace (py kit/run.py "
                       "costume search \"keyword\")")
        if spec.get("kind") == "creature" and not validate(spec, role):
            rig_path = root / "rigs" / f"{role}.json"
            if not rig_path.exists():
                out.append(f"rigs/{role}.json is missing: py kit/run.py costume {b.get('id')}")
            elif workspace.read_json(rig_path) != json.loads(json.dumps(creature_rig(spec))):
                out.append(f"rigs/{role}.json is out of step with cast/{role}.json: py kit/run.py costume {b.get('id')}")
        if role != "player" and spec.get("kind") == "humanoid" and role not in ((scene.get("clips") or {}).get("R6") or {}):
            out.append(f"{role} is built as R15 and R6 but the export has no R6 clip for it: export again")
    return out


def _open(req, timeout=None):
    return urllib.request.urlopen(req, timeout=timeout)


def _retry_after(e):
    """The seconds an HTTP error's Retry-After asks for (a number or an HTTP date), else None."""
    value = str((e.headers.get("Retry-After") if e.headers is not None else None) or "").strip()
    if value.isdigit():
        return int(value)
    try:
        when = email.utils.parsedate_to_datetime(value)
    except (TypeError, ValueError, IndexError):
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    return max(0, math.ceil((when - datetime.now(timezone.utc)).total_seconds()))


def _refused(e, limit):
    """A 4xx answer in words: what the catalog refused (it names the field and what it allows), never the network."""
    try:
        errors = json.loads(e.read(SEARCH_MAX_BYTES).decode("utf-8")).get("errors") or []
    except (ValueError, AttributeError, OSError):
        errors = []
    first = errors[0] if isinstance(errors, list) and errors and isinstance(errors[0], dict) else {}
    said = str(first.get("message") or "").strip()
    if e.code == 400 and str(first.get("field") or "").lower() == "limit":
        allowed = re.findall(r"\d+", said) or [str(n) for n in SEARCH_LIMITS]
        sizes = ", ".join(allowed[:-1]) + " or " + allowed[-1] if len(allowed) > 1 else allowed[0]
        return f"the catalog refused page size {limit}; use {sizes} (--limit); nothing was changed"
    return f"the catalog refused the search (HTTP {e.code}{': ' + said if said else ''}); nothing was changed"


def _again(e, tries, waited, limit):
    """The seconds to wait before asking a busy catalog again (429, 5xx: Retry-After, else SEARCH_BACKOFF); anything
    else, a Retry-After over RETRY_AFTER_MAX or the last try ends the search with what happened."""
    if e.code != 429 and e.code < 500:
        raise SystemExit(_refused(e, limit))
    busy = f"the catalog {'is busy' if e.code == 429 else 'had a server error'} (HTTP {e.code})"
    after = _retry_after(e)
    if after is not None and after > RETRY_AFTER_MAX:
        raise SystemExit(f"{busy} and asks to wait {after} s: search again after that; nothing was changed")
    if tries > len(SEARCH_BACKOFF):
        raise SystemExit(f"{busy} after {tries} tries ({waited:g} s of waiting): search again in a minute, one search "
                         "at a time; nothing was changed")
    return SEARCH_BACKOFF[tries - 1] if after is None else after


def search(keyword, limit=10, opener=None, type=None, wait=None):
    """[{id, type, item_type, name, price, creator}] from the public avatar catalog: read-only, no sign-in, no cookies.
    Nothing is ever bought; the result is only a list to look at. price is information only: the catalog search and
    GetProductInfo disagree, so nothing depends on it. type: shirt, pants, tshirt (their own catalog category) or a slot
    name such as hair or hat (keyword search, filtered by asset type; the hair subcategory answers 400). An item's picture is on its page,
    https://www.roblox.com/catalog/<id>, to compare with the reference before choosing. A busy catalog (429, 5xx; several
    searches at once) is asked again after SEARCH_BACKOFF (wait: the seam tests use instead of time.sleep)."""
    keyword = (keyword or "").strip()
    if not keyword:
        raise SystemExit('costume search needs a keyword: py kit/run.py costume search "samurai helmet"')
    if type is not None and type not in SEARCH_CATEGORY and type not in SEARCH_FILTER:
        raise SystemExit(f"--type must be one of {', '.join(sorted(set(SEARCH_CATEGORY) | set(SEARCH_FILTER)))}")
    limit = next((n for n in SEARCH_LIMITS if n >= limit), SEARCH_LIMITS[-1])
    query = {"Keyword": keyword, "Limit": limit}
    if type in SEARCH_CATEGORY:
        query["Category"], query["Subcategory"] = SEARCH_CATEGORY[type]
    url = SEARCH_URL + "?" + urllib.parse.urlencode(query)
    req = urllib.request.Request(url, method="GET", headers={"User-Agent": USER_AGENT})
    wait, waited = wait or time.sleep, 0
    for tries in range(1, len(SEARCH_BACKOFF) + 2):
        try:
            with (opener or _open)(req, timeout=SEARCH_TIMEOUT) as reply:
                body = reply.read(SEARCH_MAX_BYTES)
            break
        except urllib.error.HTTPError as e:  # an answer (before OSError: HTTPError is one)
            try:
                delay = _again(e, tries, waited, limit)
            finally:
                e.close()
            wait(delay)
            waited += delay
        except (OSError, http.client.HTTPException) as e:
            raise SystemExit(f"catalog search failed ({e}): it needs the network; nothing was changed") from None
    try:
        data = json.loads(body.decode("utf-8"))
    except ValueError as e:
        raise SystemExit(f"catalog search reply not understood ({e}); nothing was changed")
    items = data.get("data") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise SystemExit("catalog search failed: the reply had no data list")
    found = [{"id": i.get("id"), "type": ASSET_TYPE_NAMES.get(i.get("assetType"), str(i.get("assetType"))),
              "item_type": i.get("itemType"), "name": i.get("name"), "price": i.get("price"),
              "creator": i.get("creatorName")}
             for i in items if isinstance(i, dict)]
    if type in SEARCH_FILTER:
        found = [f for f in found if f["type"] in SEARCH_FILTER[type]]
    return found


def emit(text, stream=None):
    """print() that never crashes on a console that can't show a character (cp1252 and "\u2661"): it prints "?"."""
    import sys
    stream = stream or sys.stdout
    enc = getattr(stream, "encoding", None) or "utf-8"
    print(text.encode(enc, errors="replace").decode(enc, errors="replace"), file=stream)


def search_lines(found):
    return [f"{i['id']}  {i['type']:<20} {'price ' + str(i['price']) if i['price'] is not None else 'price ?':<12} "
            f"{i['name']}  (by {i.get('creator') or '?'})" for i in found] or ["no items found: try other words"]


def starter(role, kind, character, source):
    """A valid spec to start from: plain colours (humanoid) or a small four-part body (creature)."""
    base = {"version": VERSION, "role": role, "character": character, "source": source, "kind": kind}
    if kind == "humanoid":
        return dict(base, body={r: "#c8a07a" for r in REGIONS}, scale={}, catalog=[])
    if kind != "creature":
        raise SystemExit("--kind must be humanoid or creature")
    return dict(base, stand=1.6, root=[2, 2, 2], feet=["FootL", "FootR"], core=["Body"], pairs=[], parts={
        "Body": {"shape": "sphere", "size": [2, 2, 3], "color": "#7a6a58"},
        "Head": {"shape": "sphere", "size": [1.5, 1.5, 1.5], "color": "#7a6a58"},
        "FootL": {"size": [0.6, 0.6, 0.8], "color": "#4a3f35"},
        "FootR": {"size": [0.6, 0.6, 0.8], "color": "#4a3f35"}}, joints=[
        ["Root", ROOT, "Body", [0, 0, 0], [0, 0, 0]],
        ["Neck", "Body", "Head", [0, 0.8, -1.6], [0, 0, 0.5]],
        ["HipL", "Body", "FootL", [-0.6, -1, 0], [0, 0.3, 0]],
        ["HipR", "Body", "FootR", [0.6, -1, 0], [0, 0.3, 0]]])


def new(root, b, role, kind, character, source):
    """Write a starter cast/<role>.json and dress the role in beats.json ("model": "costume")."""
    import beats
    if not ROLE.match(str(role)):
        raise SystemExit("--new takes a role: player, target or npc1..npc99")
    path = spec_path(root, role)
    if path.exists():
        raise SystemExit(f"cast/{role}.json already exists: edit it (it is never overwritten)")
    workspace.write_json(path, starter(role, kind, character, source))
    cast = b.setdefault("cast", {})
    entry = cast.setdefault(role, {"name": character, "place": [0, 0, -6, 0, 180, 0]})
    entry["model"] = "costume"
    entry.setdefault("name", character)
    if role != "player":
        entry["rig"] = "R15"
    beats.save(b, root)
    return path


def run(root, b):
    """(problems, lines): every costume checked; creatures' rigs written to rigs/<role>.json when all is well."""
    problems = check(root, b)
    lines = [f"COSTUMES {b.get('id')}"]
    if not problems:
        for role in roles(b):
            spec = load(root, role)
            if spec["kind"] == "creature":
                r = creature_rig(spec)
                workspace.write_json(Path(root) / "rigs" / f"{role}.json", r)
                lines.append(f"  {role}: {spec['character']} (creature, {len(spec['parts'])} parts, stands "
                             f"{r['stand']:.2f}) -> rigs/{role}.json")
            else:
                items, props = spec.get("catalog") or [], spec.get("props") or []
                held = f", {len(props)} held prop{'' if len(props) == 1 else 's'}" if props else ""
                lines.append(f"  {role}: {spec['character']} (humanoid, R15 + R6): {len(items)} catalog items{held}; "
                             f"capture its rig with studio {b.get('id')} rig --role {role}")
                lines += [f"      {c['slot']}: {c['id']} {c['name']} ({c['type']}): {c['why']}" for c in items]
                lines += [f"      prop {p['name']} in the {'right' if p['at'] == GRIPS[0] else 'left'} hand ({p['at']}, "
                          f"{len(p['parts'])} parts): {p['why']}" for p in props]
                if not items:
                    lines.append("      no catalog items yet: py kit/run.py costume search \"keyword\"")
            lines.append(f"      credit: {spec['source']}")
    lines += [f"  - {p}" for p in problems]
    lines.append("COSTUMES: " + ("all clear" if not problems else f"{len(problems)} to fix")
                 + ("" if roles(b) else " (no role wears a costume)"))
    return problems, lines
