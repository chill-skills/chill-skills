"""R6 from the R15 master (spec 5.8). Each R6 limb takes its R15 upper segment's world rotation and the R6 Torso takes
the LowerTorso plus half the waist bend, so arms, legs and head point the same way as on R15; what R6 can't show
(elbows, knees, the waist, wrists and ankles) is listed by bends() so Claude re-poses those beats for R6.
Pose language on both rigs: (x, y, z) degrees = CFrame.Angles in the parent part's axes; the root joint may add
(px, py, pz) studs. Method by fwjelaa (FWJ STUDIOS).
"""
import math

import clip

# a bend past this many degrees carries meaning R6 can't show
BENDS = {"RightLowerArm": 35.0, "LeftLowerArm": 35.0, "RightLowerLeg": 35.0, "LeftLowerLeg": 35.0, "UpperTorso": 25.0,
         "RightHand": 45.0, "LeftHand": 45.0, "RightFoot": 45.0, "LeftFoot": 45.0}
WAIST_SHARE = 0.5  # how much of the R15 waist turn the merged R6 torso takes


def _pad(v):
    v = tuple(float(c) for c in v)
    return v + (0.0,) * (6 - len(v)) if len(v) < 6 else v


def _rot(v):
    return clip.rot_xyz(*_pad(v)[:3])


def angles_of(m):
    """m = Rx(x) Ry(y) Rz(z) -> (x, y, z) degrees, like make-anim's _r15.angles_of."""
    y = math.asin(max(-1.0, min(1.0, m[0][2])))
    if abs(m[0][2]) > 0.99999:  # gimbal: put it all in x
        x, z = math.atan2(m[2][1], m[1][1]), 0.0
    else:
        x, z = math.atan2(-m[1][2], m[2][2]), math.atan2(-m[0][1], m[0][0])
    return tuple(round(math.degrees(a), 4) + 0.0 for a in (x, y, z))


def degrees(m):
    return math.degrees(math.acos(max(-1.0, min(1.0, (m[0][0] + m[1][1] + m[2][2] - 1) / 2))))


def part_of(m, k):
    """The same turn as m about the same axis, k of the way."""
    ang = math.radians(degrees(m))
    if ang < 1e-9:
        return clip.rot_xyz()
    s = 2 * math.sin(ang)
    if abs(s) > 1e-9:
        axis = [(m[2][1] - m[1][2]) / s, (m[0][2] - m[2][0]) / s, (m[1][0] - m[0][1]) / s]
    else:  # a half turn: the axis comes from the diagonal
        axis = [math.sqrt(max(0.0, (m[i][i] + 1) / 2)) for i in range(3)]
    n = math.sqrt(sum(a * a for a in axis))
    x, y, z = (a / n for a in axis)
    a = ang * k
    c, sn, t = math.cos(a), math.sin(a), 1 - math.cos(a)
    return [[t * x * x + c, t * x * y - sn * z, t * x * z + sn * y],
            [t * x * y + sn * z, t * y * y + c, t * y * z - sn * x],
            [t * x * z - sn * y, t * y * z + sn * x, t * z * z + c]]


def derive(pose15):
    def g(joint):
        return _rot(pose15.get(joint, (0, 0, 0)))

    lower, upper = g("LowerTorso"), g("UpperTorso")
    chest = clip.matmul(lower, upper)
    torso = clip.matmul(lower, part_of(upper, WAIST_SHARE))
    inv = clip.transpose(torso)
    world = {"Head": clip.matmul(chest, g("Head")),
             "Right Arm": clip.matmul(chest, g("RightUpperArm")), "Left Arm": clip.matmul(chest, g("LeftUpperArm")),
             "Right Leg": clip.matmul(lower, g("RightUpperLeg")), "Left Leg": clip.matmul(lower, g("LeftUpperLeg"))}
    out = {"Torso": angles_of(torso) + _pad(pose15.get("LowerTorso", (0, 0, 0)))[3:]}
    for part, w in world.items():
        out[part] = angles_of(clip.matmul(inv, w))
    return out


def bends(pose15):
    out = []
    for joint, limit in BENDS.items():
        if joint in pose15:
            d = degrees(_rot(pose15[joint]))
            if d > limit:
                out.append((joint, round(d, 1)))
    return out
