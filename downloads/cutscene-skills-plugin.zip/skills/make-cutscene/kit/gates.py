"""Kit checks (spec 8 gate 1) on what filmset.export wrote: the camera never inside a stand-in and the subject not
hidden behind one (raycasts against map.json's boxes), the subject centre-safe on phones and visible on tablets, no
camera jump that isn't a cut, every marker handled and every cue used, flashes at most 2 a second, VFX budgets, and
make-anim's animation checks plus the R6 bends (export/scene.json). Method by fwjelaa (FWJ STUDIOS).

    py kit/run.py gates <id>          -> export/gates.json; exit 1 while anything is left to fix
    py kit/run.py expect <id> <s>     where the camera must be at that time (the play test compares)
"""
import hashlib
import json
import math
from pathlib import Path

import beats
import camtrack
import costume
import cues
import mapcap
import paths
import scenefile
import workspace

# The runtime's version, read from its index so the two never drift apart (preflight, Task 17 trap).
RUNTIME = json.loads((paths.PACK / "roblox" / "CutsceneKit" / "_index.json").read_text(encoding="utf-8"))["version"]
BUILTIN = {"Letterbox", "Line", "Shake", "Cut", "End", "Impact", "Flash", "Slowmo"}  # CutsceneKit handles these itself
LATER = {"SFX", "Face"}  # spec 5.7 names whose handlers arrive in Plans 6-7 (VFX markers need a cue: kit/cues.py)
NEAR = 0.3  # studs the camera keeps from any stand-in surface (its near plane)
CENTRE = 0.6  # the subject's head stays in the middle 60 % of a 16:9 screen (phones crop the sides)
OFF_SHARE = 0.15  # a shot may break centre-safe or the line of sight on at most this share of its frames
SETTLE = 15  # frames at a shot's start where the subject may still be entering a 4:3 frame
JUMP_STUDS, JUMP_DEG, JUMP_FOV = 3.0, 25.0, 8.0  # more than this in one frame (60 fps) is a jump
FLASH_PER_S = 2
PARTICLES_2S, LIGHTS, HIGHLIGHTS = 3200, 2, 255  # research/00 section 5 budgets; the Highlight cap is 255


def _ranges(frames):
    out, start, prev = [], None, None
    for f in sorted(frames):
        if start is None:
            start = prev = f
        elif f == prev + 1:
            prev = f
        else:
            out.append(f"{start}-{prev}" if prev != start else f"{start}")
            start = prev = f
    if start is not None:
        out.append(f"{start}-{prev}" if prev != start else f"{start}")
    return ", ".join(out)


def _xyz(v):
    return "(" + ", ".join(f"{c:g}" for c in v) + ")"


INVISIBLE = mapcap.INVISIBLE  # a stand-in at least this transparent blocks neither sight nor the camera


def boxes(mapdata):
    """The visible stand-ins (mapcap.visible); play-bound walls that nobody can see are left out of the
    line-of-sight and camera-inside checks."""
    return [{"c": b[:3], "r": mapcap.orient(*b[6:9]), "h": (b[3] / 2, b[4] / 2, b[5] / 2), "size": b[3:6]}
            for b in mapdata.get("boxes", []) if mapcap.visible(b)]


def _local(bx, p):
    d = [p[i] - bx["c"][i] for i in range(3)]
    return [sum(bx["r"][k][i] * d[k] for k in range(3)) for i in range(3)]


def inside(bx, p, margin=0.0):
    q = _local(bx, p)
    return all(abs(q[i]) <= bx["h"][i] + margin for i in range(3))


def hits(bx, a, b):
    """Does the segment a-b pass through the box? (slab test in the box's own axes)"""
    la, lb = _local(bx, a), _local(bx, b)
    t0, t1 = 0.0, 1.0
    for i in range(3):
        d, h = lb[i] - la[i], bx["h"][i]
        if abs(d) < 1e-12:
            if abs(la[i]) > h:
                return False
            continue
        u, v = sorted(((-h - la[i]) / d, (h - la[i]) / d))
        t0, t1 = max(t0, u), min(t1, v)
        if t0 > t1:
            return False
    return True


def project(cf, fov, p, aspect):
    """Where p lands on screen: (-1..1 across, -1..1 up), or None when it is behind the camera."""
    d = [p[i] - cf[i] for i in range(3)]
    r = [[cf[3], cf[4], cf[5]], [cf[6], cf[7], cf[8]], [cf[9], cf[10], cf[11]]]
    q = [sum(r[k][i] * d[k] for k in range(3)) for i in range(3)]
    depth = -q[2]
    if depth <= 1e-6:
        return None
    t = math.tan(math.radians(fov) / 2)
    return (q[0] / (depth * t * aspect) + 0.0, q[1] / (depth * t) + 0.0)


def terrain(mapdata):
    """map.json's sampled ground as {"step", "h": {(i, j): height}}; the surface is the two triangles of every square of
    four neighbouring samples, the same quads filmset builds the stand-in mesh from. None when there is none."""
    t = mapdata.get("terrain") or {}
    cells = {(c[0], c[1]): c[2] for c in t.get("cells", [])}
    return {"step": t.get("step", 6), "h": cells} if cells else None


def terrain_height(terr, x, z):
    """The ground's height at x, z (anchor space), or None where no square of four samples covers it."""
    if not terr:
        return None
    step = terr["step"]
    i, j = math.floor(x / step), math.floor(z / step)
    h = terr["h"]
    try:
        h00, h01, h10, h11 = h[(i, j)], h[(i, j + 1)], h[(i + 1, j)], h[(i + 1, j + 1)]
    except KeyError:
        return None
    u, v = x / step - i, z / step - j
    if u <= v:
        return h00 + (h11 - h01) * u + (h01 - h00) * v
    return h00 + (h10 - h00) * u + (h11 - h10) * v


def _under_ground(terr, a, b):
    """Does the segment a-b dip below the ground between its ends? (sampled every quarter stud)"""
    n = max(2, math.ceil(math.dist(a, b) / 0.25))
    for k in range(1, n):
        t = k / n
        p = [a[i] + (b[i] - a[i]) * t for i in range(3)]
        g = terrain_height(terr, p[0], p[2])
        if g is not None and p[1] < g:
            return True
    return False


def _near(bxs, points):
    lo = [min(p[i] for p in points) for i in range(3)]
    hi = [max(p[i] for p in points) for i in range(3)]
    out = []
    for k, bx in enumerate(bxs):
        reach = math.sqrt(sum(h * h for h in bx["h"])) + NEAR
        if all(bx["c"][i] + reach >= lo[i] and bx["c"][i] - reach <= hi[i] for i in range(3)):
            out.append(k)
    return out


def _subject_frames(framing, s):
    role = s.get("subject")
    if not role or s.get("offscreen") or role not in framing["heads"]:
        return None, []
    last = min(s["end_frame"], len(framing["camera"]), len(framing["heads"][role]))
    return role, list(range(s["first_frame"], last))


def unchecked(framing, shots):
    """A shot whose subject has no head track can't be framed or line-of-sight checked: say so instead of passing it."""
    return [f"shot {s['n']} ({s['type']}): {s['subject']} has no head track in export/framing.json, so its framing and "
            f"line of sight were not checked (is the role in the cast?)"
            for s in shots if s.get("subject") and not s.get("offscreen") and s["subject"] not in framing["heads"]]


def camera_clear(framing, bxs, shots, terr=None):
    cams = framing["camera"]
    if (not bxs and not terr) or not cams:
        return []
    issues, stuck = [], {}
    near = []
    if bxs:
        points = [c[:3] for c in cams] + [h for hs in framing["heads"].values() for h in hs]
        near = _near(bxs, points)
    for f, cf in enumerate(cams):
        for k in near:
            if inside(bxs[k], cf[:3], NEAR):
                stuck.setdefault(k, []).append(f)
    for k, frames in sorted(stuck.items()):
        issues.append(f"camera inside (or within {NEAR} studs of) the stand-in at {_xyz(bxs[k]['c'])} size "
                      f"{_xyz(bxs[k]['size'])} on frames {_ranges(frames)}")
    low = [f for f, cf in enumerate(cams)
           if (g := terrain_height(terr, cf[0], cf[2])) is not None and cf[1] < g + NEAR]
    if low:
        issues.append(f"camera inside (or within {NEAR} studs of) the terrain on frames {_ranges(low)}")
    for s in shots:
        role, frames = _subject_frames(framing, s)
        if not frames:
            continue
        heads = framing["heads"][role]
        blocked = [f for f in frames if any(hits(bxs[k], cams[f][:3], heads[f]) for k in near)
                   or _under_ground(terr, cams[f][:3], heads[f])]
        if len(blocked) > OFF_SHARE * len(frames):
            issues.append(f"shot {s['n']} ({s['type']}): a stand-in hides {role}'s head on frames {_ranges(blocked)}")
    return issues


def centre_safe(framing, shots):
    issues = []
    cams, fovs = framing["camera"], framing["fov"]
    for s in shots:
        role, frames = _subject_frames(framing, s)
        if not frames:
            continue
        heads = framing["heads"][role]
        wide, lost = [], []
        for f in frames:
            p = project(cams[f], fovs[f], heads[f], 16 / 9)
            if p is None or abs(p[0]) > CENTRE or abs(p[1]) > 0.9:
                wide.append(f)
            q = project(cams[f], fovs[f], heads[f], 4 / 3)
            if f - s["first_frame"] >= SETTLE and (q is None or abs(q[0]) > 1 or abs(q[1]) > 1):
                lost.append(f)
        if len(wide) > OFF_SHARE * len(frames):
            issues.append(f"shot {s['n']} ({s['type']}): {role}'s head is outside the middle {round(CENTRE * 100)} % of a "
                          f"16:9 screen on {len(wide)} of {len(frames)} frames ({_ranges(wide)}); phones crop the sides")
        if lost:
            issues.append(f"shot {s['n']} ({s['type']}): {role}'s head leaves a 4:3 screen on frames {_ranges(lost)}")
    return issues


def jumps(framing, cuts):
    cams, fovs = framing["camera"], framing["fov"]
    cutset, bad, issues = set(cuts), [], []
    for f in range(1, len(cams)):
        moved = math.dist(cams[f][:3], cams[f - 1][:3])
        turned = camtrack.angle(cams[f - 1], cams[f])
        zoom = abs(fovs[f] - fovs[f - 1])
        if f in cutset:
            if moved < 0.5 and turned < 2 and zoom < 1:
                issues.append(f"the Cut at {f / framing['fps']:.2f} s doesn't change the shot (move the camera, or drop the cut)")
        elif moved > JUMP_STUDS or turned > JUMP_DEG or zoom > JUMP_FOV:
            bad.append(f)
    if bad:
        issues.insert(0, f"the camera jumps without a Cut marker on frames {_ranges(bad)} (add a cut to the beat sheet, or ease the move)")
    return issues


def sync(data):
    issues, used = [], set()
    markers, cues = data.get("Markers") or [], data.get("Cues") or {}
    for m in markers:
        t, name, value = m[0], m[1], (m[2] if len(m) > 2 else "")
        key = f"{name}:{value}" if value else name
        if name in BUILTIN:
            if name == "Shake":
                try:
                    ok = 0 <= float(value) <= 1
                except ValueError:
                    ok = False
                if not ok:
                    issues.append(f"Shake at {t:g} s must be 0-1, got {value!r}")
            continue
        if key in cues or name in cues:
            used.add(key if key in cues else name)
        elif name in LATER:
            issues.append(f"marker {key} at {t:g} s: CutsceneKit {RUNTIME} has no {name} handler yet (Plans 3-7 add it)")
        else:
            issues.append(f"marker {key} at {t:g} s has no cue")
    issues += [f"cue {key} has no marker" for key in cues if key not in used]
    ends = [m for m in markers if m[1] == "End"]
    if len(ends) != 1 or abs(ends[0][0] - data["Length"]) > 1e-3:
        issues.append(f"there must be exactly one End marker, at {data['Length']} s")
    fov = data.get("Fov") or []
    doubles = {round(a[0], 4) for a, b in zip(fov, fov[1:]) if abs(a[0] - b[0]) < 1e-6}
    cut_times = {round(m[0], 4) for m in markers if m[1] == "Cut"}
    issues += [f"Cut at {t:g} s has no FOV cut (two Fov entries at that time)" for t in sorted(cut_times - doubles)]
    issues += [f"the FOV cuts at {t:g} s without a Cut marker" for t in sorted(doubles - cut_times)]
    return issues


def flash_rate(markers, data=None):
    """Flash and Impact markers, and (given the data module) the big manga bursts, at most FLASH_PER_S a second."""
    times = cues.flashes(data) if data else sorted(m[0] for m in markers if m[1] in ("Flash", "Impact"))
    bad = sorted({round(t, 2) for i, t in enumerate(times) if sum(1 for u in times[i:] if u - t < 1.0) > FLASH_PER_S})
    return [f"more than {FLASH_PER_S} flashes in the second from {t:g} s (comfort: at most {FLASH_PER_S} a second)"
            for t in bad]


def budgets(data):
    cues, fired, issues = data.get("Cues") or {}, [], []
    for m in data.get("Markers") or []:
        value = m[2] if len(m) > 2 else ""
        cue = cues.get(f"{m[1]}:{value}") or cues.get(m[1])
        if isinstance(cue, dict) and isinstance(cue.get("budget"), dict):
            fired.append((m[0], cue["budget"]))
            if cue["budget"].get("lights", 0) > LIGHTS:
                issues.append(f"{m[1]}:{value} at {m[0]:g} s uses {cue['budget']['lights']} lights (at most {LIGHTS} per effect)")
    for t, _ in fired:
        window = [b for u, b in fired if t <= u < t + 2]
        if sum(b.get("particles", 0) for b in window) > PARTICLES_2S:
            issues.append(f"more than {PARTICLES_2S} particles in the 2 s from {t:g} s")
        if len(window) > 1 and sum(b.get("lights", 0) for b in window) > LIGHTS:
            issues.append(f"{sum(b.get('lights', 0) for b in window)} lights at once in the 2 s from {t:g} s "
                          f"(at most {LIGHTS})")
        if sum(b.get("highlights", 0) for b in window) > HIGHLIGHTS:
            issues.append(f"more than {HIGHLIGHTS} Highlights at once from {t:g} s")
    return list(dict.fromkeys(issues))


def anim_issues(scene):
    out = [f"{clip}: {i}" for clip, found in (scene.get("issues") or {}).items() for i in found]
    for role, info in (scene.get("r6") or {}).items():
        if info.get("flags") and not info.get("override"):
            out.append(f"R6 {role}: {len(info['flags'])} beats lose an elbow, knee or waist bend (first: {info['flags'][0]}); "
                       f"re-pose them in anim/{role}_R6.py")
    return out


def costume_hash(root):
    """A fingerprint of the costume specs, cast/*.json: what Studio dresses the cast with (costume.install_specs), the
    likeness entry the likeness sheet and C7 rest on, and the film look of the previews. Only "notes" is left out (it
    changes nothing anyone builds or sees). None when the scene has no cast/ files."""
    files = sorted((Path(root) / "cast").glob("*.json"))
    if not files:
        return None
    h = hashlib.sha256()
    for path in files:
        raw = path.read_bytes()
        try:
            spec = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            spec = None  # costume.check reports it; the bytes still fingerprint it
        if isinstance(spec, dict):
            spec.pop("notes", None)
            raw = json.dumps(spec, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        h.update(path.name.encode("utf-8") + b"\0" + raw + b"\0")
    return h.hexdigest()


def export_hash(root):
    """A fingerprint of the build the checks (and later the play test, previews and sheets) were made on: scene.json
    carries the hashes of the beat sheet, anim files and rigs it came from, framing.json is the camera itself, and the
    costume specs (costume_hash) are what Studio dresses the cast with. The versioned map binding includes
    presence and raw bytes: G1 reads map.json for collision/occlusion, so editing or deleting it expires evidence.
    Legacy hashes intentionally mismatch (rerun checks and downstream evidence, not animation export).
    This is NOT a fingerprint of all runtime/library/tool sources."""
    h = hashlib.sha256()
    for name in ("scene.json", "framing.json"):
        path = Path(root) / "export" / name
        h.update(path.read_bytes() if path.exists() else b"-")
    worn = costume_hash(root)
    if worn:
        h.update(b"costume:" + worn.encode("ascii"))
    # Always bind absence too: old evidence must not silently pass this policy migration.
    mp = Path(root) / "map.json"
    h.update(b"\0gate-map-v1\0")
    if mp.exists():
        h.update(b"present\0" + hashlib.sha256(mp.read_bytes()).digest())
    else:
        h.update(b"absent\0")
    return h.hexdigest()


def module_hash(root):
    """A fingerprint of the written data module export/<id>.luau (lines, Hide, trigger). It is not part of export_hash,
    so the kit checks stay valid across a module rewrite, but the play test and preview stamps carry it."""
    h = hashlib.sha256()
    path = Path(root) / "export" / f"{beats.load(root)['id']}.luau"
    h.update(path.read_bytes() if path.exists() else b"-")
    return h.hexdigest()


def export_stale(root):
    """[problems] when the beat sheet, anim files or rigs changed after the export (scenefile.stale's own messages)."""
    scene = Path(root) / "export" / "scene.json"
    return scenefile.stale(root, workspace.read_json(scene)) if scene.exists() else []


def run(root):
    root = Path(root)
    b = beats.load(root)
    out = root / "export"
    for name in ("scene.json", "framing.json"):
        if not (out / name).exists():
            raise SystemExit(f"no export/{name}: run filmset.export in Blender first")
    old = export_stale(root)
    if old:
        raise SystemExit("kit checks not run, the export is out of date:" + chr(10) + "  - " + (chr(10) + "  - ").join(old))
    scene, framing = workspace.read_json(out / "scene.json"), workspace.read_json(out / "framing.json")
    mp = root / "map.json"
    shots = beats.shots(b)
    data = scenefile.module_data(b, scene, framing=framing)
    cuts = framing.get("cuts") or []
    cut_mismatch = ([] if sorted(cuts) == sorted(scene.get("cuts") or []) else
                    [f"export/framing.json has cuts at frames {cuts} but export/scene.json has "
                     f"{scene.get('cuts')}: re-export"])
    mapdata = workspace.read_json(mp) if mp.exists() else None
    found = {
        "animation": anim_issues(scene),
        "camera vs stand-ins": (camera_clear(framing, boxes(mapdata), shots, terrain(mapdata)) if mapdata else
                                ["no map.json: capture the map (studio <id> anchor, then map) to check the camera"]),
        "framing on phones and tablets": centre_safe(framing, shots) + unchecked(framing, shots),
        "jumps": jumps(framing, cuts) + cut_mismatch,
        "sync": sync(data),
        "flash rate": flash_rate(data["Markers"], data),
        "budgets": budgets(data),
        "VFX and awakening": cues.checks(data),
        "costumes": costume.gate_problems(root, b, scene),  # spec 14: adapted characters
    }
    issues = [f"{group}: {i}" for group, items in found.items() for i in items]
    workspace.write_json(out / "gates.json", {"ok": not issues, "issues": issues, "export": export_hash(root),
                                              "costume": costume_hash(root),
                                              "groups": {g: len(v) for g, v in found.items()}})
    lines = [("PASS " if not items else "FIX  ") + group + (f" ({len(items)})" if items else "") for group, items in found.items()]
    lines += [f"  - {i}" for i in issues]
    lines.append("KIT CHECKS: " + ("all clear" if not issues else f"{len(issues)} to fix"))
    return issues, lines


def expect(root, t):
    f = workspace.read_json(Path(root) / "export" / "framing.json")
    i = max(0, min(len(f["camera"]) - 1, round(t * f["fps"])))
    cf = f["camera"][i]
    return f"rel=({cf[0]:.2f}, {cf[1]:.2f}, {cf[2]:.2f}) fov={f['fov'][i]:.1f}"
