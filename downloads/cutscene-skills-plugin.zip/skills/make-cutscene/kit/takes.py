"""A raw Studio recording -> the preview (spec 8 gate 3). The record overlay (roblox/authoring/RecordOverlay.client.luau)
flashes the game view magenta twice just after a scene (the END flash: two pulses). This finds that double pulse,
crops to the game view (the flash's bounding box, then its centred 16:9), cuts the scene out, and makes frames and a
contact sheet. Method by fwjelaa (FWJ STUDIOS).

Sync: the scene ends LEAD s before the first pulse starts, and begins Length s earlier (end - Length = start). There is
no start flash: Snapshot.capture disables every enabled ScreenGui at scene start, so one there would be hidden.
Pulse contract (pulses() / end_flashes()): each pulse PULSE_WIDTH s long (a lost frame or two inside it does not split
it, DROPOUT), the two pulses GAP_WIDTH s apart. A flicker, a long flash or a lone pulse is not an end flash; more than
one end flash in a take is refused (one scene per take).

Frames: ddagrab pads the take to 60 fps with about 23% duplicate frames (spike S9). The preview keeps a constant 60 fps
and the duplicates are kept (dropping them would speed the clip up or make it variable-rate), so judder in the preview
is not a defect to report.

    py kit/run.py preview <id> [--rig R6]   preview/raw.mp4 -> preview/<id>.mp4, preview/frames/, preview/sheet.png
    (R6: preview/raw_R6.mp4 -> <id>_R6.mp4, frames_R6/, sheet_R6.png)

A new cut deletes that rig's side-by-side sheets and likeness.png (cut from the take it replaces): make them again.
"""
import json
import math
import re
from pathlib import Path

import beats
import media
import review
import sheets

PROBE = (48, 27)
MAGENTA = 0.25  # share of magenta pixels that makes a probe frame a flash (the game view is part of the window)
LEAD = 0.25  # RecordOverlay.LEAD: the end flash starts LEAD s after the scene's last frame
PULSE = 0.3  # RecordOverlay.PULSE: one magenta pulse (the end flash is two pulses, so it can't be mistaken for a start flash)
GAP = 0.2  # RecordOverlay.GAP: clear time between the two pulses
PULSE_WIDTH = (0.2, 0.4)  # a pulse is PULSE long, plus or minus a frame and what ddagrab's padding adds
GAP_WIDTH = (0.1, 0.3)  # and the two pulses are GAP apart
DROPOUT = 0.05  # up to three frames of a pulse may be lost without splitting it
SHEET_FRAMES = 16
CELL = (320, 180)
SYNC_TOLERANCE = 0.2  # seconds the two flashes may disagree about where the scene starts
MIN_START = 0.1  # the scene can't start closer than this to the first frame of the take (the cut would be a guess)
TAIL = 0.1  # an end flash starting in the last TAIL s of the take is cut off
SPARE = 0.5  # a take must be at least Length + SPARE long
SIGNAL_TOLERANCE = 0.5  # the scene can't start earlier than record's "start the scene now" minus this


def is_magenta(r, g, b):
    return r > 200 and g < 70 and b > 200


def share(frame):
    n = len(frame) // 3
    return sum(1 for i in range(0, len(frame) - 2, 3) if is_magenta(frame[i], frame[i + 1], frame[i + 2])) / max(1, n)


def scan(video, size=PROBE):
    """[(time, magenta share)] for every frame, from tiny probe frames at the video's own timestamps."""
    w, h = size
    proc = media.ffmpeg("-i", video, "-vf", f"scale={w}:{h},showinfo", "-f", "rawvideo", "-pix_fmt", "rgb24",
                        "-fps_mode", "passthrough", "-", binary=True)
    times = [float(t) for t in re.findall(rb"pts_time:([0-9.]+)", proc.stderr)]
    n = w * h * 3
    frames = [proc.stdout[i:i + n] for i in range(0, len(proc.stdout), n)]
    if len(times) != len(frames):
        raise SystemExit(f"FFmpeg gave {len(frames)} probe frames but {len(times)} timestamps for {Path(video).name}: "
                         "the flash times can't be trusted, record the take again")
    return [(t, share(f)) for t, f in zip(times, frames)]


def flashes(samples, min_share=MAGENTA):
    """[(time of the first flash frame, time of the first clear frame after it)]."""
    runs, start = [], None
    for t, s in samples:
        if s >= min_share and start is None:
            start = t
        elif s < min_share and start is not None:
            runs.append((start, t))
            start = None
    if start is not None:
        runs.append((start, samples[-1][0]))
    return runs


def pulses(runs, dropout=DROPOUT):
    """Runs (from flashes()) separated by no more than `dropout` s are one pulse: a frame or two lost to load or the
    encoder must not split a pulse. [(start, end)]."""
    out = []
    for first, last in runs:
        if out and first - out[-1][1] <= dropout:
            out[-1] = (out[-1][0], last)
        else:
            out.append((first, last))
    return out


def end_flashes(runs, video_end=None):
    """The overlay's end flash: two pulses, each PULSE_WIDTH long, GAP_WIDTH apart. [(start, end, 2, first pulse end)].
    Anything else magenta (a flicker, a long flash, pulses too far apart) is not it. A second pulse that runs to
    `video_end` may be short: the take was cut off there (make() then says so)."""
    found, found_pulses, i = [], pulses(runs), 0
    while i < len(found_pulses) - 1:
        a, b = found_pulses[i], found_pulses[i + 1]
        if (PULSE_WIDTH[0] <= a[1] - a[0] <= PULSE_WIDTH[1] and (PULSE_WIDTH[0] <= b[1] - b[0] <= PULSE_WIDTH[1] or (video_end is not None and b[1] >= video_end))
                and GAP_WIDTH[0] <= b[0] - a[1] <= GAP_WIDTH[1]):
            found.append((a[0], b[1], 2, a[1]))
            i += 2
        else:
            i += 1
    return found


def viewport(video, t, width=480):
    """(x, y, w, h) of the magenta game view in source pixels, 2 px inside its edge, from one frame at t."""
    info = media.probe(video)
    height = round(info["height"] * width / info["width"])
    px = media.ffmpeg("-ss", f"{t:.3f}", "-i", video, "-frames:v", "1", "-vf", f"scale={width}:{height}", "-f",
                      "rawvideo", "-pix_fmt", "rgb24", "-", binary=True).stdout
    xs, ys = [], []
    for y in range(height):
        row = y * width * 3
        for x in range(width):
            i = row + x * 3
            if i + 2 < len(px) and is_magenta(px[i], px[i + 1], px[i + 2]):
                xs.append(x)
                ys.append(y)
    if not xs:
        raise SystemExit("no magenta game view in the recording at the flash")
    k = info["width"] / width
    x0, y0 = math.ceil(min(xs) * k) + 2, math.ceil(min(ys) * k) + 2
    x1, y1 = int((max(xs) + 1) * k) - 2, int((max(ys) + 1) * k) - 2
    return x0, y0, (x1 - x0) // 2 * 2, (y1 - y0) // 2 * 2


def fit_16x9(crop):
    """The centred 16:9 part of a game view that is wider than 16:9. Roblox's field of view is vertical, so that part is
    exactly what a 16:9 screen shows. A view taller than 16:9 is left as it is (nothing more can be shown)."""
    x, y, w, h = crop
    if w * 9 <= h * 16 * 1.02:  # already 16:9 (a view's edge is only found to a few pixels): leave it whole
        return crop
    nw = h * 16 // 9 // 2 * 2
    return x + (w - nw) // 2 // 2 * 2, y, nw, h


def cut(video, out, start, end, crop):
    x, y, w, h = crop
    media.ffmpeg("-ss", f"{start:.3f}", "-to", f"{end:.3f}", "-i", video, "-vf", f"crop={w}:{h}:{x}:{y},fps=60",
                 "-c:v", "libx264", "-preset", "medium", "-crf", "16", "-pix_fmt", "yuv420p", "-an", out)
    return Path(out)


def make(root, raw=None, rig="R15"):
    root = Path(root)
    b = beats.load(root)
    if rig not in ("R15", "R6"):
        raise SystemExit(f"--rig takes R15 or R6, not {rig}")
    tag = "_R6" if rig == "R6" else ""  # every demo gets an R15 and an R6 preview (spec 14); R15 keeps the plain names
    raw = Path(raw) if raw else root / "preview" / f"raw{tag}.mp4"
    if not raw.exists():
        raise SystemExit(f"no recording at {raw}: py kit/run.py record {b['id']}{' --rig R6' if tag else ''} first")
    samples = scan(raw)
    runs = flashes(samples)
    ends = end_flashes(runs, samples[-1][0])
    if not ends:
        seen = ", ".join(f"{a:.2f} s ({z - a:.2f} s long)" for a, z in pulses(runs)) or "none"
        raise SystemExit(f"found no magenta end flash (magenta seen at: {seen}). The preview needs the end flash, the "
                         f"double pulse that comes just after the scene: two pulses {PULSE_WIDTH[0]:g}-{PULSE_WIDTH[1]:g} s "
                         f"long, {GAP_WIDTH[0]:g}-{GAP_WIDTH[1]:g} s apart. Install the overlay (studio <id> record-on) "
                         "before Play, and let the scene play to its end while recording")
    if len(ends) > 1:
        when = ", ".join(f"{e[0]:.2f} s" for e in ends)
        raise SystemExit(f"found {len(ends)} end flashes (at {when}): two scenes ran, or a trigger fired again, so the "
                         "cut would be a guess. Record one scene per take")
    length = beats.length(b)
    duration = samples[-1][0]
    if duration < length + SPARE:
        raise SystemExit(f"the take is {duration:.2f} s, shorter than the scene ({length:.2f} s) plus {SPARE:g} s: "
                         "record again with a larger --seconds")
    last = ends[0]
    if last[1] >= duration - TAIL:
        raise SystemExit(f"the end flash is cut off at the end of the take (it starts at {last[0]:.2f} s of "
                         f"{duration:.2f} s): record again with a larger --seconds")
    end = last[0] - LEAD
    start = end - length
    if start < 0:
        raise SystemExit(f"the scene would start {-start:.2f} s before the recording started: the take began too late, "
                         "or the flash seen is the start flash and the scene outran the take (start the recording "
                         "first, wait for its \"recording\" line, and give it a larger --seconds)")
    if start < MIN_START:
        raise SystemExit(f"the scene starts {start:.2f} s into the take, too close to the start to trust the cut: wait "
                         "for the \"recording\" line, then start the scene, and record again")
    meta = raw.with_suffix(".json")
    if meta.exists():
        announced = json.loads(meta.read_text(encoding="utf-8")).get("announced_at")
        if isinstance(announced, (int, float)) and start < announced - SIGNAL_TOLERANCE:
            raise SystemExit(f"the cut puts the scene start at {start:.2f} s, but record only said \"start the scene "
                             f"now\" at {announced:.2f} s: the flash seen isn't this scene's end flash, record again")
    lines = []
    seen = viewport(raw, (last[0] + last[3]) / 2)
    crop = fit_16x9(seen)
    if crop[2] * 9 < crop[3] * 16 * 0.98:
        lines.append(f"WARNING: the game view is taller than 16:9 ({seen[2]}x{seen[3]}), so the preview is too: widen "
                     "Studio's game view before recording")
    sheets.clear(root, rig)  # cut from the take this one replaces; the likeness sheet shows both casts
    (root / "preview" / "likeness.png").unlink(missing_ok=True)
    out = cut(raw, root / "preview" / f"{b['id']}{tag}.mp4", start, end, crop)
    frames_dir = root / "preview" / f"frames{tag}"
    frames_dir.mkdir(parents=True, exist_ok=True)
    for old in frames_dir.glob("*.png"):
        old.unlink()
    cells = []
    for i in range(SHEET_FRAMES):
        t = (i + 0.5) * (end - start) / SHEET_FRAMES
        cells.append(media.cell(out, frames_dir / f"f{i:02d}.png", f"{t:.2f}s", CELL, t))
    sheet = media.sheet(cells, root / "preview" / f"sheet{tag}.png", cols=4)
    review.stamp_preview(root, rig)
    review.stamp_sheet(root, "overview_R6" if tag else "overview", [sheet.name])
    return [f"preview: {out} ({end - start:.2f} s, game view {seen[2]}x{seen[3]}, cut to 16:9 {crop[2]}x{crop[3]} at {crop[0]},{crop[1]})",
            f"contact sheet: {sheet} ({SHEET_FRAMES} frames)"] + lines
