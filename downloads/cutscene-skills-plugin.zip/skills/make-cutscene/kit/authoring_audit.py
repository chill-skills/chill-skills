"""Read-only capability audit for CutsceneKit. Method by fwjelaa (FWJ STUDIOS).

Usage: python -B kit/authoring_audit.py SCENE_FOLDER
       python -B kit/authoring_audit.py beats.json --format beats
       python -B kit/authoring_audit.py runtime-data.json --format module
A folder means its beats.json. Auto detects shots/kind versus Markers/Kind.
Module means a JSON runtime data table, NOT Luau, export/scene.json or a clip.
Uses this kit's local stdlib-only helpers and bundled libraries; no animation
scripts execute. No files are written, including helper bytecode caches.
JSON findings contain rule/severity/location/message/remedy. Locations are JSON
pointers (empty=root). Exit 0 means no errors; 1 invalid input/capability;
2 CLI usage error. Suggestions do not fail. Not a replacement for live tests.
"""
import argparse
import json
from pathlib import Path
import sys

# Prevent imported local helpers from creating __pycache__ during CLI auditing.
sys.dont_write_bytecode = True

SUPPORTED_MARKERS = frozenset({"Letterbox", "Line", "Shake", "VFX", "Impact",
                               "Flash", "Slowmo", "Cut", "End"})


def finding(rule, location, message, remedy, severity="error"):
    return dict(rule=rule, severity=severity, location=location,
                message=message, remedy=remedy)


def pointer(base, key):
    return base + "/" + str(key).replace("~", "~0").replace("/", "~1")


def nonfinite(data, location=""):
    """Reject JSON decoder's accepted NaN/Infinity and overflowing exponents."""
    import math
    found = []
    if isinstance(data, float) and not math.isfinite(data):
        found.append(finding("INPUT_NUMBER", location, "Number must be finite.",
                             "Replace NaN or infinity with a finite number."))
    elif isinstance(data, (dict, list)):
        for key, value in (data.items() if isinstance(data, dict) else enumerate(data)):
            found.extend(nonfinite(value, pointer(location, key)))
    return found


def capability(data, mode):
    """Check Director.cue/fireVfx/cueFor dispatch, not just schema enums."""
    is_beats = mode == "beats"
    kind_key, cue_key = ("kind", "cues") if is_beats else ("Kind", "Cues")
    lines_key, cfg_key = ("lines", "config") if is_beats else ("Lines", "Config")
    found = []
    if data.get(kind_key) not in ("story", "intro", "awakening"):
        found.append(finding("CAP_KIND", "/" + kind_key,
                             "Only story, intro and awakening have supported end-to-end runtime entry points.",
                             "Choose a supported kind; keep targeted ultimates as planning notes."))
    if is_beats:
        entries = [(m, f"/shots/{i}/markers/{j}") for i, shot in enumerate(data["shots"])
                   for j, m in enumerate(shot.get("markers") or [])]
    else:
        entries = [(m, f"/Markers/{i}") for i, m in enumerate(data["Markers"])]
    explicit = data.get(cue_key) or {}
    used = set()
    for marker, loc in entries:
        name = marker[1]
        value = marker[2] if len(marker) > 2 else ""
        if not isinstance(value, (str, int, float)) or isinstance(value, bool):
            found.append(finding("INPUT_MARKER", loc, "Marker value must be text or a number.",
                                 "Use the marker's documented scalar value."))
            continue
        value = str(value)
        if name not in SUPPORTED_MARKERS:
            found.append(finding("CAP_MARKER", loc, f"No runtime dispatch for marker {name!r}.",
                                 "Use a supported marker; keep future effects in planning notes."))
        if name == "VFX":
            key = f"VFX:{value}" if value else "VFX"
            # Exporter generates exact-key defaults for beats; runtime falls back to VFX.
            selected = key if key in explicit else (None if is_beats else "VFX")
            if selected in explicit:
                used.add(selected)
            elif not is_beats:
                found.append(finding("CAP_CUE_MISSING", loc, "VFX marker has no runtime cue.",
                                     "Provide Cues[VFX:value] or the runtime Cues[VFX] fallback."))
    for key, cue in explicit.items():
        loc = pointer("/" + cue_key, key)
        if cue.get("kind") not in ("vfx", "screen"):
            found.append(finding("CAP_CUE_KIND", loc, f"Runtime cannot execute cue kind {cue.get('kind')!r}.",
                                 "Use vfx or screen; sfx and face are not implemented."))
        if key != "VFX" and not key.startswith("VFX:"):
            found.append(finding("CAP_CUE_DISPATCH", loc, "Only VFX markers dispatch cue tables.",
                                 "Use a VFX marker with a vfx/screen cue, not a custom marker."))
        elif key not in used:
            found.append(finding("CAP_CUE_UNUSED", loc, "Cue is not reached by any VFX marker.",
                                 "Match its key to a VFX marker or remove it from executable cues.", "suggestion"))
        if cue.get("external"):
            found.append(finding("CAP_EXTERNAL", loc, "External VFX adapter exists; installed library is not verified offline.",
                                 "Verify FwjelaaVFX.play and its stop callback in the target place.", "suggestion"))
        roles = set(data["cast"]) if is_beats else {"player"}
        if not is_beats:
            # Runtime clones are populated from animation-role tables, not Places alone.
            for rig in ("R15", "R6"):
                roles.update((data.get("Anims", {}).get(rig) or {}).keys())
        for field in (("at", "focus", "follow") if is_beats else ("follow",)):
            target = cue.get(field)
            if isinstance(target, str) and target.split(".")[0] not in roles:
                found.append(finding("INPUT_ROLE", pointer(loc, field), "Cue refers to a role outside the cast.",
                                     "Use a declared cast role."))
    for key, line in (data.get(lines_key) or {}).items():
        if line.get("voice"):
            found.append(finding("CAP_VOICE", pointer(pointer("/" + lines_key, key), "voice"),
                                 "The runtime shows subtitles but does not play line.voice.",
                                 "Remove executable voice refs; keep audio direction in planning notes."))
    cfg = data.get(cfg_key) or {}
    # Do not allow one authoring style field to hide an unsupported other field.
    styles = [("/" + cfg_key + "/Style", cfg.get("Style"))]
    if is_beats:
        styles.append(("/dialogue", data.get("dialogue")))
    for loc, style in styles:
        if style not in (None, "anime"):
            found.append(finding("CAP_DIALOGUE", loc,
                                 "Only anime subtitle UI is implemented; manga screen effects are separate.",
                                 "Use anime subtitles and VFX screen cues for supported manga effects."))
    return found


def audit(data, mode="auto"):
    """Return findings without modifying the supplied JSON object."""
    import beats
    import schema
    if not isinstance(data, dict):
        return [finding("INPUT_OBJECT", "", "Input must be a JSON object.", "Supply beats.json or a runtime data table.")]
    found = nonfinite(data)
    if found:
        return found
    if mode == "auto":
        if "shots" in data or "kind" in data:
            mode = "beats"
        elif "Markers" in data or "Kind" in data:
            mode = "module"
        else:
            return [finding("INPUT_FORMAT", "", "Cannot identify beats or runtime data.",
                            "Supply a complete beats.json or JSON runtime data table.")]
    if mode not in ("beats", "module"):
        return [finding("INPUT_FORMAT", "", "Unknown format.", "Choose auto, beats or module.")]
    # Do not let falsy malformed containers disappear through legacy `or []` defaults.
    if mode == "beats":
        for key in ("lines", "cues", "config"):
            if key in data and data[key] is not None and not isinstance(data[key], dict):
                found.append(finding("INPUT_SHAPE", "/" + key, "Expected an object.", "Use a JSON object or omit this field."))
        if isinstance(data.get("shots"), list):
            for i, shot in enumerate(data["shots"]):
                if isinstance(shot, dict) and "markers" in shot and not isinstance(shot["markers"], list):
                    found.append(finding("INPUT_SHAPE", f"/shots/{i}/markers", "Expected a marker list.", "Use [] when the shot has no markers."))
        if found:
            return found
    # Validators sometimes raise on malformed nested types. Fail closed with JSON.
    try:
        problems = beats.validate(data) if mode == "beats" else schema.validate(data)
        if mode == "beats" and not problems:
            # Validate the exporter's generated marker values/times with its shared
            # schema, not a second set of Letterbox/Slowmo/Line rules. Animation
            # refs are placeholders here; this read-only pass does not export clips.
            problems = schema.validate({
                "Kind": data["kind"], "Length": beats.snap(beats.length(data)),
                "Anims": {"Stage": "audit"}, "Markers": beats.markers(data),
                "Lines": data.get("lines"),
            })
    except (TypeError, ValueError, KeyError, AttributeError, IndexError, OverflowError) as exc:
        return [finding("INPUT_SHAPE", "", f"Malformed nested input ({type(exc).__name__}).",
                        "Use documented shot, marker, config and cue shapes.")]
    found.extend(finding("INPUT_SCHEMA", "", problem, "Correct the field named in the validation message.")
                 for problem in problems)
    if problems:
        return found
    try:
        found.extend(capability(data, mode))
    except (TypeError, ValueError, KeyError, AttributeError, IndexError) as exc:
        found.append(finding("INPUT_SHAPE", "", f"Malformed executable fields ({type(exc).__name__}).",
                             "Use lists of markers, object cue tables and object line entries."))
        return found
    if mode == "beats":
        for i, shot in enumerate(data["shots"]):
            loc = f"/shots/{i}"
            if not shot.get("action"):
                found.append(finding("CINE_INTENT", loc, "Shot has no action/intention note.",
                                     "Describe what changes for the audience in this shot.", "suggestion"))
            if not shot.get("ref"):
                found.append(finding("CINE_REFERENCE", loc, "No shot reference evidence is attached.",
                                     "If reference-led, add a timestamp/panel and observed purpose; original work may omit it.",
                                     "suggestion"))
    return found


def audit_module(data):
    return audit(data, "module")


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key {key!r}")
        result[key] = value
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--format", choices=("auto", "beats", "module"), default="auto")
    args = parser.parse_args(argv)
    path = args.input / "beats.json" if args.input.is_dir() else args.input
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=_unique_object)
        found = audit(data, args.format)
    except (OSError, UnicodeError, ValueError, RecursionError) as exc:
        found = [finding("INPUT_READ", "", f"Cannot read valid JSON: {exc}",
                         "Supply readable UTF-8 JSON without duplicate keys, not Luau or executable code.")]
    ok = not any(f["severity"] == "error" for f in found)
    print(json.dumps({"version": 1, "ok": ok, "findings": found}, ensure_ascii=True, indent=2))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
