"""Screen-record Roblox Studio while a cutscene plays (spec 8 gate 3). Windows only. It borrows the screen: Studio is
brought to the front, and the take is stopped and deleted if another program comes to the front. The capture method
is spike S9's (notes/spike-2.md). Method by fwjelaa (FWJ STUDIOS).

    py kit/run.py record <id> [--seconds 25]     -> cutscenes/<id>/preview/raw.mp4
Start it in the background, wait for its "recording" line, then trigger the scene through the Studio MCP; afterwards
py kit/run.py preview <id>.
"""
import ctypes
import json
import subprocess
import sys
import time
from pathlib import Path

STUDIO_EXE = "RobloxStudioBeta.exe"
PLACE_NAME = None  # `record --place <name>` picks the right window when two Studios are open; else the biggest
METHOD = "ddagrab"  # spike S9: the only method that reached 300 frames in 6 s (it pads to 60 fps: ~23% duplicates)
GFX_TARGET = "hwnd"  # spike S9: hwnd | exe | title (only used by gfxcapture)
CLICK = True  # spike S9: Studio renders nothing after a plain bring-to-front until the viewport is clicked
FPS = 60
DWMWA_EXTENDED_FRAME_BOUNDS = 9

if sys.platform == "win32":
    _u, _k = ctypes.windll.user32, ctypes.windll.kernel32
    _u.SetProcessDPIAware()  # physical pixels, the ones the capture sees
    _u.GetForegroundWindow.restype = ctypes.c_void_p
    _k.OpenProcess.restype = ctypes.c_void_p
else:  # pragma: no cover - the kit records on Windows only
    _u = _k = None


def exe_of(hwnd):
    pid = ctypes.c_ulong()
    _u.GetWindowThreadProcessId(ctypes.c_void_p(hwnd), ctypes.byref(pid))
    h = _k.OpenProcess(0x1000, False, pid.value)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return ""
    try:
        buf, n = ctypes.create_unicode_buffer(1024), ctypes.c_ulong(1024)
        ok = _k.QueryFullProcessImageNameW(ctypes.c_void_p(h), 0, buf, ctypes.byref(n))
        return buf.value.replace("/", "\\").rsplit("\\", 1)[-1] if ok else ""
    finally:
        _k.CloseHandle(ctypes.c_void_p(h))


def windows():
    """Visible top-level windows: (hwnd, title, (left, top, right, bottom), program file name)."""
    from ctypes import wintypes
    found = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def each(hwnd, _):
        h = ctypes.c_void_p(hwnd)
        if _u.IsWindowVisible(h):
            buf = ctypes.create_unicode_buffer(512)
            _u.GetWindowTextW(h, buf, 512)
            if buf.value:
                r = (ctypes.c_long * 4)()
                _u.GetWindowRect(h, ctypes.byref(r))
                found.append((hwnd, buf.value, tuple(r), exe_of(hwnd)))
        return True

    _u.EnumWindows(each, 0)
    return found


def clamp_rect(rect, monitor):
    """rect clamped into monitor, with even width and height (libx264 refuses odd sizes)."""
    left, top = max(rect[0], monitor[0]), max(rect[1], monitor[1])
    right, bottom = min(rect[2], monitor[2]), min(rect[3], monitor[3])
    return left, top, left + (right - left) // 2 * 2, top + (bottom - top) // 2 * 2


def capture_rect(hwnd):
    """The rect to record: DWM's extended frame bounds (the visible window), clamped to its monitor. A maximised
    window's GetWindowRect hangs 8 px off screen, which made every capture method fail (spike S9)."""
    from ctypes import wintypes

    class MonitorInfo(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT), ("rcWork", wintypes.RECT),
                    ("dwFlags", wintypes.DWORD)]

    r = wintypes.RECT()
    if ctypes.windll.dwmapi.DwmGetWindowAttribute(ctypes.c_void_p(hwnd), DWMWA_EXTENDED_FRAME_BOUNDS, ctypes.byref(r),
                                                  ctypes.sizeof(r)) != 0:
        _u.GetWindowRect(ctypes.c_void_p(hwnd), ctypes.byref(r))
    _u.MonitorFromWindow.restype = ctypes.c_void_p
    mon = _u.MonitorFromWindow(ctypes.c_void_p(hwnd), 2)  # MONITOR_DEFAULTTONEAREST
    info = MonitorInfo()
    info.cbSize = ctypes.sizeof(info)
    if mon and _u.GetMonitorInfoW(ctypes.c_void_p(mon), ctypes.byref(info)):
        m = info.rcMonitor
        return clamp_rect((r.left, r.top, r.right, r.bottom), (m.left, m.top, m.right, m.bottom))
    return clamp_rect((r.left, r.top, r.right, r.bottom), (-32768, -32768, 32767, 32767))


def pick_studio(wins, place=PLACE_NAME):
    """Of the Studio windows (found by program, as a browser tab can have "Roblox Studio" in its title) the one whose
    title has the place name, else the biggest. (hwnd, title, rect) or None."""
    studios = [w for w in wins if w[3].lower() == STUDIO_EXE.lower()]
    if not studios:
        return None
    named = [w for w in studios if place and place.lower() in w[1].lower()]
    pick = max(named or studios, key=lambda w: (w[2][2] - w[2][0]) * (w[2][3] - w[2][1]))
    return pick[:3]


def on_primary(rect, screen):
    """True when rect lies on the primary monitor, which is (0, 0, width, height) of the virtual desktop."""
    return rect[0] >= 0 and rect[1] >= 0 and rect[2] <= screen[0] and rect[3] <= screen[1]


def find_studio(place=PLACE_NAME):
    """(hwnd, title, capture rect) of the Studio window, or None. Refuses a window on another monitor: the capture's
    output index and offsets are the primary monitor's."""
    pick = pick_studio(windows(), place)
    if pick is None:
        return None
    hwnd, title, _ = pick
    rect = capture_rect(hwnd)
    if not on_primary(rect, (_u.GetSystemMetrics(0), _u.GetSystemMetrics(1))):
        raise SystemExit("Roblox Studio is not on the primary monitor: move Studio to the primary monitor, then run "
                         "this again")
    return hwnd, title, rect


def studio_in_front(hwnd):
    front = _u.GetForegroundWindow()
    return front == hwnd or (front and exe_of(front).lower() == STUDIO_EXE.lower())


def focus(hwnd, click=CLICK):
    """Bring the window to the front. Windows lets only the process that owns the input do that, so share the input
    queue of the window in front for the moment of the switch. Only a minimised window is restored: SW_RESTORE on a
    maximised one un-maximises it (spike S9). With click=True it also clicks the middle of the window: only do that
    while the game is playing (in Edit mode the click would select or deselect a part)."""
    if _u.IsIconic(ctypes.c_void_p(hwnd)):
        _u.ShowWindow(ctypes.c_void_p(hwnd), 9)  # SW_RESTORE
    front = _u.GetForegroundWindow()
    theirs = _u.GetWindowThreadProcessId(ctypes.c_void_p(front), None) if front else 0
    mine = _k.GetCurrentThreadId()
    attached = bool(theirs) and theirs != mine and _u.AttachThreadInput(mine, theirs, True)
    try:
        _u.BringWindowToTop(ctypes.c_void_p(hwnd))
        _u.SetForegroundWindow(ctypes.c_void_p(hwnd))
    finally:
        if attached:
            _u.AttachThreadInput(mine, theirs, False)
    if click:  # spike S9: Studio renders nothing until the viewport is clicked
        left, top, right, bottom = capture_rect(hwnd)
        _u.SetCursorPos((left + right) // 2, (top + bottom) // 2)
        time.sleep(0.1)
        _u.mouse_event(2, 0, 0, 0, 0)
        _u.mouse_event(4, 0, 0, 0, 0)
        time.sleep(0.1)
        # Roblox draws its own cursor in the game view (draw_mouse=0 hides only the OS one): park it on the title bar
        _u.SetCursorPos((left + right) // 2, top + 8)


def capture_cmd(method, win, seconds, out, fps=FPS, target=GFX_TARGET):
    hwnd, _, (left, top, right, bottom) = win
    w, h = (right - left) // 2 * 2, (bottom - top) // 2 * 2
    enc = ["-t", f"{seconds:g}", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "12", "-pix_fmt", "yuv420p", str(out)]
    head = ["ffmpeg", "-hide_banner", "-v", "error", "-y"]
    if method == "gfxcapture":
        who = {"hwnd": f"hwnd={hwnd}", "exe": f"window_exe={STUDIO_EXE}", "title": "window_title=(?i)roblox studio"}[target]
        even = ["-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2"]  # the window size can be odd (spike S9)
        return (head + ["-f", "lavfi", "-i", f"gfxcapture={who}:capture_cursor=0:max_framerate={fps},hwdownload,format=bgra"]
                + even + enc)
    if method == "ddagrab":
        src = (f"ddagrab=output_idx=0:framerate={fps}:offset_x={left}:offset_y={top}:video_size={w}x{h}:draw_mouse=0,"
               "hwdownload,format=bgra")
        return head + ["-f", "lavfi", "-i", src] + enc
    if method == "gdigrab":
        return head + ["-f", "gdigrab", "-framerate", str(fps), "-draw_mouse", "0", "-offset_x", str(left),
                       "-offset_y", str(top), "-video_size", f"{w}x{h}", "-i", "desktop"] + enc
    raise ValueError(f"unknown capture method {method!r}")


def _stop(proc):
    """Stop FFmpeg if it is still running: ask, wait, then kill."""
    if proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=10)


def record(seconds, out, method=METHOD, find=None, focus_fn=None, in_front=None, popen=subprocess.Popen,
           sleep=time.sleep, clock=time.monotonic, wait_front=5.0, say=None):
    """Record Studio for `seconds` into out. Only a take that finished normally, with Studio in front the whole
    time, is kept: on any other exit (another window, Ctrl-C, an error, a timeout, a failed FFmpeg) FFmpeg is stopped
    and the take and its raw.json are deleted. raw.json holds `announced_at`, the seconds into the take at which
    "start the scene now" was said (takes.make cross-checks the cut against it)."""
    def default_say(text):
        print(text, flush=True)

    find, focus_fn, in_front = find or find_studio, focus_fn or focus, in_front or studio_in_front
    say = say or default_say
    win = find()
    if win is None:
        raise SystemExit("no Roblox Studio window found: open Studio with the place (not minimised), then run this again")
    hwnd = win[0]
    focus_fn(hwnd)
    deadline = clock() + wait_front
    while not in_front(hwnd):
        if clock() > deadline:
            raise SystemExit("Roblox Studio didn't come to the front: click on Studio once, then run this again")
        sleep(0.1)
    out = Path(out)
    meta = out.with_suffix(".json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.unlink(missing_ok=True)
    meta.unlink(missing_ok=True)
    began = clock()
    proc = popen(capture_cmd(method, win, seconds, out), stdin=subprocess.DEVNULL)
    kept = False
    try:
        limit = began + seconds + 30
        announced = False
        while proc.poll() is None:
            front = in_front(hwnd)
            if not front:
                raise SystemExit("another window came to the front while recording: the take was stopped and deleted "
                                 "(keep Studio in front; run it again)")
            if clock() > limit:
                raise SystemExit("the recording didn't finish in time: stopped and deleted")
            if not announced and out.exists() and out.stat().st_size > 0:
                announced = True  # the caller must not start the scene before FFmpeg is writing (the first flash)
                meta.write_text(json.dumps({"announced_at": round(clock() - began, 3), "seconds": seconds}),
                                encoding="utf-8", newline=chr(10))
                say(f"recording {seconds:g} s to {out}: start the scene now")
            sleep(0.1)
        if not in_front(hwnd):  # a window that came up in the last moment
            raise SystemExit("another window came to the front while recording: the take was stopped and deleted "
                             "(keep Studio in front; run it again)")
        if proc.returncode != 0:
            raise SystemExit(f"FFmpeg couldn't record the screen (exit {proc.returncode}): see notes/spike-2.md S9")
        kept = True
        return out
    finally:
        try:
            _stop(proc)
        finally:
            if not kept:
                out.unlink(missing_ok=True)
                meta.unlink(missing_ok=True)
