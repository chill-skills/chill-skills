"""The data module's Cues (spec 6: marker -> VFX, screen FX, SFX or face action) and the awakening rules, built from
beats.json and the film set's framing. Method by fwjelaa (FWJ STUDIOS).

beats.json may carry  "cues": {"VFX:<value>": {kind, preset, at, yaw, follow, element, scale, external}, ...}.
A VFX marker without a cue plays the preset named by its value with the scene's defaults. `at` is studs from the
anchor (or from the followed part), or "<role>.head" / "<role>.face" (the role's head at the marker's frame, or
FACE studs in front of it toward the camera), which needs export/framing.json.
"""
import copy
import math
import re

import vfxlib

KIND_CONFIG = {  # beat-sheet config per kind, on top of beats.DEFAULT_CONFIG
    "awakening": {"Skip": False, "Replay": "always", "Cooldown": 30, "Element": "teal",
                  "Awakened": {"Duration": 30, "Aura": "Flame", "Look": ["eyes", "outline"]}},
    "ultimate": {"Skip": False, "Replay": "always", "Cooldown": 30},
}
UNSKIPPABLE = ("awakening", "ultimate")
UNSKIPPABLE_MAX = 10.5  # s: spec 6 keeps awakenings and ultimates (they can't be skipped) to about 4-10 s
FACE = 0.55  # studs: a "<role>.face" point sits this far in front of the head, toward the camera
PEAK = 1500  # live particles at once across a scene's VFX (research/03 s5, PC; spike S14 checks it while recording)
AT_POINT = re.compile(r"^(player|target|npc[1-9][0-9]?)\.(head|face)\Z")


def config_for(kind, base):
    """The starting config of a new beat sheet of this kind."""
    cfg = copy.deepcopy(base)
    cfg.update(copy.deepcopy(KIND_CONFIG.get(kind, {})))
    return cfg


def key(name, value):
    return f"{name}:{value}" if value not in (None, "") else name


def resolve_at(at, t, framing, label):
    """"player.face" at time t -> [x, y, z] studs from the anchor."""
    m = AT_POINT.match(at)
    if not m:
        raise SystemExit(f'cue {label}: at "{at}" must be 3 numbers or "<role>.head" / "<role>.face"')
    if not framing:
        raise SystemExit(f'cue {label}: at "{at}" needs export/framing.json (run filmset.export in Blender first)')
    role, point = m.groups()
    heads = framing["heads"].get(role)
    if not heads:
        raise SystemExit(f"cue {label}: the film set has no head track for {role}")
    i = max(0, min(len(heads) - 1, round(t * framing["fps"])))
    head = heads[i]
    if point == "head":
        return [round(v, 3) for v in head]
    cam = framing["camera"][min(i, len(framing["camera"]) - 1)][:3]
    d = [cam[k] - head[k] for k in range(3)]
    n = math.sqrt(sum(v * v for v in d)) or 1.0
    return [round(head[k] + d[k] / n * FACE, 3) for k in range(3)]


def module_cues(markers, explicit=None, framing=None, lib=None, strict=True):
    """Cues for the data module: one per VFX marker value (its explicit cue, else the preset of that name), each with
    the preset's budget for the kit checks, plus every other explicit cue. strict=False leaves string `at`s unresolved
    (the film set's guides)."""
    lib = lib or vfxlib.load()
    explicit = explicit or {}
    out = {}
    for m in markers:
        t, name, value = m[0], m[1], (m[2] if len(m) > 2 else "")
        if name != "VFX":
            continue
        k = key(name, value)
        if k in out:
            continue  # a string `at` resolves at the first marker of that cue
        cue = copy.deepcopy(explicit.get(k) or {"kind": "vfx", "preset": value})
        if cue.get("kind") == "screen" and strict:
            for f in ("at", "focus"):  # a manga effect at "<role>.face": a point the runtime projects every frame
                if isinstance(cue.get(f), str):
                    cue[f] = resolve_at(cue[f], t, framing, k)
        if cue.get("kind") == "vfx":
            if isinstance(cue.get("at"), str) and strict:
                cue["at"] = resolve_at(cue["at"], t, framing, k)
            if not cue.get("external") and cue.get("preset") in lib["presets"]:
                cue["budget"] = vfxlib.budget(lib, cue["preset"])
        out[k] = cue
    for k, cue in explicit.items():
        out.setdefault(k, copy.deepcopy(cue))
    return out


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def check_beats(b, lib=None):
    """What beats.validate adds for VFX: every VFX marker names a preset (or has a cue), cues are well formed,
    Slowmo values, and the length of unskippable scenes."""
    import schema  # here, not at the top: schema imports vfxlib too, and beats imports this module
    lib = lib or vfxlib.load()
    problems = []
    explicit = b.get("cues") or {}
    if not isinstance(explicit, dict):
        return ['cues must be an object: {"VFX:<value>": {"kind": "vfx", "preset": ...}}']
    for k, cue in explicit.items():
        # a "<role>.head" / "<role>.face" point resolves to numbers when the data module is written: check the rest
        plain = ({f: v for f, v in cue.items() if not (f in ("at", "focus") and isinstance(v, str) and AT_POINT.match(v))}
                 if isinstance(cue, dict) else cue)
        problems += [f"cues: {p}" for p in schema.cue_problems(k, plain, lib)]
        for f in ("at", "focus"):
            if isinstance(cue, dict) and isinstance(cue.get(f), str) and not AT_POINT.match(cue[f]):
                problems.append(f'cues: {k}.{f} "{cue[f]}" must be numbers or "<role>.head" / "<role>.face"')
        if isinstance(cue, dict) and isinstance(cue.get("follow"), str):
            role = cue["follow"].split(".")[0]
            if role not in (b.get("cast") or {}):
                problems.append(f"cues: {k} follows {role}, who is not in the cast")
    total = 0.0
    for i, s in enumerate(b.get("shots") or [], 1):
        if not isinstance(s, dict):
            continue
        total += s.get("length", 0) if _num(s.get("length")) else 0
        for m in s.get("markers") or []:
            if not (isinstance(m, list) and len(m) >= 2):
                continue
            value = str(m[2]) if len(m) > 2 else ""
            if m[1] == "VFX":
                k = key("VFX", value)
                if k not in explicit and value not in lib["presets"]:
                    problems.append(f"shot {i}: VFX marker {value!r} is not a preset ({', '.join(vfxlib.names(lib))}); "
                                    f"or give it a cue in beats.json cues")
            elif m[1] == "Slowmo":
                try:
                    ok = 0.05 <= float(value) <= 1
                except ValueError:
                    ok = False
                if not ok:
                    problems.append(f"shot {i}: Slowmo {value!r} must be a number from 0.05 to 1 (1 = normal speed)")
    if b.get("kind") in UNSKIPPABLE and total > UNSKIPPABLE_MAX + 1e-6:
        problems.append(f"an {b['kind']} can't be skipped, so it is kept to about 4-10 s (spec 6); this one is "
                        f"{total:.2f} s: shorten shots ({UNSKIPPABLE_MAX} s at most)")
    return problems


def peak(data, lib=None):
    """(the most particles the scene's VFX may have alive at once, the time it happens): each VFX marker counts its
    preset's particles over the preset's life (an upper bound)."""
    lib = lib or vfxlib.load()
    cues = data.get("Cues") or {}
    fired = []
    for m in data.get("Markers") or []:
        if m[1] != "VFX":
            continue
        cue = cues.get(key("VFX", m[2] if len(m) > 2 else "")) or {}
        preset = lib["presets"].get(cue.get("preset"))
        if preset and not cue.get("external"):
            fired.append((m[0], m[0] + preset["life"], vfxlib.budget(lib, cue["preset"])["particles"]))
    best, when = 0, 0.0
    for t, _, _ in fired:
        live = sum(p for a, b, p in fired if a <= t < b)
        if live > best:
            best, when = live, t
    return best, when


SCREEN_LAYERS = 6  # manga screen layers (focus lines, bursts, words) alive at once: CutsceneKit.Screen.MAX_LAYERS
SCREEN_LIFE = {"speedlines": 0.4, "burst": 0.5, "word": 1.0, "backdrop": 2.0}  # default lives: Screen.LIFE
BURST_FLASH = 0.6  # a burst at least this big (screen heights) counts as a flash: Screen.BURST_FLASH
BURST_SIZE = 0.45  # a burst's default size: Screen.BURST_SIZE


def screen_cue(data, m):
    """The screen cue a VFX marker fires, or None."""
    cue = (data.get("Cues") or {}).get(key("VFX", m[2] if len(m) > 2 else ""))
    return cue if isinstance(cue, dict) and cue.get("kind") == "screen" else None


def screen_layers(data):
    """(the most manga layers alive at once, the time it happens): each speedlines, burst or word cue over its life."""
    fired = []
    for m in data.get("Markers") or []:
        cue = screen_cue(data, m) if m[1] == "VFX" else None
        if cue and cue.get("effect") in ("speedlines", "burst", "word"):
            life = cue.get("life") if isinstance(cue.get("life"), (int, float)) else SCREEN_LIFE[cue["effect"]]
            fired.append((m[0], m[0] + life))
    best, when = 0, 0.0
    for t, _ in fired:
        live = sum(1 for a, b in fired if a <= t < b)
        if live > best:
            best, when = live, t
    return best, when


def flashes(data):
    """The times that count as flashes for the comfort rule: Flash and Impact markers, and big bursts."""
    out = []
    for m in data.get("Markers") or []:
        if m[1] in ("Flash", "Impact"):
            out.append(m[0])
        elif m[1] == "VFX":
            cue = screen_cue(data, m)
            if cue and cue.get("effect") == "burst" and (cue.get("size") or BURST_SIZE) >= BURST_FLASH:
                out.append(m[0])
    return sorted(out)


def checks(data, lib=None):
    """Kit checks (spec 8 gate 1) for VFX and awakenings, on the data module's dict."""
    lib = lib or vfxlib.load()
    issues = []
    kind, length = data.get("Kind"), data.get("Length") or 0
    if kind in UNSKIPPABLE and length > UNSKIPPABLE_MAX + 1e-6:
        issues.append(f"an {kind} can't be skipped: keep it to about 4-10 s (it is {length:g} s)")
    if kind == "awakening":
        if not any(m[1] == "Impact" for m in data.get("Markers") or []):
            issues.append("an awakening needs an Impact marker on its burst (spec 7: impact frames; the aura arrives on it)")
        aura = ((data.get("Config") or {}).get("Awakened") or {}).get("Aura", "Flame")
        if aura in lib["auras"] and vfxlib.aura_budget(lib, aura) > vfxlib.AURA_PARTICLES:
            issues.append(f"aura {aura} keeps more than {vfxlib.AURA_PARTICLES} particles alive")
    most, when = peak(data, lib)
    if most > PEAK:
        issues.append(f"up to {most} VFX particles alive at once from {when:g} s (at most {PEAK}): drop or shrink a layer")
    layers, when = screen_layers(data)
    if layers > SCREEN_LAYERS:
        issues.append(f"up to {layers} manga screen layers at once from {when:g} s (at most {SCREEN_LAYERS}; the runtime "
                      "drops the rest): drop a word, burst or line set")
    return issues
