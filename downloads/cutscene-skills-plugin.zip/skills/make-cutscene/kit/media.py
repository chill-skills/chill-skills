"""FFmpeg, ffprobe and yt-dlp for reference clips and previews: probe, fetch, trim, cuts, frame scores, freezes,
labelled cells, text cards and tiled sheets. Shells out only; needs no Pillow or numpy. Method by fwjelaa (FWJ STUDIOS).

Measured on FFmpeg 9 (2026-11-07): scdet logs "lavfi.scd.time: <t>" per cut; select + metadata=print gives every
frame's lavfi.scene_score (0.000000 on a repeated frame); freezedetect logs freeze_start / freeze_end; drawtext needs
the font path quoted with its drive colon escaped ('C\\:/Windows/Fonts/arial.ttf'); tile flushes a part-filled sheet.
"""
import json
import re
import shutil
import subprocess
import tempfile
import textwrap
from pathlib import Path

FONTS = (Path("C:/Windows/Fonts/arial.ttf"), Path("C:/Windows/Fonts/segoeui.ttf"),
         Path("/System/Library/Fonts/Supplemental/Arial.ttf"), Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
BG = "0x16171b"
DUP_SCORE = 0.0005  # a frame this close to the one before it is a held (repeated) frame


class MediaError(RuntimeError):
    pass


def _run(cmd, binary=False):
    cmd = [str(c) for c in cmd]
    text = {} if binary else {"text": True, "encoding": "utf-8", "errors": "replace"}
    try:
        proc = subprocess.run(cmd, capture_output=True, **text)
    except FileNotFoundError:
        raise MediaError(f"{cmd[0]} is not installed: run  py kit/run.py check") from None
    if proc.returncode != 0:
        err = proc.stderr.decode("utf-8", "replace") if binary else proc.stderr
        raise MediaError(f"{cmd[0]} failed: " + " | ".join(err.strip().splitlines()[-4:]))
    return proc


def ffmpeg(*args, binary=False):
    return _run(["ffmpeg", "-hide_banner", "-nostats", "-y", *args], binary)


def font():
    return next((p for p in FONTS if p.exists()), None)


def ff_path(p):
    """A path inside a filtergraph option: forward slashes, the drive colon escaped, single-quoted."""
    return "'" + Path(p).as_posix().replace(":", "\\:") + "'"


def probe(path):
    proc = _run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                 "stream=width,height,avg_frame_rate,r_frame_rate:format=duration", "-of", "json", path])
    info = json.loads(proc.stdout)
    if not info.get("streams"):
        raise MediaError(f"{Path(path).name} has no picture in it")
    s = info["streams"][0]

    def rate(text):
        num, _, den = (text or "0/1").partition("/")
        return float(num) / float(den) if den and float(den) else 0.0

    return {"width": int(s["width"]), "height": int(s["height"]),
            "fps": round(rate(s.get("avg_frame_rate")) or rate(s.get("r_frame_rate")), 3),
            "duration": float((info.get("format") or {}).get("duration") or 0.0)}


def synth(path, segments, size="320x180", fps=30):
    """A test clip with hard cuts. segments = [(lavfi source, seconds)] or (source, seconds, source fps), e.g.
    [("testsrc", 1.5), ("color=c=red", 1.0)]. A source fps below fps repeats frames (animated on twos)."""
    parts, labels = [], []
    for i, seg in enumerate(segments):
        src, secs = seg[0], seg[1]
        rate = seg[2] if len(seg) > 2 else fps
        sep = ":" if "=" in src else "="
        parts.append(f"{src}{sep}d={secs}:s={size}:r={rate},fps={fps}[v{i}]")
        labels.append(f"[v{i}]")
    graph = ";".join(parts) + ";" + "".join(labels) + f"concat=n={len(segments)}:v=1:a=0"
    # lossless, so a repeated frame decodes identical (score 0) and the tests stay exact
    ffmpeg("-f", "lavfi", "-i", graph, "-c:v", "libx264", "-preset", "ultrafast", "-qp", "0", "-pix_fmt", "yuv420p", path)
    return Path(path)


def fetch(url, dest_dir, run=subprocess.run):
    """Download a video link with yt-dlp into dest_dir/source.<ext> (1080p at most, no playlists)."""
    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    for old in dest.glob("source.*"):
        old.unlink()
    cmd = ["yt-dlp", "--no-playlist", "-f", "bv*[height<=1080]+ba/b[height<=1080]/b", "--merge-output-format", "mp4",
           "-o", str(dest / "source.%(ext)s"), url]
    try:
        proc = run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    except FileNotFoundError:
        raise MediaError("yt-dlp is not installed: ask the viewer for the video file (or install yt-dlp)") from None
    found = sorted(dest.glob("source.*"))
    if proc.returncode != 0 or not found:
        raise MediaError("the link won't download (private, removed, age-gated or blocked): ask the viewer for the "
                         "video file")
    return found[0]


def trim(src, dst, start=0.0, end=None):
    """Re-encoded, so the cut is frame-accurate; the picture only (reference sound isn't used)."""
    span = ["-ss", f"{start:.3f}"] + (["-to", f"{end:.3f}"] if end is not None else [])
    ffmpeg(*span, "-i", src, "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p", dst)
    return Path(dst)


def cuts(path, threshold=10.0):
    proc = ffmpeg("-i", path, "-vf", f"scdet=threshold={threshold}", "-an", "-f", "null", "-")
    return sorted({round(float(t), 3) for t in re.findall(r"lavfi\.scd\.time: ([0-9.]+)", proc.stderr)})


def frame_scores(path):
    proc = ffmpeg("-i", path, "-vf", "select='gte(scene,0)',metadata=print:key=lavfi.scene_score", "-an", "-f", "null", "-")
    times = [float(t) for t in re.findall(r"pts_time:([0-9.]+)", proc.stderr)]
    scores = [float(s) for s in re.findall(r"lavfi\.scene_score=([0-9.]+)", proc.stderr)]
    return list(zip(times, scores))


def freezes(path, noise=0.003, min_dur=0.15):
    proc = ffmpeg("-i", path, "-vf", f"freezedetect=n={noise}:d={min_dur}", "-an", "-f", "null", "-")
    starts = [float(x) for x in re.findall(r"freeze_start: ([0-9.]+)", proc.stderr)]
    ends = [float(x) for x in re.findall(r"freeze_end: ([0-9.]+)", proc.stderr)]
    if len(ends) < len(starts):  # a freeze that runs to the end of the clip has no end line
        ends += [probe(path)["duration"]] * (len(starts) - len(ends))
    return [(round(s, 3), round(e, 3)) for s, e in zip(starts, ends)]


def grab(path, t, out, width=480):
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    ffmpeg("-ss", f"{max(0.0, t):.3f}", "-i", path, "-frames:v", "1", "-vf", f"scale={width}:-2", out)
    return Path(out)


def _label(text_file, h):
    f = font()
    if not f:
        return ""
    return (f",drawtext=fontfile={ff_path(f)}:textfile={ff_path(text_file)}:expansion=none:fontcolor=white:"
            f"fontsize={max(12, h // 11)}:box=1:boxcolor=black@0.6:boxborderw=4:x=6:y=h-th-8")


def cell(src, out, label="", size=(320, 180), t=None):
    """One frame of src (a video at t seconds, or a picture) fitted into a size box, with a label along the bottom."""
    w, h = size
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    vf = f"scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:color={BG}"
    txt = out.with_name(out.stem + "_label.txt")
    try:
        if label:
            txt.write_text(label, encoding="utf-8")
            vf += _label(txt, h)
        seek = ["-ss", f"{max(0.0, t):.3f}"] if t is not None else []
        out.unlink(missing_ok=True)
        ffmpeg(*seek, "-i", src, "-frames:v", "1", "-vf", vf, out)
    finally:
        txt.unlink(missing_ok=True)
    if not out.exists():  # a seek past the last frame: FFmpeg exits 0 and writes nothing
        raise MediaError(f"no picture at {t or 0:.2f} s in {Path(src).name} (past its last frame?)")
    return out


def card(lines, out, size=(320, 180)):
    """A text card the size of a cell (a beat with no reference picture)."""
    w, h = size
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    txt = out.with_name(out.stem + "_card.txt")
    f = font()
    try:
        txt.write_text("\n".join(lines), encoding="utf-8")
        vf = "null" if not f else (f"drawtext=fontfile={ff_path(f)}:textfile={ff_path(txt)}:expansion=none:"
                                   f"fontcolor=white:fontsize={max(12, h // 12)}:line_spacing=4:x=10:y=10")
        ffmpeg("-f", "lavfi", "-i", f"color=c={BG}:s={w}x{h}:d=0.1", "-frames:v", "1", "-vf", vf, out)
    finally:
        txt.unlink(missing_ok=True)
    return out


def wrap(text, size=(320, 180)):
    """Text for card(): wrapped to the card's width, cut to the lines that fit."""
    w, h = size
    fs = max(12, h // 12)
    lines = textwrap.wrap(text, width=max(10, int(w / (fs * 0.55))))
    return lines[: max(1, (h - 20) // (fs + 4))]


def sheet(cells, out, cols=4):
    """Tile same-size cells (from cell() or card()) into one PNG, left to right, top to bottom."""
    cells = [Path(c) for c in cells]
    if not cells:
        raise MediaError("no frames for the sheet")
    rows = (len(cells) + cols - 1) // cols
    with tempfile.TemporaryDirectory() as d:
        for i, c in enumerate(cells):
            shutil.copyfile(c, Path(d) / f"{i:04d}.png")
        ffmpeg("-framerate", "1", "-i", str(Path(d) / "%04d.png"), "-vf",
               f"tile={cols}x{rows}:padding=4:margin=4:color={BG}", "-frames:v", "1", out)
    return Path(out)
