"""Studio steps for one cutscene, as self-contained Luau files: nothing in Studio uses HTTP
(.sdd/plan-1/ruling-bundle.md). Method by fwjelaa (FWJ STUDIOS).

    py kit/run.py studio <id> <step> [options]  ->  cutscenes/<id>/studio/<step>.luau, sent with execute_luau (Edit)

Each file embeds the authoring modules it needs (roblox/authoring/*.luau), builds fresh ModuleScripts from them, calls
one function with the arguments below and removes the modules again (roblox/templates/studio.luau).
"""
import json
from pathlib import Path

import beats
import bundle
import costume
import mapcap
import paths
import payload
import workspace

TEMPLATE = paths.ROBLOX / "templates" / "studio.luau"
AUTHORING = paths.ROBLOX / "authoring"
BUDGET = 60_000  # bytes per execute_luau payload: everything sent passes through the model


def clean(v):
    """Drop None values all the way down (a Luau table can't hold nil)."""
    if isinstance(v, dict):
        return {k: clean(x) for k, x in v.items() if x is not None}
    if isinstance(v, (list, tuple)):
        return [clean(x) for x in v if x is not None]
    return v


def _text(modules, main, call, args, extra=None):
    embed = {"modules": {m: bundle._read(AUTHORING / f"{m}.luau") for m in modules}, "main": main, "call": call,
             "args": clean(args)}
    embed["modules"].update(extra or {})
    return bundle.render(TEMPLATE, embed)


def _size(text):
    return len(text.encode("utf-8"))


def render(root, step, modules, main, call, args, extra=None):
    """Writes studio/<step>.luau; a step over BUDGET is written as payload parts instead (<step>.luau, <step>.2.luau, ...:
    kit/payload.py), because everything sent passes through the model. Parts left by an earlier, longer render of the
    step are removed. extra = {module name: source} for modules that are not in roblox/authoring (the step's own
    helpers)."""
    text = _text(modules, main, call, args, extra)
    size = _size(text)
    folder = Path(root) / "studio"
    folder.mkdir(parents=True, exist_ok=True)
    written = payload.write_parts(folder, f"{step}.luau", text, BUDGET, "studio")
    if len(written) == 1:
        return written[0], f"wrote {written[0]} ({size / 1000:.1f} KB)"
    return written, _parts_note(written, size)


def _parts_note(written, size):
    sizes = ", ".join(f"{p.name} {p.stat().st_size / 1000:.1f} KB" for p in written)
    return (f"{size / 1000:.1f} KB is over the {BUDGET // 1000} KB limit for one execute_luau, so it is written as "
            f"{len(written)} parts in {written[0].parent}: {sizes}\n"
            f"send them in order ({' then '.join(p.name for p in written)}); the last part runs it")


def parse_at(text):
    try:
        values = [float(v) for v in str(text).split(",")]
    except ValueError:
        values = []
    if len(values) != 4:
        raise SystemExit("--at needs x,y,z,yaw (studs and degrees), like --at 12,0,-40,90")
    return values


def chunk_line(cid, n):
    return f'return game:GetService("ServerStorage")["CutsceneCapture_{cid}"]["{int(n)}"].Value'


def trigger_of(b, opts):
    trig = dict(b.get("trigger") or {})
    if opts.get("trigger"):
        trig["type"] = opts["trigger"]
    if trig.get("type") not in beats.TRIGGERS:
        raise SystemExit("set the trigger in beats.json first (zone, prompt or api): py kit/run.py beats <id>")
    if trig["type"] == "zone":
        trig.setdefault("size", list(beats.ZONE))
    return trig


def step_anchor(root, b, opts):
    args = {"name": b["id"], "trigger": trigger_of(b, opts)}
    if opts.get("at"):
        args["at"] = parse_at(opts["at"])
    else:
        args["from"] = opts.get("from") or "camera"
    return render(root, "anchor", ["Capture"], "Capture", "placeTrigger", args)


def step_map(root, b, opts):
    return render(root, "map", ["Capture"], "Capture", "storeMap", {"name": b["id"], "radius": opts.get("radius")})


def step_rig(root, b, opts):
    role = opts.get("role")
    cast = b.get("cast") or {}
    if role not in cast:
        raise SystemExit(f"--role must be one of the cast: {', '.join(cast)}")
    c = cast[role] or {}
    if costume.is_costume(c):  # spec 14: the body that will act is the costume's, so capture that one
        spec = costume.install_specs(root, b)[role]
        if spec["kind"] == "creature":
            raise SystemExit(f"{role} is a creature: its rig comes from cast/{role}.json (py kit/run.py costume {b['id']})")
        return render(root, f"rig_{role}", ["Costume", "Capture"], "Costume", "captureRig", {"role": role, "spec": spec})
    if role == "player":
        args = {"role": role, "source": "starter", "rig": "R15"}
    elif c.get("model") in (None, "", "default"):
        args = {"role": role, "source": "default", "rig": c.get("rig", "R15")}
    else:
        args = {"role": role, "source": "path", "path": c["model"], "rig": c.get("rig", "R15")}
    return render(root, f"rig_{role}", ["Capture"], "Capture", "captureRig", args)


def _cf(cf):
    """Position to 4 decimals, rotation to 6 (4 would leave the matrix visibly non-orthonormal)."""
    return [round(v, 4) for v in cf[:3]] + [round(v, 6) for v in cf[3:]]


def compact(data):
    """A clip's JSON for embedding: only what ClipBuilder reads, CFrame numbers to 4 decimals."""
    keep = {k: data[k] for k in ("name", "loop", "priority", "parents")}
    keep["keyframes"] = [{"time": k["time"], "markers": k.get("markers", []),
                          "poses": {p: {"cf": _cf(pose["cf"]), "style": pose["style"], "dir": pose["dir"]}
                                    for p, pose in k["poses"].items()}} for k in data["keyframes"]]
    return json.dumps(keep, separators=(",", ":"))


def _install_args(b, data, manifest, opts, worn=None):
    worn = worn or {}  # spec 14: {role: costume spec}; these roles are built from their specs, not copied from the map
    args = {"name": b["id"], "data": data, "trigger": trigger_of(b, opts),
            "cast": {r: c for r, c in b["cast"].items() if r != "player" and r not in worn},
            "anchor": manifest.get("anchor")}
    if worn:
        args["costumes"] = worn
    return args


def _clip_names(scene, rig):
    names = [scene["clips"]["Stage"]]
    for kind in ("R15", "R6"):
        for role, name in (scene["clips"].get(kind) or {}).items():
            if role != "player" or rig in ("both", kind):
                names.append(name)
    return names


def _plan_parts(b, final_args, clips):
    """[(clip names, text)] for a Studio-only install: every text but the last fits BUDGET; the last one carries the
    data module, cast and trigger (and Capture) and may be over: step_install sends it as payload parts."""
    def part(names, k, n):
        args = {"name": b["id"], "part": k, "parts": n, "clips": {c: clips[c] for c in names}}
        last = k == n
        if last:
            args.update(final_args)
        mods = (["SceneInstall", "Capture", "ClipBuilder"] + (["Costume"] if final_args.get("costumes") else [])
                if last else ["SceneInstall", "ClipBuilder"])
        return _text(mods, "SceneInstall", "install", args)

    groups, cur = [], []
    for c in clips:
        # measured as part 99 of 100: the part numbers are as wide as any real count will be
        if cur and _size(part(cur + [c], 99, 100)) > BUDGET:
            groups.append(cur)
            cur = [c]
        else:
            cur.append(c)
        if _size(part(cur, 99, 100)) > BUDGET:
            raise SystemExit(f"clip {c} alone is over the {BUDGET // 1000} KB limit for one execute_luau: upload the "
                             f"clips and install by asset id (py kit/run.py upload {b['id']})")
    if _size(part(cur, 100, 100)) > BUDGET:  # the last part also carries Capture and the data module
        groups.append(cur)
        cur = []
    groups.append(cur)
    n = len(groups)
    return [(g, part(g, k + 1, n)) for k, g in enumerate(groups)]


def step_install(root, b, opts):
    out = Path(root) / "export"
    for need_file in ("manifest.json", "scene.json"):
        if not (out / need_file).exists():
            raise SystemExit(f"no export for {b['id']} yet ({need_file} is missing): run  py kit/run.py scene {b['id']}  first")
    manifest = workspace.read_json(out / "manifest.json")
    scene = workspace.read_json(out / "scene.json")
    data = (out / manifest["data"]).read_text(encoding="utf-8")
    for old in (Path(root) / "studio").glob("install*.luau"):
        old.unlink()
    worn = costume.install_specs(root, b)
    if not opts.get("clips"):
        missing = [n for n in manifest["clips"] if f'"{n}"' in data]
        if missing:
            raise SystemExit(f"{len(missing)} clips aren't uploaded yet ({', '.join(missing)}): run  py kit/run.py upload "
                             f"{b['id']} , or add --clips for a Studio-only preview")
        return render(root, "install", ["SceneInstall", "Capture"] + (["Costume"] if worn else []), "SceneInstall",
                      "install", _install_args(b, data, manifest, opts, worn))
    clips = {n: compact(workspace.read_json(out / f"{n}.json")) for n in _clip_names(scene, opts.get("rig") or "R15")}
    plan = _plan_parts(b, _install_args(b, data, manifest, opts, worn), clips)
    studio_dir = Path(root) / "studio"
    studio_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for k, (_, text) in enumerate(plan, 1):
        name = "install.luau" if len(plan) == 1 else f"install.{k}.luau"
        if k < len(plan):
            path = studio_dir / name
            path.write_text(text, encoding="utf-8", newline="\n")
            written.append(path)
        else:  # the last part carries Capture and the data module: over BUDGET it goes in payload parts of its own
            written += payload.write_parts(studio_dir, name, text, BUDGET, "studio")
    total = sum(p.stat().st_size for p in written)
    note = f"wrote {', '.join(p.name for p in written)} in {studio_dir} ({total / 1000:.1f} KB)"
    if len(written) > 1:
        note += (f"\n{len(written)} parts (~{int(total / 3.5)} tokens): send them in order; with an Open Cloud key, upload "
                 f"instead (py kit/run.py upload {b['id']}) for a one-part install")
    note += "  (Studio-only clips: this scene won't play in a published game until it is uploaded)"
    return (written[0] if len(written) == 1 else written), note


def step_remove(root, b, opts):
    return render(root, "remove", ["SceneInstall"], "SceneInstall", "remove", {"name": b["id"]})


def record_switch():
    return {"RecordSwitch": bundle._read(paths.ROBLOX / "templates" / "record_switch.luau")}


def step_record_on(root, b, opts):
    src = bundle._read(AUTHORING / "RecordOverlay.client.luau")
    return render(root, "record-on", ["SceneInstall"], "RecordSwitch", "on", {"source": src}, record_switch())


def step_record_off(root, b, opts):
    return render(root, "record-off", ["SceneInstall"], "RecordSwitch", "off", {}, record_switch())


def step_playtest_on(root, b, opts):
    return render(root, "playtest-on", ["SceneInstall"], "SceneInstall", "devModule",
                  {"name": "CutsceneKitPlayTest", "source": bundle._read(AUTHORING / "PlayTest.luau")})


def step_playtest_off(root, b, opts):
    return render(root, "playtest-off", ["SceneInstall"], "SceneInstall", "devModule",
                  {"name": "CutsceneKitPlayTest", "remove": True})


EXAMPLES = paths.ROBLOX / "examples"
_DIGITS = ("Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine")
# keys the player already uses for something else: --key refuses them and says what for
TAKEN_KEYS = {
    "W": "movement", "A": "movement", "S": "movement", "D": "movement", "Up": "movement and the camera",
    "Down": "movement and the camera", "Left": "movement and the camera", "Right": "movement and the camera",
    "Space": "jump", "LeftShift": "shift lock", "RightShift": "shift lock", "I": "camera zoom", "O": "camera zoom",
    "Slash": "chat", "Return": "chat", "Tab": "the player list", "Backquote": "a console key in many games",
    "Escape": "Roblox's menu", "F9": "Roblox's developer console", "F11": "full screen",
}
NAMED_KEYS = ("Insert", "Home", "End", "PageUp", "PageDown", "LeftControl", "RightControl")
# --key, lower-cased -> its Enum.KeyCode name: letters, digits (5 or Five), F1-F12 and NAMED_KEYS, minus TAKEN_KEYS
KEYCODE = {k: v for k, v in {**{c.lower(): c for c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ"},
                             **{str(i): d for i, d in enumerate(_DIGITS)}, **{d.lower(): d for d in _DIGITS},
                             **{f"f{i}": f"F{i}" for i in range(1, 13)}, **{n.lower(): n for n in NAMED_KEYS}}.items()
           if v not in TAKEN_KEYS}


def key_code(key):
    """The Enum.KeyCode name for --key, or SystemExit saying why not."""
    if isinstance(key, str):
        for taken, use in TAKEN_KEYS.items():
            if key.lower() == taken.lower():
                raise SystemExit(f"--key {key}: {taken} is the player's ({use}); pick another, like G, F, Q or E")
        if key.lower() in KEYCODE:
            return KEYCODE[key.lower()]
    raise SystemExit(f"--key takes a letter (not W, A, S, D, I or O), a digit 0-9, F1-F12 (not F9 or F11) or one of "
                     f"{', '.join(NAMED_KEYS)} (got {key!r})")


# the example's placeholder lines (Task 10's security ruling: the scene is fixed on the server; clients never name it)
SCENE_LINE = 'local SCENE = "" -- set by `py kit/run.py studio <id> keybind`: the one scene this key bind starts'
NAME_LINE = 'local NAME = "" -- set by `py kit/run.py studio <id> keybind`'
KEY_LINE = "local KEY = Enum.KeyCode.G -- set by `py kit/run.py studio <id> keybind --key <KeyCode>`"


def keybind_sources(name, key="G"):
    """The example key bind's two scripts with this scene and key filled in."""
    if not isinstance(name, str) or not paths.ID_RULE.match(name):
        raise SystemExit(f"the key bind's scene must be a cutscene id (letters, digits and _; got {name!r})")
    key = key_code(key)
    server = bundle._read(EXAMPLES / "AwakenKeyBind.server.luau")
    client = bundle._read(EXAMPLES / "AwakenKeyBind.client.luau")
    for text, line in ((server, SCENE_LINE), (client, NAME_LINE), (client, KEY_LINE)):
        if text.split("\n").count(line) != 1:
            raise SystemExit(f"roblox/examples changed: the line {line!r} must appear exactly once")
    server = server.replace(SCENE_LINE,
                            f'local SCENE = "{name}" -- the one scene this key bind starts (the client never names it)')
    client = client.replace(NAME_LINE, f'local NAME = "{name}"').replace(KEY_LINE, f"local KEY = Enum.KeyCode.{key}")
    return server, client


def step_keybind(root, b, opts):
    if b.get("kind") != "awakening":
        raise SystemExit(f"the key bind example starts awakenings; {b['id']} is a {b.get('kind')} scene")
    server, client = keybind_sources(b["id"], opts.get("key") or "G")
    return render(root, "keybind", ["SceneInstall"], "SceneInstall", "keyBind",
                  {"name": "AwakenKeyBind", "server": server, "client": client})


def step_keybind_off(root, b, opts):
    return render(root, "keybind-off", ["SceneInstall"], "SceneInstall", "keyBind",
                  {"name": "AwakenKeyBind", "remove": True})


STEPS = {"anchor": step_anchor, "map": step_map, "rig": step_rig, "install": step_install,
         "remove": step_remove, "record-on": step_record_on, "record-off": step_record_off,
         "playtest-on": step_playtest_on, "playtest-off": step_playtest_off}


def step_costume_look(root, b, opts):
    worn = costume.install_specs(root, b)
    if not worn:
        raise SystemExit('no role wears a costume: give it "model": "costume" in beats.json and write cast/<role>.json')
    at = parse_at(opts["at"]) if opts.get("at") else list(costume.LINEUP)
    return render(root, "costume-look", ["Costume"], "Costume", "lineup", {"costumes": worn, "at": at})


def step_costume_look_off(root, b, opts):
    return render(root, "costume-look-off", ["Costume"], "Costume", "lineupOff", {})


STEPS.update({"costume-look": step_costume_look, "costume-look-off": step_costume_look_off})


STEPS.update({"keybind": step_keybind, "keybind-off": step_keybind_off})


def run_step(cid, step, opts, env=None):
    root = workspace.open_(cid, env)
    if step == "chunk":
        n = int(opts.get("n") or 0)
        return [chunk_line(cid, n),
                f"send that one line with execute_luau (Edit); save the returned string, exactly, to "
                f"{root / 'studio' / f'map_{n}.txt'}"]
    if step not in STEPS:
        raise SystemExit(f"unknown studio step {step!r}: use one of {', '.join(sorted(list(STEPS) + ['chunk']))}")
    path, note = STEPS[step](root, beats.load(root), opts)
    if isinstance(path, list):
        lines = [note] + [f"send part {k}: execute_luau (Edit) with the full text of {p}" for k, p in enumerate(path, 1)]
    else:
        lines = [note, f"send it: execute_luau (Edit) with the full text of {path}"]
    stale = sorted(p.name for p in (root / "studio").glob("map_*.txt")) if step == "map" else []
    if stale:
        lines.append(f"{mapcap.STALE} (found {', '.join(stale)}); the new capture's chunks must be the only ones")
    return lines
