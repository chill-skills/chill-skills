"""Tests for kit/mapcap.py: chunks checked and merged into map.json. Method by fwjelaa (FWJ STUDIOS)."""
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import mapcap  # noqa: E402
import workspace  # noqa: E402

ANCHOR = [0, 0, -40, 1, 0, 0, 0, 1, 0, 0, 0, 1]


def capture(name="A", boxes="b,10,20,30,40,20,20,0,900,0,f00;b,-5,0,0,10,10,10,0,0,0,888", cells="t,1,-2,15",
            nonce="aaaaaaaa", skipped=0, found=2):
    head = json.dumps({"v": 1, "name": name, "anchor": ANCHOR, "radius": 150, "boxes": boxes.count("b,"),
                       "cells": cells.count("t,"), "skipped": skipped, "found": found, "terrain": {"step": 6, "n": 12}})
    bodies = [boxes, cells]
    return [mapcap.make_chunk(name, i, 3, p, nonce) for i, p in enumerate([head] + bodies)]


def write_folder(root, texts, start=0):
    (root / "studio").mkdir(parents=True, exist_ok=True)
    for i, t in enumerate(texts, start):
        (root / "studio" / f"map_{i}.txt").write_text(t, encoding="utf-8")


class MapcapTest(unittest.TestCase):
    def test_adler_matches_the_luau_one(self):
        self.assertEqual(mapcap.adler("Wikipedia"), "11e60398")

    def test_merge_builds_boxes_and_terrain(self):
        m = mapcap.merge([(f"map_{i}", t) for i, t in enumerate(capture())])
        self.assertEqual(m["anchor"], ANCHOR)
        self.assertEqual(m["boxes"][0], [1.0, 2.0, 3.0, 4.0, 2.0, 2.0, 0.0, 90.0, 0.0, "f00"])
        self.assertEqual(m["terrain"]["cells"], [[1, -2, 1.5]])
        self.assertEqual(m["terrain"]["step"], 6)

    def test_a_box_record_may_carry_its_transparency_in_percent(self):
        m = mapcap.merge([(f"map_{i}", t) for i, t in enumerate(capture(
            boxes="b,10,20,30,40,20,20,0,900,0,f00,100;b,-5,0,0,10,10,10,0,0,0,888,35;b,0,0,0,10,10,10,0,0,0,888"))])
        self.assertEqual([b[10:] for b in m["boxes"]], [[1.0], [0.35], []])
        self.assertEqual(m["boxes"][0][9], "f00")

    def test_corrupted_chunk_is_named(self):
        texts = capture()
        texts[1] = texts[1].replace("b,10,20", "b,10,21")
        with self.assertRaises(mapcap.ChunkError) as e:
            mapcap.merge([(f"map_{i}", t) for i, t in enumerate(texts)])
        self.assertIn("fetch chunk 1 again", str(e.exception))

    def test_missing_chunk_is_listed(self):
        with self.assertRaises(mapcap.ChunkError) as e:
            mapcap.merge([(f"map_{i}", t) for i, t in enumerate(capture()) if i != 2])
        self.assertIn("missing chunks 2", str(e.exception))

    def test_chunks_from_two_captures_are_refused(self):
        texts = capture("A")[:2] + capture("B")[2:]
        with self.assertRaises(mapcap.ChunkError) as e:
            mapcap.merge([(f"m{i}", t) for i, t in enumerate(texts)])
        self.assertIn("capture again", str(e.exception))

    def test_record_count_mismatch(self):
        texts = capture()
        payload = texts[0].split("\n", 1)[1].replace('"boxes": 2', '"boxes": 3')
        texts[0] = mapcap.make_chunk("A", 0, 3, payload)
        with self.assertRaises(mapcap.ChunkError) as e:
            mapcap.merge([(f"m{i}", t) for i, t in enumerate(texts)])
        self.assertIn("capture again", str(e.exception))

    def test_a_trailing_newline_from_the_copy_is_fine(self):
        texts = [t + "\n" for t in capture()]
        self.assertEqual(len(mapcap.merge([(f"m{i}", t) for i, t in enumerate(texts)])["boxes"]), 2)

    def test_header_line_missing(self):
        with self.assertRaises(mapcap.ChunkError) as e:
            mapcap.parse_chunk("b,1,2,3", "map_5.txt")
        self.assertIn("map_5.txt", str(e.exception))

    def test_orient_is_from_orientation(self):
        r = mapcap.orient(0, 90, 0)
        x = [r[i][0] for i in range(3)]
        for got, want in zip(x, (0, 0, -1)):
            self.assertAlmostEqual(got, want)

    def test_corners_of_a_turned_box(self):
        c = mapcap.corners([0, 0, 0, 4, 2, 2, 0, 90, 0, "fff"])
        for got, want in zip(c[7], (1, 1, -2)):
            self.assertAlmostEqual(got, want)
        self.assertEqual(len(mapcap.FACES), 6)

    def test_same_name_but_another_capture_is_named(self):
        texts = capture(nonce="aaaaaaaa")[:2] + capture(nonce="bbbbbbbb")[2:]
        with self.assertRaises(mapcap.ChunkError) as e:
            mapcap.merge([("map_0.txt", texts[0]), ("map_1.txt", texts[1]), ("map_2.txt", texts[2])])
        msg = str(e.exception)
        self.assertIn("aaaaaaaa", msg)
        self.assertIn("bbbbbbbb", msg)
        self.assertIn("map_2.txt", msg)
        self.assertIn("delete studio/map_*.txt from an older capture first", msg)

    def test_truncated_chunk_fails_the_length_check(self):
        texts = capture()
        head, payload = texts[1].split("\n", 1)
        texts[1] = head + "\n" + payload[:-4]
        with self.assertRaises(mapcap.ChunkError) as e:
            mapcap.merge([(f"map_{i}", t) for i, t in enumerate(texts)])
        self.assertIn("length", str(e.exception))
        self.assertIn("fetch chunk 1 again", str(e.exception))

    def test_duplicated_and_out_of_range_indexes(self):
        texts = capture()
        with self.assertRaises(mapcap.ChunkError) as e:
            mapcap.merge([("a.txt", texts[0]), ("b.txt", texts[1]), ("c.txt", texts[1]), ("d.txt", texts[2])])
        self.assertIn("chunk 1", str(e.exception))
        self.assertIn("twice", str(e.exception))
        wide = mapcap.make_chunk("A", 5, 3, "b,1,2", "aaaaaaaa")
        with self.assertRaises(mapcap.ChunkError) as e:
            mapcap.merge([(f"m{i}", t) for i, t in enumerate(texts)] + [("map_5.txt", wide)])
        self.assertIn("map_5.txt", str(e.exception))

    def test_non_ascii_payload_counts_bytes(self):
        payload = '{"name": "caf\u00e9"}'
        chunk = mapcap.make_chunk("A", 0, 1, payload, "aaaaaaaa")
        self.assertTrue(chunk.split("\n", 1)[0].endswith(f" {len(payload.encode('utf-8'))}"))
        self.assertEqual(mapcap.parse_chunk(chunk)[3], payload)
        with self.assertRaises(mapcap.ChunkError):
            mapcap.parse_chunk(chunk.replace("\u00e9", "e"), "x")

    def test_summary_counts_overflow_once(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "A"
            boxes = ";".join("b,0,0,0,10,10,10,0,0,0,fff" for _ in range(900))
            write_folder(root, capture(boxes=boxes, cells="t,1,1,1", skipped=100, found=1000))
            _, summary = mapcap.merge_folder(root)
            self.assertIn("900 stand-ins (100 left out of 1000)", summary)

    def test_stale_files_are_listed(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "A"
            write_folder(root, capture(nonce="aaaaaaaa"))
            write_folder(root, capture(nonce="bbbbbbbb")[:1], start=0)
            with self.assertRaises(mapcap.ChunkError) as e:
                mapcap.merge_folder(root)
            self.assertIn("delete studio/map_*.txt from an older capture first", str(e.exception))
            self.assertIn("map_1.txt", str(e.exception))

    def test_bad_file_names_and_bytes_are_named(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "A"
            write_folder(root, capture())
            (root / "studio" / "map_x.txt").write_text("hi", encoding="utf-8")
            with self.assertRaises(mapcap.ChunkError) as e:
                mapcap.merge_folder(root)
            self.assertIn("map_x.txt", str(e.exception))
            (root / "studio" / "map_x.txt").unlink()
            (root / "studio" / "map_1.txt").write_bytes(b"MAPCAP A 1/3 aaaaaaaa 00000000 1\n\xff\xfe")
            with self.assertRaises(mapcap.ChunkError) as e:
                mapcap.merge_folder(root)
            self.assertIn("map_1.txt", str(e.exception))
            self.assertIn("UTF-8", str(e.exception))

    def test_merge_folder_writes_map_json(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "A"
            (root / "studio").mkdir(parents=True)
            for i, t in enumerate(capture()):
                (root / "studio" / f"map_{i}.txt").write_text(t, encoding="utf-8")
            path, summary = mapcap.merge_folder(root)
            self.assertEqual(workspace.read_json(path)["name"], "A")
            self.assertIn("2 stand-ins (0 left out of 2)", summary)
            wrong = Path(d) / "B"
            (wrong / "studio").mkdir(parents=True)
            for i, t in enumerate(capture()):
                (wrong / "studio" / f"map_{i}.txt").write_text(t, encoding="utf-8")
            with self.assertRaises(mapcap.ChunkError):
                mapcap.merge_folder(wrong)


class VisibleTest(unittest.TestCase):
    """Play-bound walls (Transparency ~1) are captured but nobody can see them: the film set and the checks skip them."""

    def test_only_see_through_boxes_are_invisible(self):
        box = [0, 0, 0, 4, 4, 4, 0, 0, 0, "aaaaaa"]
        self.assertTrue(mapcap.visible(box))               # older captures have no transparency field
        self.assertTrue(mapcap.visible(box + [0.5]))
        self.assertFalse(mapcap.visible(box + [1.0]))
        self.assertFalse(mapcap.visible(box + [mapcap.INVISIBLE]))


if __name__ == "__main__":
    unittest.main()
