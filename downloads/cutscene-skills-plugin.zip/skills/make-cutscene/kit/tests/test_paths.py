import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import paths  # noqa: E402


class PathsTest(unittest.TestCase):
    def test_env_key_wins_and_is_trimmed(self):
        self.assertEqual(paths.load_key(env={"ROBLOX_API_KEY": " abc "}, files=[]), "abc")

    def test_key_from_first_existing_file(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "k.key"
            f.write_text("secret\n", encoding="utf-8")
            self.assertEqual(paths.load_key(env={}, files=[Path(d) / "missing.key", f]), "secret")

    def test_missing_key_explains_where_to_put_it(self):
        with self.assertRaises(SystemExit) as cm:
            paths.load_key(env={}, files=[])
        self.assertIn("roblox-open-cloud.key", str(cm.exception))

    def test_creator_prefers_group(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / "config.json").write_text(json.dumps({"group_id": "7", "user_id": "9"}), encoding="utf-8")
            self.assertEqual(paths.load_creator(Path(d)), {"groupId": "7"})

    def test_creator_user(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / "config.json").write_text(json.dumps({"group_id": "", "user_id": "123456789"}), encoding="utf-8")
            self.assertEqual(paths.load_creator(Path(d)), {"userId": "123456789"})

    def test_creator_missing(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(SystemExit):
                paths.load_creator(Path(d))

    def test_creator_null_counts_as_empty(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / "config.json").write_text(json.dumps({"group_id": None, "user_id": "9"}), encoding="utf-8")
            self.assertEqual(paths.load_creator(Path(d)), {"userId": "9"})
            (Path(d) / "config.json").write_text(json.dumps({"group_id": None, "user_id": None}), encoding="utf-8")
            with self.assertRaises(SystemExit) as cm:
                paths.load_creator(Path(d))
            self.assertIn("group_id or a user_id", str(cm.exception))

    def test_creator_bad_json_explains(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / "config.json").write_text('{"user_id": "9",', encoding="utf-8")
            with self.assertRaises(SystemExit) as cm:
                paths.load_creator(Path(d))
            self.assertIn("config.json is not valid JSON", str(cm.exception))


if __name__ == "__main__":
    unittest.main()
