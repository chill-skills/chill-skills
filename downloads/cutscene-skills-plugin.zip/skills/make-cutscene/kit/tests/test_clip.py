import ast
import re
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import clip  # noqa: E402
import paths  # noqa: E402


def look_vector(cf):
    return (-cf[5], -cf[8], -cf[11])  # -Z column: -(R02, R12, R22)


class MathTest(unittest.TestCase):
    def assertVec(self, a, b, eps=1e-6):
        for x, y in zip(a, b):
            self.assertAlmostEqual(x, y, delta=eps)

    def test_angles_match_roblox_turning_left(self):
        # CFrame.Angles(0, rad(90), 0).LookVector == (-1, 0, 0) in Roblox
        self.assertVec(look_vector(clip.cframe(ry=90)), (-1, 0, 0))

    def test_cframe_position(self):
        self.assertEqual(clip.cframe(1, 2, 3)[:3], [1.0, 2.0, 3.0])

    def test_look_at_forward_is_identity(self):
        self.assertVec(clip.look_at((0, 0, 0), (0, 0, -5)), clip.IDENTITY)

    def test_look_at_plus_x(self):
        cf = clip.look_at((1, 2, 3), (6, 2, 3))
        self.assertVec(look_vector(cf), (1, 0, 0))
        self.assertVec((cf[3], cf[6], cf[9]), (0, 0, 1))  # RightVector
        self.assertVec(cf[:3], (1, 2, 3))

    def test_conj_keeps_identity_and_angle(self):
        r = [[0, 0, 1], [0, 1, 0], [-1, 0, 0]]
        ident = clip.rot_xyz()
        self.assertEqual([[round(v, 9) for v in row] for row in clip.conj(r, ident)], ident)
        q = clip.rot_xyz(0, 0, 40)
        trace = lambda m: m[0][0] + m[1][1] + m[2][2]  # noqa: E731
        self.assertAlmostEqual(trace(clip.conj(r, q)), trace(q))


class ClipDataTest(unittest.TestCase):
    def test_merges_sorts_floors_and_counts_frames(self):
        keys = [
            {"time": 2.5, "poses": {"CutsceneCamera": {"cf": clip.IDENTITY, "style": "Linear", "dir": "In"}}},
            {"time": 0.0, "poses": {}, "markers": [["Letterbox", "in"]]},
            {"time": 2.5, "poses": {}, "markers": [["Cut", ""]]},
            {"time": 2.5 - 1 / 60, "poses": {"CutsceneCamera": {"cf": clip.IDENTITY, "style": "Constant", "dir": "Out"}}},
        ]
        d = clip.clip_data("S", "StageRoot", {"CutsceneCamera": "StageRoot"}, keys, 6.0)
        self.assertEqual([k["time"] for k in d["keyframes"]], [0.0, 2.48333, 2.5])
        self.assertEqual(d["keyframes"][2]["markers"], [["Cut", ""]])
        self.assertIn("CutsceneCamera", d["keyframes"][2]["poses"])
        self.assertEqual(d["length"], 360)
        self.assertEqual(d["priority"], "Action4")


class RbxmxTest(unittest.TestCase):
    def test_stage_clip_xml(self):
        keys = [
            {"time": 0.0, "poses": {"CutsceneCamera": {"cf": clip.cframe(1, 2, 3), "style": "Linear", "dir": "In"}},
             "markers": [["Letterbox", "in"]]},
            {"time": 1.0, "poses": {"CutsceneCamera": {"cf": clip.IDENTITY, "style": "Linear", "dir": "In"}}},
        ]
        d = clip.clip_data("S", "StageRoot", {"CutsceneCamera": "StageRoot"}, keys, 1.0)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "S.rbxmx"
            clip.write_rbxmx(d, path)
            root = ET.parse(path).getroot()
        kfs = root.find("Item")
        self.assertEqual(kfs.get("class"), "KeyframeSequence")
        self.assertEqual(kfs.find("Properties/token[@name='Priority']").text, "5")
        frames = kfs.findall("Item")
        self.assertEqual(len(frames), 2)
        stage_pose = frames[0].find("Item[@class='Pose']")
        self.assertEqual(stage_pose.find("Properties/string[@name='Name']").text, "StageRoot")
        self.assertEqual(stage_pose.find("Properties/float[@name='Weight']").text, "0")
        cam = stage_pose.find("Item[@class='Pose']")
        self.assertEqual(cam.find("Properties/string[@name='Name']").text, "CutsceneCamera")
        self.assertEqual(cam.find("Properties/float[@name='Weight']").text, "1")
        marker = frames[0].find("Item[@class='KeyframeMarker']")
        self.assertEqual(marker.find("Properties/string[@name='Value']").text, "in")


class MakeAnimDriftTest(unittest.TestCase):
    def test_token_tables_match_make_anim(self):
        path = paths.MAKE_ANIM / "kit" / "export.py"
        if not path.exists():
            self.skipTest("make-anim not installed next to make-cutscene")
        text = path.read_text(encoding="utf-8")
        for name in ("_STYLE_TOKEN", "_DIR_TOKEN", "_PRIORITY_TOKEN"):
            m = re.search(rf"^{name} = (\{{.*?\}})$", text, re.M)
            self.assertIsNotNone(m, f"{name} not found in make-anim export.py")
            self.assertEqual(ast.literal_eval(m.group(1)), getattr(clip, name), name)
        self.assertIn('<roblox xmlns:xmime="http://www.w3.org/2005/05/xmlmime" version="4">', text)


class LuauValueTest(unittest.TestCase):
    def test_nested_values(self):
        got = clip.luau_value({"Name": "A", "Lines": {"1": {"text": 'say "hi"'}}, "end": True, "Fov": [[0, 50], [2.5, 40.0]]})
        # keys sort with str (uppercase first): Fov, Lines, Name, end; "end" is reserved, so it is bracketed
        want = ('{\n\tFov = {\n\t\t{0, 50},\n\t\t{2.5, 40.0},\n\t},\n'
                '\tLines = {\n\t\t["1"] = {\n\t\t\ttext = "say \\"hi\\"",\n\t\t},\n\t},\n\tName = "A",\n\t["end"] = true,\n}')
        self.assertEqual(got, want)

    def test_strings_escape_control_characters(self):
        # escaped, never dropped: the module's text is the beat sheet's text (Task 13 review, Minor 1); a tab stays raw
        self.assertEqual(clip.luau_value("a\nb\x07c\r\td\x7f\x01" + "7"), '"a\\nb\\007c\\r\td\\127\\0017"')

    def test_strings_round_trip_through_luau(self):
        """The literal, run by the real Luau, gives back the same bytes (skipped where Luau isn't installed)."""
        import shutil
        import subprocess
        found = sorted((Path.home() / ".rokit" / "tool-storage" / "luau-lang" / "luau").glob("*/luau.exe"))
        luau = str(found[-1]) if found else shutil.which("luau")  # rokit's own shim needs a project manifest
        if not luau:
            self.skipTest("no luau executable (rokit's luau-lang/luau)")
        text = 'q"\\ \r\n\t\x1b[0m\x00\x7f 🙂 \x017 end'
        with tempfile.TemporaryDirectory() as d:
            script = Path(d) / "roundtrip.luau"
            script.write_text(f"local s = {clip.luau_value(text)}\nlocal out = {{}}\n"
                              "for i = 1, #s do out[i] = string.byte(s, i) end\nprint(table.concat(out, \" \"))\n",
                              encoding="utf-8", newline="\n")
            run = subprocess.run([luau, str(script)], capture_output=True, text=True, timeout=60)
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertEqual(run.stdout.split(), [str(b) for b in text.encode("utf-8")])

    def test_nan_and_infinity_are_refused(self):
        for bad in (float("nan"), float("inf"), {"Fov": [[0.0, float("-inf")]]}):
            with self.assertRaises(ValueError):
                clip.luau_value(bad)


if __name__ == "__main__":
    unittest.main()
