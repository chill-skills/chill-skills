"""Tests for kit/rigcap.py with make-anim's stock R6 and block-R15 joint data. Method by fwjelaa (FWJ STUDIOS)."""
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import rigcap  # noqa: E402


def cf(x, y, z, *r):
    return [float(x), float(y), float(z)] + [float(v) for v in (r or (1, 0, 0, 0, 1, 0, 0, 0, 1))]


ROOT = (-1, 0, 0, 0, 0, 1, 0, 1, 0)
RR = (0, 0, 1, 0, 1, 0, -1, 0, 0)
RL = (0, 0, -1, 0, 1, 0, 1, 0, 0)


def r6():
    parts = {"HumanoidRootPart": [2, 2, 1], "Torso": [2, 2, 1], "Head": [2, 1, 1], "Right Arm": [1, 2, 1],
             "Left Arm": [1, 2, 1], "Right Leg": [1, 2, 1], "Left Leg": [1, 2, 1]}
    joints = [["RootJoint", "HumanoidRootPart", "Torso", cf(0, 0, 0, *ROOT), cf(0, 0, 0, *ROOT)],
              ["Neck", "Torso", "Head", cf(0, 1, 0, *ROOT), cf(0, -0.5, 0, *ROOT)],
              ["Right Shoulder", "Torso", "Right Arm", cf(1, 0.5, 0, *RR), cf(-0.5, 0.5, 0, *RR)],
              ["Left Shoulder", "Torso", "Left Arm", cf(-1, 0.5, 0, *RL), cf(0.5, 0.5, 0, *RL)],
              ["Right Hip", "Torso", "Right Leg", cf(1, -1, 0, *RR), cf(0.5, 1, 0, *RR)],
              ["Left Hip", "Torso", "Left Leg", cf(-1, -1, 0, *RL), cf(-0.5, 1, 0, *RL)]]
    return {"v": 1, "role": "npc1", "rigType": "R6", "hipHeight": 0, "root": "HumanoidRootPart", "parts": parts,
            "colors": {}, "joints": joints}


def r15(hip=2.0):
    parts = {"HumanoidRootPart": [2, 2, 1], "LowerTorso": [2, 0.4, 1], "UpperTorso": [2, 1.6, 1], "Head": [1.2, 1.2, 1.2]}
    joints = [["Root", "HumanoidRootPart", "LowerTorso", cf(0, -1, 0), cf(0, -0.2, 0)],
              ["Waist", "LowerTorso", "UpperTorso", cf(0, 0.2, 0), cf(0, -0.8, 0)],
              ["Neck", "UpperTorso", "Head", cf(0, 0.8, 0), cf(0, -0.586, 0)]]
    for side, s in (("Right", 1), ("Left", -1)):
        parts.update({f"{side}UpperArm": [1, 1.169, 1], f"{side}LowerArm": [1, 1.052, 1], f"{side}Hand": [1, 0.3, 1],
                      f"{side}UpperLeg": [1, 1.217, 1], f"{side}LowerLeg": [1, 1.193, 1], f"{side}Foot": [1, 0.3, 1]})
        joints += [[f"{side}Shoulder", "UpperTorso", f"{side}UpperArm", cf(s, 0.563, 0), cf(-0.5 * s, 0.394, 0)],
                   [f"{side}Elbow", f"{side}UpperArm", f"{side}LowerArm", cf(0, -0.334, 0), cf(0, 0.259, 0)],
                   [f"{side}Wrist", f"{side}LowerArm", f"{side}Hand", cf(0, -0.501, 0), cf(0, 0.125, 0)],
                   [f"{side}Hip", "LowerTorso", f"{side}UpperLeg", cf(0.5 * s, -0.2, 0), cf(0, 0.421, 0)],
                   [f"{side}Knee", f"{side}UpperLeg", f"{side}LowerLeg", cf(0, -0.401, 0), cf(0, 0.379, 0)],
                   [f"{side}Ankle", f"{side}LowerLeg", f"{side}Foot", cf(0, -0.547, 0), cf(0, 0.102, 0)]]
    return {"v": 1, "role": "player", "rigType": "R15", "hipHeight": hip, "root": "HumanoidRootPart", "parts": parts,
            "colors": {"Head": "F5CD30"}, "joints": joints}


class RigcapTest(unittest.TestCase):
    def test_stock_rigs_are_valid(self):
        self.assertEqual(rigcap.validate(r6()), [])
        self.assertEqual(rigcap.validate(r15()), [])

    def test_foot_and_stand(self):
        self.assertAlmostEqual(rigcap.foot(r6()), 3.0, places=4)
        self.assertAlmostEqual(rigcap.foot(r15()), 3.0, places=4)
        self.assertAlmostEqual(rigcap.stand(r15(2.19)), 3.19, places=4)
        self.assertEqual(rigcap.stand(r6()), 3.0)

    def test_head_rests_where_the_joints_say(self):
        self.assertAlmostEqual(rigcap.rest_frames(r15())["Head"][1], 1.586, places=4)

    def test_missing_part_and_bad_order(self):
        bad = r15()
        del bad["parts"]["LeftFoot"]
        self.assertTrue(any("LeftFoot" in p for p in rigcap.validate(bad)))
        bad = r15()
        bad["joints"] = bad["joints"][1:] + bad["joints"][:1]
        self.assertTrue(any("parents before children" in p for p in rigcap.validate(bad)))
        bad = r15()
        bad["joints"][0][3] = [0, -1, 0]
        self.assertTrue(any("12 numbers" in p for p in rigcap.validate(bad)))

    def test_save_adds_stand_and_foot(self):
        with tempfile.TemporaryDirectory() as d:
            path, summary = rigcap.save(Path(d), "player", json.dumps(r15(2.19)))
            saved = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(path, Path(d) / "rigs" / "player.json")
            self.assertAlmostEqual(saved["stand"], 3.19, places=4)
            self.assertAlmostEqual(saved["foot"], 3.0, places=4)
            self.assertIn("R15", summary)
            self.assertIn("feet 0.19 above the floor", summary)

    def test_save_refuses_a_broken_copy(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(SystemExit) as e:
                rigcap.save(Path(d), "npc1", '{"v": 1, "rigType": "R15"')
            self.assertIn("rig_npc1.txt", str(e.exception))


if __name__ == "__main__":
    unittest.main()
