"""Tests for kit/filmset.py's Blender-free parts: what clear() may remove, the tagging of what a build makes, the clip
key rule and the choice of rig. Blender's modules (and make-anim's rigs, which needs them) are stand-ins here; the
Blender half is checked in Blender (Task 12 Steps 3-5). Method by fwjelaa (FWJ STUDIOS)."""
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

KIT = Path(__file__).resolve().parents[1]


class Block(dict):
    """An object or data block: a name, its custom properties (the dict), users, and a collection's contents."""

    def __init__(self, name, tag=None, users=0):
        super().__init__({} if tag is None else {"cs_set": tag})
        self.name, self.users, self.objects, self.children = name, users, [], []
        self.session_uid = id(self)
        self.timeline_markers = Blocks()


class Blocks(list):
    """bpy.data.<kind>: iterate, get(name), new and remove (by identity, never by equal contents)."""

    def get(self, name):
        return next((b for b in self if b.name == name), None)

    def remove(self, block, do_unlink=True):
        del self[next(i for i, b in enumerate(self) if b is block)]

    def add(self, *blocks):
        self.extend(blocks)
        return blocks[0]


def fake_data():
    return SimpleNamespace(**{k: Blocks() for k in ("objects", "meshes", "armatures", "cameras", "actions", "materials",
                                                   "collections", "scenes")})


def load_filmset():
    """Import filmset with stand-in Blender modules; sys.path and sys.modules are put back afterwards (filmset adds
    make-anim's folders, whose run.py would shadow this kit's)."""
    bpy = types.ModuleType("bpy")
    bpy.data = fake_data()
    mathutils = types.ModuleType("mathutils")
    mathutils.Matrix = mathutils.Vector = object
    rigs = types.ModuleType("rigs")
    rigs.B2R = None
    fakes = {"bpy": bpy, "bmesh": types.ModuleType("bmesh"), "mathutils": mathutils, "rigs": rigs}
    with mock.patch.dict(sys.modules, fakes), mock.patch.object(sys, "path", [str(KIT)] + sys.path):
        sys.modules.pop("filmset", None)
        import filmset
    return filmset


def m4(x, y, z):
    return [[1, 0, 0, x], [0, 1, 0, y], [0, 0, 1, z], [0, 0, 0, 1]]


def cf(*v):
    return [[v[3], v[4], v[5], v[0]], [v[6], v[7], v[8], v[1]], [v[9], v[10], v[11], v[2]], [0, 0, 0, 1]]


R = [1, 0, 0, 0, 1, 0, 0, 0, 1]


def stock():
    """A three-part stand-in for make-anim's R15: soles 3.0 under the root."""
    return {"root": "HumanoidRootPart", "hip_height": 3.0,
            "parts": {"HumanoidRootPart": (2, 2, 1), "LowerTorso": (2, 0.4, 1), "RightFoot": (1, 0.3, 1)},
            "joints": [("Root", "HumanoidRootPart", "LowerTorso", m4(0, -1, 0), m4(0, -0.2, 0)),
                       ("RightAnkle", "LowerTorso", "RightFoot", m4(0, -1.85, 0), m4(0, 0.1, 0))],
            "colors": {"HumanoidRootPart": (0.8, 0.8, 0.8), "LowerTorso": (0, 0, 1), "RightFoot": (0, 1, 0)},
            "feet": ["RightFoot"], "body": ["LowerTorso"], "pairs": [("RightFoot", "LowerTorso")]}


def capture(stand, foot, k=1.0):
    """rigs/<role>.json as rigcap writes it, k times the stock proportions."""
    return {"rigType": "R15", "role": "player", "stand": stand, "foot": foot,
            "parts": {"HumanoidRootPart": [2, 2, 1], "LowerTorso": [2, 0.4 * k, 1], "RightFoot": [1, 0.3 * k, 1]},
            "joints": [["Root", "HumanoidRootPart", "LowerTorso", [0, -1, 0] + R, [0, -0.2 * k, 0] + R],
                       ["RightAnkle", "LowerTorso", "RightFoot", [0, -1.85 * k, 0] + R, [0, 0.1 * k, 0] + R]]}


class FilmsetTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fs = load_filmset()

    def setUp(self):
        self.data = self.fs.bpy.data = fake_data()


class ClearTest(FilmsetTest):
    def test_clear_takes_only_what_carries_its_id(self):
        d = self.data
        d.objects.add(Block("Gate_Map", "Gate"), Block("Gate_npc1_R15", "Gate"), Block("Gate_npc1_R15_Head", "Gate"),
                      Block("Gate_Camera", "Gate"), Block("Gate_Intro_Map", "Gate_Intro"),
                      Block("Gate_Intro_npc1_R15", "Gate_Intro"), Block("Gate_x"))
        d.meshes.add(Block("Gate_Map", "Gate"), Block("Gate_Intro_Map", "Gate_Intro"), Block("Gate_mine"))
        d.materials.add(Block("CS_rgb_5a5", "Gate", users=1))  # still on Gate_Intro's map: kept
        d.actions.add(Block("Gate_npc1_R15", "Gate"), Block("Gate_old"))
        d.cameras.add(Block("Gate_Camera", "Gate"))
        d.collections.add(Block("Gate_Set", "Gate"), Block("Gate_Intro_Set", "Gate_Intro"), Block("Gate_stuff"))
        scene = d.scenes.add(Block("CS_Gate", "Gate"))
        scene["cs_markers"] = json.dumps([["Cut", 96], ["End", 591]])
        scene.timeline_markers.add(SimpleNamespace(name="Cut", frame=96), SimpleNamespace(name="my note", frame=10),
                                   SimpleNamespace(name="End", frame=591))
        self.fs.clear("Gate")

        def names(blocks):
            return sorted(b.name for b in blocks)
        self.assertEqual(names(d.objects), ["Gate_Intro_Map", "Gate_Intro_npc1_R15", "Gate_x"])
        self.assertEqual(names(d.meshes), ["Gate_Intro_Map", "Gate_mine"])
        self.assertEqual(names(d.materials), ["CS_rgb_5a5"])
        self.assertEqual(names(d.actions), ["Gate_old"])
        self.assertEqual(names(d.cameras), [])
        self.assertEqual(names(d.collections), ["Gate_Intro_Set", "Gate_stuff"])
        self.assertEqual([m.name for m in scene.timeline_markers], ["my note"])

    def test_a_collection_with_someone_elses_object_stays(self):
        coll = self.data.collections.add(Block("Gate_Set", "Gate"))
        coll.objects.append(Block("my lamp"))
        self.fs.clear("Gate")
        self.assertEqual([c.name for c in self.data.collections], ["Gate_Set"])

    def test_tagging_marks_only_what_was_made_inside(self):
        old = self.data.objects.add(Block("Gate_x"))
        with self.fs.tagging("Gate"):
            self.data.objects.add(Block("Gate_Map"))
            self.data.materials.add(Block("CS_rgb_aaa"))
        self.assertNotIn("cs_set", old)
        self.assertEqual(self.data.objects.get("Gate_Map")["cs_set"], "Gate")
        self.assertEqual(self.data.materials.get("CS_rgb_aaa")["cs_set"], "Gate")
        with self.assertRaises(KeyError):
            with self.fs.tagging("Gate"):
                self.data.actions.add(Block("Gate_half"))
                raise KeyError("an anim script failed")
        self.assertEqual(self.data.actions.get("Gate_half")["cs_set"], "Gate")  # still tagged: the next clear takes it

    def test_names_held_by_someone_else_are_named(self):
        b = {"id": "Gate", "cast": {"player": {}, "npc1": {"rig": "R6"}}}
        self.data.objects.add(Block("Gate_Map"), Block("Gate_Camera", "Gate"), Block("Gate_npc1_R6", "Gate_Intro"))
        self.data.collections.add(Block("Gate_Set"))
        self.assertEqual(self.fs.in_the_way("Gate", b), ["Gate_Map", "Gate_npc1_R6", "Gate_Set"])


class ClipKeysTest(FilmsetTest):
    def test_a_clip_needs_keys_on_the_first_and_last_frames(self):
        self.assertEqual(self.fs.key_problems([(0, "Head", (0, 0, 0), "linear"), (591, "Head", (0, 0, 0), "linear")],
                                              591), [])
        self.assertEqual(self.fs.key_problems([(10, "Head", (0, 0, 0), "linear")], 591),
                         ["no key at frame 0", "no key at frame 591 (the scene's last frame)"])
        self.assertEqual(self.fs.key_problems([(0, "Head", (0, 0, 0), "linear"), (591, "Head", (0, 0, 0), "linear"),
                                               (592, "Head", (0, 0, 0), "linear")], 591),
                         ["keys after the scene's last frame (591): 592"])


class RigChoiceTest(FilmsetTest):
    def kit(self):
        hand = {"R15": ("RightHand", "grip15"), "R6": ("Right Arm", "grip6")}
        rigs = SimpleNamespace(RIGS={"R15": stock()}, cf=cf, PROPS={"Sword": {"attach": hand}})
        return SimpleNamespace(rigs=rigs)

    def choose(self, cap):
        K = self.kit()
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "rigs").mkdir()
            (Path(tmp) / "rigs" / "player.json").write_text(json.dumps(cap), encoding="utf-8")
            return K, self.fs.role_rig(K, tmp, "Gate", "player", "R15")

    def test_feet_on_the_stock_floor_use_the_stock_rig(self):
        K, got = self.choose(capture(3.0, 3.0, k=1.05))
        self.assertTrue(self.fs.near_stock(capture(3.0, 3.0, k=1.05), stock()))
        self.assertEqual(got, ("R15", 3.0, ""))

    def test_longer_legs_get_their_own_proportions_and_floor(self):
        cap = capture(3.192, 3.19, k=1.06)  # the default avatar: proportions within NEAR_STOCK, legs 0.19 longer
        self.assertFalse(self.fs.near_stock(cap, stock()))
        K, got = self.choose(cap)
        self.assertEqual(got, ("Gate_player_rig", 3.192, " (captured proportions)"))
        rig = K.rigs.RIGS["Gate_player_rig"]
        self.assertEqual(rig["hip_height"], 3.192)  # ground() and soles() put the floor where Roblox stands the rig
        self.assertEqual(rig["joints"][1][3][1][3], -1.85 * 1.06)
        self.assertEqual(K.rigs.PROPS["Sword"]["attach"]["Gate_player_rig"], ("RightHand", "grip15"))

    def test_another_rig_type_is_not_used(self):
        cap = dict(capture(3.0, 3.0), rigType="R6")
        self.assertEqual(self.choose(cap)[1], ("R15", 3.0, " (its captured rig is R6: not used for R15)"))


class LookTest(FilmsetTest):
    """The film set shows a cast member in its captured colours (Task 22), never the default dummy's."""

    def look(self, cap):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "rigs").mkdir()
            (Path(tmp) / "rigs" / "npc1.json").write_text(json.dumps(cap), encoding="utf-8")
            return self.fs.look_of(tmp, "npc1")

    def test_a_map_model_keeps_its_own_colours(self):
        got = self.look({"source": "path", "colors": {"Head": "c48c6c", "UpperTorso": "#3e424c", "Bad": "12"}})
        self.assertEqual(got, {"Head": (196 / 255, 140 / 255, 108 / 255), "UpperTorso": (62 / 255, 66 / 255, 76 / 255)})

    def test_a_default_dummy_or_no_capture_keeps_the_stock_colours(self):
        self.assertIsNone(self.look({"source": "default", "colors": {"Head": "000000"}}))
        with tempfile.TemporaryDirectory() as tmp:
            self.assertIsNone(self.fs.look_of(tmp, "npc1"))

    def test_each_role_gets_its_own_materials(self):
        def box(part):
            return SimpleNamespace(type="MESH", get={"rbx_part": part}.get,
                                   data=SimpleNamespace(materials=[Block(f"Rbx_{part}")]))

        class Mat(Block):
            def __init__(self, name):
                super().__init__(name)
                bsdf = SimpleNamespace(type="BSDF_PRINCIPLED", inputs=[SimpleNamespace(default_value=None)])
                self.node_tree = SimpleNamespace(nodes=[bsdf])

        mats = self.data.materials
        mats.new = lambda name: mats.add(Mat(name))
        head, root = box("Head"), box("HumanoidRootPart")
        arm = SimpleNamespace(children=[head, root])
        self.assertEqual(self.fs.dress("Gate", "npc1", arm, {"Head": (1.0, 0.5, 0.0)}), 1)
        self.assertEqual(head.data.materials[0].name, "Gate_npc1_Head")
        self.assertEqual(head.data.materials[0].diffuse_color, (1.0, 0.5 ** 2.2, 0.0, 1.0))
        self.assertEqual(root.data.materials[0].name, "Rbx_HumanoidRootPart")  # no colour given: left alone
        self.assertEqual(self.fs.dress("Gate", "player", arm, None), 0)


class FakeAnim:
    """make-anim's ak.Anim as far as the R6 choice uses it: name, rig, length and keys (frame, joint, value, ease)."""

    def __init__(self, name, rig="R6", props=(), length=60, fps=60, priority="Action"):
        self.name, self.rig_type, self.length, self.keys = name, rig, length, []

    def key(self, frame, pose, ease="cubic_inout"):
        self.keys += [(frame, joint, tuple(v), ease) for joint, v in pose.items()]
        return self


class R6ChoiceTest(FilmsetTest):
    """r6_anim: the derived keys, or anim/<role>_R6.py (given DERIVED) when that file exists (spec 5.8)."""
    DERIVED = {0: ({"Torso": (0, 0, 0)}, "cubic_inout"), 591: ({"Torso": (0, 0, 0)}, "linear")}

    def choose(self, override=None):
        K = SimpleNamespace(ak=SimpleNamespace(Anim=FakeAnim), beats=SimpleNamespace(shots=lambda b: []))
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "anim").mkdir()
            (Path(tmp) / "anim" / "player.py").write_text("raise SystemExit('the R15 master is not read here')\n",
                                                         encoding="utf-8")
            if override is not None:
                (Path(tmp) / "anim" / "player_R6.py").write_text(override, encoding="utf-8")
            return self.fs.r6_anim(K, tmp, {"id": "Gate", "cast": {"player": {}}}, "player", {}, 591, self.DERIVED)

    def test_without_an_override_the_derived_keys_are_used(self):
        anim, over = self.choose()
        self.assertFalse(over)
        self.assertEqual((anim.name, anim.rig_type, anim.length), ("Gate_player_R6", "R6", 591))
        self.assertEqual(anim.keys, [(0, "Torso", (0, 0, 0), "cubic_inout"), (591, "Torso", (0, 0, 0), "linear")])

    def test_anim_role_R6_py_replaces_them_and_gets_DERIVED(self):
        anim, over = self.choose(
            "def build():\n"
            "    a = ak.Anim(NAME, rig=RIG, length=FRAMES, fps=FPS, priority='Action4')\n"
            "    for f, (pose, ease) in sorted(DERIVED.items()):\n"
            "        a.key(f, pose, ease)\n"
            "    a.key(F(2.0), {'Right Arm': (130, 0, 0)}, 'constant')  # re-posed: R6 has no elbow\n"
            "    return a\n")
        self.assertTrue(over)
        self.assertEqual((anim.name, anim.rig_type), ("Gate_player_R6", "R6"))
        self.assertIn((120, "Right Arm", (130, 0, 0), "constant"), anim.keys)
        self.assertIn((591, "Torso", (0, 0, 0), "linear"), anim.keys)

    def test_an_override_keeps_the_name_the_length_and_both_end_keys(self):
        with self.assertRaises(ValueError) as e:
            self.choose("def build():\n    return ak.Anim('Other', rig=RIG, length=FRAMES)\n")
        self.assertIn("anim/player_R6.py must return ak.Anim(NAME, rig=RIG, length=FRAMES", str(e.exception))
        with self.assertRaises(ValueError) as e:
            self.choose("def build():\n    return ak.Anim(NAME, rig=RIG, length=FRAMES).key(0, {'Torso': (0, 0, 0)})\n")
        self.assertIn("anim/player_R6.py: no key at frame 591", str(e.exception))


class VerdictTest(FilmsetTest):
    def test_clean_clips_name_the_next_step(self):
        ok, line = self.fs.verdict("Gate", {"Gate_player_R15": [], "Gate_player_R6": []})
        self.assertTrue(ok)
        self.assertIn("next:  py kit/run.py scene Gate", line)

    def test_clip_issues_stop_the_export(self):
        ok, line = self.fs.verdict("Gate", {"Gate_player_R15": ["feet sink", "Head snaps"], "Gate_npc1_R15": [],
                                            "Gate_player_R6": ["Right Arm snaps"]})
        self.assertFalse(ok)
        self.assertTrue(line.startswith("STOPPED: 3 clip issues (Gate_player_R15: 2, Gate_player_R6: 1)"), line)


if __name__ == "__main__":
    unittest.main()
