"""Tests for the example key bind: its Studio step (kit/studio.py keybind) and its server script, run by the real Luau
against a stub player, remote and CutsceneKit (a client is untrusted). Method by fwjelaa (FWJ STUDIOS)."""
import io
import os
import re
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import bundle  # noqa: E402
import clip  # noqa: E402
import luaurun  # noqa: E402
import paths  # noqa: E402
import payload  # noqa: E402
import run  # noqa: E402
import studio  # noqa: E402
import workspace  # noqa: E402

METHOD = "Method by fwjelaa (FWJ STUDIOS)."


class KeyBindTest(unittest.TestCase):
    def test_the_example_gets_the_scene_and_the_key(self):
        server, client = studio.keybind_sources("Awakening", "F")
        # Task 10's security ruling: the scene is fixed on the server, never named by the client
        self.assertIn('local SCENE = "Awakening"', server)
        self.assertIn('local NAME = "Awakening"', client)
        self.assertIn("local KEY = Enum.KeyCode.F", client)
        for line in (studio.SCENE_LINE, studio.NAME_LINE, studio.KEY_LINE):
            self.assertNotIn(line, server + client)
        with self.assertRaises(SystemExit):
            studio.keybind_sources("Awakening", "f; os.exit()")
        with self.assertRaises(SystemExit):
            studio.keybind_sources("Awakening", "G\n")

    def test_a_placeholder_line_must_appear_exactly_once(self):
        real = bundle._read
        doubled = lambda p: real(p) + ("\n" + studio.KEY_LINE if p.name.endswith(".client.luau") else "")
        with mock.patch.object(bundle, "_read", doubled), self.assertRaises(SystemExit) as e:
            studio.keybind_sources("Awakening")
        self.assertIn("must appear exactly once", str(e.exception))

    def test_the_key_is_one_a_player_can_spare(self):
        for asked, code in (("Q", "Q"), ("g", "G"), ("Z", "Z"), ("5", "Five"), ("0", "Zero"), ("Seven", "Seven"),
                            ("F1", "F1"), ("f12", "F12"), ("Home", "Home"), ("pageup", "PageUp")):
            self.assertIn(f"local KEY = Enum.KeyCode.{code}\n", studio.keybind_sources("Awakening", asked)[1], asked)
        # movement, chat, jump, menus and the camera zoom stay the player's (each refused with what it is for)
        for asked in ("W", "a", "S", "d", "Up", "Down", "Left", "Right", "Space", "Slash", "Return", "Tab",
                      "Backquote", "Escape", "I", "O", "LeftShift", "F9", "F11"):
            with self.assertRaises(SystemExit, msg=asked) as e:
                studio.keybind_sources("Awakening", asked)
            self.assertIn("is the player's", str(e.exception), asked)
        for asked in ("Foo", "KeypadFive", "F13", "10", "", None, "G G"):
            with self.assertRaises(SystemExit, msg=repr(asked)) as e:
                studio.keybind_sources("Awakening", asked)
            self.assertIn("--key takes", str(e.exception), repr(asked))

    def test_the_scene_name_cannot_inject_code(self):
        for bad in ('Awakening"; os.exit() --', "Awa kening", "", "1Awakening", "Awakening\n"):
            with self.assertRaises(SystemExit, msg=repr(bad)):
                studio.keybind_sources(bad, "G")

    def test_story_scenes_have_no_key_bind(self):
        with self.assertRaises(SystemExit) as e:
            studio.step_keybind(Path("."), {"id": "GateGuard", "kind": "story"}, {})
        self.assertIn("awakenings", str(e.exception))

    def test_the_client_only_says_pressed(self):
        _, client = studio.keybind_sources("Awakening")
        self.assertEqual(client.count("FireServer("), 1)
        self.assertIn('remote:FireServer("pressed")', client)
        self.assertIn("local KEY = Enum.KeyCode.G", client)

    def test_new_luau_starts_with_the_method_line(self):
        for rel in ("examples/AwakenKeyBind.server.luau", "examples/AwakenKeyBind.client.luau",
                    "tests/KeyBind.test.luau"):
            head = (paths.ROBLOX / rel).read_text(encoding="utf-8").splitlines()[:2]
            self.assertTrue(any(line.endswith(METHOD) for line in head), rel)


class KeyBindStepTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.env = {"MAKE_CUTSCENE_WORK": self.tmp.name}
        self.root = workspace.create("Awakening", env=self.env)
        b = beats.from_words("Awakening", "the player powers up", [("Hero", "Now.")])
        b["kind"] = "awakening"
        beats.save(b, self.root)

    def test_keybind_step_through_the_command_line(self):
        with mock.patch.dict(os.environ, self.env), redirect_stdout(io.StringIO()) as out:
            self.assertEqual(run.main(["run.py", "studio", "Awakening", "keybind", "--key", "Q"]), 0)
        text = (self.root / "studio" / "keybind.luau").read_text(encoding="utf-8")
        self.assertIn('call = "keyBind"', text)
        self.assertIn('name = "AwakenKeyBind"', text)
        self.assertIn("Enum.KeyCode.Q", text)
        self.assertIn('local SCENE = \\"Awakening\\"', text)
        self.assertLessEqual(len(text.encode("utf-8")), payload.MAX_BYTES)
        self.assertIn("execute_luau", out.getvalue())

    def test_keybind_off_removes_it(self):
        studio.run_step("Awakening", "keybind-off", {}, env=self.env)
        text = (self.root / "studio" / "keybind-off.luau").read_text(encoding="utf-8")
        self.assertIn('call = "keyBind"', text)
        self.assertIn("remove = true", text)
        self.assertNotIn("FireServer", text)


# The server script runs as-is (with SCENE filled in) in the real Luau. Roblox's globals are stubs: `press` is what the
# script connected to AwakenRequest.OnServerEvent, so calling it is a client firing the remote.
HARNESS = """
local SOURCE = %s
-- src: another source to run (then the script need not make the remote or connect)
local function load(awaken, src)
	local w = { T = 0, warned = {}, replies = {}, calls = {} }
	local remote = { ClassName = "RemoteEvent" }
	function remote:IsA(c)
		return c == "RemoteEvent"
	end
	remote.OnServerEvent = { Connect = function(_, fn) w.press = fn end }
	function remote:FireClient(player, ...)
		table.insert(w.replies, { player = player, n = select("#", ...), ... })
	end
	local kitModule = { Name = "CutsceneKit" }
	local ReplicatedStorage = {}
	function ReplicatedStorage:FindFirstChild(_)
		return nil
	end
	function ReplicatedStorage:WaitForChild(n)
		assert(n == "CutsceneKit", n)
		return kitModule
	end
	local Players = { PlayerRemoving = { Connect = function(_, fn) w.leave = fn end } }
	local kit = {}
	function kit.Awaken(...)
		table.insert(w.calls, table.pack(...))
		return awaken(...)
	end
	local env = setmetatable({
		game = { GetService = function(_, n)
			return (assert(({ Players = Players, ReplicatedStorage = ReplicatedStorage })[n], n))
		end },
		workspace = { GetServerTimeNow = function() return w.T end },
		Instance = { new = function(c) assert(c == "RemoteEvent", c) return remote end },
		require = function(m) assert(m == kitModule, "requires only CutsceneKit") return kit end,
		warn = function(...) table.insert(w.warned, table.concat({ ... }, " ")) end,
	}, { __index = _G })
	local fn = assert(loadstring(src or SOURCE, "AwakenKeyBind.server"))
	setfenv(fn, env)
	fn()
	w.remote = remote
	if src == nil then
		assert(remote.Name == "AwakenRequest" and remote.Parent == ReplicatedStorage, "made the remote")
		assert(type(w.press) == "function" and type(w.leave) == "function", "connected")
	end
	return w
end
-- a stand-in Player; a rejoin is a new one with the same UserId
local function player(name, userId)
	local attrs = {}
	local p = { Name = name, ClassName = "Player", UserId = userId or #name * 1000 + string.byte(name) }
	function p:GetAttribute(k)
		return attrs[k]
	end
	function p:SetAttribute(k, v)
		attrs[k] = v
	end
	return p
end
-- a client-sent value the server must never read: indexing, printing or measuring it errors (an __eq trap could never
-- fire: Luau only calls __eq when both sides are tables or both userdata)
local poison = setmetatable({}, {
	__index = function() error("read a client value") end,
	__tostring = function() error("printed a client value") end,
	__len = function() error("measured a client value") end,
})
local function last(w)
	local r = w.replies[#w.replies]
	return r and (tostring(r[1]) .. " " .. tostring(r[2]) .. " " .. tostring(r[3] and math.ceil(r[3]))) or "none"
end
"""


@unittest.skipUnless(luaurun.find(), "luau is not installed")
class ServerScriptInLuauTest(unittest.TestCase):
    """Task 10's security rulings for the first path a client can trigger, on the real example source."""

    def go(self, scenario):
        server, _ = studio.keybind_sources("Awakening")
        return luaurun.run(HARNESS % payload.long_string(server) + scenario).splitlines()

    def test_a_burst_of_presses_is_limited(self):
        out = self.go("""
local w = load(function() return false, "no living character" end)
local a, b = player("A"), player("B")
for i = 0, 19 do
	w.T = i * 0.02
	w.press(a, "pressed")
end
print(#w.calls, #w.replies)
w.T = 0.39
w.press(b, "pressed")
print(#w.calls, w.replies[#w.replies].player == b)
w.T = 0.55
w.press(a, "pressed")
print(#w.calls, #w.replies)
""")
        self.assertEqual(out, ["1\t1", "2\ttrue", "3\t3"])

    def test_a_client_sent_cframe_or_name_is_ignored(self):
        out = self.go("""
local w = load(function() return true end)
local a = player("A")
w.press(a, poison)
w.press(a, "Awakening")
w.press(a, "GateGuard")
print(#w.calls, #w.replies)
w.press(a, "pressed", poison, "GateGuard", poison)
local c = w.calls[1]
print(#w.calls, c.n, c[1] == a, c[2])
print(w.replies[1].player == a, w.replies[1][1])
""")
        self.assertEqual(out, ["0\t0", "1\t2\ttrue\tAwakening", "true\ttrue"])

    def test_the_minimum_gap_holds_with_cooldown_0(self):
        out = self.go("""
local w = load(function() return true end)
local a = player("A")
w.press(a, "pressed")
-- the awakened state is gone early (a death, or EndAwakening from the game): no Awakened, no CutsceneReady_
for _, t in { 1, 10, 29.5 } do
	w.T = t
	w.press(a, "pressed")
	print(t, #w.calls, last(w))
end
w.T = 30
w.press(a, "pressed")
print(#w.calls, last(w))
""")
        self.assertEqual(out, ["1\t1\tfalse cooldown 29", "10\t1\tfalse cooldown 20", "29.5\t1\tfalse cooldown 1",
                               "2\ttrue nil nil"])

    def test_cheap_checks_answer_before_awaken_runs(self):
        out = self.go("""
local w = load(function() error("Awaken ran") end)
local a = player("A")
a:SetAttribute("CutsceneLock", "GateGuard")
w.press(a, "pressed")
print(last(w))
a:SetAttribute("CutsceneLock", nil)
a:SetAttribute("Awakened", "Awakening")
w.T = 1
w.press(a, "pressed")
print(last(w))
a:SetAttribute("Awakened", nil)
a:SetAttribute("CutsceneReady_Awakening", 7)
w.T = 2
w.press(a, "pressed")
print(last(w))
print(#w.calls, #w.warned)
""")
        self.assertEqual(out, ["false busy nil", "false awakened nil", "false cooldown 5", "0\t0"])

    def test_bad_argument_types_never_throw(self):
        out = self.go("""
local w = load(function() return true end)
local a = player("A")
local bad = { nil, 1, 0 / 0, true, {}, { "pressed" }, function() end, "PRESSED", "pressed ", "",
	string.rep("x", 100000), poison }
local failed = 0
for i = 1, 12 do
	w.T = i
	if not pcall(w.press, a, bad[i]) then
		failed += 1
	end
end
if not pcall(w.press, a) then
	failed += 1
end
print(failed, #w.calls, #w.replies, #w.warned)
""")
        self.assertEqual(out, ["0\t0\t0\t0"])

    def test_an_invalid_scene_warns_once_not_on_every_press(self):
        out = self.go("""
local w = load(function() return false, "invalid: Length must be a number" end)
local a, b = player("A"), player("B")
for i = 0, 9 do
	w.T = i
	w.press(i % 2 == 0 and a or b, "pressed")
end
print(#w.calls, #w.warned, #w.replies, last(w))
print(string.find(w.warned[1], "Awakening", 1, true) ~= nil)
""")
        self.assertEqual(out, ["1\t1\t1\tfalse unavailable nil", "true"])

    def test_an_erroring_awaken_warns_once_and_still_starts_the_gap(self):
        # fail closed: Server.awaken may have started the shielded cinematic before it threw
        out = self.go("""
local w = load(function() error("boom") end)
local a = player("A")
w.press(a, "pressed")
print(#w.calls, last(w))
w.T = 1
w.press(a, "pressed")
print(#w.calls, last(w))
w.T = 30
w.press(a, "pressed")
print(#w.calls, #w.warned, last(w))
""")
        self.assertEqual(out, ["1\tfalse error nil", "1\tfalse cooldown 29", "2\t1\tfalse error nil"])

    def test_loading_and_seen_never_switch_it_off(self):
        out = self.go("""
for _, why in { "loading", "seen" } do
	local w = load(function(p) if p.Name == "A" then return false, why end return true end)
	local a, b = player("A"), player("B")
	w.press(a, "pressed")
	w.T = 1
	w.press(b, "pressed")
	w.press(a, "pressed")
	print(why, #w.calls, #w.warned, w.replies[1][2], w.replies[2][1])
end
""")
        self.assertEqual(out, ["loading\t3\t0\tloading\ttrue", "seen\t3\t0\tseen\ttrue"])

    def test_an_unknown_answer_never_switches_it_off(self):
        # a per-player answer a later kit adds: "not now" for that press, masked for the client, never server-wide
        out = self.go("""
local w = load(function(p) if p.Name == "A" then return false, "a reason a later kit adds (detail 42)" end return true end)
local a, b = player("A"), player("B")
w.press(a, "pressed")
w.T = 1
w.press(b, "pressed")
w.press(a, "pressed")
print(#w.calls, #w.warned, w.replies[1][2], w.replies[2][1], w.replies[3][2])
""")
        self.assertEqual(out, ["3\t0\tnot now\ttrue\tnot now"])

    SCENE_LEVEL = ["cutscene names may only use letters, digits and _", "no such cutscene: Awakening",
                   "cutscene module errored: boom", "invalid: Length must be a number",
                   "Awakening is a story scene: start it with Play", "Awakening is a ultimate scene: start it with Ultimate"]

    def switched_off(self, answers):
        """For each answer player A gets from Awaken: does the key bind stop for player B too ("off"), or not ("on")?"""
        return self.go(f"local SAMPLES = {clip.luau_value(list(answers))}\n" + """
for _, why in SAMPLES do
	local w = load(function(p) if p.Name == "A" then return false, why end return true end)
	local a, b = player("A"), player("B")
	w.press(a, "pressed")
	w.T = 1
	w.press(b, "pressed")
	print((#w.calls == 1 and #w.warned == 1 and w.replies[1][2] == "unavailable") and "off"
		or (#w.calls == 2 and #w.warned == 0) and "on" or "odd")
end
""")

    def test_each_scene_level_answer_switches_it_off(self):
        self.assertEqual(self.switched_off(self.SCENE_LEVEL), ["off"] * len(self.SCENE_LEVEL))

    def test_every_scene_level_answer_in_server_luau_switches_it_off(self):
        # read every answer Server.load and Server.awaken give; all but the per-player ones must switch the key bind
        # off, so a scene-level answer added to the kit can't slip past SCENE_BROKEN (a new per-player one fails here
        # too, until it is added to PER_PLAYER below)
        src = bundle._read(paths.ROBLOX / "CutsceneKit" / "Server.luau")
        consts = dict(re.findall(r'^Server\.([A-Z_]+) = "((?:[^"\\]|\\.)*)"', src, re.M))
        per_player = {"busy", "awakened", "cooldown", "loading", "seen", "no living character", consts["BAD_SUBJECT"]}
        answers, forwarded = [], set()
        for header in ("function Server.load(", "function Server.awaken("):
            start = src.index(header)
            body = src[start:src.index("\nend\n", start)]
            for expr in re.findall(r"^\s*return (?:nil|false), (.+?)\s*$", body, re.M):
                literal = re.match(r'"((?:[^"\\]|\\.)*)"\s*(\.\.)?', expr)
                fmt = re.match(r'\("((?:[^"\\]|\\.)*)"\):format\(', expr)
                const = re.fullmatch(r"Server\.([A-Z_]+)", expr)
                if literal:
                    answers.append(literal.group(1) + ("Awakening" if literal.group(2) else ""))
                elif fmt:
                    fills = iter(["Awakening", "story", "Play"])
                    answers.append(re.sub("%s", lambda _: next(fills), fmt.group(1)))
                elif const:
                    answers.append(consts[const.group(1)])
                elif re.fullmatch(r"[a-z]\w*", expr):
                    forwarded.add(expr)
                else:
                    self.fail(f"an answer in Server.luau this test can't read: {expr!r}")
        self.assertEqual(forwarded, {"why"})  # Server.awaken passes on Server.load's answer, read above
        scene_level = [a for a in answers if a not in per_player]
        self.assertGreaterEqual(len(scene_level), 5, scene_level)
        self.assertGreaterEqual(len(answers) - len(scene_level), 7, answers)
        got = dict(zip(answers, self.switched_off(answers)))
        self.assertEqual(got, {a: "on" if a in per_player else "off" for a in answers})

    def test_an_unfilled_example_warns_at_load_and_connects_nothing(self):
        out = self.go(f"local RAW = {payload.long_string(bundle._read(studio.EXAMPLES / 'AwakenKeyBind.server.luau'))}\n"
                      + """
local w = load(function() return true end, RAW)
print(w.press == nil, #w.warned, string.find(w.warned[1] or "", "SCENE", 1, true) ~= nil)
""")
        self.assertEqual(out, ["true\t1\ttrue"])

    def test_a_rejoin_inside_the_gap_is_refused(self):
        out = self.go("""
local w = load(function() return true end)
local a = player("A", 77)
w.press(a, "pressed")
w.leave(a)
local back = player("A", 77) -- the same user, a new Player object
w.T = 10
w.press(back, "pressed")
print(#w.calls, last(w))
w.T = 30
w.press(back, "pressed")
print(#w.calls, last(w))
""")
        self.assertEqual(out, ["1\tfalse cooldown 20", "2\ttrue nil nil"])

    def test_the_kit_cooldown_answer_is_passed_on(self):
        out = self.go("""
local w = load(function() return false, "cooldown", 12.2 end)
local a = player("A")
w.press(a, "pressed")
print(#w.calls, last(w), #w.warned)
w.T = 1
w.press(a, "pressed")
print(#w.calls)
""")
        self.assertEqual(out, ["1\tfalse cooldown 13\t0", "2"])

    def test_leaving_drops_the_press_window_but_not_the_gap(self):
        # PlayerRemoving takes the player's RATE window out (a late press is looked at again), and the gap stays
        out = self.go("""
local w = load(function() return true end)
local a = player("A")
w.press(a, "pressed")
w.leave(a)
w.T = 0.1
w.press(a, "pressed")
print(#w.calls, #w.replies, last(w))
""")
        self.assertEqual(out, ["1\t2\tfalse cooldown 30"])


if __name__ == "__main__":
    unittest.main()
