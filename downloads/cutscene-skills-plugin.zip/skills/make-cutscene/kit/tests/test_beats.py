"""Tests for kit/beats.py, the beat sheet. Method by fwjelaa (FWJ STUDIOS)."""
import copy
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import camtrack  # noqa: E402

LINES = [("Guard", "Halt. Nobody enters after dark."), ("Guard", "Turn back now, or I make you.")]
WORDS = "a guard stops the player at the gate, two lines, a push-in then a cut on his warning"


def gate():
    b = beats.from_words("GateGuard", WORDS, LINES)
    b["trigger"] = {"type": "zone", "size": [16, 8, 16]}
    b["dialogue"] = "anime"
    b["cast"]["npc1"]["model"] = "default"
    return b


class WordsTest(unittest.TestCase):
    def test_shot_grammar(self):
        b = gate()
        self.assertEqual([s["type"] for s in b["shots"]], ["ESTABLISH", "HERO", "CLIMAX", "AFTERMATH", "RETURN"])
        self.assertEqual([s["start"] for s in b["shots"]], [0.0, 1.6, 4.9, 8.1, 9.3])
        self.assertEqual(b["shots"][-1]["length"], beats.RETURN)
        self.assertEqual(beats.length(b), 9.85)
        self.assertEqual(b["lines"]["2"], {"speaker": "Guard", "text": "Turn back now, or I make you."})
        for s in b["shots"]:
            self.assertAlmostEqual(s["start"] * 60, round(s["start"] * 60), places=6)

    def test_markers_add_structure(self):
        self.assertEqual(beats.markers(gate()), [
            [0.0, "Letterbox", "in"], [1.6, "Cut", ""], [1.75, "Line", "1"], [4.9, "Cut", ""], [4.9, "Shake", "0.25"],
            [5.05, "Line", "2"], [8.1, "Cut", ""], [9.3, "Letterbox", "out"], [9.85, "End", ""]])
        self.assertEqual(beats.cut_frames(gate()), [96, 294, 486])

    def test_an_off_grid_length_ends_on_the_frame_grid(self):
        """A hand-edited length off the 60 fps grid: End sits on frame N in the module and in the Stage clip alike."""
        cf = camtrack.look_cf((0, 5, 10), (0, 4, 0))
        for extra in (0.005, -0.005):  # 9.855 s and 9.845 s: both have N = 591
            b = gate()
            b["shots"][-1]["length"] = round(b["shots"][-1]["length"] + extra, 5)
            n = camtrack.last_frame(beats.length(b))
            self.assertEqual(n, 591)
            marks = beats.markers(b)
            self.assertEqual(marks[-1], [9.85, "End", ""])
            stage = camtrack.stage_clip("S_Stage", [cf] * (n + 1), beats.cut_frames(b), marks)
            in_clip = [[k["time"], name, value] for k in stage["keyframes"] for name, value in k["markers"]]
            self.assertEqual([m[1:] for m in in_clip], [m[1:] for m in marks])
            for got, want in zip(in_clip, marks):
                self.assertAlmostEqual(got[0], want[0], places=4, msg=(extra, want))

    def test_a_shot_marker_in_the_last_half_frame_sits_on_the_end_in_both_lists(self):
        cf = camtrack.look_cf((0, 5, 10), (0, 4, 0))
        b = gate()
        last = b["shots"][-1]
        last.setdefault("markers", []).append([round(last["length"] - 0.004, 5), "Shake", "0.1"])  # 9.846 s, frame 591
        n = camtrack.last_frame(beats.length(b))
        marks = beats.markers(b)
        self.assertIn([9.85, "Shake", "0.1"], marks)
        stage = camtrack.stage_clip("S_Stage", [cf] * (n + 1), beats.cut_frames(b), marks)
        in_clip = sorted([round(k["time"], 5), name, value] for k in stage["keyframes"] for name, value in k["markers"])
        self.assertEqual(in_clip, sorted([round(m[0], 5)] + m[1:] for m in marks))

    def test_export_part_holds_what_the_clips_are_made_from(self):
        b, same = gate(), beats.export_part(gate())
        b["lines"]["2"]["text"], b["dialogue"], b["approved"] = "Go home.", "box", True
        b["shots"][1]["camera"], b["cast"]["npc1"]["hide"] = "tighter", "Gate/Guard"
        self.assertEqual(beats.export_part(b), same)  # the data module only
        for change in (lambda s: s["shots"][1]["markers"].append([0.5, "Shake", "9"]),
                       lambda s: s["shots"][2].update(length=3.0),
                       lambda s: s["cast"]["npc1"].update(place=[1, 0, -8, 0, 180, 0]),
                       lambda s: s["config"].update(Letterbox=0)):
            b = gate()
            change(b)
            self.assertNotEqual(beats.export_part(b), same)

    def test_shots_view(self):
        s = beats.shots(gate())[1]
        self.assertEqual((s["n"], s["type"], s["start"], s["end"], s["first_frame"], s["end_frame"]),
                         (2, "HERO", 1.6, 4.9, 96, 294))
        self.assertAlmostEqual(s["last"], 4.9 - 1 / 60, places=5)

    def test_a_fresh_draft_asks_what_is_missing(self):
        b = beats.from_words("GateGuard", WORDS, LINES)
        problems, questions = beats.validate(b), beats.asks(b)
        self.assertTrue(any("trigger is not set" in p for p in problems))
        self.assertTrue(any("dialogue is not set" in p for p in problems))
        self.assertTrue(any("cast.npc1.model is not set" in p for p in problems))
        self.assertEqual(len(questions), 3)
        self.assertEqual(beats.validate(gate()), [])
        self.assertEqual(beats.asks(gate()), [])


class ValidateTest(unittest.TestCase):
    def fails(self, b, mention):
        problems = beats.validate(b)
        self.assertTrue(any(mention in p for p in problems), problems)

    def test_shots_must_follow_on(self):
        b = gate()
        b["shots"][2]["start"] = 5.0
        self.fails(b, "--retime")

    def test_unknown_type_subject_and_role(self):
        b = gate()
        b["shots"][0]["type"] = "ORBIT"
        self.fails(b, "type must be one of")
        b = gate()
        b["shots"][0]["subject"] = "npc2"
        self.fails(b, "not in the cast")
        b = gate()
        b["cast"]["boss"] = {"model": "default"}
        self.fails(b, "must be player, target or npc1..npc99")

    def test_markers(self):
        b = gate()
        b["shots"][1]["markers"].append([9.0, "Shake", "0.3"])
        self.fails(b, "outside the shot")
        b = gate()
        b["shots"][1]["markers"][0][2] = "7"
        self.fails(b, "has no entry in lines")
        b = gate()
        b["shots"][2]["markers"] = []
        self.fails(b, "line 2 is never shown")
        b = gate()
        b["shots"][1]["markers"].append([0.1, "VFX:Dust", ""])
        self.fails(b, "must be [seconds into the shot, name, value]")

    def test_thirty_second_cap(self):
        b = gate()
        b["shots"][0]["length"] = 25.0
        beats.retime(b["shots"])
        self.fails(b, "at most 30 s")

    def test_bad_id_and_config(self):
        b = gate()
        b["id"] = "Gate-Guard"
        self.fails(b, "id: start with a letter")
        b = gate()
        b["config"]["Replay"] = "never"
        self.fails(b, "config: Config.Replay")

    def test_retime_snaps_to_frames(self):
        shots = [beats.shot("ACTION", 1.234), beats.shot("ACTION", 0.05)]
        beats.retime(shots)
        self.assertEqual([s["length"] for s in shots], [1.23333, 0.2])
        self.assertEqual(shots[1]["start"], 1.23333)


class RobustTest(unittest.TestCase):
    def test_odd_json_is_reported_not_raised(self):
        b = gate()
        b["shots"][0]["subject"] = ["npc1"]
        self.assertTrue(any("subject" in p for p in beats.validate(b)))
        b = gate()
        b["shots"][1]["subject"] = {"a": 1}
        self.assertTrue(any("subject" in p for p in beats.validate(b)))
        b = gate()
        b["shots"][2] = "not a shot"
        self.assertTrue(any("shot 3 must be an object" in p for p in beats.validate(b)))
        beats.table(b)

    def test_retime_sheet_clears_approval(self):
        b = gate()
        b["approved"] = True
        b["shots"][0]["length"] = 2.0
        beats.retime_sheet(b)
        self.assertFalse(b["approved"])
        self.assertEqual(b["shots"][1]["start"], 2.0)


class FilesTest(unittest.TestCase):
    def test_save_draft_never_overwrites_the_sheet(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.assertEqual(beats.save_draft(root, gate()).name, "beats.json")
            self.assertEqual(beats.save_draft(root, gate()).name, "beats.draft.json")
            self.assertEqual(beats.save_draft(root, gate(), force=True).name, "beats.json")
            self.assertEqual(beats.load(root)["id"], "GateGuard")
            self.assertEqual(beats.load(root / "beats.json")["id"], "GateGuard")

    def test_table_lists_shots_and_lines(self):
        text = beats.table(gate())
        self.assertIn("CLIMAX", text)
        self.assertIn("Turn back now, or I make you.", text)
        self.assertIn("9.85 s", text)
        broken = copy.deepcopy(gate())
        broken["trigger"] = None
        self.assertIn("trigger=None", beats.table(broken))


if __name__ == "__main__":
    unittest.main()
