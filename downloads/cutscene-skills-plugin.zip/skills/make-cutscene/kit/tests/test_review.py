"""Tests for kit/review.py, the blind score. Method by fwjelaa (FWJ STUDIOS)."""
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import fixture  # noqa: E402
import gates  # noqa: E402
import review  # noqa: E402
import workspace  # noqa: E402

NL = chr(10)


def reply(*points):
    return NL.join(f"C{i}: {p} | looked at frame {i}" for i, p in enumerate(points, 1)) + NL + "Fix: tighten shot 3" + NL


class ScoreTest(unittest.TestCase):
    def test_parse_and_score(self):
        self.assertEqual(review.parse_reply(reply(2, 2, 1, 2, 1, 2)), {"C1": 2, "C2": 2, "C3": 1, "C4": 2, "C5": 1, "C6": 2})
        self.assertEqual(review.score({c: 2 for c, _, _ in review.CRITERIA}), 10.0)
        self.assertEqual(review.score({c: 1 for c, _, _ in review.CRITERIA}), 5.0)
        self.assertEqual(review.score(review.parse_reply(reply(2, 2, 1, 2, 1, 2))), 8.6)

    def test_a_reply_missing_a_criterion(self):
        with self.assertRaises(SystemExit) as e:
            review.parse_reply("C1: 2 | x" + NL + "C2: 1 | y")
        self.assertIn("C3", str(e.exception))


class ParseTest(unittest.TestCase):
    def one(self, line, rest=2):
        text = line + NL + NL.join(f"C{i}: {rest} | x" for i in range(2, 7))
        return review.parse_reply(text)["C1"]

    def test_bold_bullets_and_dashes(self):
        for line in ("C1: 1", "**C1:** 1", "**C1**: 1", "**C1: 1**", "- C1: 1", "* **C1** = 1", "> C1 - 1",
                     "| C1 | 1 | evidence |", "C1 (Camera language): 1", "  C1:1"):
            self.assertEqual(self.one(line), 1, line)

    def test_decimals_are_read_as_decimals(self):
        self.assertEqual(self.one("C1: 1.5"), 1.5)
        self.assertEqual(self.one("C1 - 0.5/2"), 0.5)

    def test_a_score_out_of_ten_is_scaled_to_the_rubric(self):
        self.assertEqual(self.one("C1 - 8.5/10"), 1.7)
        self.assertEqual(self.one("C1: 10/10"), 2)

    def test_a_bare_number_outside_0_to_2_is_refused_loudly(self):
        for line in ("C1: 8.5", "C1: 3", "C1: 2.5/2"):
            with self.assertRaises(SystemExit) as e:
                self.one(line)
            self.assertIn("C1", str(e.exception), line)
            self.assertIn("0-2", str(e.exception), line)

    def test_prose_around_the_lines_is_ignored(self):
        text = ("Here is my review of the cutscene." + NL + "C1: 2 | shots have jobs, see C2: 0 in my notes" + NL +
                "Some thoughts about C3 follow." + NL + NL.join(f"C{i}: 1 | y" for i in range(2, 7)) + NL +
                "Fix: nothing. C4: 0 would be wrong." + NL)
        got = review.parse_reply(text)
        self.assertEqual(got["C1"], 2)
        self.assertEqual(got["C2"], 1)
        self.assertEqual(got["C4"], 1)

    def test_a_repeated_criterion_with_different_values_is_refused_and_named(self):
        text = reply(2, 2, 2, 2, 2, 2) + "C4: 0 | restated" + NL
        with self.assertRaises(SystemExit) as e:
            review.parse_reply(text)
        self.assertIn("C4", str(e.exception))
        self.assertIn("twice", str(e.exception))

    def test_a_repeated_criterion_with_the_same_value_is_fine(self):
        self.assertEqual(review.parse_reply(reply(2, 2, 2, 2, 2, 2) + "C4: 2 | again" + NL)["C4"], 2)

    def test_every_missing_criterion_is_named(self):
        with self.assertRaises(SystemExit) as e:
            review.parse_reply("C1: 2" + NL + "C3: 1" + NL + "C5: 0")
        for c in ("C2", "C4", "C6"):
            self.assertIn(c, str(e.exception))

    def test_slash_two_is_taken_as_is_and_any_other_denominator_but_ten_is_refused(self):
        self.assertEqual(self.one("C1: 1/2"), 1)
        for line in ("C1: 2/3", "C1: 1/5", "C1: 4/100"):
            with self.assertRaises(SystemExit) as e:
                self.one(line)
            self.assertIn("C1", str(e.exception), line)

    def test_scaled_and_fractional_replies_leave_a_note(self):
        text = NL.join(["C1: 8.5/10", "C2: 1.5", "C3: 2/2", "C4: 1", "C5: 2", "C6: 0"])
        found, notes = review.parse_reply_notes(text)
        self.assertEqual(found["C1"], 1.7)
        self.assertEqual(len(notes), 2)
        self.assertTrue(any("C1" in n and "8.5/10" in n for n in notes), notes)
        self.assertTrue(any("C2" in n and "1.5" in n for n in notes), notes)
        self.assertEqual(review.parse_reply_notes(reply(2, 2, 2, 2, 2, 2))[1], [])

    def test_half_points_score(self):
        self.assertEqual(review.score({c: 1.5 for c, _, _ in review.CRITERIA}), 7.5)


class RoundTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.work = Path(self.tmp.name)
        self.root = fixture.write_scene(env={"MAKE_CUTSCENE_WORK": self.tmp.name})
        self.pass_everything()

    def write_gates(self, ok=True):
        workspace.write_json(self.root / "export" / "gates.json",
                             {"ok": ok, "issues": [] if ok else ["x"], "export": gates.export_hash(self.root)})

    def pass_everything(self):
        pv = self.root / "preview"
        for name in ("Fixture_Scene.mp4", "sheet.png", "side_by_side_1.png",
                     "Fixture_Scene_R6.mp4", "sheet_R6.png", "side_by_side_R6_1.png"):  # spec 14: both casts
            (pv / name).write_bytes(b"x")
        review.stamp_preview(self.root)
        review.stamp_preview(self.root, "R6")
        review.stamp_sheet(self.root, "side_by_side", ["side_by_side_1.png"])  # what sheets.side_by_side records
        review.stamp_sheet(self.root, "side_by_side_R6", ["side_by_side_R6_1.png"])
        # Synthetic byte fixtures: this checks integrity, not media playback.
        review.stamp_sheet(self.root, "overview", ["sheet.png"])
        review.stamp_sheet(self.root, "overview_R6", ["sheet_R6.png"])
        self.write_gates()
        review.set_playtest(self.root, [f"{k}=pass" for k in review.PLAYTEST])

    def re_export(self):
        scene = workspace.read_json(self.root / "export" / "scene.json")
        scene["fov"] = scene["fov"] + [[9.0, 60]]
        workspace.write_json(self.root / "export" / "scene.json", scene)

    def build(self, n=1):
        return review.packet(self.root, n)

    def test_hard_gates(self):
        self.assertTrue(all(review.hard_gates(self.root).values()))
        review.set_playtest(self.root, ["R6=fail"])
        self.assertFalse(review.hard_gates(self.root)["G2 play test"])
        with self.assertRaises(SystemExit):
            review.set_playtest(self.root, ["R7=pass"])

    def test_a_re_export_makes_every_gate_record_stale(self):
        self.re_export()
        self.assertEqual(review.stale(self.root), ["G1 kit checks", "G2 play test", "G3 preview"])
        self.assertFalse(any(review.hard_gates(self.root).values()))

    def test_review_and_score_refuse_stale_gate_files(self):
        out = self.build()
        self.re_export()
        with self.assertRaises(SystemExit) as e:
            self.build()
        self.assertIn("re-run gates/playtest/preview for this export", str(e.exception))
        self.assertIn("G1 kit checks", str(e.exception))
        with self.assertRaises(SystemExit) as e:
            review.record(self.root, 1, [reply(2, 2, 2, 2, 2, 2)] * 3)
        self.assertIn("re-run gates/playtest/preview for this export", str(e.exception))
        self.assertTrue(out[0].exists())

    def test_re_running_the_checks_makes_them_current_again(self):
        self.re_export()
        self.write_gates()
        review.stamp_preview(self.root)
        review.stamp_preview(self.root, "R6")
        review.set_playtest(self.root, [f"{k}=pass" for k in review.PLAYTEST])
        self.assertEqual(review.stale(self.root), [])

    def test_an_r6_preview_is_stamped_and_goes_stale_like_the_r15_one(self):
        (self.root / "preview" / "export_R6.json").unlink()  # the fixture records both casts now: drop the R6 stamp
        self.assertEqual(review.stale(self.root), ["G3 preview"])  # no R6 stamp yet
        review.stamp_preview(self.root, "R6")
        self.assertTrue((self.root / "preview" / "export_R6.json").exists())
        self.assertEqual(review.stale(self.root), [])
        self.assertTrue(all(review.hard_gates(self.root).values()))
        self.re_export()
        self.write_gates()
        review.stamp_preview(self.root)  # only the R15 preview was re-made
        review.set_playtest(self.root, [f"{k}=pass" for k in review.PLAYTEST])
        self.assertEqual(review.stale(self.root), ["G3 preview"])
        self.assertFalse(review.hard_gates(self.root)["G3 preview"])
        review.stamp_preview(self.root, "R6")
        self.assertEqual(review.stale(self.root), [])

    def edit_module(self):
        mod = self.root / "export" / "Fixture_Scene.luau"
        mod.write_text(mod.read_text(encoding="utf-8") + "-- lines changed" + NL, encoding="utf-8", newline=NL)

    def test_a_data_module_change_makes_play_test_and_preview_stale(self):
        mod = self.root / "export" / "Fixture_Scene.luau"
        if not mod.exists():
            mod.write_text("return {}" + NL, encoding="utf-8", newline=NL)
            self.pass_everything()
        self.assertEqual(review.stale(self.root), [])
        before = gates.export_hash(self.root)
        self.edit_module()
        self.assertEqual(gates.export_hash(self.root), before)  # the gates' own fingerprint stays on the export
        self.assertEqual(review.stale(self.root), ["G2 play test", "G3 preview"])
        hg = review.hard_gates(self.root)
        self.assertTrue(hg["G1 kit checks"])
        self.assertFalse(hg["G2 play test"] or hg["G3 preview"])
        with self.assertRaises(SystemExit) as e:
            review.require_current(self.root)
        self.assertIn("the data module changed after the play test/preview: install and test again", str(e.exception))
        review.stamp_preview(self.root)
        review.stamp_preview(self.root, "R6")
        review.set_playtest(self.root, [f"{k}=pass" for k in review.PLAYTEST])
        self.assertEqual(review.stale(self.root), [])

    def test_a_record_without_the_hash_is_stale(self):
        workspace.write_json(self.root / "export" / "gates.json", {"ok": True, "issues": []})
        self.assertEqual(review.stale(self.root), ["G1 kit checks"])

    def test_packets_are_blind_and_complete(self):
        dirs = self.build()
        self.assertEqual(len(dirs), 3)
        self.assertEqual(len({str(d) for d in dirs}), 3)
        for out in dirs:
            self.assertEqual(sorted(p.relative_to(out).as_posix() for p in out.rglob("*")),
                             ["README.md", "beats.txt", "frames.png", "frames_R6.png", "preview_R15.mp4",
                              "preview_R6.mp4", "rubric.md", "side_by_side_1.png",
                              "side_by_side_R6_1.png"])
            self.assertNotIn((self.root / "review").resolve(), out.resolve().parents)
            text = (out / "beats.txt").read_text(encoding="utf-8")
            self.assertNotIn("score", text.lower())
            self.assertNotIn("approved", text)
            self.assertNotIn("push-in on the guard", text)  # the author's camera note
            self.assertNotIn("the guard waves", text)  # the author's action note
            self.assertIn("Stop right there.", text)
        with self.assertRaises(SystemExit):
            review.packet(self.root, 4)

    def test_a_later_round_leaves_only_the_current_packets_and_no_round_in_any_name(self):
        self.build(1)
        review.record(self.root, 1, [reply(2, 1, 2, 2, 2, 2)] * 3)
        dirs = self.build(2)
        blind = self.work / "blind"
        self.assertEqual(sorted(p.name for p in blind.iterdir()), sorted(d.name for d in dirs))
        self.assertEqual(len(dirs), 3)
        for p in blind.rglob("*"):
            rel = p.relative_to(blind).as_posix().lower()
            self.assertNotRegex(rel, r"(?:^|[-_/])r[123](?:[-_/]|$)")
            self.assertNotIn("round", rel)

    def test_old_round_named_packets_from_before_are_removed_too(self):
        old = self.work / "blind" / "Fixture_Scene-r1-1"
        old.mkdir(parents=True)
        (old / "frames.png").write_bytes(b"x")
        self.build(1)
        self.assertFalse(old.exists())

    def test_packets_hold_nothing_from_results_even_after_scoring(self):
        self.build(1)
        review.record(self.root, 1, [reply(2, 1, 2, 2, 2, 2)] * 3)
        for out in self.build(2):
            names = {p.name for p in out.rglob("*")}
            self.assertFalse(names & {"scores.json", "ledger.jsonl", "packet.json"}, names)
            self.assertFalse(any(n.startswith("reply_") for n in names), names)

    def test_results_are_kept_outside_the_packets(self):
        self.build(1)
        review.record(self.root, 1, [reply(2, 2, 2, 2, 2, 2)] * 3)
        self.assertTrue((self.root / "review" / "results" / "round1" / "scores.json").exists())
        self.assertFalse(list((self.work / "blind").rglob("scores.json")))

    def test_a_pass_is_logged(self):
        self.build(1)
        result, lines = review.record(self.root, 1, [reply(2, 2, 2, 2, 1, 2), reply(2, 2, 1, 2, 2, 2), reply(1, 2, 2, 2, 2, 2)])
        self.assertTrue(result["passed"])
        self.assertEqual(result["scores"], [9.3, 9.3, 8.9])
        self.assertEqual(result["median"], 9.3)
        ledger = (self.work / ".fwjelaa" / "ledger.jsonl").read_text(encoding="utf-8").splitlines()
        entry = json.loads(ledger[-1])
        self.assertEqual((entry["type"], entry["name"], entry["final_score"], entry["rounds"]), ("cutscene", "Fixture_Scene", 9.3, 1))
        self.assertIn("PASSED", NL.join(lines))

    def test_a_low_round_points_at_the_lowest_criterion_and_is_not_logged(self):
        self.build(1)
        result, lines = review.record(self.root, 1, [reply(2, 1, 2, 2, 2, 2), reply(2, 0, 2, 2, 2, 2), reply(2, 1, 2, 2, 2, 1)])
        self.assertFalse(result["passed"])
        self.assertEqual(result["lowest"], "C2")
        self.assertFalse((self.work / ".fwjelaa" / "ledger.jsonl").exists())
        self.assertIn("--round 2", NL.join(lines))

    def test_round_three_is_reported_honestly(self):
        self.build(3)
        result, lines = review.record(self.root, 3, [reply(1, 1, 1, 1, 1, 1)] * 3)
        self.assertFalse(result["passed"])
        self.assertIn("NOT PASSED after 3 rounds", NL.join(lines))
        self.assertTrue((self.work / ".fwjelaa" / "ledger.jsonl").exists())

    def test_scaled_replies_are_recorded_in_the_result_and_the_ledger(self):
        self.build(1)
        text = NL.join(["C1: 8.5/10", "C2: 2", "C3: 2", "C4: 2", "C5: 2", "C6: 2"])
        result, lines = review.record(self.root, 1, [text, reply(2, 2, 2, 2, 2, 2), reply(2, 2, 2, 2, 2, 2)])
        self.assertEqual(len(result["notes"][0]), 1)
        self.assertEqual(result["notes"][1:], [[], []])
        self.assertIn("scaled", NL.join(lines))
        entry = json.loads((self.work / ".fwjelaa" / "ledger.jsonl").read_text(encoding="utf-8").splitlines()[-1])
        self.assertTrue(entry["scaled_replies"])

    def test_an_export_stale_against_the_edited_beats_is_refused(self):
        import beats
        b = beats.load(self.root)
        b["cast"]["npc1"]["place"][0] += 1
        beats.save(b, self.root)
        with self.assertRaises(SystemExit) as e:
            self.build(1)
        self.assertIn("changed after the export", str(e.exception))
        self.assertTrue(gates.export_stale(self.root))
        self.assertFalse(all(review.hard_gates(self.root).values()))

    def test_a_failed_gate_caps_the_score(self):
        self.write_gates(ok=False)
        self.build(1)
        result, _ = review.record(self.root, 1, [reply(2, 2, 2, 2, 2, 2)] * 3)
        self.assertEqual(result["median"], 5.0)
        self.assertFalse(result["passed"])

    def test_a_bad_round_number_is_refused(self):
        for n in (0, 4, -1):
            with self.assertRaises(SystemExit):
                review.record(self.root, n, [reply(2, 2, 2, 2, 2, 2)] * 3)

    def test_scoring_needs_the_packet_first(self):
        with self.assertRaises(SystemExit) as e:
            review.record(self.root, 1, [reply(2, 2, 2, 2, 2, 2)] * 3)
        self.assertIn("review", str(e.exception))

    def test_a_round_is_scored_once_unless_forced(self):
        self.build(1)
        replies = [reply(2, 2, 2, 2, 2, 2)] * 3
        review.record(self.root, 1, replies)
        with self.assertRaises(SystemExit) as e:
            review.record(self.root, 1, replies)
        self.assertIn("--force", str(e.exception))
        review.record(self.root, 1, replies, force=True)
        ledger = (self.work / ".fwjelaa" / "ledger.jsonl").read_text(encoding="utf-8").splitlines()
        self.assertEqual(len(ledger), 2)
        self.assertTrue(json.loads(ledger[-1])["rescored"])

    def test_the_wrong_number_of_replies_is_refused(self):
        self.build(1)
        with self.assertRaises(SystemExit):
            review.record(self.root, 1, [reply(2, 2, 2, 2, 2, 2)] * 2)

    # I2: the blind evidence is tied to the build being scored
    def test_a_new_take_gets_a_new_preview_stamp_on_the_same_build(self):
        pv = self.root / "preview"
        before = workspace.read_json(pv / "export_R6.json")
        (pv / "Fixture_Scene_R6.mp4").write_bytes(b"another take")
        review.stamp_preview(self.root, "R6")
        self.assertNotEqual(workspace.read_json(pv / "export_R6.json"), before)
        self.assertEqual(review.stale(self.root), [], "the build itself didn't change")

    def test_packets_refuse_sheets_made_from_an_older_preview(self):
        self.build()
        pv = self.root / "preview"
        (pv / "Fixture_Scene_R6.mp4").write_bytes(b"a new R6 take")
        review.stamp_preview(self.root, "R6")
        with self.assertRaises(SystemExit) as e:
            self.build()
        self.assertIn("py kit/run.py sidebyside Fixture_Scene --rig R6", str(e.exception))
        self.assertIn("side-by-side sheets (R6)", str(e.exception))
        self.assertNotIn("(R15)", str(e.exception))  # the R15 sheets are still current
        review.stamp_sheet(self.root, "side_by_side_R6", ["side_by_side_R6_1.png"])
        review.stamp_sheet(self.root, "overview_R6", ["sheet_R6.png"])
        self.assertEqual(len(self.build()), 3)

    def test_packets_ship_only_the_sheets_the_last_run_made(self):
        (self.root / "preview" / "side_by_side_2.png").write_bytes(b"left over from a longer cut")
        for out in self.build():
            self.assertFalse((out / "side_by_side_2.png").exists())
            self.assertTrue((out / "side_by_side_1.png").exists())

    def test_sheets_with_no_record_or_from_another_preview_file_are_refused(self):
        (self.root / "preview" / "sheets.json").unlink()
        with self.assertRaises(SystemExit) as e:
            self.build()
        self.assertIn("py kit/run.py sidebyside Fixture_Scene", str(e.exception))
        review.stamp_sheet(self.root, "side_by_side", ["side_by_side_1.png"], own=False)  # made with --preview <file>
        review.stamp_sheet(self.root, "side_by_side_R6", ["side_by_side_R6_1.png"])
        with self.assertRaises(SystemExit) as e:
            self.build()
        self.assertIn("py kit/run.py sidebyside Fixture_Scene", str(e.exception))

    def test_a_listed_sheet_that_is_gone_is_refused(self):
        (self.root / "preview" / "side_by_side_1.png").unlink()
        with self.assertRaises(SystemExit) as e:
            self.build()
        self.assertIn("side_by_side_1.png", str(e.exception))

    def test_scoring_refuses_replies_made_on_an_older_export(self):
        self.build(1)
        self.re_export()
        self.pass_everything()  # every gate, preview and sheet made again for the new export, but not the packets
        self.assertEqual(review.stale(self.root), [])
        with self.assertRaises(SystemExit) as e:
            review.record(self.root, 1, [reply(2, 2, 2, 2, 2, 2)] * 3)
        self.assertIn("the build changed after the packets were made: run review again", str(e.exception))
        self.assertFalse((self.root / "review" / "results" / "round1" / "scores.json").exists())
        self.build(1)
        self.assertTrue(review.record(self.root, 1, [reply(2, 2, 2, 2, 2, 2)] * 3)[0]["passed"])

    def test_scoring_refuses_replies_made_before_a_data_module_change(self):
        mod = self.root / "export" / "Fixture_Scene.luau"
        if not mod.exists():
            mod.write_text("return {}" + NL, encoding="utf-8", newline=NL)
            self.pass_everything()
        self.build(1)
        self.edit_module()
        self.pass_everything()
        with self.assertRaises(SystemExit) as e:
            review.record(self.root, 1, [reply(2, 2, 2, 2, 2, 2)] * 3)
        self.assertIn("the build changed after the packets were made: run review again", str(e.exception))


if __name__ == "__main__":
    unittest.main()
