"""The cast overlap check (RS-1) and the IK binding to the captured rig. Method by fwjelaa (FWJ STUDIOS)."""
import ast
import math
import sys
import unittest
from pathlib import Path

KIT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(KIT))

import beats  # noqa: E402
import contact  # noqa: E402

I3 = ((1, 0, 0), (0, 1, 0), (0, 0, 1))


def cube(x, y, z, size=(1, 1, 1), yaw=0.0):
    c, s = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    m = [[c, 0, s, x], [0, 1, 0, y], [-s, 0, c, z], [0, 0, 0, 1]]
    return contact.box(m, size)


def scene_beats():
    return {"cast": {"player": {}, "npc1": {}},
            "shots": [{"start": 0.0, "length": 1.0},
                      {"start": 1.0, "length": 1.0,
                       "contacts": [[0.5, "player.RightHand", "npc1.UpperTorso", 4]]}]}


class Depth(unittest.TestCase):
    def test_apart_is_zero(self):
        self.assertEqual(contact.depth(cube(0, 0, 0), cube(1.01, 0, 0)), 0.0)

    def test_overlap_is_the_smallest_axis(self):
        self.assertAlmostEqual(contact.depth(cube(0, 0, 0), cube(0.7, 0.1, 0)), 0.3, places=6)

    def test_a_part_wholly_inside_counts(self):
        # a triangle test (BVHTree.overlap) sees no crossing faces here: the box test must
        d = contact.depth(cube(0, 0, 0, (4, 4, 4)), cube(0.2, 0, 0, (0.5, 0.5, 0.5)))
        self.assertGreater(d, 1.0)

    def test_turned_box_off_the_corner_is_apart(self):
        # a 45-degree box whose centre is inside the other's axis-aligned reach but whose sides miss it
        self.assertEqual(contact.depth(cube(0, 0, 0), cube(1.25, 0, 1.25, yaw=45)), 0.0)


class Scan(unittest.TestCase):
    def frames(self, n=4):
        # the fist sits 0.3 deep in the chest on every frame
        return [{"player": {"RightHand": cube(0, 3, -1.1, (0.4, 0.4, 0.4))},
                 "npc1": {"UpperTorso": cube(0, 3, -1.5, (2, 1.6, 1)), "LeftHand": cube(5, 3, 0)}} for _ in range(n)]

    def test_unplanned_overlap_is_named_with_its_frames(self):
        found = contact.scan(self.frames())
        self.assertEqual(len(found), 1)
        self.assertIn("npc1.UpperTorso goes 0.30 studs into player.RightHand on frames 0-3", found[0])

    def test_planned_contact_is_excused_only_on_its_frames(self):
        found = contact.scan(self.frames(), {1: [("player.RightHand", "npc1.UpperTorso")],
                                             2: [("npc1.UpperTorso", "player.RightHand")]})
        self.assertEqual(len(found), 1)
        self.assertIn("frames 0, 3", found[0])

    def test_wildcard_covers_a_limb(self):
        self.assertEqual(contact.scan(self.frames(1), {0: [("player.Right*", "npc1.UpperTorso")]}), [])

    def test_brushing_under_the_tolerance_passes(self):
        frames = [{"player": {"LeftHand": cube(0, 0, 0)}, "npc1": {"Head": cube(0.95, 0, 0)}}]
        self.assertEqual(contact.scan(frames), [])


class Plan(unittest.TestCase):
    def test_allowed_frames_follow_the_shot_start_and_hold(self):
        a = contact.allowed(scene_beats(), 60)
        self.assertEqual(sorted(a), [90, 91, 92, 93])
        self.assertEqual(a[90], [("player.RightHand", "npc1.UpperTorso")])

    def test_problems(self):
        b = scene_beats()
        self.assertEqual(contact.problems(b), [])
        b["shots"][0]["contacts"] = [[0.2, "player.RightHand", "player.Head"], [5, "player.A", "npc1.B"], ["x"]]
        p = contact.problems(b)
        self.assertEqual(len(p), 3)
        self.assertIn("two different roles", p[0])
        self.assertIn("outside the shot", p[1])

    def test_beats_validate_reports_them(self):
        path = KIT.parent / "examples" / "GateGuard" / "beats.json"
        if not path.exists():
            self.skipTest("no example beat sheet")
        import json
        b = json.loads(path.read_text(encoding="utf-8"))
        b["shots"][0]["contacts"] = [["late", "player.RightHand", "npc1.Head"]]
        self.assertTrue(any("contact" in p for p in beats.validate(b)))


class IkBinding(unittest.TestCase):
    """Blender-free: the sources are read. The bound IK itself was measured in Blender (task-reshoot-report.md)."""

    def test_r15_helpers_can_be_bound_to_another_rig(self):
        src = (KIT.parents[1] / "make-anim" / "anims" / "_r15.py").read_text(encoding="utf-8")
        fn = next(n for n in ast.parse(src).body if isinstance(n, ast.FunctionDef) and n.name == "bind")
        glob = next(n for n in fn.body if isinstance(n, ast.Global))
        self.assertEqual(set(glob.names), {"RIG", "FLOOR", "_JOINT", "_FOOT"})

    def test_filmset_binds_the_role_rig_while_an_anim_file_builds(self):
        src = (KIT / "filmset.py").read_text(encoding="utf-8")
        fn = next(n for n in ast.parse(src).body if isinstance(n, ast.FunctionDef) and n.name == "load_anim")
        body = ast.unparse(fn)
        self.assertIn("r15.bind(names['RIG'])", body)
        self.assertIn("finally", body)
        self.assertIn("r15.bind(old)", body)


if __name__ == "__main__":
    unittest.main()
