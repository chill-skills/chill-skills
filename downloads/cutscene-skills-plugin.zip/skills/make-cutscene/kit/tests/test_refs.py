"""Tests for kit/refs.py on synthetic media (FFmpeg testsrc / color with hard cuts). Method by fwjelaa (FWJ STUDIOS)."""
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import media  # noqa: E402
import refs  # noqa: E402
import workspace  # noqa: E402

HAVE_FFMPEG = shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None


class PureTest(unittest.TestCase):
    def test_shot_spans(self):
        self.assertEqual(refs.shot_spans([1.5, 2.5], 3.7), [(0.0, 1.5), (1.5, 2.5), (2.5, 3.7)])
        self.assertEqual(refs.shot_spans([], 9.0), [(0.0, 4.5), (4.5, 9.0)])
        self.assertEqual(refs.shot_spans([0.02, 1.0, 3.69], 3.7), [(0.0, 1.0), (1.0, 3.7)])

    def test_a_shot_under_the_shortest_beat_joins_its_neighbour(self):
        # beats.MIN_SHOT (0.2 s) is the shortest beat: a shorter reference shot would be stretched and shift the rest
        self.assertEqual(refs.shot_spans([1.5], 1.62), [(0.0, 1.62)])  # a short last shot joins the one before
        self.assertEqual(refs.shot_spans([1.0, 1.1, 2.0], 3.0), [(0.0, 1.1), (1.1, 2.0), (2.0, 3.0)])
        self.assertEqual(refs.shot_spans([0.1, 2.0], 3.0), [(0.0, 2.0), (2.0, 3.0)])  # the first joins the next
        self.assertEqual(refs.shot_spans([1.0, 1.2], 2.0), [(0.0, 1.0), (1.0, 1.2), (1.2, 2.0)])  # 0.2 s is a beat
        self.assertEqual(refs.joined_cuts([1.0, 1.1, 2.0, 2.9], 3.0), [1.0, 2.9])

    def test_samples_stay_on_the_shots_own_frames(self):
        # a seek past a clip's last frame writes no picture: the last sample is half a frame before the shot's last one
        times = refs.sample_times((1.5, 1.75), 6, 24)
        self.assertEqual(len(times), 6)
        self.assertTrue(all(1.5 <= t <= 1.75 - 1.5 / 24 + 1e-9 for t in times), times)
        self.assertEqual(refs.sample_times((0.0, 3.0), 2, 24), [0.75, 2.25])  # a long shot is sampled as before

    def test_timing(self):
        scores = [(i / 24, 0.0 if i % 2 else 0.01) for i in range(24)]
        t = refs.timing((0.0, 1.0), scores, [(0.2, 0.6)], 24)
        self.assertTrue(t["on_twos"])
        self.assertEqual(t["holds"], [(0.2, 0.6)])
        self.assertEqual(t["frames"], 24)
        still = refs.timing((0.0, 1.0), [(i / 24, 0.0) for i in range(24)], [], 24)
        self.assertEqual(still["speed"], "still")

    def test_a_still_shot_is_not_on_twos(self):
        still = refs.timing((0.0, 1.0), [(i / 24, 0.0) for i in range(24)], [(0.0, 1.0)], 24)
        self.assertEqual(still["speed"], "still")
        self.assertFalse(still["on_twos"])

    def test_panel_length(self):
        self.assertEqual(refs.panel_length(640, 200), 2.0)
        self.assertEqual(refs.panel_length(200, 640), 1.0)
        self.assertEqual(refs.panel_length(400, 400), 1.5)


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class RefsTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.d = Path(self.tmp.name)
        self.env = {"MAKE_CUTSCENE_WORK": str(self.d / "work")}
        patcher = mock.patch.object(refs, "FRAMES_PER_SHOT", 2)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_one_shot_per_cut(self):
        clip = media.synth(self.d / "in.mp4", [("testsrc", 1.5), ("color=c=red", 1.0), ("testsrc2", 1.2)])
        lines, path = refs.from_video("RefA", clip, env=self.env)
        b = beats.load(path)
        self.assertEqual([s["length"] for s in b["shots"]], [1.5, 1.0, 1.2])
        ref = path.parent / "ref"
        for name in ("clip.mp4", "shot_01.png", "shot_03.png", "contact.png", "timing.json", "timing.md"):
            self.assertTrue((ref / name).exists(), name)
        self.assertEqual(workspace.read_json(ref / "timing.json")["shots"][1]["speed"], "still")
        self.assertEqual(b["shots"][0]["ref"]["sheet"], "ref/shot_01.png")
        self.assertEqual([p for p in beats.validate(b) if "trigger" not in p], [])

    def test_one_long_take_is_split(self):
        clip = media.synth(self.d / "long.mp4", [("testsrc", 9.0)], size="160x90", fps=10)
        _, path = refs.from_video("RefLong", clip, env=self.env)
        self.assertEqual([s["length"] for s in beats.load(path)["shots"]], [4.5, 4.5])

    def test_over_thirty_seconds_says_how_to_trim(self):
        clip = media.synth(self.d / "huge.mp4", [("testsrc", 31.0)], size="160x90", fps=10)
        lines, path = refs.from_video("RefHuge", clip, env=self.env)
        text = "\n".join(lines)
        self.assertIn("at most 30 s", text)
        self.assertIn("--from", text)
        self.assertTrue(path.exists())

    def test_a_last_cut_under_a_fifth_of_a_second_joins_the_shot_before(self):
        # found with --to 16.96 on the AyanokojiFight clip: the last shot was a few frames long and its sheet crashed
        clip = media.synth(self.d / "tail.mp4", [("testsrc", 1.5), ("color=c=red", 0.12)], fps=24)
        with mock.patch.object(refs, "FRAMES_PER_SHOT", 6):
            lines, path = refs.from_video("RefTail", clip, env=self.env)
        b = beats.load(path)
        self.assertEqual(len(b["shots"]), 1)
        self.assertAlmostEqual(beats.length(b), media.probe(clip)["duration"], delta=1 / 24)
        self.assertIn("1 cut joined (1.50 s)", "\n".join(lines))
        self.assertTrue((path.parent / "ref" / "shot_01.png").exists())
        self.assertFalse((path.parent / "ref" / "shot_02.png").exists())

    def test_a_short_last_shot_keeps_its_sheet(self):
        # 0.3 s is a beat of its own, but its last samples fell past the clip's last frame
        clip = media.synth(self.d / "short.mp4", [("testsrc", 1.5), ("color=c=red", 0.3)], fps=24)
        with mock.patch.object(refs, "FRAMES_PER_SHOT", 6):
            lines, path = refs.from_video("RefShort", clip, env=self.env)
        self.assertEqual(len(beats.load(path)["shots"]), 2)
        for name in ("shot_02.png", "contact.png"):
            self.assertTrue((path.parent / "ref" / name).exists(), name)
        self.assertNotIn("joined", "\n".join(lines))

    def test_a_frame_past_the_end_is_a_media_error(self):
        clip = media.synth(self.d / "one.mp4", [("testsrc", 0.5)], fps=24)
        with self.assertRaises(media.MediaError) as e:
            media.cell(clip, self.d / "past.png", "past", t=5.0)
        self.assertIn("no picture at 5.00 s", str(e.exception))

    def test_vertical_phone_video(self):
        clip = media.synth(self.d / "tall.mp4", [("testsrc", 1.0), ("color=c=blue", 1.0)], size="180x320")
        _, path = refs.from_video("RefTall", clip, env=self.env)
        self.assertEqual(len(beats.load(path)["shots"]), 2)
        self.assertTrue((path.parent / "ref" / "contact.png").exists())

    def test_link_is_downloaded_then_used(self):
        clip = media.synth(self.d / "dl.mp4", [("testsrc", 1.0)])
        with mock.patch.object(media, "fetch", return_value=clip) as fetch:
            _, path = refs.from_video("RefLink", "https://youtu.be/abc", env=self.env)
        self.assertEqual(fetch.call_args[0][0], "https://youtu.be/abc")
        self.assertEqual(beats.load(path)["source"]["url"], "https://youtu.be/abc")

    def test_dead_link(self):
        with mock.patch.object(media, "fetch", side_effect=media.MediaError("ask the viewer for the video file")):
            with self.assertRaises(media.MediaError):
                refs.from_video("RefDead", "https://youtu.be/gone", env=self.env)

    def test_second_run_keeps_the_edited_sheet(self):
        clip = media.synth(self.d / "twice.mp4", [("testsrc", 1.0)])
        _, first = refs.from_video("RefTwice", clip, env=self.env)
        _, second = refs.from_video("RefTwice", clip, env=self.env)
        self.assertEqual((first.name, second.name), ("beats.json", "beats.draft.json"))

    def test_still_clip_does_not_make_the_look_anime(self):
        clip = media.synth(self.d / "still.mp4", [("color=c=red", 1.0), ("color=c=blue", 1.0)])
        _, path = refs.from_video("RefStill", clip, env=self.env)
        b = beats.load(path)
        self.assertEqual(b["look"], "live")
        self.assertFalse(any(s["ref"]["on_twos"] for s in b["shots"]))

    def test_missing_video_leaves_no_folder(self):
        with self.assertRaises(SystemExit):
            refs.from_video("RefNone", self.d / "nope.mp4", env=self.env)
        self.assertFalse((self.d / "work" / "cutscenes" / "RefNone").exists())

    def test_dead_link_leaves_no_folder(self):
        with mock.patch.object(media, "fetch", side_effect=media.MediaError("x")):
            with self.assertRaises(media.MediaError):
                refs.from_video("RefDead2", "https://youtu.be/gone", env=self.env)
        self.assertFalse((self.d / "work" / "cutscenes" / "RefDead2").exists())

    def test_panels(self):
        files = []
        for i, size in enumerate(("640x200", "200x640", "400x400")):
            p = self.d / f"p{i}.png"
            media.ffmpeg("-f", "lavfi", "-i", f"color=c=blue:s={size}:d=0.1", "-frames:v", "1", p)
            files.append(p)
        lines, path = refs.from_panels("RefPanels", [str(self.d / "p0.png"), str(self.d / "p1.png"), str(self.d / "p2.png")],
                                       env=self.env)
        b = beats.load(path)
        self.assertEqual([s["length"] for s in b["shots"]], [2.0, 1.0, 1.5])
        self.assertEqual(b["shots"][1]["ref"]["panel"], "ref/panel_02.png")
        self.assertTrue((path.parent / "ref" / "panels.png").exists())


if __name__ == "__main__":
    unittest.main()
