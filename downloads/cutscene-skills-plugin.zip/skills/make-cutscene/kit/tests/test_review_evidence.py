"""Byte-integrity regressions. Synthetic bytes are NOT playable-media evidence."""
import unittest
from tests import test_review
import review
import workspace
from unittest.mock import patch


class EvidenceTest(unittest.TestCase):
    def setUp(self):
        self.fixture = test_review.RoundTest('test_hard_gates')
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.root = self.fixture.root

    def assert_score_refused(self):
        with self.assertRaises(SystemExit):
            review.record(self.root, 1, [test_review.reply(2, 2, 2, 2, 2, 2)] * 3)
        self.assertFalse((self.root / 'review/results/round1/scores.json').exists())
        self.assertFalse((self.fixture.work / '.fwjelaa/ledger.jsonl').exists())

    def test_malformed_preview_stamps_block_generation_and_scoring_without_writes(self):
        self.fixture.build()
        # Include JSON scalars, containers, broken JSON and invalid UTF-8 on both rigs.
        for rig, filename in (("R15", "export.json"), ("R6", "export_R6.json")):
            path = self.root / "preview" / filename
            original = path.read_bytes()
            for raw in (b'[]', b'null', b'"stamp"', b'1', b'true', b'{}', b'{', b'\xff'):
                with self.subTest(rig=rig, raw=raw):
                    path.write_bytes(raw)
                    # Snapshot all evidence and outputs: refusal must not rewrite old packets either.
                    before = {p.relative_to(self.fixture.work): p.read_bytes()
                              for p in self.fixture.work.rglob('*') if p.is_file()}
                    for action in (self.fixture.build,
                                   lambda: review.record(self.root, 1, [test_review.reply(2, 2, 2, 2, 2, 2)] * 3)):
                        with self.subTest(action=action):
                            with self.assertRaises(SystemExit) as exc:
                                action()
                            message = str(exc.exception)
                            self.assertIn('regenerate', message)
                            self.assertIn(f'py kit/run.py preview Fixture_Scene --rig {rig}', message)
                            self.assertFalse((self.root / 'review/results/round1/scores.json').exists())
                            self.assertFalse((self.fixture.work / '.fwjelaa/ledger.jsonl').exists())
                            after = {p.relative_to(self.fixture.work): p.read_bytes()
                                     for p in self.fixture.work.rglob('*') if p.is_file()}
                            self.assertEqual(before, after)
                    path.write_bytes(original)

    def test_malformed_preview_stamp_diagnostics_fail_closed(self):
        for rig, filename in (("R15", "export.json"), ("R6", "export_R6.json")):
            path = self.root / 'preview' / filename
            original = path.read_bytes()
            for raw in (b'[]', b'null', b'"stamp"', b'1', b'true', b'{}', b'{', b'\xff'):
                with self.subTest(rig=rig, raw=raw):
                    path.write_bytes(raw)
                    try:
                        self.assertIn('G3 preview', review.stale(self.root))
                        self.assertFalse(review.module_changed(self.root))
                        self.assertFalse(review.costume_changed(self.root))
                        self.assertFalse(review.hard_gates(self.root)['G3 preview'])
                        self.assertTrue(review.preview_problems(self.root))
                    finally:
                        # Keep later subtests independent even when an assertion fails.
                        path.write_bytes(original)

    def test_legacy_packet_manifest_requires_regeneration(self):
        self.fixture.build()
        path = self.root / 'review/results/round1/packet.json'
        manifest = workspace.read_json(path)
        for field in ('version', 'takes', 'sheets', 'files'):
            with self.subTest(field=field):
                workspace.write_json(path, {k: v for k, v in manifest.items() if k != field})
                with self.assertRaisesRegex(SystemExit, 'regenerate'):
                    review.record(self.root, 1, [test_review.reply(2, 2, 2, 2, 2, 2)] * 3)
        self.assertFalse((self.fixture.work / '.fwjelaa/ledger.jsonl').exists())

    def test_legacy_sheet_hashes_require_regeneration(self):
        self.fixture.build()
        path = self.root / 'preview/sheets.json'
        state = workspace.read_json(path)
        del state['overview']['hashes']
        workspace.write_json(path, state)
        with self.assertRaisesRegex(SystemExit, 'regenerate'):
            self.fixture.build()
        self.assert_score_refused()

    def test_missing_source_files_block_both_entry_points(self):
        for name in ('Fixture_Scene.mp4', 'Fixture_Scene_R6.mp4', 'sheet.png', 'sheet_R6.png',
                     'side_by_side_1.png', 'side_by_side_R6_1.png'):
            with self.subTest(name=name):
                self.fixture.pass_everything()
                self.fixture.build()
                (self.root / 'preview' / name).unlink()
                with self.assertRaises(SystemExit):
                    self.fixture.build()
                self.assert_score_refused()

    def test_each_packet_file_is_bound_to_manifest(self):
        folders = self.fixture.build()
        for folder in folders:
            for path in folder.iterdir():
                with self.subTest(packet=folder.name, file=path.name):
                    original = path.read_bytes()
                    path.write_bytes(original + b'mutated')
                    self.assert_score_refused()
                    path.unlink()
                    self.assert_score_refused()
                    path.write_bytes(original)

    def test_corrupted_copy_is_rejected_before_manifest_publication(self):
        copy = review.shutil.copyfile

        def corrupt(src, dst):
            result = copy(src, dst)
            if dst.name == 'preview_R6.mp4':
                dst.write_bytes(b'corrupted copy')
            return result

        with patch.object(review.shutil, 'copyfile', side_effect=corrupt):
            with self.assertRaisesRegex(SystemExit, 'stamped source'):
                self.fixture.build()
        self.assertFalse((self.root / 'review/results/round1/packet.json').exists())

    def test_unlisted_packet_file_is_refused(self):
        folder = self.fixture.build()[0]
        (folder / 'unrecorded.txt').write_text('not blind evidence', encoding='utf-8')
        self.assert_score_refused()

    def test_malformed_sheet_records_fail_with_regeneration_guidance(self):
        self.fixture.build()
        path = self.root / 'preview/sheets.json'
        original = workspace.read_json(path)
        import copy
        for value in ([], {'files': ['other.png'], 'hashes': {'other.png': 'a' * 64}},
                      {'files': 'sheet.png'}, {'files': [None]}, {'files': ['sheet.png'], 'preview': []}):
            with self.subTest(value=value):
                state = copy.deepcopy(original)
                state['overview'] = value
                workspace.write_json(path, state)
                with self.assertRaisesRegex(SystemExit, 'regenerate|preview'):
                    self.fixture.build()
                self.assert_score_refused()

    def test_sheet_manifest_cannot_substitute_unrelated_files(self):
        self.fixture.build()
        path = self.root / 'preview/sheets.json'
        state = workspace.read_json(path)
        state['overview']['files'] = ['side_by_side_1.png']
        state['overview']['hashes'] = review.evidence.hashes(self.root / 'preview', ['side_by_side_1.png'])
        workspace.write_json(path, state)
        with self.assertRaisesRegex(SystemExit, 'regenerate'):
            self.fixture.build()
        self.assert_score_refused()

    def test_packet_contains_both_continuous_clips(self):
        for folder in self.fixture.build():
            for rig, source in [('R15', 'Fixture_Scene.mp4'), ('R6', 'Fixture_Scene_R6.mp4')]:
                self.assertEqual((folder / f'preview_{rig}.mp4').read_bytes(),
                                 (self.root / 'preview' / source).read_bytes())

    def test_packet_mutation_blocks_score(self):
        folders = self.fixture.build()
        (folders[0] / 'README.md').write_text('changed instructions', encoding='utf-8')
        with self.assertRaises(SystemExit):
            review.record(self.root, 1, [test_review.reply(2, 2, 2, 2, 2, 2)] * 3)
        self.assertFalse((self.fixture.work / '.fwjelaa/ledger.jsonl').exists())

    def test_restamped_take_and_sheets_still_invalidate_old_packet(self):
        self.fixture.build()
        (self.root / 'preview/Fixture_Scene_R6.mp4').write_bytes(b'new synthetic take')
        review.stamp_preview(self.root, 'R6')
        review.stamp_sheet(self.root, 'overview_R6', ['sheet_R6.png'])
        review.stamp_sheet(self.root, 'side_by_side_R6', ['side_by_side_R6_1.png'])
        with self.assertRaises(SystemExit):
            review.record(self.root, 1, [test_review.reply(2, 2, 2, 2, 2, 2)] * 3)

    def test_mutated_sheet_bytes_block_packet_and_score(self):
        for name in ('sheet.png', 'sheet_R6.png', 'side_by_side_1.png', 'side_by_side_R6_1.png'):
            with self.subTest(name=name):
                self.fixture.pass_everything()
                self.fixture.build()
                (self.root / 'preview' / name).write_bytes(b'mutated synthetic image')
                with self.assertRaises(SystemExit):
                    self.fixture.build()
                with self.assertRaises(SystemExit):
                    review.record(self.root, 1, [test_review.reply(2, 2, 2, 2, 2, 2)] * 3)
                self.assertFalse((self.fixture.work / '.fwjelaa/ledger.jsonl').exists())

    def test_changed_preview_bytes_block_packet_and_score_before_writes(self):
        self.fixture.build()
        video = self.root / 'preview/Fixture_Scene_R6.mp4'
        video.write_bytes(b'changed synthetic bytes')
        with self.assertRaisesRegex(SystemExit, 'preview|take'):
            self.fixture.build()
        with self.assertRaisesRegex(SystemExit, 'preview|take'):
            review.record(self.root, 1, [test_review.reply(2, 2, 2, 2, 2, 2)] * 3)
        self.assertFalse((self.root / 'review/results/round1/scores.json').exists())
        self.assertFalse((self.fixture.work / '.fwjelaa/ledger.jsonl').exists())
