"""Tests for `run.py check` (kit/setup_check.py). Method by fwjelaa (FWJ STUDIOS)."""
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import setup_check  # noqa: E402


class SetupCheckTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = Path(self.tmp.name)
        self.pack = root / "pack"
        self.pack.mkdir()
        (self.pack / "config.json").write_text(json.dumps({"user_id": "1", "work_dir": str(root / "work")}), encoding="utf-8")
        self.anim = root / "make-anim"
        (self.anim / "kit").mkdir(parents=True)
        (self.anim / "kit" / "animkit.py").write_text("", encoding="utf-8")
        self.key = root / "key.txt"

    def check(self, which=lambda exe: f"C:/bin/{exe}.exe", version=(3, 14, 0), key="SECRET-KEY-9"):
        if key:
            self.key.write_text(key, encoding="utf-8")
        return setup_check.run(which=which, version=version, env={}, key_files=[self.key], pack=self.pack,
                               make_anim=self.anim)

    def test_ready_pc(self):
        ok, lines = self.check()
        text = "\n".join(lines)
        self.assertTrue(ok, text)
        self.assertIn("OK   Python 3.14", text)
        self.assertIn("OK   ffmpeg", text)
        self.assertNotIn("FIX", text)
        self.assertIn("get_addon_status", text)
        self.assertIn("list_roblox_studios", text)

    def test_missing_ffmpeg_is_a_fix(self):
        ok, lines = self.check(which=lambda exe: None if exe in ("ffmpeg", "ffprobe") else "x")
        self.assertFalse(ok)
        self.assertIn("FIX  ffmpeg not found: install FFmpeg", "\n".join(lines))

    def test_missing_ytdlp_is_only_a_warning(self):
        ok, lines = self.check(which=lambda exe: None if exe == "yt-dlp" else "x")
        self.assertTrue(ok)
        self.assertIn("WARN yt-dlp not found", "\n".join(lines))

    def test_old_python(self):
        ok, lines = self.check(version=(3, 10, 4))
        self.assertFalse(ok)
        self.assertIn("too old", "\n".join(lines))

    def test_no_key_warns_and_explains_preview_only(self):
        ok, lines = self.check(key=None)
        text = "\n".join(lines)
        self.assertTrue(ok)
        self.assertIn("no Open Cloud key", text)
        self.assertIn("preview in Studio only", text)

    def test_the_key_is_never_shown(self):
        ok, lines = self.check(key="SECRET-KEY-9")
        self.assertNotIn("SECRET-KEY-9", "\n".join(lines))

    def test_whitespace_key_counts_as_missing(self):
        ok, lines = self.check(key="  \n")
        text = "\n".join(lines)
        self.assertNotIn("Open Cloud key found", text)
        self.assertIn("no Open Cloud key", text)

    def test_check_does_not_create_the_working_folder(self):
        work = Path(self.tmp.name) / "work"
        ok, lines = self.check()
        self.assertFalse(work.exists())
        self.assertIn(f"working folder: {work} (will be created)", "\n".join(lines))

    def test_missing_make_anim_is_a_fix(self):
        (self.anim / "kit" / "animkit.py").unlink()
        ok, lines = self.check()
        self.assertFalse(ok)
        self.assertIn("make-anim not found", "\n".join(lines))


if __name__ == "__main__":
    unittest.main()
