"""Tests for kit/r6.py: each R6 limb keeps its R15 upper segment's world rotation. Method by fwjelaa (FWJ STUDIOS)."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import clip  # noqa: E402
import r6  # noqa: E402

POSE = {"LowerTorso": (0, 20, 0, 0, -0.3, -0.5), "UpperTorso": (-10, 40, 5), "RightUpperArm": (90, 0, 10),
        "RightLowerArm": (60, 0, 0), "LeftUpperArm": (20, -10, -15), "LeftUpperLeg": (30, 0, 0),
        "RightUpperLeg": (-25, 5, 3), "Head": (10, -20, 0)}


def rot(v):
    return clip.rot_xyz(*v[:3])


def chain(*vs):
    m = clip.rot_xyz()
    for v in vs:
        m = clip.matmul(m, rot(v))
    return m


class R6Test(unittest.TestCase):
    def same(self, a, b):
        for i in range(3):
            for j in range(3):
                self.assertAlmostEqual(a[i][j], b[i][j], places=5)

    def test_limbs_keep_their_world_rotation(self):
        d = r6.derive(POSE)
        lower, upper = POSE["LowerTorso"], POSE["UpperTorso"]
        self.same(chain(d["Torso"], d["Right Arm"]), chain(lower, upper, POSE["RightUpperArm"]))
        self.same(chain(d["Torso"], d["Left Arm"]), chain(lower, upper, POSE["LeftUpperArm"]))
        self.same(chain(d["Torso"], d["Head"]), chain(lower, upper, POSE["Head"]))
        self.same(chain(d["Torso"], d["Left Leg"]), chain(lower, POSE["LeftUpperLeg"]))
        self.same(chain(d["Torso"], d["Right Leg"]), chain(lower, POSE["RightUpperLeg"]))

    def test_torso_takes_half_the_waist(self):
        d = r6.derive({"LowerTorso": (0, 20, 0), "UpperTorso": (0, 40, 0)})
        self.assertAlmostEqual(d["Torso"][1], 40.0, places=4)
        self.assertEqual(d["Torso"][3:], (0.0, 0.0, 0.0))

    def test_root_translation_is_kept(self):
        self.assertEqual(r6.derive(POSE)["Torso"][3:], (0.0, -0.3, -0.5))

    def test_rest_pose(self):
        d = r6.derive({})
        self.assertEqual(sorted(d), ["Head", "Left Arm", "Left Leg", "Right Arm", "Right Leg", "Torso"])
        self.assertTrue(all(abs(v) < 1e-9 for vals in d.values() for v in vals))

    def test_bends(self):
        self.assertEqual(r6.bends(POSE), [("RightLowerArm", 60.0), ("UpperTorso", 41.0)])
        self.assertEqual(r6.bends({"RightLowerArm": (20, 0, 0)}), [])

    def test_angles_of_inverts_rot_xyz(self):
        for v in ((-35, 20, 75), (10, -60, 170), (0, 0, 0)):
            got = r6.angles_of(clip.rot_xyz(*v))
            for a, b in zip(got, v):
                self.assertAlmostEqual(a, b, places=3)
        gimbal = r6.angles_of(clip.rot_xyz(10, 90, 30))
        self.same(clip.rot_xyz(*gimbal), clip.rot_xyz(10, 90, 30))


if __name__ == "__main__":
    unittest.main()
