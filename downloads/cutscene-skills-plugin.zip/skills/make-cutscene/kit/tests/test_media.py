"""Tests for kit/media.py on synthetic clips made by FFmpeg (no third-party media). Method by fwjelaa (FWJ STUDIOS)."""
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import media  # noqa: E402

HAVE_FFMPEG = shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class MediaTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.d = Path(cls.tmp.name)
        cls.cuts_clip = media.synth(cls.d / "cuts.mp4", [("testsrc", 1.5), ("color=c=red", 1.0), ("testsrc2", 1.2)])

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_probe(self):
        info = media.probe(self.cuts_clip)
        self.assertEqual((info["width"], info["height"]), (320, 180))
        self.assertAlmostEqual(info["fps"], 30, delta=0.01)
        self.assertAlmostEqual(info["duration"], 3.7, delta=0.1)

    def test_vertical_clip(self):
        clip = media.synth(self.d / "tall.mp4", [("testsrc", 1.0)], size="180x320")
        self.assertEqual((media.probe(clip)["width"], media.probe(clip)["height"]), (180, 320))

    def test_cuts_are_found_at_the_hard_cuts(self):
        found = media.cuts(self.cuts_clip)
        self.assertEqual(len(found), 2, found)
        self.assertAlmostEqual(found[0], 1.5, delta=0.05)
        self.assertAlmostEqual(found[1], 2.5, delta=0.05)

    def test_held_frames_show_as_zero_scores(self):
        twos = media.synth(self.d / "twos.mp4", [("testsrc", 1.0, 12)], fps=24)
        scores = media.frame_scores(twos)
        self.assertGreaterEqual(len(scores), 23)
        held = sum(1 for _, s in scores[1:] if s < media.DUP_SCORE) / (len(scores) - 1)
        self.assertGreater(held, 0.35)
        self.assertLess(held, 0.65)

    def test_freezes(self):
        clip = media.synth(self.d / "freeze.mp4", [("color=c=blue", 1.0), ("testsrc", 1.0)])
        found = media.freezes(clip)
        self.assertEqual(len(found), 1, found)
        self.assertAlmostEqual(found[0][0], 0.0, delta=0.05)
        self.assertAlmostEqual(found[0][1], 1.0, delta=0.1)

    def test_trim(self):
        out = media.trim(self.cuts_clip, self.d / "trim.mp4", 1.0, 2.0)
        self.assertAlmostEqual(media.probe(out)["duration"], 1.0, delta=0.1)

    def test_grab_cell_card_and_sheet(self):
        g = media.grab(self.cuts_clip, 2.0, self.d / "g.png", width=160)
        self.assertEqual(media.probe(g)["width"], 160)
        cells = [media.cell(self.cuts_clip, self.d / f"c{i}.png", f'shot {i}: "Halt!" 100% {i}:00', t=0.5 * i)
                 for i in range(4)]
        cells.append(media.card(media.wrap('Guard: "Turn back now, or I make you." ' * 2), self.d / "card.png"))
        for c in cells:
            info = media.probe(c)
            self.assertEqual((info["width"], info["height"]), (320, 180))
        self.assertFalse(list(self.d.glob("*_label.txt")) + list(self.d.glob("*_card.txt")), "temp text files removed")
        sheet = media.sheet(cells, self.d / "sheet.png", cols=4)
        info = media.probe(sheet)
        self.assertEqual((info["width"], info["height"]), (4 * 320 + 3 * 4 + 2 * 4, 2 * 180 + 4 + 2 * 4))

    def test_ff_path_escapes_the_drive_colon(self):
        self.assertEqual(media.ff_path("C:/a b/c.txt"), "'C\\:/a b/c.txt'")


class FetchTest(unittest.TestCase):
    def test_fetch_returns_the_downloaded_file(self):
        with tempfile.TemporaryDirectory() as d:
            def fake(cmd, **kw):
                (Path(d) / "source.mp4").write_bytes(b"x")
                return subprocess.CompletedProcess(cmd, 0, "", "")
            self.assertEqual(media.fetch("https://youtu.be/x", d, run=fake), Path(d) / "source.mp4")

    def test_dead_link_asks_for_the_file(self):
        with tempfile.TemporaryDirectory() as d:
            def fake(cmd, **kw):
                return subprocess.CompletedProcess(cmd, 1, "", "ERROR: Private video")
            with self.assertRaises(media.MediaError) as e:
                media.fetch("https://youtu.be/x", d, run=fake)
            self.assertIn("ask the viewer for the video file", str(e.exception))


if __name__ == "__main__":
    unittest.main()
