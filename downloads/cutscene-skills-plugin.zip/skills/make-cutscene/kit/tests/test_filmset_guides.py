"""Blender-free checks on filmset.py's VFX guides: the 63-byte object-name limit (guide names carry no preset name) and
the reload list. filmset imports bpy, so the source is read, not imported. Method by fwjelaa (FWJ STUDIOS)."""
import ast
import unittest
from pathlib import Path

SRC = (Path(__file__).resolve().parents[1] / "filmset.py").read_text(encoding="utf-8")
TREE = ast.parse(SRC)


def top_value(name):
    for node in TREE.body:
        if isinstance(node, ast.Assign) and any(getattr(t, "id", None) == name for t in node.targets):
            return ast.literal_eval(node.value)
    raise AssertionError(f"{name} not defined")


def guide_name():
    fn = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "guide_name")
    ns = {}
    exec(compile(ast.Module([fn], []), "filmset.py", "exec"), ns)
    return ns["guide_name"]


class Guides(unittest.TestCase):
    def test_names_are_short_and_distinct(self):
        g = guide_name()
        cid = "A" * 40
        names = {g(cid, n, k) for n in range(1, 13) for k in ("c", "a")}
        self.assertEqual(len(names), 24)
        self.assertTrue(all(len(n.encode()) <= 63 for n in names))
        self.assertEqual(g("Awakening", 3, "c"), "Awakening_VFX3c")
        self.assertEqual(g("Awakening", 3, "a"), "Awakening_VFX3a")

    def test_reload_list_has_the_new_modules(self):
        mine = top_value("MINE")
        self.assertIn("vfxlib", mine)
        self.assertIn("cues", mine)
        self.assertLess(mine.index("vfxlib"), mine.index("schema"))
        self.assertLess(mine.index("cues"), mine.index("schema"))


if __name__ == "__main__":
    unittest.main()
