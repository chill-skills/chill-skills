"""The manga screen effects' maths in CutsceneKit.Screen (roblox/CutsceneKit/Screen.luau), run outside Studio with
luau.exe: jitter on twos, flipbook cells, the focus lines' four quadrants, the word's punch and stroke, the burst's
scale-in, the backdrop card's depth and size, and the numbers the kit checks share with it. Studio runs the instance
side (roblox/tests/Screen.test.luau). Method by fwjelaa (FWJ STUDIOS)."""
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import clip  # noqa: E402
import cues  # noqa: E402
import luaurun  # noqa: E402
import paths  # noqa: E402
import vfxlib  # noqa: E402

STUBS = """
Color3 = { new = function(r, g, b) return { r, g, b } end, fromRGB = function(r, g, b) return { r, g, b } end }
local Vfx = { EASE = { out = function(x) return 1 - (1 - x) * (1 - x) end, ["in"] = function(x) return x * x end } }
local script = { Parent = { Vfx = Vfx, VfxPresets = { Manga = %s } } }
local function require(m) return m end
local Screen = (function() %s end)()
"""


def run(body):
    src = (paths.ROBLOX / "CutsceneKit" / "Screen.luau").read_text(encoding="utf-8")
    code = STUBS % (clip.luau_value(vfxlib.manga()), src) + body
    return json.loads(luaurun.run(code).strip().splitlines()[-1])


def as_json(expr):
    """Luau that prints expr (numbers, strings, booleans and flat or nested arrays/tables) as JSON."""
    return """
local function enc(v)
  if type(v) == "table" then
    if #v > 0 or next(v) == nil then
      local parts = {}
      for _, x in ipairs(v) do table.insert(parts, enc(x)) end
      return "[" .. table.concat(parts, ",") .. "]"
    end
    local keys = {}
    for k in pairs(v) do table.insert(keys, k) end
    table.sort(keys)
    local parts = {}
    for _, k in ipairs(keys) do table.insert(parts, string.format("%q", k) .. ":" .. enc(v[k])) end
    return "{" .. table.concat(parts, ",") .. "}"
  elseif type(v) == "string" then
    return string.format("%q", v)
  elseif type(v) == "boolean" then
    return tostring(v)
  end
  return string.format("%.6f", v)
end
print(enc(""" + expr + "))\n"


@unittest.skipUnless(luaurun.find(), "luau is not installed")
class ScreenMathTest(unittest.TestCase):
    def test_the_kit_checks_and_the_runtime_share_their_numbers(self):
        got = run(as_json("{ Screen.MAX_LAYERS, Screen.BURST_FLASH, Screen.BURST_SIZE, Screen.LIFE, "
                          "Screen.WORD_STROKE_MAX, Screen.JITTER }"))
        self.assertEqual(got[0], cues.SCREEN_LAYERS)
        self.assertAlmostEqual(got[1], cues.BURST_FLASH)
        self.assertAlmostEqual(got[2], cues.BURST_SIZE)
        self.assertEqual({k: round(v, 3) for k, v in got[3].items()}, cues.SCREEN_LIFE)
        self.assertAlmostEqual(got[4], vfxlib.STROKE_MAX)
        self.assertAlmostEqual(got[5], 1 / 12, places=5, msg="manga jitter runs on twos (12 fps)")

    def test_jitter_is_on_twos_and_never_repeats_a_cell(self):
        got = run(as_json("(function() local t = {} for i = 0, 24 do table.insert(t, Screen.tick(i / 60)) end "
                          "local p = {} for k = 0, 40 do table.insert(p, Screen.pick(k, 1, 4)) end "
                          "local q = {} for k = 0, 40 do table.insert(q, Screen.pick(k, 2, 4)) end return { t, p, q } end)()"))
        ticks, picks, other = got
        self.assertEqual(ticks[:6], [0, 0, 0, 0, 0, 1], "a new frame every 1/12 s (5 frames at 60 fps)")
        self.assertTrue(all(0 <= p < 4 for p in picks))
        self.assertTrue(all(a != b for a, b in zip(picks, picks[1:])), "a jitter frame always changes the cell")
        self.assertEqual(len(set(picks)), 4, "every cell gets used")
        self.assertNotEqual(picks, other, "each quadrant jitters on its own")

    def test_flipbook_cells_are_image_pixels(self):
        got = run(as_json("{ {Screen.cell(Screen.MANGA.lines, 0)}, {Screen.cell(Screen.MANGA.lines, 3)}, "
                          "{Screen.cell(Screen.MANGA.burst2, 2)}, {Screen.cell(Screen.MANGA.plum, 0)} }"))
        self.assertEqual(got[0], [0, 0, 512])
        self.assertEqual(got[1], [512, 512, 512])
        self.assertEqual(got[2], [0, 512, 512])
        self.assertEqual(got[3], [0, 0, 1024])

    def test_four_quadrants_cover_the_whole_screen_from_any_focus(self):
        for fx, fy in ((960, 540), (300, 200), (1900, 1060), (0, 540)):
            side, quads = run(as_json(f"{{ Screen.quadrants({fx}, {fy}, 1920, 1080) }}"))
            self.assertEqual(len(quads), 4)
            self.assertEqual(sorted(q[2] for q in quads), [0, 90, 180, 270])
            for x, y in ((0, 0), (1920, 0), (0, 1080), (1920, 1080), (fx + 1, fy - 1)):
                covered = False
                for cx, cy, _ in quads:
                    if abs(x - cx) <= side / 2 + 1e-3 and abs(y - cy) <= side / 2 + 1e-3:
                        covered = True
                self.assertTrue(covered, (fx, fy, x, y))
            # each label's focus corner sits on the focus: its centre is half a side away on both axes
            for cx, cy, _ in quads:
                self.assertAlmostEqual(abs(cx - fx), side / 2, places=3)
                self.assertAlmostEqual(abs(cy - fy), side / 2, places=3)

    def test_a_word_punches_in_holds_and_fades_and_its_stroke_is_capped(self):
        got = run(as_json("{ Screen.punch(0), Screen.punch(Screen.PUNCH_TIME / 2), Screen.punch(Screen.PUNCH_TIME), "
                          "Screen.punch(0, true), Screen.fadeOut(0.5, 1, 0.15), Screen.fadeOut(0.925, 1, 0.15), "
                          "Screen.fadeOut(1, 1, 0.15), Screen.strokePx(0.2), Screen.strokePx(0.05), Screen.strokePx(0), "
                          "Screen.PUNCH_TIME }"))
        self.assertAlmostEqual(got[0], 1.6)
        self.assertTrue(1 < got[1] < 1.6)
        self.assertAlmostEqual(got[2], 1)
        self.assertAlmostEqual(got[3], 1, msg="reduced motion: no punch")
        self.assertAlmostEqual(got[4], 0)
        self.assertAlmostEqual(got[5], 0.5)
        self.assertAlmostEqual(got[6], 1)
        self.assertAlmostEqual(got[7], 7, msg="7 % of the 100 px text, never more")
        self.assertAlmostEqual(got[8], 5)
        self.assertAlmostEqual(got[9], 0)
        self.assertLessEqual(got[10], 0.06, "1.6 -> 1.0 in about 3 frames")

    def test_a_burst_scales_in_over_two_frames(self):
        got = run(as_json("{ Screen.burstScale(0), Screen.burstScale(Screen.BURST_IN), Screen.burstScale(0.3), "
                          "Screen.BURST_IN }"))
        self.assertLess(got[0], 0.5)
        self.assertAlmostEqual(got[1], 1)
        self.assertAlmostEqual(got[2], 1)
        self.assertLessEqual(got[3], 0.04)

    def test_the_backdrop_card_stays_behind_every_cast_member_and_fills_the_view(self):
        got = run(as_json("{ Screen.cardDepth(nil, {}), Screen.cardDepth(nil, {4, 9.5}), Screen.cardDepth(40, {4, 9.5}), "
                          "Screen.cardDepth(5, {12}), {Screen.cardSize(10, 70, 16 / 9)} }"))
        self.assertEqual(got[0], 30.0, "no cast in view: the default distance")
        self.assertAlmostEqual(got[1], 9.5 + 3, msg="just behind the farthest cast member")
        self.assertAlmostEqual(got[2], 40, msg="further when asked")
        self.assertAlmostEqual(got[3], 15, msg="never in front of a cast member, whatever dist says")
        w, h = got[4]
        import math
        self.assertGreater(h, 2 * 10 * math.tan(math.radians(35)))
        self.assertAlmostEqual(w / h, 16 / 9, places=4)

    def test_focus_lines_hold_then_fade(self):
        got = run(as_json("{ Screen.linesAlpha(0, 0.6, 1), Screen.linesAlpha(0.3, 0.6, 1), Screen.linesAlpha(0.59, 0.6, 1), "
                          "Screen.linesAlpha(0.7, 0.6, 1), Screen.linesAlpha(0.1, 0.6, 0.5) }"))
        self.assertAlmostEqual(got[0], 1)
        self.assertAlmostEqual(got[1], 1)
        self.assertLess(got[2], 0.2)
        self.assertEqual(got[3], 0)
        self.assertAlmostEqual(got[4], 0.5)


if __name__ == "__main__":
    unittest.main()
