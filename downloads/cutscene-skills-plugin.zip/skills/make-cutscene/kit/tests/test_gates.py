"""Tests for kit/gates.py, the kit checks. Method by fwjelaa (FWJ STUDIOS)."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import camtrack  # noqa: E402
import fixture  # noqa: E402
import gates  # noqa: E402
import workspace  # noqa: E402

HEAD = [0, 4.6, -8]


def framing(cams, fovs=None, heads=None, cuts=()):
    return {"fps": 60, "frames": len(cams) - 1, "camera": cams, "fov": fovs or [50.0] * len(cams), "cuts": list(cuts),
            "heads": heads or {}}


def shot(n, first, end, subject="npc1", offscreen=False):
    return {"n": n, "type": "HERO", "subject": subject, "first_frame": first, "end_frame": end, "offscreen": offscreen}


def still(eye, look=HEAD, n=60):
    return [camtrack.look_cf(eye, look)] * n


class GeometryTest(unittest.TestCase):
    def test_camera_inside_or_too_near_a_stand_in(self):
        bx = gates.boxes({"boxes": [[0, 5, 10, 4, 4, 4, 0, 0, 0, "fff"]]})
        inside = gates.camera_clear(framing(still((0, 5, 10), (0, 5, 0))), bx, [])
        self.assertTrue(any("camera inside" in i for i in inside), inside)
        near = gates.camera_clear(framing(still((0, 5, 12.2), (0, 5, 0))), bx, [])
        self.assertEqual(len(near), 1)
        self.assertEqual(gates.camera_clear(framing(still((0, 5, 13), (0, 5, 0))), bx, []), [])

    def test_a_wall_hiding_the_subject(self):
        f = framing(still((0, 5, 10)), heads={"npc1": [HEAD] * 60})
        wall = gates.boxes({"boxes": [[0, 5, 0, 6, 10, 1, 0, 0, 0, "fff"]]})
        found = gates.camera_clear(f, wall, [shot(1, 0, 60)])
        self.assertTrue(any("hides npc1's head" in i for i in found), found)
        self.assertEqual(gates.camera_clear(f, [], [shot(1, 0, 60)]), [])

    def test_a_fully_transparent_stand_in_is_ignored(self):
        glass = [0, 5, 10, 4, 4, 4, 0, 0, 0, "fff", 1.0]
        self.assertEqual(gates.boxes({"boxes": [glass]}), [])
        self.assertEqual(len(gates.boxes({"boxes": [glass[:10] + [0.5], glass[:10]]})), 2)
        self.assertEqual(gates.camera_clear(framing(still((0, 5, 10), (0, 5, 0))), gates.boxes({"boxes": [glass]}), []), [])
        wall = [0, 5, 0, 6, 10, 1, 0, 0, 0, "fff", 1.0]
        f = framing(still((0, 5, 10)), heads={"npc1": [HEAD] * 60})
        self.assertEqual(gates.camera_clear(f, gates.boxes({"boxes": [wall]}), [shot(1, 0, 60)]), [])
        seen = gates.boxes({"boxes": [wall[:10] + [0.5]]})
        self.assertTrue(any("hides npc1's head" in i for i in gates.camera_clear(f, seen, [shot(1, 0, 60)])))

    def test_centre_safe(self):
        f = framing(still((0, 4.6, 10)), heads={"npc1": [HEAD] * 60})
        self.assertEqual(gates.centre_safe(f, [shot(1, 0, 60)]), [])
        wide = framing(still((0, 4.6, 10)), heads={"npc1": [[16, 4.6, -8]] * 60})
        found = gates.centre_safe(wide, [shot(1, 0, 60)])
        self.assertTrue(any("middle 60 %" in i for i in found), found)
        self.assertTrue(any("leaves a 4:3 screen" in i for i in found), found)
        behind = framing(still((0, 4.6, 10)), heads={"npc1": [[0, 4.6, 20]] * 60})
        self.assertTrue(gates.centre_safe(behind, [shot(1, 0, 60)]))
        self.assertEqual(gates.centre_safe(wide, [shot(1, 0, 60, offscreen=True)]), [])

    def test_projection(self):
        cf = camtrack.look_cf((0, 5, 10), (0, 5, 0))
        self.assertEqual(gates.project(cf, 50, (0, 5, 0), 16 / 9), (0.0, 0.0))
        self.assertIsNone(gates.project(cf, 50, (0, 5, 20), 16 / 9))


class TimelineTest(unittest.TestCase):
    def test_jumps(self):
        cams = still((0, 5, 10), n=30) + still((5, 5, 10), n=30)
        self.assertTrue(any("jumps without a Cut" in i for i in gates.jumps(framing(cams), [])))
        self.assertEqual(gates.jumps(framing(cams), [30]), [])
        flat = gates.jumps(framing(still((0, 5, 10))), [20])
        self.assertTrue(any("doesn't change the shot" in i for i in flat), flat)

    def test_sync(self):
        data = {"Length": 6, "Fov": [[0, 50], [3, 50], [3, 55], [6, 55]], "Cues": {"Bar": {}},
                "Markers": [[0, "Letterbox", "in"], [1, "VFX", "Dust"], [1.5, "SFX", "Hit"], [2, "Foo", ""], [2.5, "Cut", ""],
                            [3.5, "Shake", "2"]]}
        found = "\n".join(gates.sync(data))
        for want in ("no SFX handler yet", "Foo at 2 s has no cue", "cue Bar has no marker", "Shake at 3.5 s must be 0-1",
                     "exactly one End", "Cut at 2.5 s has no FOV cut", "FOV cuts at 3 s without a Cut marker"):
            self.assertIn(want, found)

    def test_flash_rate(self):
        self.assertTrue(gates.flash_rate([[1.0, "Flash", ""], [1.4, "Impact", ""], [1.8, "Flash", ""]]))
        self.assertEqual(gates.flash_rate([[1.0, "Flash", ""], [1.4, "Flash", ""], [2.1, "Flash", ""]]), [])

    def test_budgets(self):
        data = {"Cues": {"VFX:Burst": {"budget": {"particles": 2000, "lights": 3}}},
                "Markers": [[1.0, "VFX", "Burst"], [1.5, "VFX", "Burst"]]}
        found = "\n".join(gates.budgets(data))
        self.assertIn("3200", found)
        self.assertIn("3 lights", found)

    def test_anim_issues(self):
        scene = {"issues": {"A_npc1_R15": ["RightFoot skates while planted"]},
                 "r6": {"player": {"override": False, "flags": ["frame 40 (0.67 s): RightLowerArm bent 70 deg"]}}}
        found = gates.anim_issues(scene)
        self.assertEqual(len(found), 2)
        scene["r6"]["player"]["override"] = True
        self.assertEqual(len(gates.anim_issues(scene)), 1)

    def test_runtime_version_comes_from_the_runtime_index(self):
        import json
        import paths
        index = json.loads((paths.PACK / "roblox" / "CutsceneKit" / "_index.json").read_text(encoding="utf-8"))
        self.assertEqual(gates.RUNTIME, index["version"])


class RunTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = fixture.write_scene(env={"MAKE_CUTSCENE_WORK": self.tmp.name})
        cams = still((10, 6, 6), (0, 4, -4), 150) + still((-2, 5.5, -11), (0, 4.5, 0), 211)
        heads = {"npc1": [HEAD] * 361, "player": [[0, 4.6, 0]] * 361}
        workspace.write_json(self.root / "export" / "framing.json",
                             framing(cams, [50.0] * 150 + [55.0] * 211, heads, [150]))

    def test_a_clean_scene_passes(self):
        issues, lines = gates.run(self.root)
        self.assertEqual(issues, [], lines)
        self.assertTrue(workspace.read_json(self.root / "export" / "gates.json")["ok"])
        self.assertEqual(lines[-1], "KIT CHECKS: all clear")

    def test_a_wall_in_the_way_fails(self):
        m = workspace.read_json(self.root / "map.json")
        m["boxes"] = [[-1, 5, -5, 6, 10, 1, 0, 0, 0, "fff"]]
        workspace.write_json(self.root / "map.json", m)
        issues, _ = gates.run(self.root)
        self.assertTrue(any("hides player's head" in i for i in issues), issues)
        self.assertFalse(workspace.read_json(self.root / "export" / "gates.json")["ok"])

    def test_expect(self):
        self.assertEqual(gates.expect(self.root, 4.0), "rel=(-2.00, 5.50, -11.00) fov=55.0")


def terrain_map(ridge=0.0, n=3, step=6):
    """A flat field at height 0 with a ridge of the given height along the row j=0 (a wall of hill across z=0)."""
    cells = [[i, j, ridge if j == 0 else 0.0] for i in range(-n, n + 1) for j in range(-n, n + 1)]
    return {"boxes": [], "terrain": {"step": step, "n": n, "cells": cells}}


class TerrainTest(unittest.TestCase):
    def test_camera_inside_or_near_the_ground(self):
        t = gates.terrain(terrain_map())
        under = gates.camera_clear(framing(still((0, -1, 0), (0, 4, -8))), [], [], t)
        self.assertTrue(any("camera inside" in i and "terrain" in i for i in under), under)
        near = gates.camera_clear(framing(still((0, 0.2, 0), (0, 4, -8))), [], [], t)
        self.assertEqual(len(near), 1)
        self.assertEqual(gates.camera_clear(framing(still((0, 5, 0), (0, 4, -8))), [], [], t), [])

    def test_off_the_terrain_nothing_is_checked(self):
        t = gates.terrain(terrain_map())
        self.assertEqual(gates.camera_clear(framing(still((100, -50, 100), (0, 4, -8))), [], [], t), [])

    def test_a_hill_hiding_the_subject(self):
        f = framing(still((0, 5, 12)), heads={"npc1": [[0, 4.6, -12]] * 60})
        found = gates.camera_clear(f, [], [shot(1, 0, 60)], gates.terrain(terrain_map(ridge=30)))
        self.assertTrue(any("hides npc1's head" in i for i in found), found)
        self.assertEqual(gates.camera_clear(f, [], [shot(1, 0, 60)], gates.terrain(terrain_map())), [])

    def test_height_follows_the_slope_between_samples(self):
        t = gates.terrain({"terrain": {"step": 6, "n": 1, "cells": [[i, j, float(i)] for i in (-1, 0, 1) for j in (-1, 0, 1)]}})
        self.assertAlmostEqual(gates.terrain_height(t, 3, 0), 0.5)
        self.assertIsNone(gates.terrain_height(t, 30, 0))

    def test_run_checks_the_terrain_in_map_json(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        root = fixture.write_scene(env={"MAKE_CUTSCENE_WORK": tmp.name})
        cams = still((10, 6, 6), (0, 4, -4), 150) + still((-2, 5.5, -11), (0, 4.5, 0), 211)
        heads = {"npc1": [HEAD] * 361, "player": [[0, 4.6, 0]] * 361}
        workspace.write_json(root / "export" / "framing.json", framing(cams, [50.0] * 150 + [55.0] * 211, heads, [150]))
        m = workspace.read_json(root / "map.json")
        m["terrain"] = terrain_map(ridge=40)["terrain"]
        workspace.write_json(root / "map.json", m)
        issues, _ = gates.run(root)
        self.assertTrue(any("hides npc1's head" in i for i in issues), issues)


class EdgeTest(unittest.TestCase):
    def test_a_rotated_box(self):
        bx = gates.boxes({"boxes": [[0, 5, 0, 10, 4, 1, 0, 90, 0, "fff"]]})[0]
        self.assertTrue(gates.inside(bx, (0, 5, 4)))
        self.assertFalse(gates.inside(bx, (4, 5, 0)))

    def blocked_share(self, blocked):
        heads = [HEAD] * blocked + [[20, 4.6, -8]] * (100 - blocked)
        f = framing(still((0, 5, 10), n=100), heads={"npc1": heads})
        wall = gates.boxes({"boxes": [[0, 5, 0, 6, 10, 1, 0, 0, 0, "fff"]]})
        return gates.camera_clear(f, wall, [shot(1, 0, 100)])

    def test_the_off_share_tolerance_is_15_percent(self):
        self.assertEqual(self.blocked_share(15), [])
        self.assertTrue(any("hides npc1's head" in i for i in self.blocked_share(16)))

    def test_a_move_just_under_the_jump_limit_is_fine(self):
        def track(step):
            return [camtrack.look_cf((i * step, 5, 10), (0, 5, 0)) for i in range(2)]
        self.assertEqual(gates.jumps(framing(track(2.9)), []), [])
        self.assertTrue(gates.jumps(framing(track(3.1)), []))

    def test_a_subject_without_a_head_track_is_reported_not_skipped(self):
        f = framing(still((0, 5, 10)), heads={"player": [HEAD] * 60})
        found = gates.unchecked(f, [shot(1, 0, 60, subject="npc2"), shot(2, 0, 60, subject="player"),
                                    shot(3, 0, 60, subject=None), shot(4, 0, 60, subject="npc2", offscreen=True)])
        self.assertEqual(len(found), 1)
        self.assertIn("npc2", found[0])
        self.assertIn("not checked", found[0])

    def test_a_short_head_track_does_not_crash(self):
        f = framing(still((0, 5, 10)), heads={"npc1": [HEAD] * 10})
        wall = gates.boxes({"boxes": [[0, 5, 0, 6, 10, 1, 0, 0, 0, "fff"]]})
        self.assertTrue(gates.camera_clear(f, wall, [shot(1, 0, 60)]))
        gates.centre_safe(f, [shot(1, 0, 60)])

    def test_lights_are_limited_across_effects_in_a_window(self):
        data = {"Cues": {"VFX:A": {"budget": {"lights": 2}}, "VFX:B": {"budget": {"lights": 2}}},
                "Markers": [[1.0, "VFX", "A"], [1.5, "VFX", "B"]]}
        found = chr(10).join(gates.budgets(data))
        self.assertIn("4 lights", found)
        spread = dict(data, Markers=[[1.0, "VFX", "A"], [4.0, "VFX", "B"]])
        self.assertEqual(gates.budgets(spread), [])


class StaleExportTest(unittest.TestCase):
    def test_the_gates_refuse_an_export_older_than_the_edited_beats(self):
        import beats
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        root = fixture.write_scene(env={"MAKE_CUTSCENE_WORK": tmp.name})
        b = beats.load(root)
        b["cast"]["npc1"]["place"][0] += 1
        beats.save(b, root)
        with self.assertRaises(SystemExit) as e:
            gates.run(root)
        self.assertIn("changed after the export", str(e.exception))
        self.assertIn("run the export again", str(e.exception))
        self.assertFalse((root / "export" / "gates.json").exists())


class CutsSourceTest(unittest.TestCase):
    def test_framing_and_scene_must_agree_on_the_cuts(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        root = fixture.write_scene(env={"MAKE_CUTSCENE_WORK": tmp.name})
        f = workspace.read_json(root / "export" / "framing.json")
        f["cuts"] = [200]
        workspace.write_json(root / "export" / "framing.json", f)
        issues, _ = gates.run(root)
        self.assertTrue(any("cuts" in i and "re-export" in i for i in issues), issues)


class CostumeHashTest(unittest.TestCase):
    """I1: the costume specs Studio dresses the cast with are part of the build every gate record is stamped with."""

    def scene(self, costume):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        return fixture.write_scene(env={"MAKE_CUTSCENE_WORK": tmp.name}, costume=costume)

    def test_legacy_export_hash_is_stale_even_without_costumes(self):
        import hashlib
        root = self.scene(False)
        self.assertIsNone(gates.costume_hash(root))
        h = hashlib.sha256()
        for name in ("scene.json", "framing.json"):
            h.update((root / "export" / name).read_bytes())
        self.assertNotEqual(gates.export_hash(root), h.hexdigest(), "legacy evidence needs rechecking")

    def test_map_mutation_addition_and_deletion_change_the_fingerprint(self):
        root = self.scene(False)
        path = root / "map.json"
        before = gates.export_hash(root)
        original = path.read_bytes()
        path.write_bytes(original + b" ")
        self.assertNotEqual(gates.export_hash(root), before)
        path.unlink()
        absent = gates.export_hash(root)
        self.assertNotEqual(absent, before)
        path.write_bytes(b"")
        self.assertNotEqual(gates.export_hash(root), absent)
        path.write_bytes(original)
        self.assertEqual(gates.export_hash(root), before)
        self.assertEqual(gates.export_stale(root), [], "map freshness must not force animation export")

    def test_saved_g1_expires_on_map_change_and_deletion(self):
        root = self.scene(False)
        gates.run(root)
        recorded = workspace.read_json(root / "export" / "gates.json")["export"]
        self.assertEqual(recorded, gates.export_hash(root))
        path = root / "map.json"
        original = path.read_bytes()
        path.write_bytes(original + b" ")
        self.assertNotEqual(recorded, gates.export_hash(root))
        self.assertEqual(gates.export_stale(root), [])
        gates.run(root)
        refreshed = workspace.read_json(root / "export" / "gates.json")["export"]
        self.assertEqual(refreshed, gates.export_hash(root))
        path.unlink()
        self.assertNotEqual(refreshed, gates.export_hash(root))
        issues, _ = gates.run(root)
        self.assertTrue(any("no map.json" in issue for issue in issues))

    def test_subtitle_only_changes_do_not_force_export_or_g1(self):
        root = self.scene(False)
        before = gates.export_hash(root)
        b = workspace.read_json(root / "beats.json")
        next(iter(b["lines"].values()))["text"] = "New subtitle wording."
        workspace.write_json(root / "beats.json", b)
        self.assertEqual(gates.export_stale(root), [])
        self.assertEqual(gates.export_hash(root), before)

    def test_a_costume_edit_changes_the_build_fingerprint(self):
        root = self.scene(True)
        before, cos = gates.export_hash(root), gates.costume_hash(root)
        self.assertIsNotNone(cos)
        spec = workspace.read_json(root / "cast" / "npc1.json")
        spec["body"]["torso"] = "#000000"
        workspace.write_json(root / "cast" / "npc1.json", spec)
        self.assertNotEqual(gates.costume_hash(root), cos)
        self.assertNotEqual(gates.export_hash(root), before)

    def test_likeness_scale_and_catalog_count_but_notes_do_not(self):
        root = self.scene(True)
        path = root / "cast" / "player.json"
        spec = workspace.read_json(path)
        base = gates.costume_hash(root)
        workspace.write_json(path, dict(spec, notes="looked at three hats, this one reads best"))
        self.assertEqual(gates.costume_hash(root), base, "a note changes nothing Studio builds or reviewers see")
        for change in ({"likeness": {"look": 1.0, "ref": [{"video": 0.5}]}}, {"scale": {"height": 1.0}},
                       {"catalog": spec["catalog"][:1]}):
            workspace.write_json(path, dict(spec, **change))
            self.assertNotEqual(gates.costume_hash(root), base, change)
        workspace.write_json(path, spec)
        self.assertEqual(gates.costume_hash(root), base)

    def test_the_kit_checks_record_the_costume_they_read(self):
        root = self.scene(True)
        gates.run(root)
        made = workspace.read_json(root / "export" / "gates.json")
        self.assertEqual(made["export"], gates.export_hash(root))
        self.assertEqual(made["costume"], gates.costume_hash(root))


if __name__ == "__main__":
    unittest.main()
