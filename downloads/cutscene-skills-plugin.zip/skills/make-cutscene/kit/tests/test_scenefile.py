"""Tests for kit/scenefile.py on the Fixture_Scene working folder. Method by fwjelaa (FWJ STUDIOS)."""
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import fixture  # noqa: E402
import scenefile  # noqa: E402
import schema  # noqa: E402
import workspace  # noqa: E402


class ScenefileTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = fixture.write_scene(env={"MAKE_CUTSCENE_WORK": self.tmp.name}, hide="CutsceneTestGuard")

    def test_writes_a_valid_data_module_and_manifest(self):
        path = scenefile.write(self.root)
        self.assertEqual(path.name, "Fixture_Scene.luau")
        data = scenefile.module_data(beats.load(self.root), workspace.read_json(self.root / "export" / "scene.json"))
        self.assertEqual(schema.validate(data), [])
        self.assertEqual(data["Anims"]["R6"], {"player": "Fixture_Scene_player_R6"})
        self.assertEqual(data["Markers"], beats.markers(beats.load(self.root)))
        self.assertEqual(data["Config"]["Hide"], ["CutsceneTestGuard"])
        self.assertEqual(data["Config"]["Style"], "anime")
        manifest = workspace.read_json(self.root / "export" / "manifest.json")
        self.assertEqual(len(manifest["clips"]), 4)
        self.assertEqual(manifest["anchor"][2], -80)
        self.assertIn('Stage = "Fixture_Scene_Stage"', path.read_text(encoding="utf-8"))

    def test_fresh_ids_are_used_and_stale_ones_are_not(self):
        out = self.root / "export"
        sha = hashlib.sha256((out / "Fixture_Scene_Stage.rbxmx").read_bytes()).hexdigest()
        (out / "ids.json").write_text(json.dumps({"Fixture_Scene_Stage": {"id": "111", "sha": sha},
                                                  "Fixture_Scene_npc1_R15": {"id": "222", "sha": "old"},
                                                  "Fixture_Scene_player_R15": "333"}), encoding="utf-8")
        text = scenefile.write(self.root).read_text(encoding="utf-8")
        self.assertIn('Stage = "rbxassetid://111"', text)
        self.assertIn('npc1 = "Fixture_Scene_npc1_R15"', text)
        self.assertIn('player = "rbxassetid://333"', text)

    def test_line_text_survives_quotes_newlines_and_emoji(self):
        b = beats.load(self.root)
        b["lines"]["2"]["text"] = 'He said "halt"\r\nnow 🙂\x1b[0m\tend'
        beats.save(b, self.root)  # a line's words aren't in any clip: no new export needed
        text = scenefile.write(self.root).read_text(encoding="utf-8")
        # \r and ESC escaped (nothing dropped); a raw tab is a legal Luau string character
        self.assertIn('text = "He said \\"halt\\"\\r\\nnow 🙂\\027[0m\tend"', text)

    def test_a_marker_added_after_the_export_is_refused(self):
        b = beats.load(self.root)
        b["shots"][0]["markers"].append([0.5, "Shake", "9"])  # the review's case: the Stage clip doesn't carry it
        beats.save(b, self.root)
        with self.assertRaises(SystemExit) as e:
            scenefile.write(self.root)
        self.assertIn("beats.json changed after the export: run the export again", str(e.exception))
        self.assertFalse((self.root / "export" / "Fixture_Scene.luau").exists())

    def test_an_anim_file_written_after_the_export_is_refused(self):
        (self.root / "anim" / "npc1.py").write_text("def build():\n    pass\n", encoding="utf-8")
        with self.assertRaises(SystemExit) as e:
            scenefile.write(self.root)
        self.assertIn("anim/npc1.py changed after the export: run the export again", str(e.exception))

    def test_an_export_that_doesnt_say_what_it_came_from_is_refused(self):
        scene = workspace.read_json(self.root / "export" / "scene.json")
        del scene["sources"]
        workspace.write_json(self.root / "export" / "scene.json", scene)
        with self.assertRaises(SystemExit) as e:
            scenefile.write(self.root)
        self.assertIn("run the export again", str(e.exception))

    def test_an_export_that_stopped_on_clip_issues_is_refused(self):
        scene = workspace.read_json(self.root / "export" / "scene.json")
        scene["ok"], scene["issues"] = False, {"Fixture_Scene_npc1_R15": ["RightHand goes 0.20 studs into Head"]}
        workspace.write_json(self.root / "export" / "scene.json", scene)
        with self.assertRaises(SystemExit) as e:
            scenefile.write(self.root)
        self.assertIn("the export STOPPED on 1 clip issues", str(e.exception))

    def test_the_stage_clip_markers_must_match_the_module(self):
        path = self.root / "export" / "Fixture_Scene_Stage.json"
        d = json.loads(path.read_text(encoding="utf-8"))
        for k in d["keyframes"]:
            k["markers"] = [m for m in k["markers"] if m[0] != "Shake"]
        path.write_text(json.dumps(d), encoding="utf-8")
        with self.assertRaises(SystemExit) as e:
            scenefile.write(self.root)
        self.assertIn("the Stage clip's markers differ from the module's", str(e.exception))
        self.assertIn("Shake", str(e.exception))

    def test_the_camera_needs_its_own_keys_at_0_and_the_end(self):
        out = self.root / "export"
        d = json.loads((out / "Fixture_Scene_Stage.json").read_text(encoding="utf-8"))
        last = d["keyframes"][-1]
        self.assertEqual((last["time"], last["markers"]), (6.0, [["End", ""]]))  # End stays: a marker-only key at N
        last["poses"] = {}
        (out / "Fixture_Scene_Stage.json").write_text(json.dumps(d), encoding="utf-8")
        problems = scenefile.check_files(self.root, workspace.read_json(out / "scene.json"))
        self.assertTrue(any("Fixture_Scene_Stage" in p and "CutsceneCamera" in p and "frame 360" in p
                            for p in problems), problems)
        self.assertEqual(len(problems), 1, problems)

    def test_a_role_clip_needs_pose_keys_at_0_and_the_end(self):
        out = self.root / "export"
        d = json.loads((out / "Fixture_Scene_player_R15.json").read_text(encoding="utf-8"))
        d["keyframes"][-1]["poses"], d["keyframes"][-1]["markers"] = {}, [["Hit", ""]]  # only a marker at N
        (out / "Fixture_Scene_player_R15.json").write_text(json.dumps(d), encoding="utf-8")
        problems = scenefile.check_files(self.root, workspace.read_json(out / "scene.json"))
        self.assertTrue(any("Fixture_Scene_player_R15" in p and "pose keys" in p and "frame 360" in p
                            for p in problems), problems)
        self.assertEqual(len(problems), 1, problems)

    def test_an_invalid_scene_is_not_written(self):
        scene = workspace.read_json(self.root / "export" / "scene.json")
        scene["length"] = 40
        workspace.write_json(self.root / "export" / "scene.json", scene)
        with self.assertRaises(SystemExit) as e:
            scenefile.write(self.root)
        self.assertIn("Length must be", str(e.exception))
        self.assertFalse((self.root / "export" / "Fixture_Scene.luau").exists())

    def test_clip_files_are_checked(self):
        out = self.root / "export"
        d = json.loads((out / "Fixture_Scene_player_R6.json").read_text(encoding="utf-8"))
        d["keyframes"] = d["keyframes"][:1]
        (out / "Fixture_Scene_player_R6.json").write_text(json.dumps(d), encoding="utf-8")
        (out / "Fixture_Scene_npc1_R15.rbxmx").write_text("<roblox><Item", encoding="utf-8")
        problems = scenefile.check_files(self.root, workspace.read_json(out / "scene.json"))
        self.assertTrue(any("fewer than 2 keyframes" in p for p in problems), problems)
        self.assertTrue(any("not valid XML" in p for p in problems), problems)


class LineHoldTest(unittest.TestCase):
    """A line with no hold clears by the end of the shot that holds it (reviewers saw line 2 over the next shot)."""

    SCENE = {"clips": {"Stage": "S"}, "fov": 70}

    def sheet(self, lengths, line_shots, holds=None):
        shots = [beats.shot("ACTION", n, "player", markers=[[0.15, "Line", str(k)]] if k else None)
                 for n, k in zip(lengths, line_shots)]
        beats.retime(shots)
        lines = {str(k): {"speaker": "A", "text": f"line {k}"} for k in line_shots if k}
        for k, h in (holds or {}).items():
            lines[str(k)]["hold"] = h
        b = {"id": "Hold", "kind": "story", "cast": {"player": {}}, "shots": shots, "lines": lines, "config": {}}
        return b, dict(self.SCENE, length=beats.length(b))

    def clear_at(self, b, scene, key):
        data = scenefile.module_data(b, scene)
        t = next(m[0] for m in beats.markers(b) if m[1] == "Line" and m[2] == key)
        return round(t + data["Lines"][key]["hold"], 3)

    def test_line_in_shot_3_of_5_clears_at_that_shots_end(self):
        b, scene = self.sheet([2.0] * 5, [0, 0, 1, 0, 2])
        self.assertEqual(self.clear_at(b, scene, "1"), 6.0)
        self.assertEqual(self.clear_at(b, scene, "2"), 10.0)

    def test_explicit_hold_is_kept(self):
        b, scene = self.sheet([2.0] * 5, [0, 0, 1, 0, 2], holds={1: 3.5})
        data = scenefile.module_data(b, scene)
        self.assertEqual(data["Lines"]["1"]["hold"], 3.5)
        self.assertNotIn("hold", b["lines"]["2"])  # the beat sheet itself is not rewritten

    def test_short_shot_holds_at_least_1_2_s(self):
        b, scene = self.sheet([0.8, 2.0], [1, 0])
        self.assertEqual(scenefile.module_data(b, scene)["Lines"]["1"]["hold"], 1.2)

    def test_min_hold_stops_at_the_next_line(self):
        b, scene = self.sheet([0.8, 0.8], [1, 2])
        data = scenefile.module_data(b, scene)
        self.assertEqual(self.clear_at(b, scene, "1"), 0.95)  # next line shows at 0.8 + 0.15

    def test_rewriting_the_module_needs_no_new_export(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        root = fixture.write_scene(env={"MAKE_CUTSCENE_WORK": tmp.name})
        before = scenefile.sources(root)
        scenefile.write(root)
        self.assertEqual(scenefile.sources(root), before)
        self.assertEqual(scenefile.stale(root, workspace.read_json(root / "export" / "scene.json")), [])
        self.assertNotIn("Lines", json.dumps(beats.export_part(beats.load(root))))


if __name__ == "__main__":
    unittest.main()
