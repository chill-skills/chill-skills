"""Tests for kit/vfxlib.py, the VFX preset library. Method by fwjelaa (FWJ STUDIOS)."""
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import bundle  # noqa: E402
import vfxlib  # noqa: E402


class VfxLibTest(unittest.TestCase):
    def setUp(self):
        self.lib = copy.deepcopy(vfxlib.load())

    def test_the_shipped_library_is_valid(self):
        self.assertEqual(vfxlib.validate(self.lib), [])

    def test_the_spec_presets_exist(self):
        # spec 7: charge-up, aura burst, light pillar, crater with debris, shockwave rings, ground cracks, wind lines,
        # lightning, dust; plus the persistent aura and the power-down (spec 11 step 3)
        for name in ("Charge", "Burst", "Pillar", "Crater", "Shockwave", "Cracks", "Wind", "Lightning", "Dust",
                     "PowerDown"):
            self.assertIn(name, vfxlib.names(self.lib))
        self.assertIn("Flame", vfxlib.auras(self.lib))
        self.assertEqual(self.lib["auras"]["Flame"]["powerDown"], "PowerDown")

    def test_budget_counts_particles_lights_and_parts(self):
        self.assertEqual(vfxlib.budget(self.lib, "Burst"), {"particles": 92, "lights": 1, "highlights": 0, "parts": 14})
        self.assertEqual(vfxlib.budget(self.lib, "Crater"), {"particles": 30, "lights": 0, "highlights": 0, "parts": 97})
        self.assertEqual(vfxlib.budget(self.lib, "Lightning")["parts"], 56)

    def test_aura_stays_under_sixty_live_particles(self):
        self.assertLessEqual(vfxlib.aura_budget(self.lib, "Flame"), vfxlib.AURA_PARTICLES)
        self.lib["auras"]["Flame"]["wisps"]["rate"] = 20
        self.assertTrue(any("keeps" in p for p in vfxlib.validate(self.lib)))

    def test_bad_layers_are_named(self):
        layers = self.lib["presets"]["Burst"]["layers"]
        layers[0]["shape"] = "cube"
        layers[1]["r"] = [[0.2, 1], [0.1, 5]]
        layers[4]["texture"] = "nope"
        layers[4]["bogus"] = 1
        found = "\n".join(vfxlib.validate(self.lib))
        self.assertIn("preset Burst layer 1 (shape): shape must be one of ball, column, disc", found)
        self.assertIn("preset Burst layer 2 (ring): r key times must start at 0 or later and never go back", found)
        self.assertIn("preset Burst layer 5 (emit): texture must be one of the textures", found)
        self.assertIn("preset Burst layer 5 (emit): unknown field 'bogus'", found)

    def test_only_engine_textures_are_allowed(self):
        for bad in ("rbxassetid://123", "http://x/y.png", "rbxasset://fonts/x.ttf", "rbxasset://textures/particles/../x.png",
                    "rbxasset://textures/particles/a.dds" + chr(10), "rbxthumb://type=Asset&id=1"):
            lib = copy.deepcopy(self.lib)
            lib["textures"]["glow"] = bad
            found = "\n".join(vfxlib.validate(lib))
            self.assertIn("texture glow", found, bad)
            self.assertIn("engine textures only", found, bad)
            self.assertIn("preset Burst layer", found, bad)  # names the preset and field that use it
            self.assertIn("field texture", found, bad)

    def test_every_element_defines_an_accent(self):
        del self.lib["elements"]["teal"]["accent"]
        self.assertIn("element teal: accent must be 6 hex digits", "\n".join(vfxlib.validate(self.lib)))

    def test_particles_must_end_inside_the_preset(self):
        self.lib["presets"]["Dust"]["layers"][0]["life"] = [0.8, 3.0]
        self.assertIn("after the preset's life", "\n".join(vfxlib.validate(self.lib)))

    def test_limits_per_preset(self):
        self.lib["presets"]["Burst"]["layers"][4]["count"] = 700
        self.lib["presets"]["Burst"]["layers"].append({"kind": "light", "life": 0.2, "brightness": 1, "range": 4})
        self.lib["presets"]["Burst"]["layers"].append({"kind": "light", "life": 0.2, "brightness": 1, "range": 4})
        found = "\n".join(vfxlib.validate(self.lib))
        self.assertIn("preset Burst: 742 particles (at most 600)", found)
        self.assertIn("preset Burst: 3 lights (spec 7: at most 2 per effect)", found)

    def test_luau_module_is_generated_from_the_json(self):
        text = vfxlib.luau(self.lib)
        self.assertTrue(text.startswith("-- VfxPresets: generated from vfx/presets.json"))
        self.assertIn("Method by fwjelaa (FWJ STUDIOS).", text.split("\n")[1])
        self.assertIn("JSONDecode(", text)
        import payload
        decoded = json.loads(payload._payload(text))
        self.assertEqual(decoded["Presets"]["Burst"], self.lib["presets"]["Burst"])
        self.assertEqual(sorted(decoded), ["Auras", "Elements", "Manga", "Presets", "Textures"])
        self.assertEqual(decoded["Manga"], vfxlib.manga())

    def test_the_manga_textures_are_uploaded_ids_with_their_flipbook_cells(self):
        m = vfxlib.manga()
        self.assertEqual(sorted(m), ["burst", "burst2", "inksmoke", "lines", "plum", "whiteburst"])
        for name, t in m.items():
            self.assertRegex(t["id"], vfxlib.ASSET_ID, name)
            self.assertIn(t["grid"], (1, 2), name)
            self.assertTrue(all(0 <= c < t["grid"] ** 2 for c in t["cells"]), name)
        self.assertEqual(m["lines"]["cells"], [0, 1, 2, 3], "four quadrant cells to jitter between")
        self.assertEqual(m["burst"]["id"], m["burst2"]["id"], "both burst shapes share one sheet")
        for t in json.loads(vfxlib.MANGA_PATH.read_text(encoding="utf-8"))["textures"].values():
            self.assertTrue((vfxlib.MANGA_PATH.parent / t["file"]).exists(), t["file"])

    def test_a_preset_can_carry_the_manga_screen_effects(self):
        lib = json.loads(json.dumps(self.lib))
        lib["presets"]["Burst"]["screen"] = [
            {"effect": "burst", "image": "burst", "size": 0.5, "rot": 10, "life": 0.4, "at": [0.5, 0.5]},
            {"effect": "word", "text": "POW!!", "fill": "black", "stroke": 0.05, "font": "Bangers"},
            {"effect": "speedlines", "focus": [0.4, 0.5], "density": 0.8, "color": "black", "follow": "player.Head"}]
        self.assertFalse([p for p in vfxlib.validate(lib) if "screen" in p])
        lib["presets"]["Burst"]["screen"] = [{"effect": "word", "text": "", "stroke": 0.2, "image": "nope",
                                              "at": [1], "font": "Arial"}]
        found = "\n".join(vfxlib.validate(lib))
        self.assertIn("preset Burst screen 1: text must be 1-16 characters", found)
        self.assertIn("preset Burst screen 1: stroke must be 0-0.07 of the text size", found)
        self.assertIn("preset Burst screen 1: image must be a manga texture", found)
        self.assertIn("preset Burst screen 1: at must be [x, y] (screen, 0-1) or [x, y, z]", found)
        self.assertIn("preset Burst screen 1: font must be one of Bangers", found)

    def test_load_reads_a_changed_file_again(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "presets.json"
            p.write_text(json.dumps(self.lib), encoding="utf-8")
            self.assertIn("Burst", vfxlib.names(vfxlib.load(p)))
            del self.lib["presets"]["Burst"]
            p.write_text(json.dumps(self.lib), encoding="utf-8")
            import os
            st = p.stat()
            os.utime(p, ns=(st.st_atime_ns, st.st_mtime_ns + 10_000_000))
            self.assertNotIn("Burst", vfxlib.names(vfxlib.load(p)))

    @unittest.skipUnless(vfxlib.FWJELAA_VFX.exists(), "fwjelaa-vfx is not next to this skill")
    def test_shared_elements_match_fwjelaa_vfx(self):
        # the palettes are fwjelaa-vfx's (read, never edited): fail loudly if either side drifts
        theirs = vfxlib.fwjelaa_elements()
        self.assertEqual(sorted(theirs), sorted(vfxlib.SHARED_ELEMENTS), "fwjelaa-vfx added or dropped an element")
        for name in vfxlib.SHARED_ELEMENTS:
            ours = {k: v for k, v in self.lib["elements"][name].items() if k != "accent"}
            self.assertEqual(ours, theirs[name], name)

    def test_crimson_is_a_red_element_for_the_closing_aura(self):
        # not shared with fwjelaa-vfx (like azure); fire reads orange, so Daniel's UI red needs its own palette
        self.assertIn("crimson", self.lib["elements"])
        self.assertNotIn("crimson", vfxlib.SHARED_ELEMENTS)
        self.assertEqual(vfxlib.validate(self.lib), [])
        pal = self.lib["elements"]["crimson"]
        for role in vfxlib.roles_used(self.lib):
            if role in ("deep", "white", "black"):
                continue  # resolved by the runtime, not per element
            self.assertIn(role, pal, role)
        r, g, b = (int(pal["main"][i:i + 2], 16) for i in (0, 2, 4))
        self.assertGreater(r, 2 * max(g, b), "crimson main must be clearly red")
        self.assertGreater(r, 120)

    def test_report_lists_every_preset(self):
        problems, lines = vfxlib.report(self.lib)
        self.assertEqual(problems, [])
        self.assertEqual(lines[-1], "VFX LIBRARY: ok")
        self.assertTrue(any(line.strip().startswith("Burst") for line in lines))

    def test_the_vfx_presets_module_is_generated_from_the_json(self):
        files = bundle.install_embed()["files"]
        self.assertEqual(files["CutsceneKit/VfxPresets.luau"], vfxlib.luau())
        self.assertFalse((bundle.ROBLOX / "CutsceneKit" / "VfxPresets.luau").exists(), "generated, never a file")


if __name__ == "__main__":
    unittest.main()
