"""Tests for kit/sheets.py, the side-by-side sheet. Method by fwjelaa (FWJ STUDIOS)."""
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import media  # noqa: E402
import sheets  # noqa: E402
import workspace  # noqa: E402

HAVE_FFMPEG = shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None
SIZE = (3 * 480 + 2 * 4 + 2 * 4, 2 * 270 + 4 + 2 * 4)


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class SheetsTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = workspace.create("SbsTry", env={"MAKE_CUTSCENE_WORK": self.tmp.name})
        media.synth(self.root / "ref" / "clip.mp4", [("testsrc", 1.0), ("color=c=red", 1.0)])
        media.ffmpeg("-f", "lavfi", "-i", "color=c=blue:s=400x600:d=0.1", "-frames:v", "1", self.root / "ref" / "panel_02.png")
        shots = [beats.shot("ACTION", 1.0, ref={"mid": 0.5}), beats.shot("ACTION", 1.0, ref={"panel": "ref/panel_02.png"}),
                 beats.shot("AFTERMATH", 0.5, action="the guard turns away")]
        beats.save(beats.draft("SbsTry", {"type": "video"}, shots), self.root)
        media.synth(self.root / "preview" / "SbsTry.mp4", [("testsrc2", 2.5)])

    def test_one_sheet_reference_on_top(self):
        paths = sheets.side_by_side(self.root)
        self.assertEqual([p.name for p in paths], ["side_by_side_1.png"])
        info = media.probe(paths[0])
        self.assertEqual((info["width"], info["height"]), SIZE)
        self.assertFalse((self.root / "preview" / "_sbs").exists())

    def test_no_preview_yet(self):
        (self.root / "preview" / "SbsTry.mp4").unlink()
        with self.assertRaises(SystemExit) as e:
            sheets.side_by_side(self.root)
        self.assertIn("py kit/run.py preview SbsTry", str(e.exception))

    def test_r6_preview_gets_its_own_sheet(self):
        media.synth(self.root / "preview" / "SbsTry_R6.mp4", [("testsrc2", 2.5)])
        paths = sheets.side_by_side(self.root, rig="R6")
        self.assertEqual([p.name for p in paths], ["side_by_side_R6_1.png"])
        self.assertTrue((self.root / "preview" / "side_by_side_R6_1.png").exists())
        self.assertFalse((self.root / "preview" / "side_by_side_1.png").exists())

    def test_r6_without_its_preview_names_the_fix(self):
        with self.assertRaises(SystemExit) as e:
            sheets.side_by_side(self.root, rig="R6")
        self.assertIn("SbsTry_R6.mp4", str(e.exception))

    def test_explicit_preview_path(self):
        other = self.root / "preview" / "other.mp4"
        shutil.copyfile(self.root / "preview" / "SbsTry.mp4", other)
        paths = sheets.side_by_side(self.root, preview=other)
        self.assertEqual([p.name for p in paths], ["side_by_side_1.png"])

    def test_bad_rig_refused(self):
        with self.assertRaises(SystemExit) as e:
            sheets.side_by_side(self.root, rig="R9")
        self.assertIn("R15 or R6", str(e.exception))

    def _spy(self):
        calls = {"cell": [], "card": []}
        real_cell, real_fit = media.cell, sheets.fit_words

        def cell(src, out, label="", size=(320, 180), t=None):
            calls["cell"].append((Path(src).name, label, t))
            return real_cell(src, out, label, size, t)

        def fit(text, size):
            lines, fs = real_fit(text, size)
            calls["card"].append(" ".join(lines))
            return lines, fs

        media.cell, sheets.fit_words = cell, fit
        self.addCleanup(setattr, media, "cell", real_cell)
        self.addCleanup(setattr, sheets, "fit_words", real_fit)
        return calls

    def test_alignment_exact_timestamps(self):
        calls = self._spy()
        sheets.side_by_side(self.root)
        ours = [c for c in calls["cell"] if c[0] == "SbsTry.mp4"]
        self.assertEqual([c[2] for c in ours], [0.5, 1.5, 2.25])
        self.assertEqual([c for c in calls["cell"] if c[0] == "clip.mp4"], [("clip.mp4", "reference, shot 1", 0.5)])
        self.assertEqual([c[0] for c in calls["cell"] if c[0] == "panel_02.png"], ["panel_02.png"])

    def test_words_reference_gets_a_text_card(self):
        calls = self._spy()
        sheets.side_by_side(self.root)
        self.assertEqual(len(calls["card"]), 1)
        self.assertIn("the guard turns away", calls["card"][0])
        self.assertIn("WORDS ONLY", calls["card"][0])

    def test_missing_reference_clip_is_refused(self):
        (self.root / "ref" / "clip.mp4").unlink()
        with self.assertRaises(SystemExit) as e:
            sheets.side_by_side(self.root)
        self.assertIn("ref/clip.mp4 is missing", str(e.exception))
        self.assertFalse((self.root / "preview" / "_sbs").exists())

    def test_missing_panel_is_refused(self):
        (self.root / "ref" / "panel_02.png").unlink()
        with self.assertRaises(SystemExit) as e:
            sheets.side_by_side(self.root)
        self.assertIn("ref/panel_02.png but that file is missing", str(e.exception))
        self.assertFalse((self.root / "preview" / "_sbs").exists())

    def test_reference_time_past_the_clip_is_refused_and_cleaned_up(self):
        b = beats.load(self.root)
        b["shots"][0]["ref"] = {"mid": 9.5}
        beats.save(b, self.root)
        with self.assertRaises(SystemExit) as e:
            sheets.side_by_side(self.root)
        self.assertIn("past the end of ref/clip.mp4", str(e.exception))
        self.assertFalse((self.root / "preview" / "_sbs").exists())

    def test_short_preview_is_refused(self):
        media.synth(self.root / "preview" / "SbsTry.mp4", [("testsrc2", 1.0)])
        with self.assertRaises(SystemExit) as e:
            sheets.side_by_side(self.root)
        msg = str(e.exception)
        self.assertIn("cut short", msg)
        self.assertIn("re-record", msg)
        self.assertEqual(len(msg.splitlines()), 1)
        self.assertFalse((self.root / "preview" / "_sbs").exists())

    def test_more_than_six_shots_are_paged_six_per_sheet(self):
        shots = [beats.shot("ACTION", 0.5, action=f"beat {n}") for n in range(8)]
        beats.save(beats.draft("SbsTry", {"type": "words"}, shots), self.root)
        media.synth(self.root / "preview" / "SbsTry.mp4", [("testsrc2", 4.2)])
        paths = sheets.side_by_side(self.root)
        self.assertEqual([p.name for p in paths], ["side_by_side_1.png", "side_by_side_2.png"])
        self.assertEqual(media.probe(paths[0])["width"], 6 * 480 + 5 * 4 + 2 * 4)
        self.assertEqual(media.probe(paths[1])["width"], 2 * 480 + 1 * 4 + 2 * 4)

    def test_a_shorter_run_leaves_no_older_numbered_sheets(self):
        shots = [beats.shot("ACTION", 0.5, action=f"beat {n}") for n in range(8)]
        beats.save(beats.draft("SbsTry", {"type": "words"}, shots), self.root)
        media.synth(self.root / "preview" / "SbsTry.mp4", [("testsrc2", 4.2)])
        sheets.side_by_side(self.root)
        r6 = self.root / "preview" / "side_by_side_R6_1.png"
        r6.write_bytes(b"the R6 run's sheet")
        beats.save(beats.draft("SbsTry", {"type": "words"}, shots[:3]), self.root)
        paths = sheets.side_by_side(self.root)
        self.assertEqual([p.name for p in paths], ["side_by_side_1.png"])
        self.assertFalse((self.root / "preview" / "side_by_side_2.png").exists())
        self.assertEqual(r6.read_bytes(), b"the R6 run's sheet", "an R15 run leaves the R6 sheets alone")

    def test_the_sheets_record_the_preview_stamp_they_were_made_from(self):
        stamp = {"export": "e", "module": "m", "video": "v"}
        workspace.write_json(self.root / "preview" / "export.json", stamp)
        sheets.side_by_side(self.root)
        made = workspace.read_json(self.root / "preview" / "sheets.json")
        self.assertEqual(made["side_by_side"]["files"], ["side_by_side_1.png"])
        self.assertEqual(made["side_by_side"]["preview"], {"R15": stamp})
        self.assertEqual(made["side_by_side"]["hashes"],
                         sheets.review.evidence.hashes(self.root / "preview", ["side_by_side_1.png"]))
        other = self.root / "preview" / "other.mp4"
        shutil.copyfile(self.root / "preview" / "SbsTry.mp4", other)
        sheets.side_by_side(self.root, preview=other)  # any file: not evidence of the stamped preview
        made = workspace.read_json(self.root / "preview" / "sheets.json")
        self.assertEqual(made["side_by_side"]["preview"], {"R15": None})


LONG = ("WORDS ONLY, shot 4 ACTION: the camera starts wide on the street, then a strong eased push to a medium "
        "close-up of the hero as she turns toward the lantern and the crowd falls quiet around her  camera: "
        "slow dolly in with a small handheld wobble, then a gentle rack focus from the lantern to her eyes while the "
        "street lights flicker and the music swells, ending on her eyes at the very last word")


class FitWordsTest(unittest.TestCase):
    def test_short_text_keeps_the_default_size(self):
        lines, fs = sheets.fit_words("WORDS ONLY, shot 1 AFTERMATH: the guard turns away", sheets.CELL)
        self.assertEqual(fs, sheets.CELL[1] // 12)
        self.assertEqual(" ".join(lines), "WORDS ONLY, shot 1 AFTERMATH: the guard turns away")

    def test_long_text_shrinks_and_keeps_its_last_word(self):
        lines, fs = sheets.fit_words(LONG, sheets.CELL)
        self.assertLess(fs, sheets.CELL[1] // 12)
        self.assertGreaterEqual(fs, sheets.MIN_FS)
        self.assertEqual(" ".join(lines).split()[-1], "word")
        self.assertEqual(" ".join(lines), " ".join(LONG.split()))
        self.assertLessEqual(len(lines) * (fs + 4), sheets.CELL[1] - 20)

    def test_text_too_long_even_at_the_smallest_size_ends_with_an_ellipsis(self):
        huge = " ".join(f"word{n}" for n in range(400))
        lines, fs = sheets.fit_words(huge, sheets.CELL)
        self.assertEqual(fs, sheets.MIN_FS)
        self.assertTrue(lines[-1].endswith("…"))
        self.assertLessEqual(len(lines) * (fs + 4), sheets.CELL[1] - 20)
        self.assertTrue(lines[0].startswith("word0"))


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class OurLabelTest(unittest.TestCase):
    def test_label_stays_off_the_bottom_12_percent(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        d = Path(tmp.name)
        media.synth(d / "v.mp4", [("testsrc2", 1.0)])
        sheets.ours_frame(d / "v.mp4", d / "ours.png", "ours, shot 2  3.25s", 0.5)
        media.cell(d / "v.mp4", d / "plain.png", "", sheets.CELL, 0.5)
        w, h = sheets.CELL

        def rows(path, y0, y1):
            proc = media.ffmpeg("-i", path, "-vf", f"crop={w}:{y1 - y0}:0:{y0}", "-f", "rawvideo", "-pix_fmt", "rgb24",
                                "-", binary=True)
            return proc.stdout

        low = int(h * 0.88)
        self.assertEqual(rows(d / "ours.png", low, h), rows(d / "plain.png", low, h))
        self.assertNotEqual(rows(d / "ours.png", 0, int(h * 0.2)), rows(d / "plain.png", 0, int(h * 0.2)))


if __name__ == "__main__":
    unittest.main()
