"""The data-module contract (spec 6): kit/schema.py and CutsceneKit.Data.validate must give the same problems for the
same module. The Python side always runs; the Luau side runs Data.luau in luau.exe when it is installed.
Method by fwjelaa (FWJ STUDIOS)."""
import copy
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import luaurun  # noqa: E402
import schema  # noqa: E402


def good():
    return {
        "Name": "Wake", "Kind": "awakening", "Length": 10,
        "Anims": {"Stage": "Wake_Stage", "R15": {"player": "Wake_player_R15"}},
        "Places": {"player": [0, 0, 0, 0, 0, 0]}, "Fov": [[0, 50], [10, 60]],
        "Markers": [[0, "Letterbox", "in"], [1.2, "VFX", "Charge"], [2.5, "Impact", ""], [2.5, "VFX", "Burst"],
                    [3, "Slowmo", "0.25"], [9.45, "Letterbox", "out"], [10, "End", ""]],
        "Cues": {"VFX:Charge": {"kind": "vfx", "preset": "Charge"},
                 "VFX:Burst": {"kind": "vfx", "preset": "Burst", "at": [0, 0, 0], "follow": "player",
                               "budget": {"particles": 92, "lights": 1, "highlights": 0, "parts": 14}}},
        "Config": {"Skip": False, "Replay": "always", "Cooldown": 30, "Element": "azure",
                   "Awakened": {"Duration": 30, "Aura": "Flame", "Look": ["eyes", "outline"], "At": 2.5},
                   "Grade": {"Tint": "ffd9a0", "Saturation": -0.1}},
    }


def variant(**changes):
    d = good()
    for path, value in changes.items():
        keys = path.split("__")
        node = d
        for k in keys[:-1]:
            node = node[k]
        node[keys[-1]] = value
    return d


CASES = [  # (example, a problem it must report, or None when it is valid)
    (good(), None),
    (variant(Cues={"VFX:Burst": {"kind": "vfx", "preset": "Nope"}}), "Cues[VFX:Burst].preset Nope is not a VFX preset"),
    (variant(Cues={"VFX:Burst": {"kind": "vfx", "preset": "SlashSweep", "external": True}}), None),
    (variant(Cues={"VFX:Burst": {"kind": "boom"}}), "Cues[VFX:Burst] needs a kind: vfx, screen, sfx or face"),
    (variant(Cues={"VFX:Burst": {"kind": "vfx", "preset": "Burst", "at": [0, 1]}}),
     "Cues[VFX:Burst].at must be 3 numbers {x, y, z}"),
    (variant(Cues={"VFX:Burst": {"kind": "vfx", "preset": "Burst", "follow": "boss.Head"}}),
     "Cues[VFX:Burst].follow must be a role or role.Part, like player.Head"),
    (variant(Cues={"VFX:Burst": {"kind": "vfx", "preset": "Burst", "follow": "npc12.Right_Arm"}}), None),
    (variant(Cues={"VFX:Burst": {"kind": "vfx", "preset": "Burst", "scale": 0}}), "Cues[VFX:Burst].scale must be a number > 0"),
    (variant(Cues={"VFX:Burst": {"kind": "vfx", "preset": "Burst", "element": "pink"}}),
     "Cues[VFX:Burst].element pink is not a VFX element"),
    (variant(Cues={"VFX:Lines": {"kind": "screen", "effect": "zoom"}}),
     "Cues[VFX:Lines].effect must be grade, bloom, flash, speedlines, focus, burst, word or backdrop"),
    # the manga effects (VFX-1): sound words, impact bursts, focus lines, backdrop cards, and the cast's key light
    (variant(Cues={"VFX:Pow": {"kind": "screen", "effect": "word", "text": "POW!!", "at": [0.3, 0.2], "size": 0.22,
                               "rot": -12, "life": 1, "fill": "black", "stroke": 0, "font": "Bangers"}}), None),
    (variant(Cues={"VFX:Pow": {"kind": "screen", "effect": "word", "text": "THIS IS FAR TOO LONG"}}),
     "Cues[VFX:Pow].text must be 1-16 characters (a sound word like POW!!)"),
    (variant(Cues={"VFX:Pow": {"kind": "screen", "effect": "word"}}),
     "Cues[VFX:Pow].text must be 1-16 characters (a sound word like POW!!)"),
    (variant(Cues={"VFX:Pow": {"kind": "screen", "effect": "word", "text": "BZZT", "stroke": 0.1}}),
     "Cues[VFX:Pow].stroke must be 0-0.07 of the text size (thicker fills the letters in)"),
    (variant(Cues={"VFX:Pow": {"kind": "screen", "effect": "word", "text": "BZZT", "font": "ComicSans"}}),
     "Cues[VFX:Pow].font must be one of Bangers, LuckiestGuy, FredokaOne, PermanentMarker, Creepster, DenkOne"),
    (variant(Cues={"VFX:Pow": {"kind": "screen", "effect": "word", "text": "BZZT", "fill": "pink"}}),
     "Cues[VFX:Pow].fill must be white, black, a colour role or #rrggbb"),
    (variant(Cues={"VFX:Pow": {"kind": "screen", "effect": "word", "text": "?!", "fill": "#ff00aa", "rot": 8}}), None),
    (variant(Cues={"VFX:Pow": {"kind": "screen", "effect": "word", "text": "?!", "rot": "left"}}),
     "Cues[VFX:Pow].rot must be a number of degrees"),
    (variant(Cues={"VFX:Hit": {"kind": "screen", "effect": "burst", "image": "burst2", "follow": "player.RightHand",
                               "at": [0, 0, -1], "size": 0.6, "rot": 15, "life": 0.5}}), None),
    (variant(Cues={"VFX:Hit": {"kind": "screen", "effect": "burst", "image": "rbxassetid://123"}}), None),
    (variant(Cues={"VFX:Hit": {"kind": "screen", "effect": "burst", "image": "boom"}}),
     "Cues[VFX:Hit].image must be a manga texture (burst, burst2, inksmoke, lines, plum, whiteburst) or "
     "rbxassetid://<number>"),
    (variant(Cues={"VFX:Hit": {"kind": "screen", "effect": "burst", "size": 3}}),
     "Cues[VFX:Hit].size must be a share of the screen height, more than 0 and at most 2"),
    (variant(Cues={"VFX:Hit": {"kind": "screen", "effect": "burst", "at": [1]}}),
     "Cues[VFX:Hit].at must be 2 numbers (x, y on the screen, 0-1) or 3 numbers {x, y, z}"),
    (variant(Cues={"VFX:Lines": {"kind": "screen", "effect": "speedlines", "focus": [0.5, 0.4], "density": 0.8,
                                 "alpha": 1, "color": "black", "life": 0.6}}), None),
    (variant(Cues={"VFX:Lines": {"kind": "screen", "effect": "speedlines", "density": 2}}),
     "Cues[VFX:Lines].density must be a number from 0 to 1"),
    (variant(Cues={"VFX:Lines": {"kind": "screen", "effect": "speedlines", "follow": "boss"}}),
     "Cues[VFX:Lines].follow must be a role or role.Part, like player.Head"),
    (variant(Cues={"VFX:Lines": {"kind": "screen", "effect": "speedlines", "focus": "middle"}}),
     "Cues[VFX:Lines].focus must be 2 numbers (x, y on the screen, 0-1) or 3 numbers {x, y, z}"),
    (variant(Cues={"VFX:Bg": {"kind": "screen", "effect": "backdrop", "image": "plum", "dist": 30, "life": 1.5,
                              "color": "#ffffff"}}), None),
    (variant(Cues={"VFX:Bg": {"kind": "screen", "effect": "backdrop", "dist": 0}}),
     "Cues[VFX:Bg].dist must be a number of studs > 0"),
    (variant(Cues={"VFX:Bg": {"kind": "screen", "effect": "backdrop", "life": -1}}),
     "Cues[VFX:Bg].life must be a number of seconds > 0"),
    (variant(Cues={"VFX:Glow": {"kind": "screen", "effect": "bloom", "size": 24}}), None),
    (variant(Config__CastLight=True), None),
    (variant(Config__CastLight={"Color": "ffffff", "Brightness": 1.5, "Range": 10}), None),
    (variant(Config__CastLight="yes"), "Config.CastLight must be true, false or a table {Color, Brightness, Range}"),
    (variant(Config__CastLight={"Color": "#fff"}), "Config.CastLight.Color must be 6 hex digits like ffffff"),
    (variant(Config__CastLight={"Brightness": 11}), "Config.CastLight.Brightness must be a number from 0 to 10"),
    (variant(Config__CastLight={"Range": 0}), "Config.CastLight.Range must be a number from 1 to 60"),
    (variant(Cues=[1, 2]), "Cues must be a table of marker = cue"),
    (variant(Markers=[[0, "Slowmo", "0"], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Markers=[[0, "Slowmo", "fast"], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Config__Cooldown=-1), "Config.Cooldown must be a number of seconds >= 0"),
    (variant(Config__Element="pink"), "Config.Element pink is not a VFX element"),
    (variant(Config__Awakened=5), "Config.Awakened must be a table"),
    (variant(Config__Awakened={"Duration": 0}), "Config.Awakened.Duration must be a number of seconds > 0"),
    (variant(Config__Awakened={"Aura": "Smoke"}), "Config.Awakened.Aura Smoke is not an aura style"),
    (variant(Config__Awakened={"Look": ["eyes", "wings"]}), "Config.Awakened.Look must be a list of eyes, outline or tint"),
    (variant(Config__Awakened={"At": 11}), "Config.Awakened.At must be a time inside the scene"),
    (variant(Config__Awakened={"Element": "pink"}), "Config.Awakened.Element pink is not a VFX element"),
    (variant(Config__Grade={"Contrast": 2}), "Config.Grade.Contrast must be a number from -1 to 1"),
    (variant(Config__Grade={"Tint": "#ffd9a0"}), "Config.Grade.Tint must be 6 hex digits like ffd9a0"),
    (variant(Config__Grade=3), "Config.Grade must be a table"),
    (variant(Markers=[[0, "Slowmo", "0x1"], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Markers=[[0, "Slowmo", "0x.8"], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Markers=[[0, "Slowmo", True], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Markers=[[0, "Slowmo", False], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Markers=[[0, "Slowmo", "1e0"], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Markers=[[0, "Slowmo", "5."], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Markers=[[0, "Slowmo", "-0.5"], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Markers=[[0, "Slowmo", "0.5 x"], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Markers=[[0, "Slowmo", "inf"], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Markers=[[0, "Slowmo", "nan"], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Markers=[[0, "Slowmo", 2], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Markers=[[0, "Slowmo", " 0.5 "], [10, "End", ""]]), None),
    (variant(Markers=[[0, "Slowmo", "0.5"], [10, "End", ""]]), None),
    (variant(Markers=[[0, "Slowmo", ".8"], [10, "End", ""]]), None),
    (variant(Markers=[[0, "Slowmo", 0.25], [10, "End", ""]]), None),
    (variant(Markers=[[0, "Slowmo", 1], [10, "End", ""]]), None),
    (variant(Markers=[[0, "Slowmo"], [10, "End", ""]]), "Slowmo marker 1 must be a number from 0.05 to 1"),
    (variant(Cues={"VFX:Burst": {"kind": "vfx", "preset": "Burst", "yaw": "left"}}), "Cues[VFX:Burst].yaw must be a number of degrees"),
    (variant(Cues={"VFX:Burst": {"kind": "vfx"}}), "Cues[VFX:Burst].preset nil is not a VFX preset"),
    (variant(Cues={"VFX:Burst": {"kind": "vfx", "preset": 5}}), "Cues[VFX:Burst].preset 5 is not a VFX preset"),
    (variant(Cues={"VFX:Burst": {"kind": "vfx", "preset": "Nope", "external": False}}), "Cues[VFX:Burst].preset Nope is not a VFX preset"),
    (variant(Cues={"VFX:Burst": {"kind": "vfx", "preset": 5, "external": True}}), "Cues[VFX:Burst].preset must be a string"),
    (variant(Cues={"VFX:Burst": 7}), "Cues[VFX:Burst] needs a kind: vfx, screen, sfx or face"),
    (variant(Cues="x"), "Cues must be a table of marker = cue"),
    (variant(Config__Cooldown="soon"), "Config.Cooldown must be a number of seconds >= 0"),
    (variant(Config__Awakened={"At": -1}), "Config.Awakened.At must be a time inside the scene"),
    (variant(Config__Awakened={"Look": "eyes"}), "Config.Awakened.Look must be a list of eyes, outline or tint"),
    (variant(Config__Awakened={"Duration": "long"}), "Config.Awakened.Duration must be a number of seconds > 0"),
]


class ContractTest(unittest.TestCase):
    def test_python_reports_each_case(self):
        for example, want in CASES:
            found = schema.validate(example)
            if want is None:
                self.assertEqual(found, [], example)
            else:
                self.assertIn(want, found)

    @unittest.skipUnless(luaurun.find(), "luau is not installed")
    def test_luau_reports_the_same_problems(self):
        examples = [copy.deepcopy(e) for e, _ in CASES]
        luau = luaurun.data_problems(examples)
        self.assertEqual(len(luau), len(examples))
        for example, got in zip(examples, luau):
            self.assertEqual(sorted(got), sorted(schema.validate(example)), example)

    @unittest.skipUnless(luaurun.find(), "luau is not installed")
    def test_every_luau_file_parses(self):
        self.assertEqual(luaurun.parse_all(), [])

    def test_new_patterns_refuse_a_trailing_newline(self):
        self.assertIsNone(schema.FOLLOW.match("player.Head\n"))
        self.assertIsNotNone(schema.FOLLOW.match("player.Head"))
        self.assertIsNone(schema.HEX6.match("ffd9a0\n"))
        self.assertIsNotNone(schema.HEX6.match("ffd9a0"))

    def test_unhashable_values_are_reported_not_raised(self):
        found = schema.validate(variant(Config__Element=["teal"], Config__Awakened={"Aura": {}, "Element": []}))
        self.assertTrue(any(p.startswith("Config.Element ") for p in found))
        self.assertTrue(any(p.startswith("Config.Awakened.Aura ") for p in found))

    def test_slowmo_refuses_nan_and_infinity(self):
        for v in (float("nan"), float("inf"), float("-inf"), True):
            found = schema.validate(variant(Markers=[[0, "Slowmo", v], [10, "End", ""]]))
            self.assertIn("Slowmo marker 1 must be a number from 0.05 to 1", found, v)

    def test_every_preset_resolves_every_role_for_every_element(self):
        import vfxlib
        lib = vfxlib.load()
        used = vfxlib.roles_used(lib)
        self.assertIn("accent", used)
        for name, pal in lib["elements"].items():
            missing = sorted(r for r in used if r not in pal)
            self.assertEqual(missing, [], f"element {name} lacks roles used by presets")

    def test_long_string_never_closes_early(self):
        for text in ("a]]b", "x]=]y]==]", "\nstarts with a newline", ""):
            lit = luaurun.long_string(text)
            level = lit.index("[", 1) - 1
            self.assertTrue(lit.endswith("]" + "=" * level + "]"))
            self.assertEqual(lit[level + 3:-(level + 2)], text)


if __name__ == "__main__":
    unittest.main()
