"""Tests for the working folder (paths.work_dir, check_id; kit/workspace.py). Method by fwjelaa (FWJ STUDIOS)."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import paths  # noqa: E402
import workspace  # noqa: E402


class WorkspaceTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.env = {"MAKE_CUTSCENE_WORK": self.tmp.name}

    def test_work_dir_env_wins(self):
        self.assertEqual(paths.work_dir(self.env), Path(self.tmp.name))

    def test_work_dir_from_config(self):
        pack = Path(self.tmp.name) / "pack"
        pack.mkdir()
        (pack / "config.json").write_text('{"user_id": "1", "work_dir": "D:/cut work"}', encoding="utf-8")
        self.assertEqual(paths.work_dir({}, pack), Path("D:/cut work"))

    def test_work_dir_default(self):
        pack = Path(self.tmp.name) / "empty"
        pack.mkdir()
        self.assertEqual(paths.work_dir({}, pack), Path.home() / "make-cutscene")

    def test_bad_ids_are_refused(self):
        for bad in ("Gate-Guard", "gate guard", "1Gate", "", "x" * 61, "Gaté", 'Gate"Guard'):
            with self.assertRaises(SystemExit) as e:
                paths.check_id(bad)
            self.assertIn("letters, digits and _", str(e.exception))
        self.assertEqual(paths.check_id("Gate_Guard2"), "Gate_Guard2")

    def test_ids_must_fit_blenders_63_byte_names(self):
        longest = max(paths.BLENDER_SUFFIXES, key=len)
        self.assertTrue(longest.startswith("_npc99_"))
        self.assertLessEqual(paths.MAX_ID + len(longest), paths.BLENDER_NAME_LIMIT)
        self.assertEqual(paths.BLENDER_NAME_LIMIT, 63)
        ok = "A" * paths.MAX_ID
        self.assertEqual(paths.check_id(ok), ok)
        self.assertLessEqual(len((ok + longest).encode()), 63)
        self.assertLessEqual(len(("CS_" + ok).encode()), 63)
        with self.assertRaises(SystemExit) as e:
            paths.check_id("A" * (paths.MAX_ID + 1))
        self.assertIn(f"at most {paths.MAX_ID}", str(e.exception))
        self.assertIn("63", str(e.exception))
        self.assertIn("letters, digits and _", str(e.exception))

    def test_create_makes_every_folder_and_keeps_notes(self):
        root = workspace.create("GateGuard", env=self.env)
        self.assertEqual(root, Path(self.tmp.name) / "cutscenes" / "GateGuard")
        for name in workspace.FOLDERS:
            self.assertTrue((root / name).is_dir(), name)
        (root / "notes.md").write_text("mine", encoding="utf-8")
        workspace.create("GateGuard", env=self.env)
        self.assertEqual((root / "notes.md").read_text(encoding="utf-8"), "mine")

    def test_unknown_kind_is_refused(self):
        with self.assertRaises(SystemExit):
            workspace.create("A", kind="movie", env=self.env)

    def test_open_missing_explains(self):
        with self.assertRaises(SystemExit) as e:
            workspace.open_("Nope", env=self.env)
        self.assertIn("py kit/run.py new Nope", str(e.exception))

    def test_write_json_is_utf8_lf_and_round_trips(self):
        p = Path(self.tmp.name) / "a" / "x.json"
        workspace.write_json(p, {"t": "Halt — “stop” 🙂"})
        raw = p.read_bytes()
        self.assertNotIn(b"\r\n", raw)
        self.assertTrue(raw.endswith(b"\n"))
        self.assertFalse(p.with_suffix(".json.tmp").exists())
        self.assertEqual(workspace.read_json(p)["t"], "Halt — “stop” 🙂")

    def test_read_json_names_the_bad_file(self):
        p = Path(self.tmp.name) / "bad.json"
        p.write_text("{", encoding="utf-8")
        with self.assertRaises(SystemExit) as e:
            workspace.read_json(p)
        self.assertIn("bad.json", str(e.exception))


if __name__ == "__main__":
    unittest.main()
