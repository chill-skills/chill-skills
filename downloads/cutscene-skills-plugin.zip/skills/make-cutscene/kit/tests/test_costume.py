"""Tests for kit/costume.py: costume specs for adapted characters (spec 14). Method by fwjelaa (FWJ STUDIOS)."""
import copy
import email.message
import http.client
import io
import sys
import tempfile
import unittest
import urllib.error
import urllib.parse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import clip  # noqa: E402
import costume  # noqa: E402
import rigcap  # noqa: E402
import workspace  # noqa: E402

HERO = {"version": 1, "role": "player", "character": "Hero", "source": "Test reference, CC BY 4.0", "kind": "humanoid",
        "body": {"head": "#f1c9a5", "torso": "#d9d4c7", "left_arm": "#f1c9a5", "right_arm": "#f1c9a5",
                 "left_leg": "#4e3d30", "right_leg": "#4e3d30"},
        "film": {"torso": "#cbc4b5"}, "scale": {"height": 0.95, "width": 0.8},
        "catalog": [{"slot": "hair", "id": 123456, "type": "HairAccessory", "name": "Red Bob", "creator": "Roblox",
                     "why": "short red bob like the reference's fringe and length"},
                    {"slot": "shirt", "id": 777, "type": "Shirt", "name": "Cream Tunic", "creator": "Someone",
                     "why": "cream tunic with the same collar"}],
        "likeness": {"look": 1.0, "ref": [{"video": 2.5, "crop": [0.3, 0.0, 0.75, 1.0]}]}}

# a spec from before spec 14.3: parts built in the place. validate() refuses it; proxies() still places its stand-ins.
LEGACY = dict(copy.deepcopy(HERO), catalog=[{
    "slot": "hair", "id": 123456, "type": "HairAccessory", "name": "Red Bob", "creator": "Roblox", "why": "x",
    "proxy": {"at": "HairAttachment", "shape": "sphere", "size": [1.3, 0.8, 1.3], "offset": [0, -0.1, 0.05],
              "color": "#b4472e"}}], built=[
    {"name": "Sword", "at": "RightGripAttachment", "parts": [
        {"size": [0.2, 0.7, 0.2], "offset": [0, 0, 0], "color": "#3a2a1e", "material": "Wood"},
        {"size": [0.1, 2.4, 0.3], "offset": [0, 1.7, 0], "color": "#c9ced6", "material": "Metal"}]},
    {"name": "Glow", "at": "HatAttachment", "parts": [
        {"shape": "sphere", "size": [0.5, 0.5, 0.5], "offset": [0, 0.2, 0], "color": "#e070ff",
         "material": "Neon", "transparency": 0.2, "light": {"color": "#e070ff", "range": 10, "brightness": 2}}]}])


def item(slot, id_, type_):
    return {"slot": slot, "id": id_, "type": type_, "name": "n", "creator": "c", "why": "matches"}


# a held prop (ledger 2b): an object held in a hand that the catalog doesn't have, built from shapes at a grip
SWORD = {"name": "Sword", "at": "RightGripAttachment", "why": "her short sword, drawn in the right hand",
         "film": "#7d848b", "parts": [
             {"size": [0.18, 0.6, 0.18], "offset": [0, 0, 0], "color": "#2b2420", "material": "Leather"},
             {"size": [0.08, 2.2, 0.28], "offset": [0, 1.5, 0], "color": "#7d848b", "material": "Metal"}]}


def armed(*props):
    return dict(copy.deepcopy(HERO), props=[copy.deepcopy(p) for p in props])


def creature():
    return costume.starter("npc1", "creature", "Beast", "Test reference, CC BY 4.0")


class SpecTest(unittest.TestCase):
    def test_starters_and_the_example_are_valid(self):
        self.assertEqual(costume.validate(HERO, "player"), [])
        self.assertEqual(costume.validate(costume.starter("npc2", "humanoid", "Guard", "credit"), "npc2"), [])
        self.assertEqual(costume.validate(creature(), "npc1"), [])

    def test_outside_art_is_refused_wherever_it_hides(self):
        for where in ("top", "part", "catalog"):
            s = copy.deepcopy(HERO) if where != "part" else creature()
            if where == "top":
                s["meshId"] = "rbxassetid://1"
            elif where == "part":
                s["parts"]["Body"]["TextureID"] = "rbxassetid://2"
            else:
                s["catalog"][0]["image_url"] = "https://example.com/hair.png"
            found = costume.validate(s, "player" if where != "part" else "npc1")
            self.assertTrue(any("never brings in" in p for p in found), (where, found))

    def test_wrong_values_are_named(self):
        s = copy.deepcopy(HERO)
        s["body"]["torso"] = "red"
        s["scale"]["height"] = 1.4
        s["catalog"][0]["id"] = "123456"
        s["catalog"][1]["type"] = "Hat"
        del s["catalog"][1]["why"]
        s["catalog"].append({"slot": "cape", "id": 5, "name": "x", "creator": "y"})
        found = "\n".join(costume.validate(s, "npc1"))
        for bit in ("body.torso must be #rrggbb", "scale.height must be 0.9-1.05", "catalog[1].id",
                    "catalog[2].type is Hat but a shirt slot takes", "catalog[2].why is needed", "catalog[3].slot",
                    "role is player but the file is cast/npc1.json"):
            self.assertIn(bit, found)

    def test_a_catalog_item_carries_its_asset_type_and_why(self):
        s = copy.deepcopy(HERO)
        del s["catalog"][0]["type"]
        s["catalog"][1]["why"] = "  "
        found = "\n".join(costume.validate(s))
        self.assertIn("catalog[1].type must be the catalog asset type", found)
        self.assertIn("catalog[2].why is needed", found)

    def test_a_humanoid_is_never_built_from_parts(self):
        found = "\n".join(costume.validate(LEGACY, "player"))
        self.assertIn("built[1] (Sword)", found)
        self.assertIn("built[2] (Glow)", found)
        self.assertIn("search the marketplace", found)
        self.assertIn("catalog[1].proxy", found)
        s = copy.deepcopy(HERO)
        s["built"] = []
        self.assertEqual(costume.validate(s, "player"), [])  # an empty list is no accessory
        self.assertEqual(costume.validate(creature(), "npc1"), [])  # creatures keep their built parts

    def test_a_second_shirt_and_a_missing_credit_are_refused(self):
        s = copy.deepcopy(HERO)
        s["source"] = " "
        s["catalog"] += [item("shirt", 8, "Shirt")]
        found = "\n".join(costume.validate(s))
        self.assertIn("source is needed", found)
        self.assertIn("2 shirt items", found)

    def test_r6_does_not_render_layered_clothing(self):
        s = copy.deepcopy(HERO)
        s["catalog"] = [item("hair", 1, "HairAccessory"), item("layered_jacket", 2, "JacketAccessory"),
                        item("layered_pants", 3, "PantsAccessory")]
        found = "\n".join(costume.validate(s, "player"))
        self.assertIn("R6 doesn't render layered clothing: add a classic Shirt and Pants", found)
        self.assertIn("torso", found)
        self.assertIn("legs", found)
        # every humanoid gets an R6 copy (an NPC is built as R15 and R6), so an NPC needs the classic pair too
        s["role"] = "npc1"
        self.assertIn("R6 doesn't render", "\n".join(costume.validate(s, "npc1")))
        self.assertIn("R6 doesn't render", "\n".join(costume.validate(s, "npc1", rig="R6")))
        # classic items beside the layered ones are the fix, and the layered ones stay as R15 extras
        s["catalog"] += [item("shirt", 4, "Shirt"), item("pants", 5, "Pants")]
        s["role"] = "player"
        self.assertEqual(costume.validate(s, "player"), [])
        # only the torso pieces need a Shirt, only the leg pieces a Pants
        s["catalog"] = [item("layered_jacket", 2, "JacketAccessory"), item("pants", 5, "Pants")]
        found = "\n".join(costume.validate(s, "player"))
        self.assertIn("torso", found)
        self.assertNotIn("legs", found)

    def test_catalog_duplicates_and_too_many_accessories(self):
        s = copy.deepcopy(HERO)
        s["catalog"].append(item("hat", 123456, "Hat"))
        self.assertIn("id 123456 is listed twice", "\n".join(costume.validate(s)))
        s = copy.deepcopy(HERO)
        s["catalog"] = [item("hat", 100 + i, "Hat") for i in range(11)]
        self.assertIn("11 accessories", "\n".join(costume.validate(s)))

    def test_a_creature_part_may_be_named_curly(self):
        s = creature()
        s["parts"]["Curly_Tail"] = dict(s["parts"]["FootL"])
        s["joints"].append(["Tail", "Body", "Curly_Tail", [0, 0, 1], [0, 0, 0]])
        self.assertEqual(costume.validate(s, "npc1"), [])

    def test_the_player_is_never_a_creature(self):
        s = creature()
        s["role"] = "player"
        self.assertIn("the player wears a humanoid costume", "\n".join(costume.validate(s)))

    def test_a_creature_needs_a_head_feet_and_joints_in_order(self):
        s = creature()
        s["parts"]["Snout"] = s["parts"].pop("Head")
        s["joints"][1][2] = "Snout"
        self.assertIn("parts needs a Head", "\n".join(costume.validate(s)))
        s = creature()
        s["joints"][0], s["joints"][1] = s["joints"][1], s["joints"][0]
        found = "\n".join(costume.validate(s))
        self.assertIn("joints[1] must join HumanoidRootPart", found)
        self.assertIn("Body has no joint yet", found)
        s = creature()
        s["feet"] = ["Tail"]
        self.assertIn("feet must list", "\n".join(costume.validate(s)))

    def test_a_creature_that_floats_names_its_real_stand(self):
        s = creature()
        s["stand"] = 2.0
        self.assertIn("feet sit 0.40 studs above the floor: set stand to 1.60", "\n".join(costume.validate(s)))

    def test_likeness_refs_and_crops(self):
        s = copy.deepcopy(HERO)
        s["likeness"] = {"look": 1, "ref": [{"video": 1, "panel": "ref/panel_01.png"}, {"panel": "p.png"},
                                            {"video": 2}]}
        self.assertIn("likeness.ref must list 1-2", "\n".join(costume.validate(s)))
        s["likeness"]["ref"] = [{"panel": "ref/panel_01.png", "crop": [0.5, 0, 0.4, 1]}]
        self.assertIn("crop must be", "\n".join(costume.validate(s)))


class PropTest(unittest.TestCase):
    """A humanoid's held props (ledger 2b): built shapes, only at a hand grip, only for held objects."""

    def found(self, *props):
        return "\n".join(costume.validate(armed(*props), "player"))

    def test_a_held_prop_is_valid_in_either_hand(self):
        self.assertEqual(costume.validate(armed(SWORD), "player"), [])
        torch = dict(copy.deepcopy(SWORD), name="Torch", at="LeftGripAttachment")
        del torch["film"]  # optional, like a catalog item's
        self.assertEqual(costume.validate(armed(SWORD, torch), "player"), [])
        self.assertEqual(costume.validate(dict(copy.deepcopy(HERO), props=[]), "player"), [])

    def test_a_prop_is_held_at_a_grip_and_nowhere_else(self):
        for at in ("HatAttachment", "WaistBackAttachment", "RightHand", None):
            found = self.found(dict(SWORD, at=at))
            self.assertIn("props[1] (Sword).at must be RightGripAttachment or LeftGripAttachment", found, at)
            self.assertIn("search the marketplace", found, at)  # anything worn comes from the catalog

    def test_bad_props_are_named(self):
        big = copy.deepcopy(SWORD)
        big["parts"][1]["size"] = [0.1, 9, 0.3]
        far = copy.deepcopy(SWORD)
        far["parts"][1]["offset"] = [0, 9, 0, 0, 0, 30]
        red = copy.deepcopy(SWORD)
        red["parts"][0]["color"] = "red"
        cases = [
            (dict(SWORD, parts=[]), "props[1] (Sword).parts must list 1-12 parts"),
            (dict(SWORD, parts=[SWORD["parts"][0]] * 13), "props[1] (Sword).parts must list 1-12 parts"),
            (big, "props[1] (Sword).parts[2].size: a held prop's part is at most 8 studs a side"),
            (far, "props[1] (Sword).parts[2].offset: a held prop's part sits at most 8 studs from the grip"),
            (red, "props[1] (Sword).parts[1].color must be #rrggbb"),
            (dict(SWORD, why="  "), "props[1] (Sword).why is needed"),
            ({k: v for k, v in SWORD.items() if k != "why"}, "props[1] (Sword).why is needed"),
            (dict(SWORD, film="grey"), "props[1] (Sword).film must be #rrggbb"),
            (dict(SWORD, glow=True), "props[1] (Sword): unknown keys glow"),
            (dict(SWORD, name="1st"), "props[1] (1st).name must start with a letter"),
            (dict(SWORD, name="RightHand"), "props[1] (RightHand).name must start with a letter"),
            ("Sword", "props[1] must be an object"),
        ]
        for prop, want in cases:
            self.assertIn(want, self.found(prop), want)
        self.assertIn("props must be a list", "\n".join(costume.validate(dict(copy.deepcopy(HERO), props={}))))

    def test_a_name_is_used_once_and_a_hand_holds_one_prop(self):
        self.assertIn("props: Sword is named twice", self.found(SWORD, dict(SWORD, at="LeftGripAttachment")))
        self.assertIn("props: RightGripAttachment holds Sword and Dagger; a hand holds one prop",
                      self.found(SWORD, dict(SWORD, name="Dagger")))

    def test_built_is_still_refused_for_a_humanoid_with_its_message(self):
        s = armed(SWORD)
        s["built"] = copy.deepcopy(LEGACY["built"])
        found = costume.validate(s, "player")
        self.assertIn(f"built[1] (Sword): a humanoid is never dressed with parts built in the place; {costume.MARKET}",
                      found)
        self.assertEqual(len(found), 2, found)  # built[1] and built[2]; the held prop itself is fine

    def test_a_creature_has_no_props(self):
        s = creature()
        s["props"] = [copy.deepcopy(SWORD)]
        self.assertIn("unknown keys for a creature: props", "\n".join(costume.validate(s, "npc1")))

    def test_a_prop_never_brings_art_in(self):
        p = copy.deepcopy(SWORD)
        p["parts"][1]["MeshId"] = "rbxassetid://5"
        self.assertIn("never brings in", self.found(p))

    def test_items_on_lists_the_held_props_on_both_rigs(self):
        for rig in ("R15", "R6"):
            held = [c for c in costume.items_on(armed(SWORD), rig) if c.get("held")]
            self.assertEqual([c["name"] for c in held], ["Sword"], rig)
            self.assertEqual(held[0]["rigs"], ["R15", "R6"])
        self.assertEqual(costume.colors(armed(SWORD), "R15"), costume.colors(HERO, "R15"))  # a prop paints no region


class DefaultFaceTest(unittest.TestCase):
    """A face accessory with no classic face hides the head's default face (the classic smile) on both rigs: it showed
    through the accessory's see-through parts on R6 (AyanokojiFight's Studio round, ledger 2b ruling)."""

    def test_a_face_accessory_without_a_classic_face_hides_the_default_face(self):
        masked = dict(copy.deepcopy(HERO), catalog=HERO["catalog"] + [item("face_acc", 9, "FaceAccessory")])
        for rig in ("R15", "R6"):
            self.assertTrue(costume.hides_default_face(masked, rig), rig)
            self.assertFalse(costume.hides_default_face(HERO, rig), rig)  # no face accessory: the default face stays
            faced = dict(masked, catalog=masked["catalog"] + [item("face", 10, "Face")])
            self.assertFalse(costume.hides_default_face(faced, rig), rig)  # a classic face is kept
        self.assertFalse(costume.hides_default_face(creature(), "R15"))

    def test_both_rigs_wear_the_slots_studio_decides_from(self):
        # Studio decides from the items each rig wears (Costume.items): both slots reach both rigs
        self.assertEqual(costume.item_rigs("face_acc"), ["R15", "R6"])
        self.assertEqual(costume.item_rigs("face"), ["R15", "R6"])


class RigTest(unittest.TestCase):
    def test_creature_rig_is_a_captured_rig_with_its_own_feet(self):
        r = costume.creature_rig(creature())
        self.assertEqual(r["rigType"], "R15")
        self.assertAlmostEqual(r["hipHeight"], 0.6)
        self.assertAlmostEqual(r["foot"], 1.6)
        self.assertEqual(r["joints"][1][3], clip.cframe(0, 0.8, -1.6))
        frames = rigcap.rest_frames(r)
        self.assertEqual([round(v, 4) for v in frames["Head"][:3]], [0.0, 0.8, -2.1])
        self.assertEqual(r["feet"], ["FootL", "FootR"])
        self.assertEqual(r["colors"]["Body"], "7a6a58")

    def test_proxies_sit_on_the_attachment_of_each_rig(self):
        p15 = {p["name"]: p for p in costume.proxies(LEGACY, "R15")}
        p6 = {p["name"]: p for p in costume.proxies(LEGACY, "R6")}
        self.assertEqual(sorted(p15), ["Glow_1", "Sword_1", "Sword_2", "hair_123456_1"])
        self.assertEqual(p15["Glow_1"]["part"], "Head")
        self.assertEqual([round(v, 4) for v in p15["Glow_1"]["cf"][:3]], [0.0, 0.79, 0.0])  # measured Hat (0, 0.59, 0) + 0.2
        self.assertEqual(p6["Sword_2"]["part"], "Right Arm")
        # spike S16: the R6 grip is not turned (0, 0, 0): the offset (0, 1.7, 0) is added to (0, -1, 0)
        self.assertEqual([round(v, 4) for v in p6["Sword_2"]["cf"][:3]], [0.0, 0.7, 0.0])
        # the R15 grip is turned -90 degrees about X: its +Y runs out of the front of the fist (-Z)
        p15s = {p["name"]: p for p in costume.proxies(LEGACY, "R15")}
        self.assertEqual([round(v, 4) for v in p15s["Sword_2"]["cf"][:3]], [0.0, -0.158, -1.7])
        self.assertEqual(costume.ATTACH["RightGripAttachment"]["R6"][2], (0, 0, 0))
        self.assertEqual(costume.proxies(creature(), "R15"), [])
        self.assertEqual(costume.proxies(HERO, "R15"), [])  # a catalog-dressed humanoid has nothing built

    def test_colors_follow_regions_and_the_film_look(self):
        c15, c6 = costume.colors(HERO, "R15"), costume.colors(HERO, "R6")
        self.assertEqual(c15["RightLowerArm"], "#f1c9a5")
        self.assertEqual(c15["UpperTorso"], "#cbc4b5")  # film wins over the body colour
        self.assertEqual(c6["Left Leg"], "#4e3d30")
        self.assertEqual(costume.colors(creature(), "R15")["Head"], "#7a6a58")
        self.assertEqual(costume.hex3("#b4472e"), "b43")


class FolderTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = workspace.create("CostumeTry", env={"MAKE_CUTSCENE_WORK": self.tmp.name})
        b = beats.draft("CostumeTry", {"type": "words", "text": "x"}, [beats.shot("HERO", 2.0)])
        b["cast"]["npc1"] = {"name": "Guard", "model": "default", "rig": "R15", "place": [0, 0, -8, 0, 180, 0]}
        beats.save(b, self.root)

    def b(self):
        return beats.load(self.root)

    def test_new_writes_a_starter_and_dresses_the_role(self):
        path = costume.new(self.root, self.b(), "npc1", "creature", "Beast", "credit")
        self.assertTrue(path.exists())
        self.assertEqual(self.b()["cast"]["npc1"]["model"], "costume")
        self.assertEqual(costume.roles(self.b()), ["npc1"])
        with self.assertRaises(SystemExit):
            costume.new(self.root, self.b(), "npc1", "creature", "Beast", "credit")
        problems, lines = costume.run(self.root, self.b())
        self.assertEqual(problems, [])
        self.assertTrue((self.root / "rigs" / "npc1.json").exists())
        self.assertIn("COSTUMES: all clear", lines[-1])

    def test_check_names_missing_and_unworn_files(self):
        b = self.b()
        b["cast"]["player"]["model"] = "costume"
        beats.save(b, self.root)
        workspace.write_json(costume.spec_path(self.root, "npc3"), creature())
        found = "\n".join(costume.check(self.root, self.b()))
        self.assertIn("player wears a costume but cast/player.json is missing", found)
        self.assertIn("cast/npc3.json is not worn", found)

    def test_player_costumes_are_for_story_and_intro_scenes(self):
        b = self.b()
        b["kind"] = "awakening"
        b["cast"]["player"]["model"] = "costume"
        beats.save(b, self.root)
        workspace.write_json(costume.spec_path(self.root, "player"), HERO)
        self.assertIn("only in story and intro scenes", "\n".join(costume.check(self.root, self.b())))

    def test_derives_r6_and_install_specs(self):
        costume.new(self.root, self.b(), "npc1", "humanoid", "Guard", "credit")
        costume.new(self.root, self.b(), "npc2", "creature", "Beast", "credit")
        b = self.b()
        self.assertTrue(costume.derives_r6(self.root, "player", b["cast"]["player"]))
        self.assertTrue(costume.derives_r6(self.root, "npc1", b["cast"]["npc1"]))
        self.assertFalse(costume.derives_r6(self.root, "npc2", b["cast"]["npc2"]))
        specs = costume.install_specs(self.root, b)
        self.assertEqual(sorted(specs), ["npc1", "npc2"])
        self.assertNotIn("source", specs["npc1"])

    def test_gate_problems_want_a_likeness_and_r6_clips(self):
        costume.new(self.root, self.b(), "npc1", "humanoid", "Guard", "credit")
        found = "\n".join(costume.gate_problems(self.root, self.b(), {"length": 2.0, "clips": {"R15": {"npc1": "x"}}}))
        self.assertIn("has no likeness", found)
        self.assertIn("no R6 clip for it", found)
        spec = workspace.read_json(costume.spec_path(self.root, "npc1"))
        spec["likeness"] = {"look": 9.0, "ref": [{"video": 1.0}]}
        workspace.write_json(costume.spec_path(self.root, "npc1"), spec)
        found = "\n".join(costume.gate_problems(self.root, self.b(), {"length": 2.0, "clips": {"R6": {"npc1": "y"}}}))
        self.assertIn("likeness.look must be a time inside the scene", found)
        self.assertNotIn("no R6 clip", found)

    def test_an_empty_catalog_is_flagged_at_the_gate(self):
        costume.new(self.root, self.b(), "npc1", "humanoid", "Guard", "credit")
        found = "\n".join(costume.gate_problems(self.root, self.b(), {"length": 2.0, "clips": {}}))
        self.assertIn("cast/npc1.json has no catalog items", found)

    def test_install_specs_keep_what_studio_builds_and_say_which_rig_wears_what(self):
        b = self.b()
        b["cast"]["player"]["model"] = "costume"
        beats.save(b, self.root)
        spec = copy.deepcopy(HERO)
        spec["catalog"].append(dict(item("layered_jacket", 9, "JacketAccessory"), name="Coat"))
        workspace.write_json(costume.spec_path(self.root, "player"), spec)
        got = costume.install_specs(self.root, self.b())["player"]
        for gone in ("likeness", "notes", "source", "film"):
            self.assertNotIn(gone, got)
        self.assertEqual([(c["slot"], c["id"], c["type"]) for c in got["catalog"]],
                         [("hair", 123456, "HairAccessory"), ("shirt", 777, "Shirt"), ("layered_jacket", 9,
                                                                                         "JacketAccessory")])
        for c in got["catalog"]:
            self.assertNotIn("why", c)
            self.assertNotIn("creator", c)
        self.assertEqual([c["rigs"] for c in got["catalog"]], [["R15", "R6"], ["R15", "R6"], ["R15"]])
        self.assertEqual([c["id"] for c in costume.catalog_for(got, "R6")], [123456, 777])
        self.assertEqual([c["id"] for c in costume.catalog_for(got, "R15")], [123456, 777, 9])
        self.assertNotIn("props", got)  # no held prop: nothing more is sent

    def test_install_specs_carry_held_props_for_studio_to_build(self):
        b = self.b()
        b["cast"]["player"]["model"] = "costume"
        beats.save(b, self.root)
        workspace.write_json(costume.spec_path(self.root, "player"), armed(SWORD))
        got = costume.install_specs(self.root, self.b())["player"]
        # the why and the film colour stay on disk, like a catalog item's; both rigs hold every prop
        self.assertEqual(got["props"], [{"name": "Sword", "at": "RightGripAttachment", "parts": SWORD["parts"]}])
        problems, lines = costume.run(self.root, self.b())
        self.assertEqual(problems, [])
        text = "\n".join(lines)
        self.assertIn("player: Hero (humanoid, R15 + R6): 2 catalog items, 1 held prop", text)
        self.assertIn("prop Sword in the right hand (RightGripAttachment, 2 parts): her short sword, drawn in the "
                      "right hand", text)

    def test_a_stale_creature_rig_is_flagged(self):
        costume.new(self.root, self.b(), "npc2", "creature", "Beast", "credit")
        scene = {"length": 2.0, "clips": {}}
        self.assertIn("rigs/npc2.json is missing", "\n".join(costume.gate_problems(self.root, self.b(), scene)))
        costume.run(self.root, self.b())
        self.assertNotIn("rigs/npc2.json", "\n".join(costume.gate_problems(self.root, self.b(), scene)))
        spec = workspace.read_json(costume.spec_path(self.root, "npc2"))
        spec["parts"]["Body"]["size"] = [2, 2, 4]
        workspace.write_json(costume.spec_path(self.root, "npc2"), spec)
        self.assertIn("rigs/npc2.json is out of step", "\n".join(costume.gate_problems(self.root, self.b(), scene)))

    def test_a_creature_on_an_r6_rig_is_refused(self):
        # Studio builds a creature as one R15-typed rig and the Director plays Anims.R15[role] on it: an R6 clip would
        # leave it standing still
        costume.new(self.root, self.b(), "npc1", "creature", "Beast", "credit")
        self.assertNotIn("cast.npc1.rig", "\n".join(costume.check(self.root, self.b())))
        b = self.b()
        b["cast"]["npc1"]["rig"] = "R6"
        beats.save(b, self.root)
        self.assertIn("cast.npc1.rig must be R15 (or unset)", "\n".join(costume.check(self.root, self.b())))


class FakeReply:
    def __init__(self, body):
        self.body = body

    def read(self, size=-1):
        return self.body if size is None or size < 0 else self.body[:size]

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class SearchTest(unittest.TestCase):
    REPLY = (b'{"data": [{"id": 111, "itemType": "Asset", "assetType": 8, "name": "Samurai Kabuto", "price": 75,'
             b' "creatorName": "Roblox"},'
             b' {"id": 222, "itemType": "Asset", "assetType": 41, "name": "Ronin Hair"}]}')

    def test_search_reads_the_public_catalog_without_signing_in(self):
        seen = []

        def opener(req, timeout=None):
            seen.append(req)
            return FakeReply(self.REPLY)

        found = costume.search("samurai helmet", limit=10, opener=opener)
        req = seen[0]
        self.assertEqual(req.get_method(), "GET")
        self.assertTrue(req.full_url.startswith("https://catalog.roblox.com/v1/search/items/details?"))
        self.assertIn("Keyword=samurai+helmet", req.full_url)
        self.assertIn("Limit=10", req.full_url)
        self.assertEqual(req.get_header("User-agent"), "fwjelaa-cutscene-kit")
        self.assertFalse(req.has_header("Cookie") or req.has_header("Authorization"))
        self.assertEqual([f["id"] for f in found], [111, 222])
        self.assertEqual(found[0]["type"], "Hat")
        self.assertEqual(found[1]["type"], "HairAccessory")
        self.assertIsNone(found[1]["price"])
        self.assertIn("111", costume.search_lines(found)[0])
        self.assertIn("Hat", costume.search_lines(found)[0])

    def test_search_failures_are_named(self):
        def down(req, timeout=None):
            raise OSError("no network")

        with self.assertRaises(SystemExit) as ctx:
            costume.search("hair", opener=down)
        self.assertIn("catalog search failed", str(ctx.exception))
        with self.assertRaises(SystemExit):
            costume.search("   ", opener=down)
        with self.assertRaises(SystemExit) as ctx:
            costume.search("hair", opener=lambda req, timeout=None: FakeReply(b"not json"))
        self.assertIn("not understood", str(ctx.exception))
        self.assertNotIn("needs the network", str(ctx.exception))

        def cut(req, timeout=None):
            raise http.client.IncompleteRead(b"x")

        with self.assertRaises(SystemExit) as ctx:
            costume.search("hair", opener=cut)
        self.assertIn("catalog search failed", str(ctx.exception))

    def test_search_encodes_the_keyword_and_bounds_the_call(self):
        seen = {}

        def opener(req, timeout=None):
            seen["req"], seen["timeout"] = req, timeout
            return FakeReply(self.REPLY)

        costume.search("a&b=c#d é", opener=opener)
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(seen["req"].full_url).query)
        self.assertEqual(query["Keyword"], ["a&b=c#d é"])
        self.assertEqual(seen["timeout"], costume.SEARCH_TIMEOUT)
        self.assertNotIn("#", seen["req"].full_url)

    def test_search_shows_who_made_each_item(self):
        found = costume.search("samurai", opener=lambda req, timeout=None: FakeReply(self.REPLY))
        self.assertEqual(found[0]["creator"], "Roblox")
        self.assertIn("Roblox", costume.search_lines(found)[0])

    def query(self, **kw):
        seen = []

        def opener(req, timeout=None):
            seen.append(req.full_url)
            return FakeReply(self.REPLY)

        found = costume.search("plain", opener=opener, **kw)
        return urllib.parse.parse_qs(urllib.parse.urlsplit(seen[0]).query), found

    def test_classic_clothing_has_its_own_category(self):
        q, _ = self.query(type="shirt")
        self.assertEqual((q["Category"], q["Subcategory"]), (["Clothing"], ["ClassicShirts"]))
        q, _ = self.query(type="pants")
        self.assertEqual((q["Category"], q["Subcategory"]), (["Clothing"], ["ClassicPants"]))

    def test_hair_and_hats_search_by_keyword_and_are_filtered_by_type(self):
        q, found = self.query(type="hair")  # the hair subcategory answers 400: keyword only
        self.assertNotIn("Category", q)
        self.assertNotIn("Subcategory", q)
        self.assertEqual([f["id"] for f in found], [222])
        _, found = self.query(type="hat")
        self.assertEqual([f["id"] for f in found], [111])
        _, found = self.query()
        self.assertEqual(len(found), 2)

    def test_an_unknown_search_type_is_named(self):
        with self.assertRaises(SystemExit) as ctx:
            costume.search("x", type="cape", opener=lambda req, timeout=None: FakeReply(self.REPLY))
        self.assertIn("--type must be one of", str(ctx.exception))
        self.assertIn("shirt", str(ctx.exception))

    def test_price_is_information_only(self):
        found = costume.search("samurai", opener=lambda req, timeout=None: FakeReply(self.REPLY))
        self.assertIn("price 75", costume.search_lines(found)[0])
        self.assertIn("price ?", costume.search_lines(found)[1])
        # a catalog item may carry any price (the two APIs disagree); the validator never looks at it
        for price in (0, 65, 48, None, "free"):
            s = copy.deepcopy(HERO)
            s["catalog"][0]["price"] = price
            self.assertEqual(costume.validate(s, "player"), [], price)

    def test_the_build_rules_task_5_reads(self):
        self.assertTrue(costume.BUILD["handle_attachment_named_like_body_attachment"])
        self.assertFalse(costume.BUILD["set_accessories_wipe"])
        self.assertIn("never true", costume.BUILD["note"])

    def test_only_the_page_sizes_the_catalog_takes(self):
        # measured 2026-11-08: 10, 28 and 30 answer 200; 50, 60, 100 and 120 answer 400 "Allowed values: 10, 28, 30"
        self.assertEqual(costume.SEARCH_LIMITS, (10, 28, 30))
        for asked, sent in ((10, "10"), (12, "28"), (30, "30"), (60, "30"), (100, "30")):
            q, _ = self.query(limit=asked)
            self.assertEqual(q["Limit"], [sent], asked)


def http_error(code, body=b"", retry_after=None):
    headers = email.message.Message()
    if retry_after is not None:
        headers["Retry-After"] = str(retry_after)
    return urllib.error.HTTPError(costume.SEARCH_URL, code, "x", headers, io.BytesIO(body))


LIMIT_400 = b'{"errors":[{"code":0,"message":"Allowed values: 10, 28, 30","field":"limit"}]}'


class RetryTest(unittest.TestCase):
    """429 and 5xx are asked again with backoff (Retry-After wins); a 400 says what was refused. No network here."""

    def search(self, answers, **kw):
        asked, waits = [], []

        def opener(req, timeout=None):
            asked.append(req.full_url)
            a = answers.pop(0) if len(answers) > 1 else answers[0]
            if isinstance(a, Exception):
                raise a
            return FakeReply(a)

        try:
            return costume.search("sword", opener=opener, wait=waits.append, **kw), asked, waits
        except SystemExit as e:
            return str(e), asked, waits

    def test_a_busy_catalog_is_asked_again_with_backoff(self):
        found, asked, waits = self.search([http_error(429), http_error(503), SearchTest.REPLY])
        self.assertEqual([f["id"] for f in found], [111, 222])
        self.assertEqual(len(asked), 3)
        self.assertEqual(waits, [1, 2])

    def test_retry_after_is_honoured(self):
        found, asked, waits = self.search([http_error(429, retry_after=3), SearchTest.REPLY])
        self.assertEqual(len(found), 2)
        self.assertEqual(waits, [3])

    def test_a_catalog_that_stays_busy_gives_up_with_a_clear_message(self):
        msg, asked, waits = self.search([http_error(429)])
        self.assertEqual(len(asked), 4)
        self.assertEqual(waits, [1, 2, 4])
        self.assertIn("the catalog is busy (HTTP 429)", msg)
        self.assertIn("4 tries", msg)
        self.assertIn("search again in a minute", msg)
        self.assertNotIn("needs the network", msg)
        msg, asked, _ = self.search([http_error(502)])
        self.assertEqual(len(asked), 4)
        self.assertIn("HTTP 502", msg)

    def test_a_long_retry_after_is_not_waited_for(self):
        msg, asked, waits = self.search([http_error(429, retry_after=120)])
        self.assertEqual((len(asked), waits), (1, []))
        self.assertIn("asks to wait 120 s", msg)

    def test_a_refused_page_size_is_named(self):
        msg, asked, waits = self.search([http_error(400, LIMIT_400)], limit=28)
        self.assertEqual((len(asked), waits), (1, []))  # an answer: never asked again
        self.assertIn("the catalog refused page size 28; use 10, 28 or 30", msg)
        self.assertNotIn("needs the network", msg)

    def test_another_refusal_says_what_the_catalog_said(self):
        body = b'{"errors":[{"code":0,"message":"Category subcategory selection not supported."}]}'
        msg, asked, _ = self.search([http_error(400, body)], type="shirt")
        self.assertEqual(len(asked), 1)
        self.assertIn("the catalog refused the search (HTTP 400: Category subcategory selection not supported.)", msg)
        self.assertNotIn("needs the network", msg)
        msg, _, _ = self.search([http_error(403, b"not json")])
        self.assertIn("the catalog refused the search (HTTP 403)", msg)


class CommandTest(unittest.TestCase):
    def test_costume_new_then_check(self):
        import contextlib
        import io
        import os
        from unittest import mock
        import run
        with tempfile.TemporaryDirectory() as d, mock.patch.dict(os.environ, {"MAKE_CUTSCENE_WORK": d}):
            root = workspace.create("CmdTry")
            beats.save(beats.draft("CmdTry", {"type": "words", "text": "x"}, [beats.shot("HERO", 2.0)]), root)
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                code = run.main(["run.py", "costume", "CmdTry", "--new", "npc1", "--kind", "creature",
                                 "--character", "Beast", "--source", "credit"])
            self.assertEqual(code, 0, out.getvalue())
            self.assertIn("npc1: Beast (creature, 4 parts, stands 1.60) -> rigs/npc1.json", out.getvalue())
            with self.assertRaises(SystemExit):
                run.main(["run.py", "costume", "CmdTry", "--new", "npc2"])  # no --character / --source

    def test_costume_search_survives_a_cp1252_console(self):
        import contextlib
        import io
        from unittest import mock
        import run
        reply = (b'{"data": [{"id": 5, "itemType": "Asset", "assetType": 41, "name": "Heart \xe2\x99\xa1 Hair",'
                 b' "price": 10, "creatorName": "Ana \xe2\x99\xa1"}]}')
        raw = io.BytesIO()
        console = io.TextIOWrapper(raw, encoding="cp1252", errors="strict", write_through=True)
        with mock.patch.object(costume, "_open", lambda req, timeout=None: FakeReply(reply)):
            with contextlib.redirect_stdout(console):
                code = run.main(["run.py", "costume", "search", "heart"])
        self.assertEqual(code, 0)
        text = raw.getvalue().decode("cp1252")
        self.assertIn("Heart ? Hair", text)
        self.assertIn("5", text)

    def test_costume_search_type_reaches_the_api(self):
        import contextlib
        import io
        from unittest import mock
        import run
        seen = []

        def fake(req, timeout=None):
            seen.append(req.full_url)
            return FakeReply(SearchTest.REPLY)

        with mock.patch.object(costume, "_open", fake), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(run.main(["run.py", "costume", "search", "plain", "--type", "shirt"]), 0)
        self.assertIn("Subcategory=ClassicShirts", seen[0])

    def test_costume_search_prints_items_and_buys_nothing(self):
        import contextlib
        import io
        from unittest import mock
        import run
        out = io.StringIO()
        with mock.patch.object(costume, "_open", lambda req, timeout=None: FakeReply(SearchTest.REPLY)):
            with contextlib.redirect_stdout(out):
                code = run.main(["run.py", "costume", "search", "samurai helmet"])
        self.assertEqual(code, 0)
        self.assertIn("111", out.getvalue())
        self.assertIn("Samurai Kabuto", out.getvalue())
        with self.assertRaises(SystemExit) as ctx:
            run.main(["run.py", "costume", "search", "hair", "--limit", "abc"])
        self.assertIn("usage", str(ctx.exception))
        self.assertIn("--limit 10|28|30]", str(ctx.exception))  # only the page sizes the catalog takes


if __name__ == "__main__":
    unittest.main()
