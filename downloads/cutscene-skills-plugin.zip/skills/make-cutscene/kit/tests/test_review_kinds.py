"""Tests for the play-test keys of each kind of scene (kit/review.py). Method by fwjelaa (FWJ STUDIOS)."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import review  # noqa: E402
import workspace  # noqa: E402


class ReviewTest(unittest.TestCase):
    def test_an_awakening_has_its_own_play_test(self):
        self.assertIn("aura", review.playtest_keys("awakening"))
        self.assertNotIn("restore-skip", review.playtest_keys("awakening"), "an awakening can't be skipped")
        self.assertEqual(review.playtest_keys("story"), review.PLAYTEST)
        with tempfile.TemporaryDirectory() as d:
            workspace.write_json(Path(d) / "beats.json", {"id": "Wake", "kind": "awakening"})
            lines = review.set_playtest(d, ["aura=pass"])
            self.assertIn("aura: pass", lines)
            with self.assertRaises(SystemExit):
                review.set_playtest(d, ["restore-skip=pass"])


if __name__ == "__main__":
    unittest.main()
