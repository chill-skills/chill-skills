"""Tests for kit/bundle.py. Method by fwjelaa (FWJ STUDIOS)."""
import json
import re
import tempfile
import unittest
from pathlib import Path

import bundle
import clip
import paths
import payload

ROBLOX = paths.PACK / "roblox"


class BundleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.out = Path(cls.tmp.name)
        cls.written = bundle.write_all(cls.out)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def text(self, name):
        # the whole script, joined from its parts when it is over the payload budget (kit/payload.py)
        return payload.joined(self.out, name)

    def test_render_swaps_line_and_raises_without_it(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "t.luau"
            p.write_text("-- head\n" + bundle.EMBED_LINE + "\nreturn EMBED\n", encoding="utf-8")
            out = bundle.render(p, {"a": 1})
            self.assertNotIn(bundle.EMBED_LINE, out)
            self.assertIn("local EMBED = {", out)
            self.assertIn("a = 1", out)
            p.write_text("-- head\nreturn 1\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                bundle.render(p, {})

    def test_write_all_writes_six_files(self):
        names = sorted(p.name for p in self.written if not re.search(r"\.\d+\.luau$", p.name))
        self.assertEqual(names, ["dev.luau", "dev_authoring.luau", "fixture.luau", "fixture_assets.luau",
                                 "fixture_r6.luau", "install.luau"])
        for p in self.written:
            self.assertTrue(p.exists())

    def test_no_http_in_outputs(self):
        for p in self.written:
            s = p.read_text(encoding="utf-8")
            self.assertNotIn("HttpService:GetAsync", s, p.name)
            self.assertNotIn("127.0.0.1", s, p.name)

    def test_install_contains_every_module(self):
        index = json.loads((ROBLOX / "CutsceneKit" / "_index.json").read_text(encoding="utf-8"))
        s = self.text("install.luau")
        for m in index["modules"]:
            self.assertIn(f"CutsceneKit/{m}.luau", s)
        self.assertIn("CutsceneKit/CutsceneKit.luau", s)
        self.assertIn("scripts/CutsceneServer.server.luau", s)
        self.assertIn("scripts/CutsceneClient.client.luau", s)

    def test_dev_embed_has_tests_and_clips(self):
        e = bundle.dev_embed()
        self.assertIn("Smoke", e["tests"])
        self.assertEqual(sorted(e["files"]), ["Test"])
        self.assertIn("Fixture_Walkin_Stage", e["clips"])
        json.loads(e["clips"]["Fixture_Walkin_Stage"])

    def test_dev_and_dev_authoring_split_the_authoring_modules(self):
        core, extra = bundle.dev_embed(), bundle.dev_authoring_embed()
        self.assertEqual(sorted(core["authoring"]), ["ClipBuilder"])
        self.assertNotIn("ClipBuilder", core["files"])
        self.assertIn("Capture", extra["authoring"])
        self.assertIn("Capture", extra["tests"])
        self.assertNotIn("Capture", core["tests"])
        self.assertIn("PlayTest", extra["authoring"])  # payload parts carry it now (Plan 2b Task 1)
        self.assertIn("PlayTest", extra["tests"])
        self.assertEqual(sorted(set(core["authoring"]) | set(extra["authoring"])), sorted(bundle.authoring_modules()))
        all_tests = {p.name[: -len(".test.luau")] for p in (ROBLOX / "tests").glob("*.test.luau")}
        self.assertEqual(set(core["tests"]) | set(extra["tests"]), all_tests)
        self.assertFalse(set(core["tests"]) & set(extra["tests"]))
        self.assertEqual(self.text("dev.luau").count("KeyframeSequence from clip JSON"), 1)
        self.assertIn("Authoring", self.text("dev.luau"))
        self.assertIn("send out/dev.luau first", self.text("dev_authoring.luau"))

    def test_every_output_fits_one_execute_luau(self):
        for p in self.written:
            size = len(p.read_bytes())
            self.assertLessEqual(size, bundle.MAX_BYTES, f"{p.name} is {size} bytes")

    def test_fixture_outputs_differ(self):
        self.assertIn('npcRig = "R15"', self.text("fixture.luau"))
        self.assertIn("useClips = true", self.text("fixture.luau"))
        self.assertIn('npcRig = "R6"', self.text("fixture_r6.luau"))
        self.assertIn("useClips = false", self.text("fixture_assets.luau"))

    def test_outputs_start_with_template_comment(self):
        pairs = {
            "install.luau": ROBLOX / "install.luau",
            "dev.luau": ROBLOX / "dev" / "install_dev.luau",
            "dev_authoring.luau": ROBLOX / "dev" / "install_dev_authoring.luau",
            "fixture.luau": ROBLOX / "dev" / "install_fixture.luau",
            "fixture_r6.luau": ROBLOX / "dev" / "install_fixture.luau",
            "fixture_assets.luau": ROBLOX / "dev" / "install_fixture.luau",
        }
        for out, tpl in pairs.items():
            first = tpl.read_text(encoding="utf-8").split("\n", 1)[0]
            self.assertTrue(first.startswith("--"), tpl.name)
            self.assertEqual(self.text(out).split("\n", 1)[0], first, out)

    def test_embedded_text_round_trips_through_the_luau_literal(self):
        def unescape(lit):
            out, i = [], 1
            while i < len(lit) - 1:
                ch = lit[i]
                if ch == "\\":
                    i += 1
                    ch = {"n": "\n", "\\": "\\", '"': '"'}[lit[i]]
                out.append(ch)
                i += 1
            return "".join(out)

        def strings(v):
            if isinstance(v, str):
                yield v
            elif isinstance(v, dict):
                for x in v.values():
                    yield from strings(x)

        count = 0
        for embed in (bundle.install_embed(), bundle.dev_embed(), bundle.dev_authoring_embed(), bundle.fixture_embed()):
            for src in strings(embed):
                self.assertEqual(unescape(clip._luau_str(src)), src)
                count += 1
        self.assertGreater(count, 10)

    def test_control_characters_in_embedded_files_are_refused(self):
        for bad in ("a\rb", "a\x0cb", "a\x0bb", "a\x00b"):
            with tempfile.TemporaryDirectory() as d:
                p = Path(d) / "Evil.luau"
                p.write_bytes(("x" + bad).encode("utf-8"))
                with self.assertRaises(ValueError) as cm:
                    bundle._read(p)
                self.assertIn("Evil.luau", str(cm.exception))

    def test_crlf_is_normalised_not_refused(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "Ok.luau"
            p.write_bytes(b"a\r\nb\tc\n")
            self.assertEqual(bundle._read(p), "a\nb\tc\n")


if __name__ == "__main__":
    unittest.main()
