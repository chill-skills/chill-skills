"""Tests for the example on-join intro (roblox/examples/IntroOnJoin.server.luau): the real source runs in the real Luau
against stub Players, ReplicatedStorage, characters and the kit's Api. Method by fwjelaa (FWJ STUDIOS)."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import luaurun  # noqa: E402
import paths  # noqa: E402
import payload  # noqa: E402

METHOD = "Method by fwjelaa (FWJ STUDIOS)."
SOURCE = paths.ROBLOX / "examples" / "IntroOnJoin.server.luau"

# load(opts) runs the script once in a fresh world. opts.kit = false (no CutsceneKit), opts.api = false (a kit with no
# Api), opts.scene = false (no data module), opts.invoke = function(...) (the Api's answer), opts.onWait = function(s)
# (runs inside task.wait: a player can leave or die there). task.spawn runs at once and task.wait only moves the clock,
# so everything happens inside the call that fires the event.
HARNESS = """
local SOURCE = %s
local function signal()
	local s = { fns = {} }
	function s:Connect(fn)
		table.insert(self.fns, fn)
		return { Disconnect = function() end }
	end
	function s:Fire(...)
		for _, fn in self.fns do
			fn(...)
		end
	end
	return s
end
local function inst(name, class, children)
	local o = { Name = name, ClassName = class, kids = children or {} }
	function o:IsA(c)
		return c == self.ClassName
	end
	function o:FindFirstChild(n)
		return self.kids[n]
	end
	function o:WaitForChild(n, timeout)
		table.insert(W.waits, n .. "@" .. tostring(timeout))
		return self.kids[n]
	end
	return o
end
W = nil
local function load(opts)
	opts = opts or {}
	W = { T = 0, warned = {}, calls = {}, waits = {} }
	local api = inst("Api", "BindableFunction")
	function api.Invoke(self, ...)
		assert(self == api, "Invoke called as a method")
		table.insert(W.calls, table.pack(...))
		if opts.invoke then
			return opts.invoke(...)
		end
		return true
	end
	local kitKids = {}
	if opts.api ~= false then
		kitKids.Api = api
	end
	local rsKids = {}
	if opts.kit ~= false then
		rsKids.CutsceneKit = inst("CutsceneKit", "ModuleScript", kitKids)
	end
	if opts.scene ~= false then
		rsKids.Cutscenes = inst("Cutscenes", "Folder", { ForbiddenGate = inst("ForbiddenGate", "ModuleScript") })
	end
	local RS = inst("ReplicatedStorage", "ReplicatedStorage", rsKids)
	local Players = { PlayerAdded = signal(), PlayerRemoving = signal(), list = opts.players or {} }
	function Players:GetPlayers()
		return self.list
	end
	W.Players = Players
	for _, p in Players.list do
		p.Parent = Players -- already in the game when the script starts
	end
	local env = setmetatable({
		game = { GetService = function(_, n)
			return (assert(({ Players = Players, ReplicatedStorage = RS })[n], n))
		end },
		task = {
			spawn = function(fn, ...)
				fn(...)
			end,
			wait = function(s)
				W.T += s or 0
				if opts.onWait then
					opts.onWait(s)
				end
				return s
			end,
		},
		warn = function(...)
			table.insert(W.warned, table.concat({ ... }, " "))
		end,
	}, { __index = _G })
	local fn = assert(loadstring(SOURCE, "IntroOnJoin.server"))
	setfenv(fn, env)
	fn()
	return W
end
-- a stand-in Player; spawn(p) gives it a new character and fires CharacterAdded
local function player(name)
	local p = { Name = name, ClassName = "Player", CharacterAdded = signal(), Character = nil, Parent = nil }
	return p
end
local function body(withRoot)
	local c = inst("Character", "Model", withRoot == false and {} or { HumanoidRootPart = inst("HumanoidRootPart", "Part") })
	c.Parent = "Workspace"
	return c
end
local function join(p)
	p.Parent = W.Players
	table.insert(W.Players.list, p)
	W.Players.PlayerAdded:Fire(p)
end
local function spawn(p, c)
	c = c or body()
	p.Character = c
	p.CharacterAdded:Fire(c)
	return c
end
local function calls()
	local out = {}
	for _, c in W.calls do
		table.insert(out, tostring(c[1]) .. ":" .. tostring(c[2] and c[2].Name) .. ":" .. tostring(c[3]) .. ":" .. c.n)
	end
	return table.concat(out, ",")
end
"""


@unittest.skipUnless(luaurun.find(), "luau is not installed")
class IntroOnJoinTest(unittest.TestCase):
    def go(self, scenario):
        src = SOURCE.read_text(encoding="utf-8").replace("\r\n", "\n")
        return luaurun.run(HARNESS % payload.long_string(src) + scenario).splitlines()

    def test_the_first_spawn_plays_the_intro_once(self):
        out = self.go("""
load()
local a = player("A")
join(a)
print(calls(), #W.warned)
spawn(a)
print(calls(), W.T)
spawn(a) -- a respawn on the same server: no replay
print(calls())
local b = player("B")
join(b)
spawn(b)
print(calls(), #W.warned)
""")
        self.assertEqual(out, ["\t0", "Play:A:ForbiddenGate:3\t1.5", "Play:A:ForbiddenGate:3",
                               "Play:A:ForbiddenGate:3,Play:B:ForbiddenGate:3\t0"])

    def test_a_player_already_in_game_when_the_script_starts(self):
        out = self.go("""
local a, b = player("A"), player("B")
a.Character = body()
load({ players = { a, b } })
print(calls())
spawn(b) -- b had no character yet: its first one plays
spawn(a) -- a's respawn does not
print(calls())
""")
        self.assertEqual(out, ["Play:A:ForbiddenGate:3", "Play:A:ForbiddenGate:3,Play:B:ForbiddenGate:3"])

    def test_no_scene_installed_does_nothing(self):
        out = self.go("""
load({ scene = false })
local a = player("A")
join(a)
spawn(a)
print(#W.calls, #W.warned, W.T)
""")
        self.assertEqual(out, ["0\t0\t0"])

    def test_no_kit_does_nothing_and_stops_waiting(self):
        out = self.go("""
load({ kit = false })
local a, b = player("A"), player("B")
join(a)
spawn(a)
join(b)
spawn(b)
print(#W.calls, #W.warned, table.concat(W.waits, ","))
load({ api = false })
local c = player("C")
join(c)
spawn(c)
print(#W.calls, #W.warned, table.concat(W.waits, ","))
""")
        # the kit is waited for once (60 s), not once per player
        self.assertEqual(out, ["0\t0\tCutsceneKit@60", "0\t0\tCutsceneKit@60,Api@60"])

    def test_a_character_without_a_root_is_skipped(self):
        out = self.go("""
load()
local a = player("A")
join(a)
spawn(a, body(false))
print(#W.calls, #W.warned, W.waits[#W.waits])
""")
        self.assertEqual(out, ["0\t0\tHumanoidRootPart@15"])

    def test_a_leave_or_death_during_the_delay_cancels_it(self):
        out = self.go("""
local a
load({ onWait = function() a.Parent = nil end })
a = player("A")
join(a)
spawn(a)
print(#W.calls)
local b
load({ onWait = function() b.Character = body() end })
b = player("B")
join(b)
spawn(b)
print(#W.calls)
""")
        self.assertEqual(out, ["0", "0"])

    def test_it_never_throws(self):
        out = self.go("""
load({ invoke = function() error("boom") end })
local a, b = player("A"), player("B")
join(a)
local ok1 = pcall(spawn, a)
join(b)
local ok2 = pcall(spawn, b)
print(ok1, ok2, #W.calls, #W.warned, string.find(W.warned[1], "boom", 1, true) ~= nil)
load({ invoke = function() return false, "busy" end })
local c = player("C")
join(c)
print(pcall(spawn, c), #W.warned, string.find(W.warned[1], "busy", 1, true) ~= nil)
""")
        # one warning per server, whatever goes wrong
        self.assertEqual(out, ["true\ttrue\t2\t1\ttrue", "true\t1\ttrue"])

    def test_a_leaver_is_forgotten(self):
        out = self.go("""
load()
local a = player("A")
join(a)
spawn(a)
W.Players.PlayerRemoving:Fire(a)
-- the same Player object can't come back (a rejoin is a new Player); a forgotten one plays again, as a new join would
spawn(a)
print(#W.calls)
""")
        self.assertEqual(out, ["2"])

    def test_new_luau_starts_with_the_method_line(self):
        head = SOURCE.read_text(encoding="utf-8").splitlines()[:3]
        self.assertTrue(any(METHOD in line for line in head))


if __name__ == "__main__":
    unittest.main()
