"""Tests for kit/schema.py, the Python twin of CutsceneKit.Data.validate. Method by fwjelaa (FWJ STUDIOS)."""
import copy
import re
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import fixture  # noqa: E402
import paths  # noqa: E402
import schema  # noqa: E402


def good():
    return copy.deepcopy(fixture.module_data())


class SchemaTest(unittest.TestCase):
    def fails(self, data, mention):
        problems = schema.validate(data)
        self.assertTrue(problems, "should be invalid")
        self.assertIn(mention, "; ".join(problems))

    def test_fixture_data_is_valid(self):
        self.assertEqual(schema.validate(fixture.module_data()), [])
        self.assertEqual(schema.validate(fixture.module_data({"Fixture_Walkin_Stage": "123"})), [])

    def test_not_a_table(self):
        self.assertEqual(schema.validate([]), ["the module must return a table"])

    def test_max_length_matches_the_luau_contract(self):
        luau = (paths.PACK / "roblox" / "CutsceneKit" / "Data.luau").read_text(encoding="utf-8")
        self.assertEqual(int(re.search(r"Data\.MAX_LENGTH = (\d+)", luau).group(1)), schema.MAX_LENGTH)
        self.assertEqual(schema.MAX_LENGTH, 30)

    def test_length_over_the_cap(self):
        d = good()
        d["Length"] = 30.5
        self.fails(d, "Length must be more than 0 and at most 30 s")

    def test_name_is_optional_but_a_string(self):
        d = good()
        del d["Name"]
        self.assertEqual(schema.validate(d), [])
        d["Name"] = 5
        self.fails(d, "Name must be a string")

    def test_bad_fov_shape(self):
        d = good()
        d["Fov"] = [[0, 50], [1, "wide"]]
        self.fails(d, "Fov entry 2 must be {time, fov}")

    def test_fov_going_back_in_time(self):
        d = good()
        d["Fov"] = [[0, 50], [2, 40], [1, 55]]
        self.fails(d, "Fov times go backwards at 3")

    def test_fov_outside_1_to_120(self):
        d = good()
        d["Fov"] = [[0, 0.5]]
        self.fails(d, "Fov entry 1 must be 1-120 degrees")

    def test_places_need_six_numbers(self):
        d = good()
        d["Places"]["npc1"] = [0, 0, -8]
        self.fails(d, "Places.npc1 must be 6 numbers")

    def test_anim_refs_are_strings(self):
        d = good()
        d["Anims"]["R6"]["npc1"] = 123
        self.fails(d, "Anims.R6 must map roles to clip refs (strings)")

    def test_lines_need_text(self):
        d = good()
        d["Lines"]["1"] = {"speaker": "Guard"}
        self.fails(d, "Lines[1] needs a text")

    def test_negative_marker_time(self):
        d = good()
        d["Markers"][0] = [-0.1, "Letterbox", "in"]
        self.fails(d, "marker 1 is before 0 s")

    def test_letterbox_marker_value(self):
        d = good()
        d["Markers"][0] = [0.0, "Letterbox", "on"]
        self.fails(d, "Letterbox marker 1 must be in or out")

    def test_skip_type(self):
        d = good()
        d["Config"]["Skip"] = True
        self.fails(d, "Config.Skip must be false or a number of seconds >= 0")
        d["Config"]["Skip"] = False
        self.assertEqual(schema.validate(d), [])

    def test_letterbox_range(self):
        d = good()
        d["Config"]["Letterbox"] = 0.3
        self.fails(d, "Config.Letterbox must be a number from 0 to 0.2")

    def test_style_is_a_string(self):
        d = good()
        d["Config"]["Style"] = 1
        self.fails(d, "Config.Style must be a string")

    def test_markers_must_be_a_list(self):
        d = good()
        d["Markers"] = {1: [0.0, "End", ""]}
        self.fails(d, "Markers must be a list with no gaps")

    def test_fov_inside_the_scene(self):
        d = good()
        d["Fov"] = [[0.0, 50], [7.0, 50]]
        self.fails(d, "Fov entry 2 is outside the scene")

    def test_line_hold_and_voice(self):
        d = good()
        d["Lines"]["1"]["hold"] = 0
        self.fails(d, "Lines[1].hold must be a number of seconds > 0")
        d = good()
        d["Lines"]["1"]["voice"] = 5
        self.fails(d, "Lines[1].voice must be a string")

    def test_config_hide(self):
        d = good()
        d["Config"]["Hide"] = ["Gate/Guard"]
        self.assertEqual(schema.validate(d), [])
        d["Config"]["Hide"] = "Gate/Guard"
        self.fails(d, "Config.Hide must be a list of paths like Gate/Guard")

    def test_hold_edge_values(self):
        for bad in (-1, True, "2"):
            d = good()
            d["Lines"]["1"]["hold"] = bad
            self.fails(d, "Lines[1].hold must be a number of seconds > 0")

    def test_config_hide_entry_must_be_a_string(self):
        d = good()
        d["Config"]["Hide"] = [5]
        self.fails(d, "Config.Hide must be a list of paths like Gate/Guard")

    def test_config_hide_path_rule(self):
        for bad in ("", "/Gate", "Workspace/Gate", "Workspace"):
            d = good()
            d["Config"]["Hide"] = [bad]
            self.fails(d, f"Config.Hide path '{bad}' is not valid")
        d = good()
        d["Config"]["Hide"] = ["Gate/Guard", "WorkspaceGate"]
        self.assertEqual(schema.validate(d), [])


class AnchoredRulesTest(unittest.TestCase):
    """`$` also matches before a final newline; names that reach generated Luau must not carry one."""

    def test_a_trailing_newline_is_refused(self):
        import beats
        import clip
        import costume
        for rule in (schema.ROLE, beats.ROLE, paths.ID_RULE, costume.NAME):
            self.assertIsNone(rule.match("npc1\n"), rule.pattern)
        self.assertIsNotNone(schema.ROLE.match("npc1"))
        self.assertIsNone(paths.ID_RULE.match("Gate\n"))
        self.assertIsNotNone(paths.ID_RULE.match("Gate"))
        self.assertIsNone(costume.HEX.match("#aabbcc\n"))
        self.assertIsNone(clip._IDENT.match("ab\n"))


if __name__ == "__main__":
    unittest.main()
