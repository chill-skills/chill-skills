"""Tests for kit/payload.py: scripts over the execute_luau budget go to Studio in parts. Method by fwjelaa (FWJ STUDIOS)."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import bundle  # noqa: E402
import luaurun  # noqa: E402
import payload  # noqa: E402


def script(kb):
    line = 'local x = "' + "a]]b" * 10 + '" -- ' + "y" * 40 + "\n"
    text = "-- a test script\n"
    while len(text.encode("utf-8")) < kb * 1000:
        text += line
    return text + 'return "done"\n'

FAKE_STUDIO = """
local function make(class)
	local o = { ClassName = class, Name = class, _kids = {}, _attrs = {}, _parent = nil }
	local methods = {}
	function methods.FindFirstChild(self, name)
		for _, k in self._kids do
			if k.Name == name then
				return k
			end
		end
		return nil
	end
	function methods.GetChildren(self)
		return { table.unpack(self._kids) }
	end
	function methods.SetAttribute(self, k, v)
		self._attrs[k] = v
	end
	function methods.GetAttribute(self, k)
		return self._attrs[k]
	end
	function methods.Destroy(self)
		local p = rawget(self, "_parent")
		if p then
			table.remove(p._kids, table.find(p._kids, self))
			rawset(self, "_parent", nil)
		end
	end
	return setmetatable(o, {
		__index = function(self, k) return methods[k] or methods.FindFirstChild(self, k) end,
		__newindex = function(self, k, v)
			if k == "Parent" then
				methods.Destroy(self)
				if v then
					table.insert(v._kids, self)
					rawset(self, "_parent", v)
				end
			else
				rawset(self, k, v)
			end
		end,
	})
end
local storage = make("ServerStorage")
game = { GetService = function(_, name) return storage end }
Instance = { new = make }
require = function(m) return loadstring(m.Source)() end
function STAGING() return storage:FindFirstChild("CutsceneKitStaging") end
function SEND(text) return loadstring(text)() end
"""


class PayloadTest(unittest.TestCase):
    def test_a_small_script_is_one_file(self):
        text = script(10)
        self.assertEqual(payload.parts("install.luau", text), [("install.luau", text)])

    def test_a_big_script_splits_under_the_budget_and_joins_back(self):
        text = script(150)
        parts = payload.parts("install.luau", text)
        self.assertEqual([p[0] for p in parts], ["install.luau", "install.2.luau", "install.3.luau"])
        for name, body in parts:
            self.assertLessEqual(len(body.encode("utf-8")), payload.MAX_BYTES, name)
            self.assertIn("Method by fwjelaa (FWJ STUDIOS).", body.split("\n")[1])
        self.assertEqual("".join(payload._payload(b) for _, b in parts), text)
        self.assertIn('send out/install.2.luau next', parts[0][1])
        self.assertIn("pcall(require, joined)", parts[-1][1])
        self.assertNotIn("pcall(require, joined)", parts[0][1])

    def test_parts_of_one_bundle_share_a_token_that_changes_with_the_text(self):
        a = payload.parts("dev.luau", script(70))
        b = payload.parts("dev.luau", script(70) + "-- changed\n")
        token = lambda body: body.split('"Token", "')[1][:12] if '"Token", "' in body else body.split('~= "')[1][:12]
        self.assertEqual(token(a[0][1]), token(a[1][1]))
        self.assertNotEqual(token(a[0][1]), token(b[0][1]))

    def test_write_parts_removes_parts_left_from_a_bigger_bundle(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d)
            self.assertEqual(len(payload.write_parts(out, "install.luau", script(150))), 3)
            (out / "install_other.2.luau").write_text("keep", encoding="utf-8")
            written = payload.write_parts(out, "install.luau", script(10))
            self.assertEqual([p.name for p in written], ["install.luau"])
            self.assertFalse((out / "install.2.luau").exists())
            self.assertTrue((out / "install_other.2.luau").exists())
            self.assertEqual(payload.joined(out, "install.luau"), script(10))

    def test_joined_reads_parts_back(self):
        with tempfile.TemporaryDirectory() as d:
            payload.write_parts(Path(d), "dev.luau", script(130))
            self.assertEqual(payload.joined(Path(d), "dev.luau"), script(130))

    def test_long_string_survives_closing_brackets(self):
        for text in ("a]]b", "x]=]y]==]", "\nnewline first", ""):
            lit = payload.long_string(text)
            self.assertEqual(payload._payload("v.Value = " + lit), text)


@unittest.skipUnless(luaurun.find(), "luau is not installed")
class PartsRunInAFakeStudioTest(unittest.TestCase):
    """The generated part scripts, run by the real Luau against a stub of Instance/game: the right answers in order,
    a stale or lone last part named and not run, and the staging folder gone at the end."""

    def go(self, sends):
        code = [FAKE_STUDIO]
        for text in sends:
            code.append("print(SEND(" + payload.long_string(text) + "))")
        code.append("print(STAGING() == nil)")
        return luaurun.run("\n".join(code)).splitlines()

    def test_parts_in_order_run_the_script_and_clean_up(self):
        text = script(100)
        parts = payload.parts("big.luau", text, 40_000)
        self.assertEqual(len(parts), 3)
        out = self.go([b for _, b in parts])
        self.assertEqual(out[0], "out/big.luau part 1/3 stored: send out/big.2.luau next")
        self.assertEqual(out[1], "out/big.luau part 2/3 stored: send out/big.3.luau next")
        self.assertEqual(out[2:], ["done", "true"])

    def test_a_last_part_sent_alone_is_named_and_not_run(self):
        parts = payload.parts("big.luau", script(100), 40_000)
        out = self.go([parts[-1][1]])
        self.assertIn("big.luau: part 1 (slot big_1) is missing or from another build: send out/big.luau, out/big.2.luau", out[0])

    def test_a_part_from_another_bundle_is_refused(self):
        a = payload.parts("big.luau", script(100), 40_000)
        b = payload.parts("big.luau", script(100) + "-- other" + chr(10), 40_000)
        out = self.go([a[0][1], a[1][1], b[2][1]])
        self.assertIn("is missing or from another build", out[2])

    def test_parts_of_the_same_text_cut_at_different_budgets_never_mix(self):
        """The reviewer's mix: parts 1-2 of a 30 KB build, then the last part of a 40 KB build of the same text."""
        text = script(100)
        small = payload.parts("big.luau", text, 30_000)
        normal = payload.parts("big.luau", text, 40_000)
        self.assertNotEqual(len(small), len(normal))
        out = self.go([small[0][1], small[1][1], normal[-1][1]])
        self.assertIn("part 1 (slot big_1) is missing or from another build", out[2])
        self.assertNotIn("done", out)

    def test_a_slot_left_by_a_longer_earlier_send_is_cleaned(self):
        text = script(100)
        longer = payload.parts("big.luau", text, 30_000)
        shorter = payload.parts("big.luau", text, 60_000)
        out = self.go([longer[0][1], longer[1][1], longer[2][1]] + [b for _, b in shorter])
        self.assertEqual(out[-2:], ["done", "true"])

    def test_a_join_leaves_the_parts_of_a_bundle_whose_name_starts_the_same(self):
        """dev's join must not take dev_authoring's stored parts: only <stem>_<n> and <stem>_joined are its own."""
        other = payload.parts("big_extra.luau", script(100), 40_000)
        mine = payload.parts("big.luau", script(100), 40_000)
        out = self.go([other[0][1]] + [b for _, b in mine] + [b for _, b in other[1:]])
        self.assertEqual(out.count("done"), 2, out)
        self.assertEqual(out[-1], "true")


class TinyBudgetTest(unittest.TestCase):
    def test_a_budget_under_the_wrapper_is_refused_at_once(self):
        import time
        started = time.time()
        for budget in (-5, 0, 1, 1_000, payload.OVERHEAD, payload.OVERHEAD + payload.MIN_CHUNK - 1):
            with self.assertRaises(SystemExit) as e:
                payload.parts("x.luau", "a\n" * 5_000, budget)
            self.assertIn("too small", str(e.exception))
            self.assertIn(str(payload.OVERHEAD + payload.MIN_CHUNK), str(e.exception))
        self.assertLess(time.time() - started, 5)

    def test_the_smallest_allowed_budget_still_makes_parts_that_fit(self):
        budget = payload.OVERHEAD + payload.MIN_CHUNK
        for name, body in payload.parts("x.luau", script(8), budget):
            self.assertLessEqual(len(body.encode("utf-8")), budget, name)

    def test_budget_zero_is_not_the_default(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(SystemExit):
                bundle.write_all(d, budget=0)


class LuauCheckFailsTest(unittest.TestCase):
    """The check must be able to say no: a green run that can't fail proves nothing."""

    def setUp(self):
        if not luaurun.find():
            self.skipTest("luau.exe is not installed (rokit add luau-lang/luau): the failure-path checks need the real Luau")

    def test_a_syntax_error_is_reported_with_its_file_and_line(self):
        bad = luaurun.parse_texts({"ok.luau": "return 1\n", "x/bad.luau": "local a = 1\nlocal = = 2\n"})
        self.assertEqual([name for name, _ in bad], ["x/bad.luau"])
        self.assertIn("x/bad.luau", bad[0][1])
        self.assertRegex(bad[0][1], r'x/bad\.luau"\]:2\b')

    def test_a_multi_line_compile_message_stays_one_entry(self):
        bad = luaurun.parse_texts({"a.luau": "if x then\n", "b.luau": "return 2\n", "c.luau": "local = 3\n"})
        self.assertEqual(sorted(name for name, _ in bad), ["a.luau", "c.luau"])

    def test_parse_all_names_the_bad_file_of_a_tree(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "good.luau").write_text("return 1\n", encoding="utf-8")
            (root / "sub").mkdir()
            (root / "sub" / "broken.luau").write_text("local function (\n", encoding="utf-8")
            bad = luaurun.parse_all(root)
            self.assertEqual([p for p, _ in bad], ["sub/broken.luau"])
            self.assertRegex(bad[0][1], r":1\b")

    def test_a_runtime_error_in_a_stubbed_run_fails(self):
        with self.assertRaises(RuntimeError) as e:
            luaurun.run(FAKE_STUDIO + "\nlocal part = Instance.new('Folder')\nreturn part.Missing.Deeper\n")
        self.assertIn("luau failed", str(e.exception))
        with self.assertRaises(RuntimeError):
            luaurun.run("error('boom')")

    def test_a_script_that_never_finishes_is_a_clean_error(self):
        with self.assertRaises(RuntimeError) as e:
            luaurun.run("while true do end", timeout=1)
        self.assertIn("did not finish", str(e.exception))

    def test_run_without_luau_says_how_to_install_it(self):
        with self.assertRaises(SystemExit) as e:
            self._no_luau()
        self.assertIn("rokit add", str(e.exception))

    @staticmethod
    def _no_luau():
        real = luaurun.find
        luaurun.find = lambda: None
        try:
            luaurun.run("return 1")
        finally:
            luaurun.find = real

    def test_versions_sort_by_number_not_text(self):
        paths_ = [Path("s/0.99.0/luau.exe"), Path("s/0.733.0/luau.exe"), Path("s/0.100.1/luau.exe")]
        self.assertEqual(sorted(paths_, key=luaurun._version_key)[-1].parent.name, "0.733.0")


class BundlePartsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.out = Path(cls.tmp.name)
        cls.written = bundle.write_all(cls.out)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_every_written_file_fits_one_execute_luau(self):
        for p in self.written:
            self.assertLessEqual(len(p.read_bytes()), payload.MAX_BYTES, p.name)

    def test_the_install_joins_back_to_the_whole_installer(self):
        whole = payload.joined(self.out, "install.luau")
        self.assertIn("CutsceneKit/Director.luau", whole)
        self.assertTrue(whole.rstrip().endswith('installed (%d modules)"):format(EMBED.version, #EMBED.modules)'))

    @unittest.skipUnless(luaurun.find(), "luau is not installed")
    def test_every_part_and_every_joined_script_parses(self):
        texts = {p.name: p.read_text(encoding="utf-8") for p in self.written}
        for name in ("install.luau", "dev.luau"):
            texts["joined " + name] = payload.joined(self.out, name)
        self.assertEqual(luaurun.parse_texts(texts), [])

    def test_delta_carries_only_what_changed(self):
        e = bundle.delta_embed(["Data", "Fov"], ["Smoke"])
        self.assertEqual(sorted(e["files"]), ["CutsceneKit/Data.luau", "CutsceneKit/Fov.luau"])
        self.assertEqual(sorted(e["tests"]), ["Smoke"])
        with self.assertRaises(SystemExit) as err:
            bundle.delta_embed(["Nope"], ["Nada"])
        self.assertIn("Nope", str(err.exception))
        self.assertIn("test Nada", str(err.exception))
        with tempfile.TemporaryDirectory() as d:
            written = bundle.write_delta(["Fov"], [], d)
            self.assertEqual(written[0].name, "delta.luau")
            self.assertIn("delta: CutsceneKit %s rebuilt", payload.joined(Path(d), "delta.luau"))

    def test_a_forced_small_budget_makes_parts_that_all_fit(self):
        with tempfile.TemporaryDirectory() as d:
            files = bundle.write_all(d, budget=30_000)
            names = sorted(p.name for p in files)
            self.assertIn("install.2.luau", names)
            for p in files:
                self.assertLessEqual(len(p.read_bytes()), 30_000, p.name)
            self.assertEqual(payload.joined(Path(d), "install.luau"), payload.joined(self.out, "install.luau"))

    def test_the_install_can_grow_into_more_parts(self):
        """A later plan adds runtime modules (a clip preload, VFX): the install just takes another part."""
        embed = bundle.install_embed()
        embed["files"]["CutsceneKit/Preload.luau"] = "-- grown module\n" + "local a = 1\n" * 20_000
        embed["modules"] = embed["modules"] + ["Preload"]
        text = bundle.render(bundle.ROBLOX / "install.luau", embed)
        with tempfile.TemporaryDirectory() as d:
            files = payload.write_parts(d, "install.luau", text, payload.MAX_BYTES)
            self.assertGreater(len(files), len([p for p in self.written if p.name.startswith("install")]))
            for p in files:
                self.assertLessEqual(len(p.read_bytes()), payload.MAX_BYTES, p.name)
            self.assertEqual(payload.joined(Path(d), "install.luau"), text)

    def test_no_bundle_is_named_like_a_payload_part(self):
        import re
        for name in ("install.luau", "dev.luau", "dev_authoring.luau", "fixture.luau", "fixture_r6.luau",
                     "fixture_assets.luau"):
            self.assertFalse(re.search(r"\.\d+\.luau$", name), name)
        jobs = [p.name for p in self.written if not re.search(r"\.\d+\.luau$", p.name)]
        self.assertEqual(len(jobs), 6)


if __name__ == "__main__":
    unittest.main()
