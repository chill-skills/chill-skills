"""Tests for kit/cues.py (the data module's Cues and the awakening rules) and its wiring into beats, scenefile and
gates. Method by fwjelaa (FWJ STUDIOS)."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import cues  # noqa: E402
import gates  # noqa: E402
import scenefile  # noqa: E402
import schema  # noqa: E402
import shotscript  # noqa: E402
import vfxlib  # noqa: E402
import workspace  # noqa: E402

FRAMING = {"fps": 60, "camera": [[0, 5, 10] + [1, 0, 0, 0, 1, 0, 0, 0, 1]] * 120,
           "heads": {"player": [[0, 5, 0]] * 120}}
FRAMING_LONG = {"fps": 60, "camera": [[0, 5, 10, 1, 0, 0, 0, 1, 0, 0, 0, 1]] * 240, "heads": {"player": [[0, 4.8, 0]] * 240}}


def awakening(markers=None, length=2.0):
    shots = [beats.shot("ESTABLISH", 1.0, markers=[[0.3, "VFX", "Charge"]], cut=False),
             beats.shot("IMPACT", length, markers=markers if markers is not None else [[0.0, "Impact", ""], [0.0, "VFX", "Burst"]])]
    b = beats.draft("Wake", {"type": "words", "text": "a hero awakens"}, shots, kind="awakening")
    b["trigger"] = {"type": "api"}
    return b


def scene_for(b):
    total = beats.length(b)
    return {"id": b["id"], "length": total, "clips": {"Stage": "Wake_Stage", "R15": {"player": "Wake_player_R15"}},
            "fov": [[0, 50], [1.0, 50], [1.0, 40], [total, 40]]}  # the cut at 1 s


def beat_sheet(**over):
    b = {"id": "Wake", "kind": "awakening", "cast": {"player": {"place": [0, 0, 0, 0, 0, 0]}},
         "shots": [{"type": "ESTABLISH", "start": 0, "length": 1.0, "markers": [[0.2, "VFX", "Charge"]]},
                   {"type": "IMPACT", "start": 1.0, "length": 1.0, "markers": [[0.0, "Impact", ""], [0.0, "VFX", "Burst"],
                                                                              [0.1, "Slowmo", "0.25"]]}],
         "cues": {}}
    b.update(over)
    return b


class CuesTest(unittest.TestCase):
    def test_a_marker_without_a_cue_plays_its_preset_with_a_budget(self):
        found = cues.module_cues([[1.0, "VFX", "Burst"], [2.0, "Shake", "0.5"]])
        self.assertEqual(found, {"VFX:Burst": {"kind": "vfx", "preset": "Burst",
                                               "budget": vfxlib.budget(vfxlib.load(), "Burst")}})

    def test_an_explicit_cue_wins_and_screen_cues_are_kept(self):
        explicit = {"VFX:Flare": {"kind": "vfx", "preset": "EyeFlare", "follow": "player.Head"},
                    "VFX:Lines": {"kind": "screen", "effect": "speedlines", "life": 0.4}}
        found = cues.module_cues([[3.0, "VFX", "Flare"], [4.0, "VFX", "Lines"]], explicit)
        self.assertEqual(found["VFX:Flare"]["preset"], "EyeFlare")
        self.assertEqual(found["VFX:Flare"]["budget"]["particles"], 3)
        self.assertEqual(found["VFX:Lines"], explicit["VFX:Lines"])
        self.assertIsNot(found["VFX:Lines"], explicit["VFX:Lines"], "a copy, never the beat sheet's own dict")

    def test_face_points_resolve_from_the_framing(self):
        found = cues.module_cues([[1.0, "VFX", "Flare"]], {"VFX:Flare": {"kind": "vfx", "preset": "EyeFlare", "at": "player.face"}},
                                 FRAMING)
        self.assertEqual(found["VFX:Flare"]["at"], [0, 5, cues.FACE])
        found = cues.module_cues([[1.0, "VFX", "Flare"]], {"VFX:Flare": {"kind": "vfx", "preset": "EyeFlare", "at": "player.head"}},
                                 FRAMING)
        self.assertEqual(found["VFX:Flare"]["at"], [0, 5, 0])

    def test_a_face_point_without_framing_names_the_fix(self):
        with self.assertRaises(SystemExit) as e:
            cues.module_cues([[1.0, "VFX", "Flare"]], {"VFX:Flare": {"kind": "vfx", "preset": "EyeFlare", "at": "player.face"}})
        self.assertIn("filmset.export", str(e.exception))
        left = cues.module_cues([[1.0, "VFX", "Flare"]], {"VFX:Flare": {"kind": "vfx", "preset": "EyeFlare", "at": "player.face"}},
                                strict=False)
        self.assertEqual(left["VFX:Flare"]["at"], "player.face")

    def test_awakening_config_starts_from_the_kind(self):
        cfg = cues.config_for("awakening", {"Skip": 2, "Replay": "saved", "Letterbox": 0.11})
        self.assertEqual(cfg["Skip"], False)
        self.assertEqual(cfg["Replay"], "always")
        self.assertEqual(cfg["Letterbox"], 0.11)
        self.assertEqual(cfg["Awakened"]["Aura"], "Flame")
        self.assertEqual(cues.config_for("story", {"Skip": 2}), {"Skip": 2})

    def test_beat_sheet_checks(self):
        self.assertEqual(cues.check_beats(beat_sheet()), [])
        bad = beat_sheet()
        bad["shots"][0]["markers"].append([0.5, "VFX", "Kamehameha"])
        bad["shots"][1]["markers"].append([0.5, "Slowmo", "3"])
        bad["cues"] = {"VFX:Glow": {"kind": "vfx", "preset": "Burst", "follow": "npc4.Head", "at": "player.nose"}}
        found = "\n".join(cues.check_beats(bad))
        self.assertIn("VFX marker 'Kamehameha' is not a preset", found)
        self.assertIn("Slowmo '3' must be a number from 0.05 to 1", found)
        self.assertIn("VFX:Glow follows npc4, who is not in the cast", found)
        self.assertIn('VFX:Glow.at "player.nose"', found)

    def test_an_unskippable_scene_is_kept_short(self):
        long = beat_sheet()
        long["shots"][1]["length"] = 12.0
        self.assertIn("can't be skipped", "\n".join(cues.check_beats(long)))
        story = beat_sheet(kind="story")
        story["shots"][1]["length"] = 12.0
        self.assertEqual(cues.check_beats(story), [])

    def test_kit_checks(self):
        data = {"Kind": "awakening", "Length": 9.0, "Markers": [[1, "VFX", "Burst"], [9, "End", ""]],
                "Cues": {"VFX:Burst": {"kind": "vfx", "preset": "Burst"}}, "Config": {}}
        self.assertIn("an awakening needs an Impact marker", "\n".join(cues.checks(data)))
        data["Markers"].insert(0, [1, "Impact", ""])
        self.assertEqual(cues.checks(data), [])
        data["Markers"] = [[1, "Impact", ""]] + [[1 + i * 0.05, "VFX", "Charge"] for i in range(20)] + [[9, "End", ""]]
        data["Cues"] = {"VFX:Charge": {"kind": "vfx", "preset": "Charge"}}
        self.assertEqual(cues.peak(data)[0], 20 * 108)
        self.assertIn("VFX particles alive at once", "\n".join(cues.checks(data)))
        data["Length"] = 12
        self.assertIn("can't be skipped", "\n".join(cues.checks(data)))


class AwakeningBeatsTest(unittest.TestCase):
    def test_an_awakening_draft_is_unskippable_and_has_an_awakened_state(self):
        b = awakening()
        self.assertIs(b["config"]["Skip"], False)
        self.assertEqual(b["config"]["Replay"], "always")
        self.assertEqual(b["config"]["Awakened"]["Aura"], "Flame")
        self.assertEqual(beats.validate(b), [])

    def test_unknown_vfx_and_long_awakenings_are_refused(self):
        b = awakening(markers=[[0.5, "VFX", "Nope"]], length=11.0)
        found = "\n".join(beats.validate(b))
        self.assertIn("VFX marker 'Nope' is not a preset", found)
        self.assertIn("can't be skipped", found)

    def test_awakened_at_is_checked_against_the_real_length(self):
        b = awakening()
        b["config"]["Awakened"]["At"] = 1.5  # inside the 3 s scene (the old probe used 1 s)
        self.assertEqual(beats.validate(b), [])
        b["config"]["Awakened"]["At"] = 9
        self.assertIn("config: Config.Awakened.At must be a time inside the scene", beats.validate(b))


class CuesInTheModuleTest(unittest.TestCase):
    def test_vfx_markers_reach_the_data_module_with_their_cues(self):
        b = awakening()
        data = scenefile.module_data(b, scene_for(b))
        self.assertEqual(sorted(data["Cues"]), ["VFX:Burst", "VFX:Charge"])
        self.assertEqual(data["Cues"]["VFX:Burst"]["budget"]["particles"], 92)
        self.assertEqual(schema.validate(data), [])

    def test_face_points_use_the_framing(self):
        b = awakening()
        b["shots"][1]["markers"].append([0.5, "VFX", "Flare"])
        b["cues"] = {"VFX:Flare": {"kind": "vfx", "preset": "EyeFlare", "at": "player.face"}}
        data = scenefile.module_data(b, scene_for(b), framing=FRAMING_LONG)
        at = data["Cues"]["VFX:Flare"]["at"]  # 0.55 studs from the head toward the camera at (0, 5, 10)
        for got, want in zip(at, [0, 4.811, 0.55]):
            self.assertAlmostEqual(got, want, places=3)

    def test_framing_of_reads_the_export(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertIsNone(scenefile.framing_of(d))
            workspace.write_json(Path(d) / "export" / "framing.json", FRAMING_LONG)
            self.assertEqual(scenefile.framing_of(d)["fps"], 60)


class GatesTest(unittest.TestCase):
    def test_the_runtime_now_handles_impact_flash_slowmo_and_vfx(self):
        self.assertTrue({"Impact", "Flash", "Slowmo"} <= gates.BUILTIN)
        self.assertNotIn("VFX", gates.LATER)
        b = awakening()
        data = scenefile.module_data(b, scene_for(b))
        self.assertEqual(gates.sync(data), [])


class ShotscriptWiringTest(unittest.TestCase):
    def test_an_awakening_draft_gets_the_awakening_config(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "s.md"
            p.write_text("1. WIDE / 24mm, static, 2.0s. Hero stands. VFX: charge." + chr(10), encoding="utf-8")
            b = shotscript.draft("Try", p, kind="awakening")
            self.assertIs(b["config"]["Skip"], False)
            self.assertEqual(b["config"]["Replay"], "always")
            self.assertEqual(b["config"]["Cooldown"], 30)
            self.assertEqual(b["config"]["Element"], "teal")
            self.assertEqual(b["config"]["Awakened"]["Aura"], "Flame")
            story = shotscript.draft("Try", p, kind="story")
            self.assertEqual(story["config"], beats.DEFAULT_CONFIG)


MANGA_CUES = {  # one of each manga effect, as a beats.json "cues" block
    "VFX:Lines": {"kind": "screen", "effect": "speedlines", "focus": "player.face", "life": 0.6, "alpha": 1,
                  "density": 0.8, "color": "black"},
    "VFX:Hit": {"kind": "screen", "effect": "burst", "image": "burst", "follow": "player.RightHand", "size": 0.5,
                "life": 0.5, "rot": -10},
    "VFX:Pow": {"kind": "screen", "effect": "word", "text": "POW!!", "at": [0.3, 0.22], "size": 0.2, "rot": -12,
                "life": 1.0, "fill": "black", "stroke": 0},
    "VFX:Bg": {"kind": "screen", "effect": "backdrop", "image": "whiteburst", "life": 1.6},
}


class MangaCuesTest(unittest.TestCase):
    def test_a_screen_cue_at_a_face_becomes_a_point_the_runtime_projects(self):
        markers = [[0.5, "VFX", "Lines"], [0.5, "VFX", "Hit"], [0.6, "VFX", "Pow"], [0.5, "VFX", "Bg"]]
        found = cues.module_cues(markers, MANGA_CUES, FRAMING)
        self.assertEqual(found["VFX:Lines"]["focus"], [0, 5, 0.55], "0.55 studs in front of the head, toward the lens")
        self.assertEqual(found["VFX:Pow"], MANGA_CUES["VFX:Pow"], "screen fractions stay as they are")
        self.assertNotIn("budget", found["VFX:Hit"], "screen cues spawn no particles")
        guides = cues.module_cues(markers, MANGA_CUES, None, strict=False)
        self.assertEqual(guides["VFX:Lines"]["focus"], "player.face", "the film set's guides leave it unresolved")

    def test_the_beat_sheet_accepts_every_manga_effect_and_names_a_bad_one(self):
        shots = [{"type": "IMPACT", "start": 0, "length": 2.0,
                  "markers": [[0.5, "VFX", "Lines"], [0.5, "VFX", "Hit"], [0.6, "VFX", "Pow"], [0.0, "VFX", "Bg"]]}]
        b = beat_sheet(kind="story", shots=shots, cues=MANGA_CUES, config={"CastLight": {"Range": 12}})
        self.assertEqual(cues.check_beats(b), [])
        bad = dict(MANGA_CUES, **{"VFX:Pow": dict(MANGA_CUES["VFX:Pow"], stroke=0.12),
                                  "VFX:Lines": dict(MANGA_CUES["VFX:Lines"], focus="the middle")})
        found = "\n".join(cues.check_beats(beat_sheet(kind="story", shots=shots, cues=bad)))
        self.assertIn("Cues[VFX:Pow].stroke must be 0-0.07 of the text size", found)
        self.assertIn('cues: VFX:Lines.focus "the middle" must be numbers or "<role>.head" / "<role>.face"', found)

    def test_too_many_manga_layers_at_once_are_named(self):
        cue = {"kind": "screen", "effect": "word", "text": "BZZT", "life": 1.0}
        data = {"Markers": [[1.0 + 0.05 * i, "VFX", "W"] for i in range(cues.SCREEN_LAYERS + 1)],
                "Cues": {"VFX:W": cue}, "Length": 3}
        most, when = cues.screen_layers(data)
        self.assertEqual(most, cues.SCREEN_LAYERS + 1)
        self.assertAlmostEqual(when, 1.3)
        self.assertTrue(any("manga screen layers at once" in i for i in cues.checks(data)))
        data["Markers"] = data["Markers"][:cues.SCREEN_LAYERS]
        self.assertFalse(any("manga screen layers" in i for i in cues.checks(data)))

    def test_a_big_burst_counts_as_a_flash_and_a_small_one_does_not(self):
        data = {"Markers": [[1.0, "Impact", ""], [1.0, "VFX", "Big"], [1.3, "VFX", "Small"], [1.5, "Flash", ""]],
                "Cues": {"VFX:Big": {"kind": "screen", "effect": "burst", "size": 0.7},
                         "VFX:Small": {"kind": "screen", "effect": "burst"}}}
        self.assertEqual(cues.flashes(data), [1.0, 1.0, 1.5])
        self.assertTrue(gates.flash_rate(data["Markers"], data), "three flashes inside one second")
        data["Cues"]["VFX:Big"]["size"] = 0.5
        self.assertEqual(gates.flash_rate(data["Markers"], data), [])


if __name__ == "__main__":
    unittest.main()
