"""Tests for the blind score's spec 14 parts: C7 character likeness for adapted characters, and gate 3 wanting both
casts' previews (and the likeness sheet). Method by fwjelaa (FWJ STUDIOS)."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import fixture  # noqa: E402
import gates  # noqa: E402
import review  # noqa: E402
import scenefile  # noqa: E402
import workspace  # noqa: E402

NL = chr(10)


def reply(*points):
    return NL.join(f"C{i}: {p} | looked at frame {i}" for i, p in enumerate(points, 1)) + NL


class CriteriaTest(unittest.TestCase):
    def test_c7_only_counts_when_asked_for(self):
        crit = review.CRITERIA + (review.LIKENESS,)
        self.assertEqual(review.parse_reply(reply(2, 2, 2, 2, 2, 2, 0)), {f"C{i}": 2 for i in range(1, 7)})
        self.assertEqual(review.parse_reply(reply(2, 2, 2, 2, 2, 2, 0), crit)["C7"], 0)
        with self.assertRaises(SystemExit) as e:
            review.parse_reply(reply(2, 2, 2, 2, 2, 2), crit)
        self.assertIn("C7", str(e.exception))
        self.assertEqual(review.score({f"C{i}": 2 for i in range(1, 8)}, crit), 10.0)
        self.assertEqual(review.score(dict({f"C{i}": 2 for i in range(1, 7)}, C7=0), crit), 8.8)  # 14 of 16


class DressedRoundTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = fixture.write_scene(env={"MAKE_CUTSCENE_WORK": self.tmp.name}, costume=True)
        scenefile.write(self.root)
        self.make_evidence()

    def make_evidence(self, take=b"x"):
        """Gates, play test, both previews and their side-by-side sheets for the build as it is now."""
        pv = self.root / "preview"
        for name in ("Fixture_Scene.mp4", "sheet.png", "side_by_side_1.png", "Fixture_Scene_R6.mp4", "sheet_R6.png",
                     "side_by_side_R6_1.png"):
            (pv / name).write_bytes(take)
        review.stamp_preview(self.root)
        review.stamp_preview(self.root, "R6")
        review.stamp_sheet(self.root, "side_by_side", ["side_by_side_1.png"])
        review.stamp_sheet(self.root, "side_by_side_R6", ["side_by_side_R6_1.png"])
        # Synthetic byte fixtures: this checks integrity, not media playback.
        review.stamp_sheet(self.root, "overview", ["sheet.png"])
        review.stamp_sheet(self.root, "overview_R6", ["sheet_R6.png"])
        workspace.write_json(self.root / "export" / "gates.json",
                             {"ok": True, "issues": [], "export": gates.export_hash(self.root),
                              "costume": gates.costume_hash(self.root)})
        review.set_playtest(self.root, [f"{k}=pass" for k in review.PLAYTEST])

    def make_likeness(self):
        (self.root / "preview" / "likeness.png").write_bytes(b"x")
        review.stamp_sheet(self.root, "likeness", ["likeness.png"])  # what sheets.likeness records

    def test_changed_or_missing_likeness_bytes_block_packet_and_score(self):
        for mutation in ('changed', 'missing'):
            with self.subTest(mutation=mutation):
                self.make_likeness()
                review.packet(self.root, 1)
                path = self.root / 'preview/likeness.png'
                if mutation == 'changed':
                    path.write_bytes(b'changed synthetic likeness image')
                else:
                    path.unlink()
                with self.assertRaises(SystemExit):
                    review.packet(self.root, 1)
                with self.assertRaises(SystemExit):
                    review.record(self.root, 1, [reply(2, 2, 2, 2, 2, 2, 2)] * 3)
                self.assertFalse((self.root / 'review/results/round1/scores.json').exists())
                self.assertFalse((Path(self.tmp.name) / '.fwjelaa/ledger.jsonl').exists())

    def edit_costume(self):
        path = self.root / "cast" / "npc1.json"
        spec = workspace.read_json(path)
        spec["body"]["torso"] = "#000000"
        workspace.write_json(path, spec)

    def test_a_costume_edit_makes_every_gate_record_stale(self):
        self.make_likeness()
        self.assertEqual(review.stale(self.root), [])
        self.edit_costume()
        self.assertEqual(review.stale(self.root), ["G1 kit checks", "G2 play test", "G3 preview"])
        self.assertFalse(any(review.hard_gates(self.root).values()))
        with self.assertRaises(SystemExit) as e:
            review.packet(self.root, 1)
        self.assertIn("costume specs (cast/*.json) changed", str(e.exception))

    def test_the_likeness_sheet_must_come_from_the_current_previews(self):
        self.make_likeness()
        self.assertEqual(len(review.packet(self.root, 1)), 3)
        self.edit_costume()
        self.make_evidence(take=b"new takes in the new costume")  # everything made again but likeness.png
        self.assertEqual(review.stale(self.root), [])
        with self.assertRaises(SystemExit) as e:
            review.packet(self.root, 1)
        self.assertIn("likeness.png", str(e.exception))
        self.assertIn("py kit/run.py likeness Fixture_Scene", str(e.exception))
        self.make_likeness()
        self.assertEqual(len(review.packet(self.root, 1)), 3)

    def test_a_costumed_scene_is_scored_on_c7(self):
        self.assertEqual([c for c, _, _ in review.criteria_for(beats.load(self.root))][-1], "C7")
        self.assertEqual(review.preview_missing(self.root, beats.load(self.root)), ["likeness.png"])
        self.assertFalse(review.hard_gates(self.root)["G3 preview"])
        with self.assertRaises(SystemExit) as e:
            review.packet(self.root, 1)
        self.assertIn("py kit/run.py likeness Fixture_Scene", str(e.exception))
        self.make_likeness()
        self.assertTrue(review.hard_gates(self.root)["G3 preview"])
        for out in review.packet(self.root, 1):
            self.assertTrue((out / "likeness.png").exists())
            self.assertTrue((out / "frames_R6.png").exists())
            self.assertIn("C7: <0|1|2>", (out / "README.md").read_text(encoding="utf-8"))
        result, lines = review.record(self.root, 1, [reply(2, 2, 2, 2, 2, 2, 2)] * 3)
        self.assertEqual(result["criteria"]["C7"], 2)
        self.assertTrue(result["passed"])

    def test_both_casts_are_needed_for_gate_3(self):
        (self.root / "preview" / "likeness.png").write_bytes(b"x")
        (self.root / "preview" / "Fixture_Scene_R6.mp4").unlink()
        self.assertEqual(review.preview_missing(self.root, beats.load(self.root)), ["Fixture_Scene_R6.mp4"])
        self.assertFalse(review.hard_gates(self.root)["G3 preview"])
        (self.root / "preview" / "sheet_R6.png").unlink()
        with self.assertRaises(SystemExit) as e:
            review.packet(self.root, 1)
        self.assertIn("--rig R6", str(e.exception))


class GateTest(unittest.TestCase):
    def test_the_kit_checks_list_costume_problems(self):
        with tempfile.TemporaryDirectory() as d:
            root = fixture.write_scene(env={"MAKE_CUTSCENE_WORK": d}, costume=True)
            issues, lines = gates.run(root)
            text = NL.join(lines)
            self.assertIn("costumes", text)
            self.assertIn("has no likeness", text)  # the fixture's costumes carry no likeness entry


if __name__ == "__main__":
    unittest.main()
