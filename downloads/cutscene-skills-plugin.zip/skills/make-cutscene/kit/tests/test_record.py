"""Tests for kit/record.py with fake windows and a fake FFmpeg process. Method by fwjelaa (FWJ STUDIOS)."""
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import record  # noqa: E402

WIN = (42, "cuttt - Roblox Studio", (10, 20, 1931, 1101))


class FakeProc:
    def __init__(self, out, polls=3, code=0, hang=False):
        self.out, self.polls, self.code, self.hang = out, polls, code, hang
        self.returncode, self.stopped, self.killed = None, False, False

    def poll(self):
        self.polls -= 1
        Path(self.out).write_bytes(b"mp4")  # a take exists on disk while FFmpeg runs, so a stop has to delete it
        if self.polls <= 0:
            self.returncode = self.code if self.returncode is None else self.returncode
            return self.returncode
        return None

    def terminate(self):
        self.stopped = True

    def kill(self):
        self.killed = True
        self.hang = False

    def wait(self, timeout=None):
        if self.hang:
            raise subprocess.TimeoutExpired("ffmpeg", timeout)
        return 0


class Clock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        self.t += 0.1
        return self.t


class RecordTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.out = Path(self.tmp.name) / "preview" / "raw.mp4"

    procs = []

    def run_record(self, front=lambda hwnd: True, find=lambda: WIN, polls=3, say=lambda text: None, code=0,
                   hang=False, clock=None):
        procs = self.procs = []

        def popen(cmd, **kw):
            procs.append((cmd, FakeProc(self.out, polls, code, hang)))
            return procs[-1][1]

        path = record.record(8, self.out, method="gdigrab", find=find, focus_fn=lambda hwnd: None, in_front=front,
                             popen=popen, sleep=lambda s: None, clock=clock or Clock(), say=say)
        return path, procs

    def test_commands(self):
        gfx = record.capture_cmd("gfxcapture", WIN, 8, "o.mp4", target="hwnd")
        self.assertIn("gfxcapture=hwnd=42:capture_cursor=0:max_framerate=60,hwdownload,format=bgra", gfx)
        self.assertIn("scale=trunc(iw/2)*2:trunc(ih/2)*2", gfx)  # spike S9: an odd window size is refused by libx264
        dda = " ".join(record.capture_cmd("ddagrab", WIN, 8, "o.mp4"))
        self.assertIn("offset_x=10:offset_y=20:video_size=1920x1080", dda)
        gdi = record.capture_cmd("gdigrab", WIN, 8, "o.mp4")
        self.assertEqual(gdi[gdi.index("-video_size") + 1], "1920x1080")
        with self.assertRaises(ValueError):
            record.capture_cmd("fraps", WIN, 8, "o.mp4")

    def test_spike_s9_choices(self):
        self.assertEqual((record.METHOD, record.GFX_TARGET, record.CLICK), ("ddagrab", "hwnd", True))

    def test_a_maximised_window_rect_is_clamped_to_the_monitor(self):
        # GetWindowRect of a maximised window hangs 8 px off screen and made every capture method fail (spike S9)
        self.assertEqual(record.clamp_rect((-8, -8, 1928, 1040), (0, 0, 1920, 1080)), (0, 0, 1920, 1040))
        self.assertEqual(record.clamp_rect((0, 0, 1921, 1033), (0, 0, 1920, 1080)), (0, 0, 1920, 1032))  # even sizes
        self.assertEqual(record.clamp_rect((10, 20, 1931, 1101), (0, 0, 3840, 2160)), (10, 20, 1930, 1100))
        clamped = record.clamp_rect((-8, -8, 1928, 1040), (0, 0, 1920, 1080))
        cmd = " ".join(record.capture_cmd("ddagrab", (1, "t", clamped), 8, "o.mp4"))
        self.assertIn("offset_x=0:offset_y=0:video_size=1920x1040", cmd)

    def test_a_good_take(self):
        path, procs = self.run_record()
        self.assertEqual(path, self.out)
        self.assertTrue(self.out.exists())
        self.assertEqual(procs[0][0][-1], str(self.out))

    def test_it_says_when_the_recording_has_started(self):
        said = []
        self.run_record(say=said.append)
        self.assertEqual(len(said), 1)
        self.assertIn("recording", said[0])

    def test_another_window_stops_and_deletes_the_take(self):
        state = {"n": 0}

        def front(hwnd):
            state["n"] += 1
            return state["n"] < 3  # in front at first, then something else comes up

        with self.assertRaises(SystemExit) as e:
            self.run_record(front=front, polls=50)
        self.assertIn("another window came to the front", str(e.exception))
        self.assertFalse(self.out.exists())  # FakeProc wrote it while "recording", so this proves the delete
        self.assertTrue(self.procs[0][1].stopped)

    def assert_cleaned_up(self, proc):
        self.assertTrue(proc.stopped, "FFmpeg was left running")
        self.assertFalse(self.out.exists(), "a half-recorded take was left behind")
        self.assertFalse(self.out.with_name("raw.json").exists())

    def test_ctrl_c_stops_ffmpeg_and_deletes_the_take(self):
        state = {"n": 0}

        def front(hwnd):
            state["n"] += 1
            if state["n"] == 3:
                raise KeyboardInterrupt
            return True

        with self.assertRaises(KeyboardInterrupt):
            self.run_record(front=front, polls=50)
        self.assert_cleaned_up(self.procs[0][1])

    def test_any_exception_stops_ffmpeg_and_deletes_the_take(self):
        state = {"n": 0}

        def front(hwnd):
            state["n"] += 1
            if state["n"] == 3:
                raise OSError("window handle went away")
            return True

        with self.assertRaises(OSError):
            self.run_record(front=front, polls=50)
        self.assert_cleaned_up(self.procs[0][1])

    def test_ffmpeg_that_will_not_stop_is_killed(self):
        state = {"n": 0}

        def front(hwnd):
            state["n"] += 1
            return state["n"] < 3

        with self.assertRaises(SystemExit):
            self.run_record(front=front, polls=50, hang=True)
        self.assert_cleaned_up(self.procs[0][1])
        self.assertTrue(self.procs[0][1].killed)

    def test_a_recording_that_overruns_is_stopped_and_deleted(self):
        with self.assertRaises(SystemExit) as e:
            self.run_record(polls=10 ** 6)
        self.assertIn("didn't finish in time", str(e.exception))
        self.assert_cleaned_up(self.procs[0][1])

    def test_a_nonzero_ffmpeg_exit_deletes_the_take(self):
        with self.assertRaises(SystemExit) as e:
            self.run_record(code=1)
        self.assertIn("couldn't record", str(e.exception))
        self.assertFalse(self.out.exists())

    def test_a_window_in_the_last_moment_is_caught(self):
        calls = {"n": 0}

        def front(hwnd):
            calls["n"] += 1
            return calls["n"] < 4  # wait loop, two polls, then the check after the last poll

        with self.assertRaises(SystemExit) as e:
            self.run_record(front=front, polls=3)
        self.assertIn("another window came to the front", str(e.exception))
        self.assertFalse(self.out.exists())

    def test_the_start_signal_is_written_next_to_the_take(self):
        import json
        self.run_record()
        data = json.loads(self.out.with_name("raw.json").read_text(encoding="utf-8"))
        self.assertGreater(data["announced_at"], 0)
        self.assertLess(data["announced_at"], 2)

    def test_studio_on_another_monitor_is_refused(self):
        self.assertTrue(record.on_primary((0, 0, 1920, 1032), (1920, 1080)))
        self.assertFalse(record.on_primary((1920, 0, 3840, 1080), (1920, 1080)))
        self.assertFalse(record.on_primary((-1920, 0, 0, 1080), (1920, 1080)))

    def test_the_studio_window_with_the_place_name_is_chosen(self):
        wins = [(1, "other - Roblox Studio", (0, 0, 1920, 1032), record.STUDIO_EXE),
                (2, "cuttt - Roblox Studio", (0, 0, 800, 600), record.STUDIO_EXE),
                (3, "cuttt in a browser", (0, 0, 2000, 2000), "chrome.exe")]
        self.assertEqual(record.pick_studio(wins, "cuttt")[0], 2)
        self.assertEqual(record.pick_studio(wins, "nope")[0], 1)  # none matches: the biggest
        self.assertIsNone(record.pick_studio([wins[2]], "cuttt"))

    def test_no_studio(self):
        with self.assertRaises(SystemExit) as e:
            self.run_record(find=lambda: None)
        self.assertIn("no Roblox Studio window", str(e.exception))

    def test_studio_never_comes_to_the_front(self):
        with self.assertRaises(SystemExit) as e:
            self.run_record(front=lambda hwnd: False)
        self.assertIn("click on Studio once", str(e.exception))


if __name__ == "__main__":
    unittest.main()
