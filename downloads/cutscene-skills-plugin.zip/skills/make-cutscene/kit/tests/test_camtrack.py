"""Tests for kit/camtrack.py. Method by fwjelaa (FWJ STUDIOS)."""
import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import camtrack as ct  # noqa: E402


def look(cf):
    return (-cf[5], -cf[8], -cf[11])


class MathTest(unittest.TestCase):
    def near(self, a, b, eps=1e-6):
        for x, y in zip(a, b):
            self.assertAlmostEqual(x, y, delta=eps)

    def test_round_trip(self):
        cf = ct.look_cf((10, 6, 6), (0, 4, -4))
        self.near(ct.blender_to_cframe(ct.cframe_to_blender(cf)), cf, 1e-5)

    def test_blender_axes(self):
        ident = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
        self.near(look(ct.blender_to_cframe(ident)), (0, -1, 0))  # a Blender camera at rest looks down
        self.near(ct.blender_to_cframe([[1, 0, 0, 1], [0, 1, 0, 2], [0, 0, 1, 3], [0, 0, 0, 1]])[:3], (-1, 3, 2))
        rx90 = [[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]]  # turned up to look along Blender +Y
        self.near(look(ct.blender_to_cframe(rx90)), (0, 0, 1))  # = Roblox +Z (back)

    def test_fov(self):
        self.assertAlmostEqual(ct.vfov(24), 53.1301, places=3)
        self.assertAlmostEqual(ct.vfov(ct.lens_for(53.7)), 53.7, places=6)

    def test_look_cf(self):
        with self.assertRaises(ValueError):
            ct.look_cf((0, 10, 0), (0, 0, 0))
        up = ct.look_cf((0, 5, 10), (0, 5, 0), roll=90)
        self.near((up[4], up[7], up[10]), (-1, 0, 0))  # the top leans to the left

    def test_lerp_cf_halfway(self):
        a, b = ct.look_cf((0, 5, 10), (0, 5, 0)), ct.look_cf((10, 5, 0), (0, 5, 0))
        mid = ct.lerp_cf(a, b, 0.5)
        self.near(mid[:3], (5, 5, 5))
        self.assertAlmostEqual(ct.angle(a, mid), 45, places=4)


class ReduceTest(unittest.TestCase):
    def test_straight_dolly_needs_two_keys(self):
        frames = [ct.look_cf((0, 5, 10 - f * 0.1), (0, 4, -10)) for f in range(61)]
        keys = ct.reduce(frames)
        self.assertEqual([(k[0], k[2]) for k in keys], [(0, "Linear"), (60, "Linear")])

    def test_orbit_stays_within_tolerance_and_step(self):
        frames = [ct.look_cf((10 * math.sin(math.radians(f * 3)), 5, 10 * math.cos(math.radians(f * 3))), (0, 4, 0))
                  for f in range(121)]
        keys = ct.reduce(frames)
        self.assertLess(len(keys), 121)
        for (fa, ca, *_), (fb, cb, *_) in zip(keys, keys[1:]):
            self.assertLessEqual(ct.angle(ca, cb), ct.MAX_STEP_DEG + 1e-6)
            for f in range(fa + 1, fb):
                got = ct.lerp_cf(ca, cb, (f - fa) / (fb - fa))
                self.assertLessEqual(ct.angle(got, frames[f]), ct.TOL_DEG + 1e-6)
                self.assertLessEqual(math.dist(got[:3], frames[f][:3]), ct.TOL_STUDS + 1e-6)

    def test_cut_holds_then_jumps(self):
        a = [ct.look_cf((0, 5, 10 - f * 0.1), (0, 4, -10)) for f in range(30)]
        b = [ct.look_cf((-2, 5.5, -11), (0, 4.5, 0))] * 31
        keys = ct.reduce(a + b, cuts=[30])
        self.assertEqual([(k[0], k[2], k[3]) for k in keys],
                         [(0, "Linear", "In"), (29, "Constant", "Out"), (30, "Linear", "In"), (60, "Linear", "In")])

    def test_fov_track(self):
        fovs = [50 - f * 0.2 for f in range(30)] + [55.0] * 31
        self.assertEqual(ct.fov_track(fovs, [30]),
                         [[0.0, 50.0], [0.48333, 44.2], [0.5, 44.2], [0.5, 55.0], [1.0, 55.0]])
        self.assertEqual(ct.fov_track([130.0] * 3), [[0.0, 120.0], [0.03333, 120.0]])

    def test_stage_clip(self):
        a = [ct.look_cf((0, 5, 10), (0, 4, -10))] * 61
        clip = ct.stage_clip("S_Stage", a, [], [[0.0, "Letterbox", "in"], [1.0, "End", ""]])
        self.assertEqual(clip["root"], "StageRoot")
        self.assertEqual(clip["parents"], {"CutsceneCamera": "StageRoot"})
        self.assertEqual(clip["length"], 60)
        self.assertEqual([k["time"] for k in clip["keyframes"]], [0.0, 1.0])
        self.assertEqual(clip["keyframes"][1]["markers"], [["End", ""]])


class PlanTest(unittest.TestCase):
    SHOTS = [{"n": 1, "type": "ESTABLISH", "start": 0.0, "end": 1.6, "last": 1.58333},
             {"n": 2, "type": "HERO", "start": 1.6, "end": 3.0, "last": 2.98333}]

    def plan(self):
        return ct.CamPlan(3.0, cuts=[96], shots=self.SHOTS)

    def test_resolved_holds_the_key_before_a_cut(self):
        p = self.plan()
        p.key(0, eye=(10, 6, 6), look=(0, 4, -4), fov=50)
        p.key(1.0, eye=(5, 6, 3), look=(0, 4, -4), fov=45)
        p.key(1.6, eye=(-2, 5.5, -11), look=(0, 4.5, 0), fov=55, ease="linear")
        keys = p.resolved()
        self.assertEqual([(k["frame"], k["ease"]) for k in keys],
                         [(0, "cubic_inout"), (60, "constant"), (96, "linear"), (180, "linear")])

    def test_resolved_ends_on_the_last_frame(self):
        p = self.plan()
        p.key(0, eye=(10, 6, 6), look=(0, 4, -4), fov=50)
        p.key(1.6, eye=(-2, 5.5, -11), look=(0, 4.5, 0), fov=55)
        p.key(2.98333, eye=(-2, 5, -10), look=(0, 4.5, 0), fov=52)  # the shot's `last`: frame 179
        keys = p.resolved()
        self.assertEqual([k["frame"] for k in keys], [0, 96, 179, 180])
        self.assertEqual((keys[-1]["cf"], keys[-1]["fov"]), (keys[-2]["cf"], keys[-2]["fov"]))  # held onto frame N
        p.key(3.0, eye=(-1, 5, -9), look=(0, 4.5, 0), fov=50)
        self.assertEqual([k["frame"] for k in p.resolved()], [0, 96, 179, 180])  # a key already on N is kept
        self.assertEqual(p.resolved()[-1]["fov"], 50.0)

    def test_a_cut_needs_a_key(self):
        p = self.plan()
        p.key(0, eye=(10, 6, 6), look=(0, 4, -4))
        with self.assertRaises(ValueError) as e:
            p.resolved()
        self.assertIn("1.600 s", str(e.exception))

    def test_key_at_zero_and_ranges(self):
        p = self.plan()
        with self.assertRaises(ValueError):
            p.resolved()
        with self.assertRaises(ValueError):
            p.key(0, eye=(1, 1, 1), look=(0, 0, 0), fov=150)
        with self.assertRaises(ValueError):
            p.key(0, eye=(1, 1, 1), look=(0, 0, 0), ease="wobble")
        with self.assertRaises(ValueError):
            p.key(4.0, eye=(1, 1, 1), look=(0, 0, 0))
        self.assertEqual(p.shot(2)["start"], 1.6)
        with self.assertRaises(ValueError):
            p.shot(9)

    def test_a_cut_at_zero_is_the_first_shot(self):
        p = ct.CamPlan(3.0, cuts=[0, 96], shots=self.SHOTS)
        self.assertEqual(p.cuts, [96])
        p.key(0, eye=(10, 6, 6), look=(0, 4, -4), fov=50)
        p.key(1.6, eye=(-2, 5.5, -11), look=(0, 4.5, 0), fov=55, ease="linear")
        self.assertEqual([(k["frame"], k["ease"]) for k in p.resolved()],
                         [(0, "constant"), (96, "linear"), (180, "linear")])

    def test_a_cut_past_the_end_is_named(self):
        p = ct.CamPlan(3.0, cuts=[96, 200], shots=self.SHOTS)
        p.key(0, eye=(10, 6, 6), look=(0, 4, -4))
        p.key(1.6, eye=(-2, 5.5, -11), look=(0, 4.5, 0))
        with self.assertRaises(ValueError) as e:
            p.resolved()
        self.assertIn("3.333 s is past the end of the scene (3.0 s)", str(e.exception))


class LastFrameTest(unittest.TestCase):
    """The convention: a scene of L seconds has frames 0..N, N = round(L * 60). Frame N (t = L) is the last frame: the
    End marker and every clip's last key sit on it, and the Stage clip is N / 60 = L long, never a frame more."""

    def test_the_last_frame_is_the_scene_length(self):
        self.assertEqual(ct.last_frame(9.85), 591)
        self.assertEqual(ct.last_frame(9.8583), 591)  # off the frame grid: the nearest frame (9.85 s)
        p = ct.CamPlan(9.85)
        self.assertEqual(p.frames, 591)
        p.key(9.85, eye=(0, 5, 10), look=(0, 4, 0))
        self.assertEqual(p.keys[-1]["frame"], 591)
        with self.assertRaises(ValueError):
            p.key(9.85 + 1 / 60, eye=(0, 5, 10), look=(0, 4, 0))

    def test_the_stage_clip_ends_on_the_last_frame(self):
        n = ct.last_frame(9.85)
        frames = [ct.look_cf((0, 5, 10), (0, 4, 0))] * (n + 1)  # the film set samples frames 0..N
        clip = ct.stage_clip("S_Stage", frames, [96], [[0.0, "Letterbox", "in"], [9.85, "End", ""]])
        self.assertEqual(clip["length"], n)
        self.assertAlmostEqual(clip["keyframes"][-1]["time"], 9.85, places=5)
        self.assertEqual(clip["keyframes"][-1]["markers"], [["End", ""]])
        late = ct.stage_clip("S_Stage", frames, [], [[9.8583, "End", ""]])  # a length off the frame grid
        self.assertLessEqual(late["keyframes"][-1]["time"], n / 60)
        self.assertEqual(late["keyframes"][-1]["markers"], [["End", ""]])


if __name__ == "__main__":
    unittest.main()
