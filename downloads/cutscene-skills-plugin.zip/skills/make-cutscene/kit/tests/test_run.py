"""Tests for the command line (kit/run.py). Method by fwjelaa (FWJ STUDIOS)."""
import contextlib
import io
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import run  # noqa: E402
import setup_check  # noqa: E402


def call(*argv):
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        code = run.main(["run.py", *argv])
    return code, out.getvalue()


class RunTest(unittest.TestCase):
    def test_unknown_command_prints_usage(self):
        code, out = call("nope")
        self.assertEqual(code, 2)
        self.assertIn("py kit/run.py check", out)

    def test_new_makes_the_folder(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.dict(os.environ, {"MAKE_CUTSCENE_WORK": d}):
            code, out = call("new", "GateGuard")
            self.assertEqual(code, 0)
            self.assertTrue((Path(d) / "cutscenes" / "GateGuard" / "notes.md").exists())

    def test_take_pops_the_flag_and_its_value(self):
        args = ["a", "--from", "1.5", "b"]
        self.assertEqual(run.take(args, "--from", float), 1.5)
        self.assertEqual(args, ["a", "b"])
        self.assertEqual(run.take(args, "--to", float, 9.0), 9.0)
        lines = ["--line", "A: x", "--line", "B: y"]
        self.assertEqual(run.take_all(lines, "--line"), ["A: x", "B: y"])

    def test_ref_usage_after_flags_are_removed(self):
        with self.assertRaises(SystemExit) as e:
            call("ref", "video", "X", "--from", "1")
        self.assertIn("usage", str(e.exception))
        with self.assertRaises(SystemExit):
            call("ref", "words", "X", "--line", "A: b")

    def test_ref_hint_names_the_file_written(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.dict(os.environ, {"MAKE_CUTSCENE_WORK": d}):
            args = ["ref", "words", "Gate", "go", "--line", "Guard: Halt."]
            _, first = call(*args)
            self.assertNotIn("beats.draft.json", first)
            _, second = call(*args)
            self.assertIn("beats.draft.json", second)
            self.assertIn("--force", second)

    def test_retime_clears_approved(self):
        import beats
        with tempfile.TemporaryDirectory() as d, mock.patch.dict(os.environ, {"MAKE_CUTSCENE_WORK": d}):
            call("ref", "words", "Gate", "go", "--line", "Guard: Halt.", "--trigger", "zone", "--dialogue", "anime",
                 "--model", "default")
            self.assertEqual(call("beats", "Gate", "--go")[0], 0)
            root = Path(d) / "cutscenes" / "Gate"
            self.assertTrue(beats.load(root)["approved"])
            call("beats", "Gate", "--retime")
            self.assertFalse(beats.load(root)["approved"])

    def test_check_exit_code_follows_the_result(self):
        with mock.patch.object(setup_check, "run", return_value=(False, ["FIX x"])):
            code, out = call("check")
        self.assertEqual(code, 1)
        self.assertIn("FIX x", out)


if __name__ == "__main__":
    unittest.main()
