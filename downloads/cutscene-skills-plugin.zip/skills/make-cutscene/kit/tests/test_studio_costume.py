"""Tests for the Studio steps that build costumes (spec 14): install, rig capture and the costume lineup.
Method by fwjelaa (FWJ STUDIOS)."""
import io
import json
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import costume  # noqa: E402
import fixture  # noqa: E402
import luaurun  # noqa: E402
import payload  # noqa: E402
import scenefile  # noqa: E402
import studio  # noqa: E402
import workspace  # noqa: E402


class CostumeStepTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.env = {"MAKE_CUTSCENE_WORK": self.tmp.name}
        self.root = fixture.write_scene(env=self.env, costume=True)
        scenefile.write(self.root)

    def text(self, step):
        return (self.root / "studio" / f"{step}.luau").read_text(encoding="utf-8")

    @staticmethod
    def args_of(text):
        return text[:text.index('call = "')]  # the step's arguments come before the embedded modules

    def test_the_costumed_fixture_is_a_valid_scene(self):
        b = beats.load(self.root)
        self.assertEqual(costume.roles(b), ["player", "npc1"])
        self.assertEqual(costume.check(self.root, b), [])
        data = (self.root / "export" / "Fixture_Scene.luau").read_text(encoding="utf-8")
        self.assertIn('Costumes = {', data)
        self.assertIn("Costume = true", data)
        scene = workspace.read_json(self.root / "export" / "scene.json")
        self.assertEqual(sorted(scene["clips"]["R6"]), ["npc1", "player"])

    def last_install(self):
        """The install step's only part, or its last one (it carries the data module, cast and costumes)."""
        parts = sorted((self.root / "studio").glob("install.*.luau"), key=lambda p: int(p.name.split(".")[1]))
        return (parts[-1] if parts else self.root / "studio" / "install.luau").read_text(encoding="utf-8")

    def test_install_builds_the_costumes_instead_of_copying_a_model(self):
        studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
        text = self.last_install()
        args = self.args_of(text)
        self.assertIn("costumes = {", args)
        self.assertIn('character = "Fixture Guard"', args)
        self.assertNotIn('model = "costume"', args)  # the costumed guard is not in the copied cast
        self.assertIn('Costume = "', text)  # the Costume module rides along
        self.assertIn("Fixture_Scene_npc1_R6", text)
        worn = args.split("costumes = {", 1)[1]
        for kept_on_disk in ("source = ", "creator = ", "why = ", "film = "):  # credits and the film look stay on disk
            self.assertNotIn(kept_on_disk, worn)
        self.assertIn('rigs = {"R15", "R6"}', worn)  # catalog_for: each copy wears the items its rig shows

    def test_without_costumes_nothing_changes(self):
        root = fixture.write_scene(env=self.env)
        scenefile.write(root)
        self.assertFalse((root / "cast" / "player.json").exists())
        studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "R15"}, env=self.env)
        text = (root / "studio" / "install.luau").read_text(encoding="utf-8")
        self.assertNotIn("costumes = {", self.args_of(text))  # (SceneInstall's own source names the argument)
        self.assertNotIn('Costume = "', text)
        b = beats.load(root)
        manifest = workspace.read_json(root / "export" / "manifest.json")
        args = studio._install_args(b, "data", manifest, {"clips": True})
        self.assertEqual(set(args), {"name", "data", "trigger", "cast", "anchor"})  # the arguments Plan 2 sent
        self.assertEqual(args, studio._install_args(b, "data", manifest, {"clips": True}, {}))

    def test_the_rig_step_captures_the_costume(self):
        studio.run_step("Fixture_Scene", "rig", {"role": "npc1"}, env=self.env)
        text = self.text("rig_npc1")
        self.assertIn('call = "captureRig"', text)
        self.assertIn('main = "Costume"', text)
        self.assertIn('character = "Fixture Guard"', text)

    def test_a_creature_has_no_rig_step(self):
        spec = costume.starter("npc1", "creature", "Beast", "credit")
        workspace.write_json(self.root / "cast" / "npc1.json", spec)
        with self.assertRaises(SystemExit) as e:
            studio.run_step("Fixture_Scene", "rig", {"role": "npc1"}, env=self.env)
        self.assertIn("is a creature", str(e.exception))

    def test_a_bad_spec_stops_the_install(self):
        spec = workspace.read_json(self.root / "cast" / "npc1.json")
        spec["catalog"][0]["meshId"] = "rbxassetid://1"
        workspace.write_json(self.root / "cast" / "npc1.json", spec)
        with self.assertRaises(SystemExit) as e:
            studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
        self.assertIn("cast/npc1.json", str(e.exception))
        self.assertFalse(list((self.root / "studio").glob("install*.luau")))  # nothing to send

    def budget(self, size):
        was, studio.BUDGET = studio.BUDGET, size
        self.addCleanup(setattr, studio, "BUDGET", was)

    def by_id(self):
        import hashlib
        out = self.root / "export"
        ids = {n: {"id": str(100 + i), "sha": hashlib.sha256((out / f"{n}.rbxmx").read_bytes()).hexdigest()}
               for i, n in enumerate(scenefile.clip_names(workspace.read_json(out / "scene.json")))}
        (out / "ids.json").write_text(json.dumps(ids), encoding="utf-8", newline="\n")
        scenefile.write(self.root)

    def test_a_costumed_by_id_install_over_the_budget_is_sent_in_parts(self):
        self.by_id()
        self.budget(20_000)  # the install is about 60 KB (it grows with the authoring modules): three parts or more
        lines = "\n".join(studio.run_step("Fixture_Scene", "install", {}, env=self.env))
        folder = self.root / "studio"
        names = sorted(p.name for p in folder.glob("install*.luau"))
        self.assertGreaterEqual(len(names), 3)
        self.assertEqual(names, sorted(["install.luau"] + [f"install.{k}.luau" for k in range(2, len(names) + 1)]))
        for name in names:
            self.assertLessEqual((folder / name).stat().st_size, studio.BUDGET)
        self.assertIn("the last part runs it", lines)
        whole = payload.joined(folder, "install.luau")
        self.budget(60_000)
        studio.run_step("Fixture_Scene", "install", {}, env=self.env)
        self.assertEqual(sorted(p.name for p in folder.glob("install*.luau")), ["install.luau"])
        self.assertEqual((folder / "install.luau").read_text(encoding="utf-8"), whole)

    def test_a_costumed_by_id_install_with_a_4_kb_data_module_no_longer_refuses(self):
        self.by_id()
        data = self.root / "export" / "Fixture_Scene.luau"
        data.write_text(data.read_text(encoding="utf-8") + "\n-- " + "p" * 10_000 + "\n", encoding="utf-8", newline="\n")
        studio.run_step("Fixture_Scene", "install", {}, env=self.env)
        names = sorted(p.name for p in (self.root / "studio").glob("install*.luau"))
        self.assertEqual(names, ["install.2.luau", "install.luau"])
        for name in names:
            self.assertLessEqual((self.root / "studio" / name).stat().st_size, studio.BUDGET)
        self.assertIn("p" * 10_000, payload.joined(self.root / "studio", "install.luau"))

    def test_a_studio_only_install_whose_last_part_is_over_goes_in_parts(self):
        self.budget(40_000)  # SceneInstall, Capture, ClipBuilder and Costume alone are about 46 KB
        studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
        folder = self.root / "studio"
        names = sorted(p.name for p in folder.glob("install*.luau"))
        self.assertGreater(len(names), 2)
        self.assertTrue(any(n.count(".") == 3 for n in names), names)  # install.<k>.2.luau: the last part, split
        for name in names:
            self.assertLessEqual((folder / name).stat().st_size, studio.BUDGET)
        last = [n for n in names if n.count(".") == 2 and n != "install.luau"][-1]
        self.assertIn("Costume", payload.joined(folder, last))
        self.assertIn("Nobody passes this gate.", payload.joined(folder, last))

    @unittest.skipUnless(luaurun.find(), "luau is not installed")
    def test_every_part_of_a_split_install_parses(self):
        self.budget(40_000)
        studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
        texts = {p.name: p.read_text(encoding="utf-8") for p in (self.root / "studio").glob("install*.luau")}
        self.assertEqual(luaurun.parse_texts(texts), [])

    def test_a_clip_that_cannot_fit_even_alone_is_still_refused(self):
        self.budget(10_000)
        with self.assertRaises(SystemExit) as e:
            studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
        self.assertIn("upload", str(e.exception))

    def test_costume_look_and_off(self):
        lines = studio.run_step("Fixture_Scene", "costume-look", {}, env=self.env)
        text = self.text("costume-look")
        self.assertIn('call = "lineup"', text)
        self.assertIn("at = {600, 0, 600, 0}", self.args_of(text))
        self.assertIn("costume-look.luau", "\n".join(lines))
        studio.run_step("Fixture_Scene", "costume-look-off", {}, env=self.env)
        self.assertIn('call = "lineupOff"', self.text("costume-look-off"))

    def test_costume_look_at_a_place(self):
        studio.run_step("Fixture_Scene", "costume-look", {"at": "10,0,20,90"}, env=self.env)
        self.assertIn("at = {10.0, 0.0, 20.0, 90.0}", self.args_of(self.text("costume-look")))

    def test_costume_look_needs_a_costume(self):
        fixture.write_scene(env=self.env)
        with self.assertRaises(SystemExit) as e:
            studio.run_step("Fixture_Scene", "costume-look", {}, env=self.env)
        self.assertIn("no role wears a costume", str(e.exception))


class TestsceneCommandTest(unittest.TestCase):
    def test_testscene_costume_dresses_the_fixture(self):
        import run
        with tempfile.TemporaryDirectory() as tmp, mock.patch.dict(os.environ, {"MAKE_CUTSCENE_WORK": tmp}):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(run.cmd_testscene(["--costume"]), 0)
            root = Path(tmp) / "cutscenes" / "Fixture_Scene"
            self.assertTrue((root / "cast" / "npc1.json").exists())
            self.assertEqual(costume.roles(beats.load(root)), ["player", "npc1"])
            with redirect_stdout(io.StringIO()):
                run.cmd_testscene([])
            self.assertEqual(costume.roles(beats.load(root)), [])
            self.assertFalse((root / "cast" / "npc1.json").exists())


class SourceTest(unittest.TestCase):
    def test_new_luau_starts_with_the_method_line(self):
        import paths
        for rel in ("authoring/Costume.luau", "tests/Costume.test.luau", "tests/DataCostume.test.luau"):
            head = (paths.ROBLOX / rel).read_text(encoding="utf-8").splitlines()[:2]
            self.assertTrue(any(line.endswith("Method by fwjelaa (FWJ STUDIOS).") for line in head), rel)

    def test_the_fixture_costumes_are_valid_specs(self):
        for role, spec in fixture.COSTUMES.items():
            self.assertEqual(costume.validate(json.loads(json.dumps(spec)), role), [], role)

    def test_the_fixture_dresses_from_the_catalog_only(self):
        # spec 14.3: a character wears real catalog items; parts are only for creatures and props
        for role, spec in fixture.COSTUMES.items():
            self.assertNotIn("built", spec, role)
            slots = {c["slot"] for c in spec["catalog"]}
            self.assertLessEqual({"shirt", "pants"}, slots, role)  # R6 shows classic clothing only
            self.assertTrue(all(c.get("film") for c in spec["catalog"]), role)  # the film set's stand-in colours


if __name__ == "__main__":
    unittest.main()
