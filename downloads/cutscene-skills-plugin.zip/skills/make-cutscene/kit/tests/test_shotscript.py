"""Tests for kit/shotscript.py: shot scripts in words -> draft shots. Method by fwjelaa (FWJ STUDIOS)."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import shotscript  # noqa: E402

SCRIPT = """# awakening - Power awakening (approx 20 s, 12 shots)

1. WIDE / 24mm, high crane, 2.0s. Ruined arena at dusk, rubble and scorched ground. The hero kneels at centre, head bowed. SFX: wind, low ringing tone.
2. CLOSE-UP / 85mm, static, 1.5s. Fingers clench dust; a tiny blue spark between knuckles. SFX: faint crackle.
3. MEDIUM / 50mm, slow orbit left, 2.0s. Thin aura wisps rise from the hero's shoulders. VFX: rising embers. SFX: heartbeat.
4. LOW ANGLE GROUND / 20mm, 1.2s. Fine cracks spread across the floor towards camera. SFX: stone crackle building.
5. EXTREME CLOSE-UP eyes / 100mm, 1.0s. Eyes snap open, pupils ignite gold. SFX: sharp inhale, ring stinger.
6. MEDIUM / 35mm, quick push-in, 1.2s. Hero stands; aura column erupts upward, cloth whipping. VFX: light pillar, camera shake. SFX: rising roar.
7. WIDE / 18mm, 1.5s. Ground splits in a ring, chunks float up. VFX: debris lift, dust ring.
8. CLOSE-UP / 50mm, 0.6s. Hero's fists clench; a beat of silence. SFX: all sound cuts out.
9. WIDE SHOCKWAVE / 14mm, camera pushed back, 1.0s. A white shockwave ring blasts outward and slams the lens. VFX: white flash frame, bloom. SFX: huge boom.
10. SLOW-MOTION CLOSE / 85mm, 120 fps feel, 3.0s. Hair and cloak float, embers hang, a single piece of rubble drifts past. SFX: muffled low drone.
11. SLOW-MOTION MEDIUM-LOW / 35mm, slow arc up, 2.5s. Hero turns toward camera, eyes glowing, aura calm now. HERO (whisper): "Now I remember."
12. HERO SHOT / 28mm low angle, slow pull-back, 3.0s. Hero stands in a crater, silhouette against a burning sky, title-card style. SFX: music swell, then cut to gameplay.
"""


class ShotScriptTest(unittest.TestCase):
    def setUp(self):
        self.shots = shotscript.parse(SCRIPT)

    def test_every_numbered_shot_is_read(self):
        self.assertEqual([s["n"] for s in self.shots], list(range(1, 13)))
        self.assertEqual(sum(s["length"] for s in self.shots), 20.5)
        s9 = self.shots[8]
        self.assertEqual((s9["type"], s9["lens"], s9["move"]), ("IMPACT", 14.0, "camera pushed back"))
        self.assertEqual(self.shots[11]["move"], "low angle, slow pull-back")
        self.assertEqual(self.shots[3]["move"], "")
        self.assertEqual(self.shots[0]["fov"], 53.1)

    def test_types_follow_the_framing_words(self):
        self.assertEqual([s["type"] for s in self.shots],
                         ["ESTABLISH", "INSERT", "ACTION", "ACTION", "INSERT", "ACTION", "ACTION", "INSERT", "IMPACT",
                          "INSERT", "ACTION", "HERO"])

    def test_vfx_words_become_suggested_markers(self):
        self.assertEqual({s["n"]: s["vfx"] for s in self.shots if s["vfx"]},
                         {2: ["Spark"], 3: ["Embers", "Wisps"], 4: ["Cracks"], 5: ["EyeFlare"], 6: ["Pillar"],
                          7: ["Dust", "Lift"], 9: ["Shockwave"], 10: ["Embers"], 12: ["Crater"]})
        self.assertEqual(self.shots[5]["screen"], ["Shake"])
        self.assertEqual(self.shots[8]["screen"], ["Flash", "Impact"])
        self.assertEqual([s["n"] for s in self.shots if s["slow"]], [10, 11])
        self.assertEqual(self.shots[10]["line"], ("HERO", "Now I remember.", "whisper"))

    def test_fit_keeps_every_beat_in_order(self):
        lengths = shotscript.fit([s["length"] for s in self.shots], 9.45)
        self.assertAlmostEqual(sum(lengths), 9.45, places=6)
        self.assertTrue(all(v >= shotscript.MIN_SHOT - 1e-9 for v in lengths))
        self.assertGreater(lengths[9], lengths[7], "a long beat stays longer than a short one")
        with self.assertRaises(SystemExit):
            shotscript.fit([1.0] * 12, 3.0)

    def test_draft_shots_carry_markers_lines_slowmo_and_a_return(self):
        shots, lines = shotscript.draft_shots(self.shots, "player", fit_to=10.0, kind="awakening")
        self.assertEqual(len(shots), 13)
        self.assertEqual(shots[-1]["type"], "RETURN")
        self.assertAlmostEqual(sum(s["length"] for s in shots), 10.0, places=3)
        self.assertEqual(lines, {"1": {"speaker": "Hero", "text": "Now I remember."}})
        names = [(m[1], m[2]) for m in shots[8]["markers"]]
        self.assertIn(("VFX", "Shockwave"), names)
        self.assertIn(("Impact", ""), names)
        self.assertIn(("Slowmo", "0.25"), [(m[1], m[2]) for m in shots[9]["markers"]])
        self.assertIn(("Slowmo", "1"), [(m[1], m[2]) for m in shots[11]["markers"]])
        for s in shots:
            for m in s["markers"]:
                self.assertTrue(0 <= m[0] <= s["length"], (s["type"], m))

    def test_a_script_without_numbered_shots_says_how_to_write_one(self):
        with self.assertRaises(SystemExit) as e:
            shotscript.parse("just some words")
        self.assertIn("6. MEDIUM / 35mm", str(e.exception))
        with self.assertRaises(SystemExit) as e:
            shotscript.parse("1. WIDE / 24mm, crane. No length here.")
        self.assertIn("no length", str(e.exception))


if __name__ == "__main__":
    unittest.main()
