"""Tests for kit/takes.py on a synthetic 'Studio window' recording: a magenta game view with the overlay's flashes
(a double pulse at the end of the scene, optionally a single start flash). Method by fwjelaa (FWJ STUDIOS)."""
import json
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import media  # noqa: E402
import paths  # noqa: E402
import takes  # noqa: E402
import workspace  # noqa: E402

HAVE_FFMPEG = shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None


def graph(end_at=4.0, start_at=1.0, d=5.5, view="960x540", pulses=(0.0, 0.5), width=0.29, spans=None):
    """A 1280x720 'window' with a test-pattern game view; magenta over the view at a single start flash (start_at,
    optional) and at each pulse of the end flash (end_at + offset)."""
    w, h = (int(v) for v in view.split("x"))
    times = [] if start_at is None else [start_at]
    times += [end_at + p for p in pulses]
    spans = spans if spans is not None else [(t, round(t + width, 3)) for t in times]  # explicit spans: (from, to) s
    enable = "+".join(f"between(t,{a},{b})" for a, b in spans)
    return (f"color=c=gray:s=1280x720:d={d}:r=60[bg];testsrc=s={w}x{h}:d={d}:r=60[gv];"
            f"color=c=0xFF00FF:s={w}x{h}:d={d}:r=60[mg];[bg][gv]overlay=160:90[a];"
            f"[a][mg]overlay=160:90:enable='{enable}'")


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class TakesTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = workspace.create("TakeTry", env={"MAKE_CUTSCENE_WORK": self.tmp.name})
        beats.save(beats.draft("TakeTry", {"type": "words", "text": "x"}, [beats.shot("ACTION", 2.2)]), self.root)
        self.raw = self.root / "preview" / "raw.mp4"
        self.record(graph())

    def frames(self, path):
        out = subprocess.run(["ffprobe", "-v", "error", "-count_frames", "-select_streams", "v:0", "-show_entries",
                              "stream=nb_read_frames", "-of", "csv=p=0", str(path)], capture_output=True, text=True)
        return int(out.stdout.strip())

    def record(self, spec):
        media.ffmpeg("-f", "lavfi", "-i", spec, "-c:v", "libx264", "-preset", "ultrafast", "-qp", "0",
                     "-pix_fmt", "yuv444p", self.raw)

    def refused(self):
        with self.assertRaises(SystemExit) as e:
            takes.make(self.root)
        return str(e.exception)

    def test_flashes(self):
        runs = takes.flashes(takes.scan(self.raw))
        self.assertEqual(len(runs), 3, runs)
        self.assertAlmostEqual(runs[0][0], 1.0, delta=0.03)
        self.assertAlmostEqual(runs[0][1], 1.3, delta=0.03)
        self.assertAlmostEqual(runs[1][0], 4.0, delta=0.03)
        self.assertAlmostEqual(runs[2][0], 4.5, delta=0.03)

    def test_the_double_pulse_is_the_end_flash(self):
        ends = takes.end_flashes(takes.flashes(takes.scan(self.raw)))  # the single start-like flash is ignored
        self.assertEqual(len(ends), 1, ends)
        self.assertAlmostEqual(ends[0][0], 4.0, delta=0.03)
        self.assertAlmostEqual(ends[0][1], 4.8, delta=0.03)
        self.assertEqual(ends[0][2], 2)

    def test_viewport(self):
        x, y, w, h = takes.viewport(self.raw, 1.15)
        for got, want in zip((x, y, w, h), (160, 90, 960, 540)):
            self.assertAlmostEqual(got, want, delta=8)

    def test_make(self):
        lines = takes.make(self.root)
        info = media.probe(self.root / "preview" / "TakeTry.mp4")
        self.assertAlmostEqual(info["duration"], 2.2, delta=0.04)
        self.assertAlmostEqual(info["width"], 960, delta=16)
        self.assertAlmostEqual(self.frames(self.root / "preview" / "TakeTry.mp4"), 132, delta=1)
        self.assertTrue((self.root / "preview" / "sheet.png").exists())
        self.assertEqual(len(list((self.root / "preview" / "frames").glob("*.png"))), takes.SHEET_FRAMES)
        self.assertFalse(any("WARNING" in line for line in lines), lines)

    def test_both_synthetic_clips_remain_decodable_in_review_packets(self):
        # Actual FFmpeg-generated test patterns, not Studio playback or artistic review.
        import review
        import gates
        import sheets
        takes.make(self.root)
        (self.root / 'preview/raw_R6.mp4').write_bytes(self.raw.read_bytes())
        takes.make(self.root, rig='R6')
        for rig in ('R15', 'R6'):
            sheets.side_by_side(self.root, rig=rig)
        workspace.write_json(self.root / 'export/gates.json',
                             {'ok': True, 'export': gates.export_hash(self.root)})
        review.set_playtest(self.root, [f'{key}=pass' for key in review.PLAYTEST])
        for folder in review.packet(self.root, 1):
            for rig in ('R15', 'R6'):
                clip = folder / f'preview_{rig}.mp4'
                self.assertAlmostEqual(media.probe(clip)['duration'], 2.2, delta=0.04)
                self.assertAlmostEqual(self.frames(clip), 132, delta=1)
        made = workspace.read_json(self.root / 'preview/sheets.json')
        self.assertEqual(made['overview']['hashes'],
                         review.evidence.hashes(self.root / 'preview', ['sheet.png']))
        self.assertEqual(made['overview_R6']['preview']['R6'], review.preview_stamp(self.root, 'R6'))

    def test_a_new_cut_clears_the_sheets_made_from_the_old_one(self):
        pv = self.root / "preview"
        for name in ("side_by_side_1.png", "side_by_side_2.png", "side_by_side_R6_1.png", "likeness.png"):
            (pv / name).write_bytes(b"made from the old cut")
        takes.make(self.root)
        self.assertFalse((pv / "side_by_side_1.png").exists())
        self.assertFalse((pv / "side_by_side_2.png").exists())
        self.assertFalse((pv / "likeness.png").exists(), "the likeness sheet shows both casts")
        self.assertTrue((pv / "side_by_side_R6_1.png").exists(), "the R6 cut's own sheets stay")

    def test_an_r6_preview_has_its_own_names(self):
        raw6 = self.root / "preview" / "raw_R6.mp4"
        raw6.write_bytes(self.raw.read_bytes())
        (self.root / "preview" / "raw_R6.json").write_text(json.dumps({"announced_at": 0.4}), encoding="utf-8")
        lines = takes.make(self.root, rig="R6")
        pv = self.root / "preview"
        self.assertAlmostEqual(media.probe(pv / "TakeTry_R6.mp4")["duration"], 2.2, delta=0.04)
        self.assertTrue((pv / "sheet_R6.png").exists())
        self.assertEqual(len(list((pv / "frames_R6").glob("*.png"))), takes.SHEET_FRAMES)
        self.assertFalse((pv / "TakeTry.mp4").exists())  # the R15 names are untouched
        self.assertFalse((pv / "sheet.png").exists())
        self.assertIn("TakeTry_R6.mp4", lines[0])
        takes.make(self.root)  # no rig = R15, exactly as before
        self.assertTrue((pv / "TakeTry.mp4").exists() and (pv / "sheet.png").exists())
        self.assertEqual(len(list((pv / "frames").glob("*.png"))), takes.SHEET_FRAMES)

    def test_the_r6_names_match_the_side_by_side_sheet(self):
        import sheets
        raw6 = self.root / "preview" / "raw_R6.mp4"
        raw6.write_bytes(self.raw.read_bytes())
        takes.make(self.root, rig="R6")
        made = sheets.side_by_side(self.root, rig="R6")  # finds preview/TakeTry_R6.mp4
        self.assertTrue(made and all("R6" in Path(m).name for m in made), made)

    def test_an_unknown_rig_or_a_missing_r6_take_is_refused(self):
        with self.assertRaises(SystemExit) as e:
            takes.make(self.root, rig="R7")
        self.assertIn("R15 or R6", str(e.exception))
        with self.assertRaises(SystemExit) as e:
            takes.make(self.root, rig="R6")
        self.assertIn("record TakeTry --rig R6", str(e.exception))

    def test_the_end_flash_alone_is_enough(self):
        self.record(graph(start_at=None))
        lines = takes.make(self.root)
        info = media.probe(self.root / "preview" / "TakeTry.mp4")
        self.assertAlmostEqual(info["duration"], 2.2, delta=0.04)  # end - Length = start
        self.assertFalse(any("WARNING" in line for line in lines), lines)

    def test_a_take_without_the_end_flash_is_refused(self):
        media.ffmpeg("-f", "lavfi", "-i", "testsrc=s=320x180:d=1:r=30", "-pix_fmt", "yuv420p", self.raw)
        self.assertIn("end flash", self.refused())

    def test_a_single_flash_is_not_the_end_flash(self):
        self.record(graph(end_at=3.0, start_at=None, pulses=(0.0,)))
        message = self.refused()
        self.assertIn("double", message)
        self.assertIn("end flash", message)

    def test_a_one_frame_flicker_is_not_a_pulse(self):
        self.record(graph(start_at=None, spans=[(4.0, 4.01), (4.2, 4.21)]))
        message = self.refused()
        self.assertIn("end flash", message)
        self.assertIn("double", message)

    def test_a_two_frame_dropout_inside_a_pulse_is_still_one_pulse(self):
        self.record(graph(start_at=None, spans=[(4.0, 4.09), (4.13, 4.29), (4.5, 4.79)]))
        ends = takes.end_flashes(takes.flashes(takes.scan(self.raw)))
        self.assertEqual(len(ends), 1, ends)
        self.assertAlmostEqual(ends[0][0], 4.0, delta=0.03)
        self.assertFalse(any("WARNING" in line for line in takes.make(self.root)))

    def test_pulses_of_the_wrong_width_or_gap_are_refused(self):
        self.record(graph(start_at=None, spans=[(4.0, 4.6), (4.8, 5.1)]))  # 0.6 s wide: two scenes overlapped?
        self.assertIn("double", self.refused())
        self.record(graph(start_at=None, spans=[(3.0, 3.29), (3.9, 4.19)]))  # 0.6 s apart
        self.assertIn("double", self.refused())

    def test_overlapping_triggers_are_refused(self):
        self.record(graph(start_at=None, spans=[(2.6, 2.89), (3.1, 3.39), (4.2, 4.49), (4.7, 4.99)]))
        message = self.refused()
        self.assertIn("2 end flashes", message)
        self.assertIn("one scene per take", message)

    def test_a_scene_that_would_start_before_the_recording_is_refused(self):
        self.record(graph(end_at=1.5, start_at=None))  # end 1.25: start < 0
        self.assertIn("before the recording started", self.refused())

    def test_a_start_that_is_too_close_to_the_beginning_is_refused(self):
        self.record(graph(end_at=2.5, start_at=None))  # start 0.05 s: no lead-in
        self.assertIn("too close to the start", self.refused())

    def test_a_truncated_take_is_refused(self):
        self.record(graph(end_at=4.9, start_at=None, pulses=(0.0, 0.55)))  # the second pulse runs off the end
        self.assertIn("cut off", self.refused())

    def test_a_take_shorter_than_the_scene_is_refused(self):
        self.record(graph(end_at=1.5, start_at=None, d=2.6))
        self.assertIn("shorter than the scene", self.refused())

    def test_the_cut_must_agree_with_when_the_scene_was_started(self):
        self.record(graph(start_at=None))  # the scene starts at 1.55 s in the take
        meta = self.root / "preview" / "raw.json"
        meta.write_text(json.dumps({"announced_at": 3.0}), encoding="utf-8")
        self.assertIn("start the scene now", self.refused())
        meta.write_text(json.dumps({"announced_at": 0.4}), encoding="utf-8")
        self.assertFalse(any("WARNING" in line for line in takes.make(self.root)))

    def test_a_wide_game_view_is_cropped_to_its_centred_16_by_9(self):
        self.record(graph(view="1000x400"))  # 2.5:1, as in a maximised Studio
        takes.make(self.root)
        info = media.probe(self.root / "preview" / "TakeTry.mp4")
        self.assertAlmostEqual(info["width"] / info["height"], 16 / 9, delta=0.02)
        self.assertAlmostEqual(info["height"], 396, delta=8)  # full height of the view, the sides are trimmed
        self.assertEqual(takes.fit_16x9((100, 50, 1000, 400)), (244, 50, 710, 400))
        self.assertEqual(takes.fit_16x9((0, 0, 960, 540)), (0, 0, 960, 540))
        self.assertEqual(takes.fit_16x9((0, 0, 600, 600)), (0, 0, 600, 600))  # taller than 16:9: left as it is


class OverlayContractTest(unittest.TestCase):
    """The Luau overlay and takes.py must agree on the flash timing."""

    def test_overlay_constants_match_takes(self):
        src = (paths.ROBLOX / "authoring" / "RecordOverlay.client.luau").read_text(encoding="utf-8")
        m = re.search(r"local LEAD, PULSE, GAP = ([0-9.]+), ([0-9.]+), ([0-9.]+)", src)
        self.assertIsNotNone(m, "RecordOverlay.client.luau must declare: local LEAD, PULSE, GAP = ...")
        self.assertEqual(tuple(float(v) for v in m.groups()), (takes.LEAD, takes.PULSE, takes.GAP))
        self.assertIn("startAt + duration + LEAD", src)  # the end flash starts LEAD after the scene's last frame
        self.assertIn("Method by fwjelaa (FWJ STUDIOS).", "\n".join(src.splitlines()[:2]))


if __name__ == "__main__":
    unittest.main()
