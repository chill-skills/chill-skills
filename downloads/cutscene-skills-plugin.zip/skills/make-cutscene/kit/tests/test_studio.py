"""Tests for kit/studio.py: per-cutscene Studio steps. Method by fwjelaa (FWJ STUDIOS)."""
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import bundle  # noqa: E402
import luaurun  # noqa: E402
import paths  # noqa: E402
import payload  # noqa: E402
import studio  # noqa: E402
import workspace  # noqa: E402


class StudioTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.env = {"MAKE_CUTSCENE_WORK": self.tmp.name}
        self.root = workspace.create("GateGuard", env=self.env)
        b = beats.from_words("GateGuard", "a guard stops the player", [("Guard", "Halt.")])
        b["trigger"] = {"type": "zone", "size": [16, 8, 16]}
        beats.save(b, self.root)

    def test_anchor_step(self):
        lines = studio.run_step("GateGuard", "anchor", {"at": "10,0,-20,90"}, env=self.env)
        path = self.root / "studio" / "anchor.luau"
        text = path.read_text(encoding="utf-8")
        self.assertIn("local EMBED = {", text)
        self.assertNotIn(bundle.EMBED_LINE, text)
        self.assertIn('call = "placeTrigger"', text)
        self.assertIn("at = {10.0, 0.0, -20.0, 90.0}", text)
        self.assertIn("Capture.placeTrigger", text)
        self.assertLess(len(text.encode("utf-8")), studio.BUDGET)
        self.assertIn("execute_luau", "\n".join(lines))

    def test_anchor_from_camera_by_default(self):
        studio.run_step("GateGuard", "anchor", {}, env=self.env)
        self.assertIn('from = "camera"', (self.root / "studio" / "anchor.luau").read_text(encoding="utf-8"))

    def test_trigger_must_be_set(self):
        b = beats.load(self.root)
        b["trigger"] = None
        beats.save(b, self.root)
        with self.assertRaises(SystemExit) as e:
            studio.run_step("GateGuard", "anchor", {}, env=self.env)
        self.assertIn("trigger", str(e.exception))

    def test_bad_at(self):
        with self.assertRaises(SystemExit):
            studio.parse_at("1,2")

    def test_map_and_chunk(self):
        studio.run_step("GateGuard", "map", {}, env=self.env)
        self.assertIn('call = "storeMap"', (self.root / "studio" / "map.luau").read_text(encoding="utf-8"))
        line = studio.run_step("GateGuard", "chunk", {"n": 3}, env=self.env)[0]
        self.assertEqual(line, 'return game:GetService("ServerStorage")["CutsceneCapture_GateGuard"]["3"].Value')

    def synthetic(self, step, kb):
        """A step whose text is about `kb` KB: the arguments carry the bulk (as a costume's catalog list does)."""
        return studio.render(self.root, step, ["Capture"], "Capture", "storeMap",
                             {"name": "GateGuard", "radius": 1, "pad": "".join(f"{i:06d}," for i in range(kb * 143))})

    def test_an_oversized_step_is_written_as_parts_never_refused(self):
        paths_, note = self.synthetic("big", 130)
        self.assertEqual([p.name for p in paths_], ["big.luau", "big.2.luau", "big.3.luau"])
        for p in paths_:
            self.assertLessEqual(p.stat().st_size, studio.BUDGET)
        for p in paths_:
            self.assertIn(p.name, note)
        self.assertLess(note.index("big.luau"), note.index("big.2.luau"))
        self.assertLess(note.index("big.2.luau"), note.index("big.3.luau"))
        text = studio._text(["Capture"], "Capture", "storeMap",
                            {"name": "GateGuard", "radius": 1, "pad": "".join(f"{i:06d}," for i in range(130 * 143))})
        self.assertGreater(len(text.encode("utf-8")), 2 * studio.BUDGET)
        self.assertEqual(payload.joined(self.root / "studio", "big.luau"), text)

    def test_run_step_lists_every_part_in_order(self):
        was, studio.BUDGET = studio.BUDGET, 5_000  # the anchor step embeds Capture: about 18 KB
        self.addCleanup(setattr, studio, "BUDGET", was)
        lines = "\n".join(studio.run_step("GateGuard", "anchor", {"at": "1,2,3,4"}, env=self.env))
        self.assertIn("send part 1", lines)
        self.assertLess(lines.index("anchor.luau"), lines.index("anchor.2.luau"))

    def test_a_step_under_the_budget_is_one_file_with_the_same_name_and_text(self):
        path, note = studio.render(self.root, "small", ["Capture"], "Capture", "storeMap", {"name": "GateGuard"})
        want = studio._text(["Capture"], "Capture", "storeMap", {"name": "GateGuard"})
        self.assertEqual(path, self.root / "studio" / "small.luau")
        self.assertEqual(path.read_bytes(), want.encode("utf-8"))
        self.assertEqual(note, f"wrote {path} ({len(want.encode('utf-8')) / 1000:.1f} KB)")
        self.assertEqual(sorted(p.name for p in (self.root / "studio").glob("small*")), ["small.luau"])

    def test_a_step_that_shrinks_loses_its_stale_parts(self):
        self.synthetic("big", 130)
        self.assertTrue((self.root / "studio" / "big.3.luau").exists())
        self.synthetic("big", 70)  # two parts now
        self.assertEqual(sorted(p.name for p in (self.root / "studio").glob("big*")), ["big.2.luau", "big.luau"])
        studio.render(self.root, "big", ["Capture"], "Capture", "storeMap", {"name": "GateGuard"})
        self.assertEqual(sorted(p.name for p in (self.root / "studio").glob("big*")), ["big.luau"])
        self.assertIn("Capture", payload.joined(self.root / "studio", "big.luau"))

    def test_studio_parts_name_studio_never_out_and_bundles_still_name_out(self):
        paths_, _ = self.synthetic("big", 130)
        for p in paths_:
            text = p.read_text(encoding="utf-8")
            head = text[:text.index("local ServerStorage")]
            tail = text[text.index("local ServerStorage"):].replace(payload.long_string(payload._payload(text)), "")
            for piece in (head, tail):
                self.assertNotIn("out/", piece)
            self.assertIn("studio/big", head)
        self.assertIn("stored: send studio/big.2.luau next", paths_[0].read_text(encoding="utf-8"))
        self.assertIn("send studio/big.luau, studio/big.2.luau, studio/big.3.luau again, in order",
                      paths_[-1].read_text(encoding="utf-8"))
        bundled = payload.parts("big.luau", "x" * 130_000)
        self.assertIn("-- out/big.luau is part 1 of", bundled[0][1])
        self.assertIn("stored: send out/big.2.luau next", bundled[0][1])
        self.assertIn("send out/big.luau, out/big.2.luau, out/big.3.luau again", bundled[-1][1])

    def test_a_budget_smaller_than_the_part_wrapper_is_refused_and_says_why(self):
        was, studio.BUDGET = studio.BUDGET, 1_000
        self.addCleanup(setattr, studio, "BUDGET", was)
        with self.assertRaises(SystemExit) as e:
            studio.render(self.root, "tiny", ["Capture"], "Capture", "storeMap", {"name": "GateGuard"})
        self.assertIn("too small", str(e.exception))

    @unittest.skipUnless(luaurun.find(), "luau is not installed")
    def test_every_part_of_an_oversized_step_parses(self):
        paths_, _ = self.synthetic("big", 130)
        bad = luaurun.parse_texts({p.name: p.read_text(encoding="utf-8") for p in paths_})
        self.assertEqual(bad, [])

    def test_every_rendered_step_is_under_the_budget(self):
        for step in ("anchor", "map"):
            studio.run_step("GateGuard", step, {}, env=self.env)
            size = (self.root / "studio" / f"{step}.luau").stat().st_size
            self.assertLess(size, studio.BUDGET, step)

    def test_map_step_warns_about_older_chunks(self):
        (self.root / "studio").mkdir(exist_ok=True)
        (self.root / "studio" / "map_0.txt").write_text("old", encoding="utf-8")
        text = "\n".join(studio.run_step("GateGuard", "map", {}, env=self.env))
        self.assertIn("delete studio/map_*.txt from an older capture first", text)
        self.assertIn("map_0.txt", text)

    def test_template_clears_a_leftover_holder(self):
        self.assertIn('FindFirstChild("_CutsceneAuthoring")', studio.TEMPLATE.read_text(encoding="utf-8"))

    def test_unknown_step(self):
        with self.assertRaises(SystemExit) as e:
            studio.run_step("GateGuard", "fly", {}, env=self.env)
        self.assertIn("anchor", str(e.exception))

    def test_clean_drops_nones(self):
        self.assertEqual(studio.clean({"a": None, "b": [1, None], "c": {"d": None, "e": 2}}), {"b": [1], "c": {"e": 2}})


class InstallStepTest(unittest.TestCase):
    def setUp(self):
        import fixture
        import scenefile
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.env = {"MAKE_CUTSCENE_WORK": self.tmp.name}
        self.root = fixture.write_scene(env=self.env)
        scenefile.write(self.root)

    def text(self, step="install"):
        return (self.root / "studio" / f"{step}.luau").read_text(encoding="utf-8")

    @staticmethod
    def args_of(text):
        return text[:text.index('call = "install"')]  # the step's arguments come before the embedded modules

    FORCE_MARGIN = 1_500  # room the last forced part keeps for SceneInstall to grow, in bytes

    def forced_budget(self):
        """A payload budget that splits this fixture install into parts and still fits its last part, measured from the
        real install (no fixed constant: SceneInstall grows, and a constant goes stale). The smallest budget that works
        is found by trying, then FORCE_MARGIN is added so a later growth of the fixed part doesn't break the tests."""
        was = studio.BUDGET
        try:
            def fits(budget):
                studio.BUDGET = budget
                try:
                    studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
                except SystemExit:
                    return False
                # a last part over the budget is sent as payload parts (install.2.2.luau): these tests want it whole
                return not list((self.root / "studio").glob("install.*.*.luau"))

            whole = was
            lo, hi = 1_000, whole  # lo does not fit, hi does
            while hi - lo > 100:
                mid = (lo + hi) // 2
                lo, hi = (lo, mid) if fits(mid) else (mid, hi)
            budget = hi + self.FORCE_MARGIN
            studio.BUDGET = was
            studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
            one_part = (self.root / "studio" / "install.luau").exists()
            size = len((self.root / "studio" / "install.luau").read_bytes()) if one_part else 0
            self.assertTrue(one_part and budget < size - self.FORCE_MARGIN,
                            f"the fixture install ({size} B) is too small to force a split at {budget} B")
            return budget
        finally:
            studio.BUDGET = was

    def test_clips_must_be_uploaded_or_asked_for(self):
        with self.assertRaises(SystemExit) as e:
            studio.run_step("Fixture_Scene", "install", {}, env=self.env)
        self.assertIn("--clips", str(e.exception))

    def test_studio_only_clips_for_one_rig(self):
        lines = studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "R15"}, env=self.env)
        text = self.text()
        for name in ("Fixture_Scene_Stage", "Fixture_Scene_npc1_R15", "Fixture_Scene_player_R15"):
            self.assertIn(f'{name} = "', text)  # a key of the embedded clips table
        self.assertNotIn('Fixture_Scene_player_R6 = "', text)
        self.assertIn('call = "install"', text)
        self.assertLess(len(text.encode("utf-8")), studio.BUDGET)
        self.assertIn("won't play in a published game", "\n".join(lines))

    def test_both_rigs_and_a_prompt_trigger(self):
        studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both", "trigger": "prompt"}, env=self.env)
        text = self.text()
        self.assertIn('Fixture_Scene_player_R6 = "', text)
        self.assertIn('type = "prompt"', text)

    def test_uploaded_scene_installs_by_id(self):
        import hashlib
        import json
        import re
        import scenefile
        out = self.root / "export"
        ids = {n: {"id": str(100 + i), "sha": hashlib.sha256((out / f"{n}.rbxmx").read_bytes()).hexdigest()}
               for i, n in enumerate(scenefile.clip_names(workspace.read_json(out / "scene.json")))}
        (out / "ids.json").write_text(json.dumps(ids), encoding="utf-8", newline="\n")
        scenefile.write(self.root)
        studio.run_step("Fixture_Scene", "install", {}, env=self.env)
        text = self.text()
        args = text[:text.index('call = "install"')]  # the step's arguments: they come before the embedded modules
        self.assertIsNone(re.search(r"\bclips\s*=", args))  # no embedded clips: the module names asset ids
        self.assertIn("rbxassetid://100", text)

    def test_remove(self):
        studio.run_step("Fixture_Scene", "remove", {}, env=self.env)
        self.assertIn('call = "remove"', self.text("remove"))

    def test_compact_keeps_what_clipbuilder_reads(self):
        import json
        d = workspace.read_json(self.root / "export" / "Fixture_Scene_Stage.json")
        c = json.loads(studio.compact(d))
        self.assertEqual(set(c), {"name", "loop", "priority", "parents", "keyframes"})
        for k in c["keyframes"]:
            for pose in k["poses"].values():
                cf = pose["cf"]
                self.assertTrue(all(len(str(v).split(".")[-1]) <= 4 for v in cf[:3]), cf)
                self.assertTrue(all(len(str(v).split(".")[-1]) <= 6 for v in cf[3:]), cf)

    def test_compact_rotations_stay_orthonormal(self):
        import json
        d = {"name": "c", "loop": False, "priority": "Action4", "parents": {}, "keyframes": [
            {"time": 0, "poses": {"P": {"cf": [1.23456789, 2, 3, 0.8660254, -0.5, 0, 0.5, 0.8660254, 0, 0, 0, 1],
                                        "style": "Linear", "dir": "In"}}}]}
        cf = json.loads(studio.compact(d))["keyframes"][0]["poses"]["P"]["cf"]
        self.assertEqual(cf[0], 1.2346)
        row = cf[3:6]
        self.assertAlmostEqual(sum(v * v for v in row), 1.0, places=5)

    def test_the_forced_budget_is_measured_from_the_real_overhead(self):
        budget = self.forced_budget()
        studio.BUDGET, was = budget, studio.BUDGET
        self.addCleanup(setattr, studio, "BUDGET", was)
        studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
        last = len(self.text("install.2").encode("utf-8"))
        self.assertGreaterEqual(budget - last, 0)
        self.assertLessEqual(budget - last, 4_000)  # the margin is a margin, not a different regime

    def test_part_k_will_not_run_before_part_k_minus_one(self):
        studio.BUDGET, was = self.forced_budget(), studio.BUDGET
        self.addCleanup(setattr, studio, "BUDGET", was)
        studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
        second = self.text("install.2")
        self.assertIn("part = 2", second)
        self.assertIn("parts = 2", second)
        self.assertIn("did not run yet", second)  # the guard, in the embedded SceneInstall
        self.assertNotIn("part = 2", self.text("install.1"))

    def test_a_big_install_goes_in_ordered_parts_with_the_data_in_the_last(self):
        studio.BUDGET, was = self.forced_budget(), studio.BUDGET
        self.addCleanup(setattr, studio, "BUDGET", was)
        lines = studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
        folder = self.root / "studio"
        self.assertFalse((folder / "install.luau").exists())
        first, last = self.text("install.1"), self.text("install.2")
        for text in (first, last):
            self.assertLessEqual(len(text.encode("utf-8")), studio.BUDGET)
        self.assertIn("part = 1", first)
        self.assertNotIn('type = "zone"', self.args_of(first))
        self.assertNotIn("Nobody passes this gate.", first)  # the data module is only in the last part
        self.assertIn("Nobody passes this gate.", last)
        self.assertIn('type = "zone"', self.args_of(last))
        joined = "\n".join(lines)
        self.assertIn("2 parts (~", joined)
        self.assertIn("py kit/run.py upload Fixture_Scene", joined)
        self.assertLess(joined.index("install.1.luau"), joined.index("install.2.luau"))

    def test_a_smaller_install_afterwards_leaves_no_old_parts(self):
        studio.BUDGET, was = self.forced_budget(), studio.BUDGET
        self.addCleanup(setattr, studio, "BUDGET", was)
        studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
        studio.BUDGET = was
        studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
        names = sorted(p.name for p in (self.root / "studio").glob("install*.luau"))
        self.assertEqual(names, ["install.luau"])

    def test_every_non_last_part_embeds_every_module_its_code_path_needs(self):
        """The template's `need` asserts on a module that was not embedded (N1): a part before the last one embeds no
        Capture, so SceneInstall may only ask for the modules it embeds before it returns from `stage`."""
        import re
        import paths
        studio.BUDGET, was = self.forced_budget(), studio.BUDGET
        self.addCleanup(setattr, studio, "BUDGET", was)
        studio.run_step("Fixture_Scene", "install", {"clips": True, "rig": "both"}, env=self.env)
        first = self.text("install.1")
        embedded = set(re.findall(r'^\t\t(\w+) = "', first[first.index("modules = {"):], re.M))
        self.assertEqual(embedded, {"SceneInstall", "ClipBuilder"})
        src = (paths.PACK / "roblox" / "authoring" / "SceneInstall.luau").read_text(encoding="utf-8")
        before_return = src[src.index("local function stage"):src.index("return msg")]
        asked = set(re.findall(r'need\("(\w+)"\)', before_return))
        self.assertLessEqual(asked, embedded)
        self.assertNotIn("Capture", asked)
        self.assertGreater(src.index('need("Capture")'), src.index("return msg"))

    def test_a_plan_with_many_parts_stays_under_the_budget(self):
        b = beats.load(self.root)
        clips = {f"C{i}": "x" * 20000 for i in range(30)}
        plan = studio._plan_parts(b, {"name": "Fixture_Scene", "data": "return {}"}, clips)
        self.assertGreater(len(plan), 10)  # part numbers are two digits wide
        for _, text in plan:
            self.assertLessEqual(len(text.encode("utf-8")), studio.BUDGET)

    def test_clips_keep_their_order_across_parts(self):
        b = beats.load(self.root)
        clips = {f"C{i}": "x" * 8000 for i in range(12)}
        plan = studio._plan_parts(b, {"name": "Fixture_Scene", "data": "return {}"}, clips)
        self.assertGreater(len(plan), 1)
        self.assertEqual([c for names, _ in plan for c in names], list(clips))
        for _, text in plan:
            self.assertLessEqual(len(text.encode("utf-8")), studio.BUDGET)

    def test_one_clip_too_big_for_any_part_is_refused_and_named(self):
        b = beats.load(self.root)
        with self.assertRaises(SystemExit) as e:
            studio._plan_parts(b, {"name": "Fixture_Scene", "data": "return {}"}, {"HugeClip": "x" * (studio.BUDGET + 1)})
        self.assertIn("HugeClip", str(e.exception))
        self.assertIn("upload", str(e.exception))

    def test_the_asset_id_install_is_one_part_without_clipbuilder(self):
        import hashlib
        import json
        import scenefile
        out = self.root / "export"
        ids = {n: {"id": str(100 + i), "sha": hashlib.sha256((out / f"{n}.rbxmx").read_bytes()).hexdigest()}
               for i, n in enumerate(scenefile.clip_names(workspace.read_json(out / "scene.json")))}
        (out / "ids.json").write_text(json.dumps(ids), encoding="utf-8", newline="\n")
        scenefile.write(self.root)
        studio.run_step("Fixture_Scene", "install", {}, env=self.env)
        text = self.text()
        self.assertNotIn('ClipBuilder = "', text)
        self.assertNotIn("part = ", self.args_of(text))
        self.assertLess(len(text.encode("utf-8")), studio.BUDGET)

    def test_a_missing_export_says_to_run_scene_first(self):
        root = workspace.create("NoExport", env=self.env)
        b = beats.from_words("NoExport", "a guard stops the player", [("Guard", "Halt.")])
        b["trigger"] = {"type": "zone", "size": [16, 8, 16]}
        beats.save(b, root)
        with self.assertRaises(SystemExit) as e:
            studio.run_step("NoExport", "install", {"clips": True}, env=self.env)
        self.assertIn("py kit/run.py scene NoExport", str(e.exception))


class SceneInstallSourceTest(unittest.TestCase):
    def test_header_sentence_ends_line_one_or_two(self):
        import paths
        lines = (paths.PACK / "roblox" / "authoring" / "SceneInstall.luau").read_text(encoding="utf-8").split("\n")
        self.assertTrue(any(ln.endswith("Method by fwjelaa (FWJ STUDIOS).") for ln in lines[:2]), lines[:2])

    def test_testscene_passes_hide_to_the_scene(self):
        import contextlib
        import io
        import os
        from unittest import mock
        import run
        with tempfile.TemporaryDirectory() as d, mock.patch.dict(os.environ, {"MAKE_CUTSCENE_WORK": d}):
            with contextlib.redirect_stdout(io.StringIO()):
                code = run.main(["run.py", "testscene", "--hide", "Gate/Guard"])
            self.assertEqual(code, 0)
            b = beats.load(workspace.open_("Fixture_Scene", {"MAKE_CUTSCENE_WORK": d}))
        self.assertEqual(b["cast"]["npc1"]["hide"], "Gate/Guard")


class TestRunnerMessageTest(unittest.TestCase):
    def test_missing_suite_message_names_the_authoring_bundle(self):
        text = (paths_root() / "roblox" / "dev" / "Test.luau").read_text(encoding="utf-8")
        self.assertIn("out/dev_authoring.luau", text)


def paths_root():
    import paths
    return paths.PACK


LUAU = next(iter(sorted(Path(os.environ.get("USERPROFILE", "")).glob(".rokit/tool-storage/luau-lang/luau/*/luau.exe"))), None)

ADLER = """
local function adler(s)
	local a, b = 1, 0
	for i = 1, #s do
		a = (a + string.byte(s, i)) % 65521
		b = (b + a) % 65521
	end
	return string.format("%08x", b * 65536 + a)
end
"""

# stubs for the Roblox globals the overlay touches; records what it does and prints it
OVERLAY_HARNESS = """
local STUDIO, ATTR = %(studio)s, %(attr)s
local created, handlers, delays, warns, seq = 0, {}, {}, {}, {}
local attrs = {}
Enum = setmetatable({}, { __index = function(_, k) return setmetatable({}, { __index = function(_, v) return k .. "." .. v end }) end })
UDim2 = { fromScale = function() return "udim2" end }
Color3 = { fromRGB = function() return "color" end }
Instance = { new = function(class)
	local store = {}
	if class == "ScreenGui" then created += 1 end
	return setmetatable({}, { __index = store, __newindex = function(_, k, v)
		store[k] = v
		if k == "Enabled" and class == "ScreenGui" then table.insert(seq, v and 1 or 0) end
	end })
end }
task = { delay = function(t, f) table.insert(delays, { t = t, f = f }) end, wait = function() end }
warn = function(m) table.insert(warns, m) end
workspace = { GetServerTimeNow = function() return 100 end }
local player = {
	WaitForChild = function() return {} end,
	GetAttribute = function(_, n) return attrs[n] end,
	GetAttributeChangedSignal = function() return { Connect = function(_, f) table.insert(handlers, f) end } end,
}
local services = {
	RunService = { IsStudio = function() return STUDIO end },
	ReplicatedStorage = { GetAttribute = function() return ATTR end },
	Players = { LocalPlayer = player },
}
game = { GetService = function(_, n) return services[n] end }
;(function()
%(source)s
end)()
print("created=" .. created, "handlers=" .. #handlers)
if #handlers > 0 then
	attrs.CutsceneStartAt, attrs.CutsceneDuration = 110, 6
	handlers[1]()
	handlers[1]()
	print("delays=" .. #delays, "wait=" .. (delays[1] and delays[1].t or "none"), "warns=" .. #warns)
	delays[1].f()
	print("seq=" .. table.concat(seq, ""))
end
"""

STEP_HARNESS = ADLER + """
local created = {}
local attrs = {}
local captured, hadOverlay = nil, @HAD@
Instance = { new = function(class)
	local store = { ClassName = class, Destroy = function() end }
	return setmetatable({}, { __index = store, __newindex = function(_, k, v)
		store[k] = v
		if k == "Source" and class == "LocalScript" then captured = v end
	end })
end }
local scripts = { Name = "StarterPlayerScripts", FindFirstChild = function(_, name)
	return hadOverlay and name == "CutsceneRecordOverlay" and { Destroy = function() end } or nil
end }
local services = {
	ServerStorage = { FindFirstChild = function() return nil end },
	HttpService = {}, Players = {},
	ReplicatedStorage = { SetAttribute = function(_, n, v) attrs[n] = v end },
	StarterPlayer = { WaitForChild = function() return scripts end },
}
game = { GetService = function(_, n) return services[n] end }
require = function(m) return loadstring(m.Source)() end
local result = (function()
@SOURCE@
end)()
print("result=" .. result)
print("attr=" .. tostring(attrs.CutsceneKitRecord))
print("source=" .. (captured and (#captured .. ":" .. adler(captured)) or "none"))
"""


def run_luau(text):
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "h.luau"
        path.write_text(text, encoding="utf-8", newline="\n")
        proc = subprocess.run([str(LUAU), str(path)], capture_output=True, text=True, timeout=60)
    if proc.returncode != 0:
        raise AssertionError(f"luau failed: {proc.stderr or proc.stdout}")
    return proc.stdout


def step_run(had, source):
    return run_luau(STEP_HARNESS.replace("@HAD@", had).replace("@SOURCE@", source))


def overlay_run(studio_value, attr):
    src = (paths.ROBLOX / "authoring" / "RecordOverlay.client.luau").read_text(encoding="utf-8")
    return run_luau(OVERLAY_HARNESS % {"studio": studio_value, "attr": attr, "source": src})


class RecordStepTest(unittest.TestCase):
    def setUp(self):
        import fixture
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.env = {"MAKE_CUTSCENE_WORK": self.tmp.name}
        self.root = fixture.write_scene(env=self.env)
        self.overlay = (paths.ROBLOX / "authoring" / "RecordOverlay.client.luau").read_text(encoding="utf-8")

    def text(self, step):
        return (self.root / "studio" / f"{step}.luau").read_text(encoding="utf-8")

    def test_record_on_installs_the_overlay_and_sets_the_attribute(self):
        lines = studio.run_step("Fixture_Scene", "record-on", {}, env=self.env)
        text = self.text("record-on")
        self.assertIn('main = "RecordSwitch"', text)
        self.assertIn('call = "on"', text)
        self.assertIn("CutsceneKitRecord", text)  # RecordSwitch sets it
        self.assertIn("CutsceneStartAt", text)  # the overlay's own source is embedded
        self.assertLess(len(text.encode("utf-8")), studio.BUDGET)
        self.assertIn("record-on.luau", chr(10).join(lines))

    def test_record_off_deletes_the_overlay_and_clears_the_attribute(self):
        studio.run_step("Fixture_Scene", "record-off", {}, env=self.env)
        text = self.text("record-off")
        self.assertIn('call = "off"', text)
        self.assertIn("remove = true", text)  # RecordSwitch.off removes the overlay through SceneInstall.devScript
        self.assertIn("SetAttribute(ATTRIBUTE, nil)", text)
        self.assertNotIn("CutsceneStartAt", text)

    def test_the_overlay_is_not_a_module_in_any_bundle(self):
        self.assertNotIn("RecordOverlay", bundle.authoring_modules())
        self.assertNotIn("RecordSwitch", bundle.authoring_modules())

    def test_the_overlay_is_gated_on_studio_and_the_attribute(self):
        head = chr(10).join(self.overlay.splitlines()[:16])
        self.assertIn(":IsStudio()", head)
        self.assertIn('GetAttribute("CutsceneKitRecord")', head)

    @unittest.skipUnless(LUAU, "luau.exe not installed")
    def test_the_overlay_stays_dark_outside_studio_or_without_the_attribute(self):
        for studio_value, attr in (("false", "true"), ("true", "false"), ("true", "nil"), ("false", "nil")):
            out = overlay_run(studio_value, attr)
            self.assertIn("created=0\\thandlers=0".replace("\\t", chr(9)), out, (studio_value, attr, out))

    @unittest.skipUnless(LUAU, "luau.exe not installed")
    def test_the_overlay_runs_in_studio_with_the_attribute(self):
        out = overlay_run("true", "true")
        self.assertIn("created=1" + chr(9) + "handlers=1", out)
        # the scene ends at 110 + 6; the end flash is LEAD (0.25) later; the stub clock says it is 100 now
        self.assertIn("wait=16.25", out)
        self.assertIn("seq=01010", out)  # dark, then two pulses

    @unittest.skipUnless(LUAU, "luau.exe not installed")
    def test_an_overlapping_trigger_is_refused_with_a_message(self):
        out = overlay_run("true", "true")
        self.assertIn("delays=1" + chr(9) + "wait=16.25" + chr(9) + "warns=1", out)  # the second trigger was skipped

    @unittest.skipUnless(LUAU, "luau.exe not installed")
    def test_the_rendered_record_on_runs_and_embeds_the_overlay_exactly(self):
        import zlib
        studio.run_step("Fixture_Scene", "record-on", {}, env=self.env)
        out = (step_run("false", self.text("record-on")))
        data = self.overlay.encode("utf-8")
        self.assertIn("installed StarterPlayerScripts.CutsceneRecordOverlay", out)
        self.assertIn("attr=true", out)
        self.assertIn(f"source={len(data)}:{zlib.adler32(data):08x}", out)

    @unittest.skipUnless(LUAU, "luau.exe not installed")
    def test_the_rendered_record_off_clears_the_attribute_and_says_what_it_did(self):
        studio.run_step("Fixture_Scene", "record-off", {}, env=self.env)
        text = self.text("record-off")
        out = (step_run("true", text))
        self.assertIn("result=removed StarterPlayerScripts.CutsceneRecordOverlay", out)
        self.assertIn("attr=nil", out)
        out = (step_run("false", text))
        self.assertIn("result=nothing to remove", out)


class PlayTestStepTest(unittest.TestCase):
    def setUp(self):
        import fixture
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.env = {"MAKE_CUTSCENE_WORK": self.tmp.name}
        self.root = fixture.write_scene(env=self.env)
        self.src = (paths.ROBLOX / "authoring" / "PlayTest.luau").read_text(encoding="utf-8")

    def text(self, step):
        return (self.root / "studio" / f"{step}.luau").read_text(encoding="utf-8")

    def test_playtest_on_installs_the_module_as_a_dev_module(self):
        lines = studio.run_step("Fixture_Scene", "playtest-on", {}, env=self.env)
        text = self.text("playtest-on")
        self.assertIn('call = "devModule"', text)
        self.assertIn("CutsceneKitPlayTest", text)
        self.assertIn("PlayTest.PROBE", text)  # the module's own source is embedded
        self.assertLess(len(text.encode("utf-8")), studio.BUDGET)
        self.assertIn("playtest-on.luau", chr(10).join(lines))

    def test_playtest_off_removes_it(self):
        studio.run_step("Fixture_Scene", "playtest-off", {}, env=self.env)
        text = self.text("playtest-off")
        self.assertIn("remove = true", text)
        self.assertNotIn("PlayTest.PROBE", text)

    def test_playtest_off_names_the_module_and_carries_the_character_cleanup(self):
        studio.run_step("Fixture_Scene", "playtest-off", {}, env=self.env)
        studio.run_step("Fixture_Scene", "playtest-on", {}, env=self.env)
        text = self.text("playtest-off")
        self.assertIn('name = "CutsceneKitPlayTest"', text)
        self.assertIn("and the temporary StarterCharacter", text)  # SceneInstall.devModule takes a tagged one away
        self.assertIn("SceneInstall.dropPlayTest", self.text("playtest-on"))  # the remove step shares the same SceneInstall

    def test_remove_embeds_the_play_test_cleanup(self):
        studio.run_step("Fixture_Scene", "remove", {}, env=self.env)
        self.assertIn("SceneInstall.dropPlayTest(removed)", self.text("remove"))

    def test_playtest_refuses_outside_studio_and_reports_a_start_failure(self):
        self.assertIn("RunService:IsStudio()", self.src)
        self.assertIn("dev-only", self.src)
        self.assertIn("FAILED: ", self.src)
        for seam in ("PlayTest.isStudio", "PlayTest.player", "PlayTest.sleep"):
            self.assertIn(seam, self.src)

    def test_playtest_is_an_authoring_module_with_the_brief_api(self):
        self.assertIn("PlayTest", bundle.authoring_modules())
        for fn in ("start", "approach", "press", "arm", "read", "skip", "kill", "lock", "setRig"):
            self.assertIn(f"function PlayTest.{fn}(", self.src)
        head = chr(10).join(self.src.splitlines()[:2])
        self.assertIn("Method by fwjelaa (FWJ STUDIOS).", head)


if __name__ == "__main__":
    unittest.main()
