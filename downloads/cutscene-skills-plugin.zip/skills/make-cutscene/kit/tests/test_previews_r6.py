"""Tests for the likeness sheet (spec 14: reference beside our R15 cast and our R6 cast). The R6 take itself
(takes.make rig="R6") is covered by test_takes. Method by fwjelaa (FWJ STUDIOS)."""
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import media  # noqa: E402
import sheets  # noqa: E402
import workspace  # noqa: E402
from tests.test_costume import HERO  # noqa: E402

HAVE_FFMPEG = shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class LikenessTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = workspace.create("LikeTry", env={"MAKE_CUTSCENE_WORK": self.tmp.name})
        b = beats.draft("LikeTry", {"type": "video"}, [beats.shot("HERO", 2.0)])
        b["cast"]["player"]["model"] = "costume"
        beats.save(b, self.root)
        spec = json.loads(json.dumps(HERO))
        spec["likeness"] = {"look": 1.0, "ref": [{"video": 0.5, "crop": [0.25, 0.0, 0.75, 1.0]}]}
        workspace.write_json(self.root / "cast" / "player.json", spec)
        media.synth(self.root / "ref" / "clip.mp4", [("testsrc", 1.0)])
        for name in ("LikeTry.mp4", "LikeTry_R6.mp4"):
            media.synth(self.root / "preview" / name, [("testsrc2", 2.0)])

    def test_one_row_per_character_reference_then_both_casts(self):
        out = sheets.likeness(self.root)
        info = media.probe(out)
        self.assertEqual((info["width"], info["height"]), (4 * 360 + 3 * 4 + 2 * 4, 360 + 2 * 4))
        self.assertFalse((self.root / "preview" / "_like").exists())

    def test_the_sheet_records_both_preview_stamps(self):
        r15, r6 = {"export": "e", "module": "m", "video": "a"}, {"export": "e", "module": "m", "video": "b"}
        workspace.write_json(self.root / "preview" / "export.json", r15)
        workspace.write_json(self.root / "preview" / "export_R6.json", r6)
        sheets.likeness(self.root)
        made = workspace.read_json(self.root / "preview" / "sheets.json")["likeness"]
        self.assertEqual(made["files"], ["likeness.png"])
        self.assertEqual(made["preview"], {"R15": r15, "R6": r6})
        self.assertEqual(made["hashes"], sheets.review.evidence.hashes(self.root / "preview", ["likeness.png"]))

    def test_both_previews_are_needed(self):
        (self.root / "preview" / "LikeTry_R6.mp4").unlink()
        with self.assertRaises(SystemExit) as e:
            sheets.likeness(self.root)
        self.assertIn("LikeTry_R6.mp4", str(e.exception))

    def test_a_scene_without_costumes_has_no_likeness_sheet(self):
        b = beats.load(self.root)
        b["cast"]["player"]["model"] = None
        beats.save(b, self.root)
        with self.assertRaises(SystemExit) as e:
            sheets.likeness(self.root)
        self.assertIn("adapts no character", str(e.exception))

    def test_a_broken_reference_clip_is_one_line_not_a_traceback(self):
        (self.root / "ref" / "clip.mp4").write_bytes(b"not a video")
        with self.assertRaises(SystemExit) as e:
            sheets.likeness(self.root)
        msg = str(e.exception)
        self.assertIn("clip.mp4", msg)
        self.assertNotIn("Traceback", msg)
        self.assertFalse((self.root / "preview" / "_like").exists())

    def test_a_broken_preview_is_one_line_not_a_traceback(self):
        (self.root / "preview" / "LikeTry_R6.mp4").write_bytes(b"not a video")
        with self.assertRaises(SystemExit) as e:
            sheets.likeness(self.root)
        self.assertIn("LikeTry_R6.mp4", str(e.exception))
        self.assertFalse((self.root / "preview" / "_like").exists())

    def test_a_panel_outside_ref_is_refused(self):
        spec = workspace.read_json(self.root / "cast" / "player.json")
        spec["likeness"]["ref"] = [{"panel": "ref/../../x.png"}]
        workspace.write_json(self.root / "cast" / "player.json", spec)
        with self.assertRaises(SystemExit):
            sheets.likeness(self.root)


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class TwoRoleLikenessTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = workspace.create("TwoTry", env={"MAKE_CUTSCENE_WORK": self.tmp.name})
        b = beats.draft("TwoTry", {"type": "video"},
                        [beats.shot("HERO", 2.0, subject="player"), beats.shot("HERO", 4.0, subject="npc1")])
        b["cast"]["player"]["model"] = "costume"
        b["cast"]["npc1"] = {"place": [0, 0, 0, 0, 0, 0], "model": "costume"}
        beats.save(b, self.root)
        for role, name, look in (("player", "Hero", 0.25), ("npc1", "Villain", 0.5)):
            spec = json.loads(json.dumps(HERO))
            spec.update({"role": role, "character": name})
            spec["likeness"] = {"look": look, "ref": [{"video": 0.5}, {"video": 0.6}]}
            workspace.write_json(self.root / "cast" / f"{role}.json", spec)
        media.synth(self.root / "ref" / "clip.mp4", [("testsrc", 1.0)])
        for name in ("TwoTry.mp4", "TwoTry_R6.mp4"):
            media.synth(self.root / "preview" / name, [("testsrc2", 6.0)])

    def _sampled(self):
        calls = []
        real = media.cell

        def spy(src, out, label="", size=(320, 180), t=None):
            if "ours" in label:
                calls.append((label, t))
            return real(src, out, label, size, t)
        media.cell = spy
        self.addCleanup(setattr, media, "cell", real)
        sheets.likeness(self.root)
        return calls

    def test_each_row_is_sampled_in_its_own_roles_shot_and_labelled(self):
        calls = self._sampled()
        self.assertEqual(len(calls), 4)
        player, npc = calls[:2], calls[2:]
        for label, t in player:
            self.assertEqual(t, 1.0)  # middle of shot 1 (0-2 s), not likeness.look 0.25
            self.assertIn("player: Hero", label)
            self.assertNotIn("not focused", label)
        for label, t in npc:
            self.assertEqual(t, 4.0)  # middle of shot 2 (2-6 s)
            self.assertIn("npc1: Villain", label)
        self.assertIn("R15", player[0][0])
        self.assertIn("R6", player[1][0])
        info = media.probe(self.root / "preview" / "likeness.png")
        self.assertEqual(info["height"], 2 * 360 + 3 * 4)

    def test_a_role_no_shot_focuses_falls_back_and_says_so(self):
        b = beats.load(self.root)
        b["shots"][1]["subject"] = "player"
        beats.save(b, self.root)
        calls = self._sampled()
        label, t = calls[2]
        self.assertEqual(t, 0.5)
        self.assertIn("npc1: Villain", label)
        self.assertIn("not focused", label)


if __name__ == "__main__":
    unittest.main()
