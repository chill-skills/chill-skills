"""Read-only authoring capability CLI regressions. Method by fwjelaa (FWJ STUDIOS)."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

KIT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(KIT))
import fixture


class AuditTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def run_audit(self, data, mode="module"):
        path = self.root / "input.json"
        path.write_text(json.dumps(data), encoding="utf-8")
        result = subprocess.run([sys.executable, "-B", str(KIT / "authoring_audit.py"),
                                 str(path), "--format", mode], capture_output=True, text=True)
        self.assertTrue(result.stdout, result.stderr)
        return result.returncode, json.loads(result.stdout)

    def test_sfx_with_matching_cue_is_a_hard_error(self):
        data = fixture.module_data()
        data["Markers"].insert(1, [0.2, "SFX", "Boom"])
        data["Cues"] = {"SFX:Boom": {"kind": "sfx"}}
        code, report = self.run_audit(data)
        self.assertEqual(code, 1)
        self.assertFalse(report["ok"])
        errors = [f for f in report["findings"] if f["severity"] == "error"]
        self.assertTrue(any(f["rule"] == "CAP_MARKER" for f in errors))
        self.assertTrue(all(set(f) == {"rule", "severity", "location", "message", "remedy"} for f in errors))

    def test_real_module_and_vfx_screen_dispatch_pass(self):
        data = fixture.module_data()
        data["Markers"].insert(1, [0.1, "VFX", "Burst"])
        data["Markers"].insert(2, [0.2, "VFX", "Word"])
        data["Cues"] = {"VFX:Burst": {"kind": "vfx", "preset": "Burst"},
                        "VFX:Word": {"kind": "screen", "effect": "word", "text": "POW!!"}}
        code, report = self.run_audit(data)
        self.assertEqual(code, 0, report)
        self.assertTrue(report["ok"])

    def test_unsupported_kinds_dispatch_and_voice_fail(self):
        for name, cue in (("SFX", None), ("Face", {"kind": "face"}),
                          ("Custom", {"kind": "screen", "effect": "flash"}),
                          ("VFX", {"kind": "sfx"})):
            with self.subTest(name=name):
                data = fixture.module_data()
                data["Markers"].insert(1, [0.1, name, "X"])
                if cue:
                    data["Cues"] = {f"{name}:X": cue}
                code, report = self.run_audit(data)
                self.assertEqual(code, 1, report)
        for change in ({"Kind": "ultimate"}, {"Lines": {"1": {"text": "hey", "voice": "asset"}}},
                       {"Config": {"Style": "manhwa"}}):
            code, report = self.run_audit(dict(fixture.module_data(), **change))
            self.assertEqual(code, 1, report)

    def test_malformed_json_shapes_and_nonfinite_values_fail_cleanly(self):
        for data in ([], None, {}, {"Markers": 1}, dict(fixture.module_data(), Markers=[None]),
                     dict(fixture.module_data(), Length=float("nan")),
                     dict(fixture.module_data(), Cues={"VFX:X": {"kind": "screen", "life": float("inf")}}),
                     dict(fixture.module_data(), Markers=[[0, "VFX", {}]])):
            with self.subTest(data=data):
                code, report = self.run_audit(data)
                self.assertEqual(code, 1, report)
                self.assertFalse(report["ok"])
        path = self.root / "broken.json"
        path.write_text('{"Kind":', encoding="utf-8")
        for target in (path, self.root / "missing.json"):
            result = subprocess.run([sys.executable, str(KIT / "authoring_audit.py"), str(target)],
                                    capture_output=True, text=True)
            self.assertEqual(result.returncode, 1, result.stderr)
            self.assertFalse(json.loads(result.stdout)["ok"])

    def test_existing_beats_directory_passes_without_writes_or_execution(self):
        source = KIT.parent / "examples" / "GateGuard" / "beats.json"
        data = json.loads(source.read_text(encoding="utf-8"))
        (self.root / "beats.json").write_text(json.dumps(data), encoding="utf-8")
        (self.root / "anim").mkdir()
        (self.root / "anim" / "camera.py").write_text("raise RuntimeError('must not execute')", encoding="utf-8")
        before = {p.relative_to(self.root): (p.read_bytes(), p.stat().st_mtime_ns)
                  for p in self.root.rglob("*") if p.is_file()}
        result = subprocess.run([sys.executable, str(KIT / "authoring_audit.py"), str(self.root)],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        report = json.loads(result.stdout)
        self.assertTrue(report["ok"])
        self.assertTrue(any(f["severity"] == "suggestion" for f in report["findings"]))
        after = {p.relative_to(self.root): (p.read_bytes(), p.stat().st_mtime_ns)
                 for p in self.root.rglob("*") if p.is_file()}
        self.assertEqual(before, after)

    def test_beats_intervals_role_references_and_default_vfx(self):
        source = KIT.parent / "examples" / "GateGuard" / "beats.json"
        data = json.loads(source.read_text(encoding="utf-8"))
        data["shots"][0]["markers"] = [[0.1, "VFX", "Burst"]]
        data["cues"] = {"VFX:Word": {"kind": "screen", "effect": "word", "text": "POW!!", "at": "npc1.face"}}
        data["shots"][0]["markers"].append([0.2, "VFX", "Word"])
        code, report = self.run_audit(data, "beats")
        self.assertEqual(code, 0, report)
        for field, value in (("length", 0), ("start", 2), ("subject", "npc99"), ("markers", 2)):
            bad = json.loads(json.dumps(data))
            bad["shots"][0][field] = value
            code, report = self.run_audit(bad, "beats")
            self.assertEqual(code, 1, report)
        data["cues"]["VFX:Word"]["at"] = "npc99.face"
        code, report = self.run_audit(data, "beats")
        self.assertEqual(code, 1, report)

    def test_runtime_fallback_and_all_supported_scene_kinds(self):
        for kind in ("story", "intro", "awakening"):
            data = fixture.module_data()
            data["Kind"] = kind
            data["Markers"].insert(1, [0.1, "VFX", "Anything"])
            data["Cues"] = {"VFX": {"kind": "screen", "effect": "flash"}}
            code, report = self.run_audit(data)
            self.assertEqual(code, 0, report)

    def test_duplicate_keys_and_missing_runtime_cue_fail(self):
        data = fixture.module_data()
        data["Markers"].insert(1, [0.1, "VFX", "Burst"])
        code, report = self.run_audit(data)
        self.assertEqual(code, 1)
        self.assertIn("CAP_CUE_MISSING", [f["rule"] for f in report["findings"]])
        path = self.root / "duplicate.json"
        path.write_text('{"Kind":"story","Kind":"ultimate"}', encoding="utf-8")
        result = subprocess.run([sys.executable, str(KIT / "authoring_audit.py"), str(path)],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)
        self.assertIn("Duplicate JSON key", json.loads(result.stdout)["findings"][0]["message"])

    def test_falsy_malformed_beats_fields_fail(self):
        data = json.loads((KIT.parent / "examples/GateGuard/beats.json").read_text(encoding="utf-8"))
        for field in ("markers",):
            for value in (False, 0, "", {}):
                bad = json.loads(json.dumps(data))
                bad["shots"][0][field] = value
                code, report = self.run_audit(bad, "beats")
                self.assertEqual(code, 1, (value, report))

    def test_runtime_follow_requires_existing_role(self):
        data = fixture.module_data()
        data["Markers"].insert(1, [0.1, "VFX", "Burst"])
        data["Cues"] = {"VFX:Burst": {"kind": "vfx", "preset": "Burst", "follow": "npc99.Head"}}
        code, report = self.run_audit(data)
        self.assertEqual(code, 1, report)

    def test_generated_marker_contract_matches_exporter(self):
        import copy
        import beats
        import schema
        base = json.loads((KIT.parent / "examples/GateGuard/beats.json").read_text(encoding="utf-8"))
        cases = [("Letterbox", v, v in ("in", "out"))
                 for v in ("in", "out", "banana", "IN", "", 1, True, None)]
        cases += [("Slowmo", v, valid) for v, valid in (
            (0.05, True), (1, True), (0.1, True), (".05", True), (" 1 ", True),
            ("0.10", True), ("1e-1", False), ("+0.1", False), ("1.", False),
            (0.049, False), (1.001, False), (0, False), (-1, False),
            (True, False), (False, False), (None, False), ("", False),
            (float("nan"), False), (float("inf"), False))]
        for name, value, valid in cases:
            with self.subTest(name=name, value=value):
                data = copy.deepcopy(base)
                data["shots"][0].setdefault("markers", []).append([0.1, name, value])
                module = fixture.module_data()
                module.update(Length=beats.snap(beats.length(data)),
                              Markers=beats.markers(data), Lines=data["lines"])
                self.assertEqual(not schema.validate(module), valid)
                for mode, payload in (("beats", data), ("module", module)):
                    code, report = self.run_audit(payload, mode)
                    self.assertEqual(code, 0 if valid else 1, (mode, report))
                    self.assertEqual(report["ok"], valid)

    def test_generated_marker_times_and_lines_use_runtime_contract(self):
        import copy
        base = json.loads((KIT.parent / "examples/GateGuard/beats.json").read_text(encoding="utf-8"))
        for change in ("negative_time", "speaker", "hold"):
            with self.subTest(change=change):
                data = copy.deepcopy(base)
                if change == "negative_time":
                    # Beats permits this tolerance, but generated markers may not precede zero.
                    data["shots"][0].setdefault("markers", []).append([-0.0005, "Shake", "0.2"])
                else:
                    data["lines"][next(iter(data["lines"]))][change] = True
                code, report = self.run_audit(data, "beats")
                self.assertEqual(code, 1, report)
                self.assertIn("INPUT_SCHEMA", [f["rule"] for f in report["findings"]])

    def test_api_is_deterministic_and_does_not_mutate_input(self):
        import copy
        import authoring_audit
        data = fixture.module_data()
        original = copy.deepcopy(data)
        first = authoring_audit.audit_module(data)
        self.assertEqual(first, authoring_audit.audit_module(data))
        self.assertEqual(data, original)


if __name__ == "__main__":
    unittest.main()
