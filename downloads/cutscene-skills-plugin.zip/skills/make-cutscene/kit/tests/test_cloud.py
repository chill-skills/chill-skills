import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import cloud  # noqa: E402
import fixture  # noqa: E402
import paths  # noqa: E402


class FakeUploader:
    def __init__(self, fail_first=0, status=503):
        self.calls, self.fail_first, self.status = [], fail_first, status

    def __call__(self, path, display, description, creator, key):
        self.calls.append((Path(path).name, display, creator))
        if len(self.calls) <= self.fail_first:
            return {"name": Path(path).stem, "status": self.status, "error": "busy"}
        return {"name": Path(path).stem, "assetId": str(1000 + len(self.calls))}


class CloudTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.fixtures = Path(self.tmp.name)
        fixture.build(self.fixtures / fixture.NAME)
        patcher = mock.patch.object(paths, "FIXTURES", self.fixtures)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.addCleanup(self.tmp.cleanup)

    KEY = "SECRET-KEY-123"

    def run_upload(self, up):
        return cloud.upload_fixture(fixture.NAME, uploader=up, key=self.KEY, creator={"userId": "1"}, sleep=lambda s: None)

    def test_uploads_every_clip_and_rebuilds_with_ids(self):
        up = FakeUploader()
        ids, lines = self.run_upload(up)
        self.assertEqual(len(up.calls), 5)
        self.assertEqual(len(ids), 5)
        source = (self.fixtures / fixture.NAME / f"{fixture.NAME}.luau").read_text(encoding="utf-8")
        self.assertIn('Stage = "rbxassetid://', source)
        self.assertNotIn(self.KEY, "\n".join(lines), "the key never appears in the report")

    def test_second_run_skips_uploaded_clips(self):
        self.run_upload(FakeUploader())
        up = FakeUploader()
        ids, lines = self.run_upload(up)
        self.assertEqual(up.calls, [])
        self.assertTrue(all("already uploaded" in line for line in lines))

    def test_retries_server_errors(self):
        up = FakeUploader(fail_first=2, status=503)
        ids, _ = self.run_upload(up)
        self.assertEqual(len(ids), 5)
        self.assertEqual(len(up.calls), 7)

    def test_client_errors_are_reported_not_retried(self):
        up = FakeUploader(fail_first=1, status=403)
        ids, lines = self.run_upload(up)
        self.assertEqual(len(ids), 4)
        self.assertTrue(any("FAILED 403" in line for line in lines))
        source = (self.fixtures / fixture.NAME / f"{fixture.NAME}.luau").read_text(encoding="utf-8")
        self.assertIn('Stage = "Fixture_Walkin_Stage"', source, "a failed clip keeps its Studio-only name")

    def test_failure_lines_never_contain_the_key(self):
        def leaky(path, display, description, creator, key):
            return {"name": Path(path).stem, "status": 401, "error": "bad key " + self.KEY}

        ids, lines = self.run_upload(leaky)
        text = "\n".join(lines)
        self.assertNotIn(self.KEY, text)
        self.assertIn("[redacted]", text)

    def test_exceptions_become_failed_lines_and_the_rest_still_uploads(self):
        inner = FakeUploader()

        def flaky(path, display, description, creator, key):
            if not inner.calls:
                inner.calls.append(("boom", display, creator))
                raise RuntimeError("secret detail " + self.KEY)
            return inner(path, display, description, creator, key)

        ids, lines = self.run_upload(flaky)
        self.assertEqual(len(ids), 4)
        self.assertTrue(any("FAILED RuntimeError" in line for line in lines))
        self.assertNotIn(self.KEY, "\n".join(lines))
        source = (self.fixtures / fixture.NAME / f"{fixture.NAME}.luau").read_text(encoding="utf-8")
        self.assertIn('Stage = "Fixture_Walkin_Stage"', source)


class SceneUploadTest(unittest.TestCase):
    KEY = "SECRET-KEY-456"

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.env = {"MAKE_CUTSCENE_WORK": self.tmp.name}
        import scenefile
        self.root = fixture.write_scene(env=self.env)
        scenefile.write(self.root)

    def upload(self, up, sleep=lambda s: None):
        return cloud.upload_scene("Fixture_Scene", uploader=up, key=self.KEY, creator={"userId": "1"}, sleep=sleep,
                                  env=self.env, prefix="")

    def test_upload_rewrites_the_data_module(self):
        ids, lines = self.upload(FakeUploader())
        self.assertEqual(len(ids), 4)
        text = (self.root / "export" / "Fixture_Scene.luau").read_text(encoding="utf-8")
        self.assertIn('Stage = "rbxassetid://', text)
        self.assertNotIn('"Fixture_Scene_Stage"', text)
        saved = json.loads((self.root / "export" / "ids.json").read_text(encoding="utf-8"))
        self.assertEqual(set(saved["Fixture_Scene_Stage"]), {"id", "sha"})
        self.assertFalse((self.root / "export" / "ids.json.tmp").exists())

    def test_only_a_changed_clip_goes_up_again(self):
        self.upload(FakeUploader())
        rbxmx = self.root / "export" / "Fixture_Scene_npc1_R15.rbxmx"
        rbxmx.write_text(rbxmx.read_text(encoding="utf-8").replace("</roblox>", " </roblox>"), encoding="utf-8")
        up = FakeUploader()
        ids, lines = self.upload(up)
        self.assertEqual([c[0] for c in up.calls], ["Fixture_Scene_npc1_R15.rbxmx"])

    def test_exhausted_retries_back_off_and_name_the_clip(self):
        waits = []
        up = FakeUploader(fail_first=99, status=503)
        ids, lines = self.upload(up, sleep=waits.append)
        self.assertEqual(ids, {})
        self.assertTrue(lines[0].startswith("Fixture_Scene_Stage: FAILED 503 after 4 tries"), lines[0])
        self.assertIn("the file is kept", lines[0])
        self.assertEqual(waits[:3], [2.0, 4.0, 8.0])

    def test_a_strange_uploader_result_is_a_failed_line(self):
        ids, lines = self.upload(lambda *a: "not a dict")
        self.assertTrue(all("FAILED bad uploader result" in line for line in lines[:4]), lines)

    def test_the_key_never_shows_even_inside_a_nested_error(self):
        def leaky(path, display, description, creator, key):
            return {"status": 400, "error": {"detail": "bad " + key}}
        ids, lines = self.upload(leaky)
        self.assertNotIn(self.KEY, chr(10).join(lines))

    def test_a_transient_network_error_is_retried_with_backoff(self):
        calls, waits = [], []
        inner = FakeUploader()

        def flaky(path, display, description, creator, key):
            calls.append(Path(path).name)
            if len(calls) <= 2:
                raise TimeoutError("slow " + key)
            return inner(path, display, description, creator, key)

        ids, lines = self.upload(flaky, sleep=waits.append)
        self.assertEqual(len(ids), 4)
        self.assertEqual(waits, [2.0, 4.0])
        self.assertNotIn(self.KEY, chr(10).join(lines))

    def test_a_programming_error_is_not_retried(self):
        calls = []

        def broken(*a):
            calls.append(1)
            raise ValueError(self.KEY)

        ids, lines = self.upload(broken)
        self.assertEqual(len(calls), 4)  # once per clip
        self.assertTrue(any("FAILED ValueError" in line for line in lines))
        self.assertNotIn(self.KEY, chr(10).join(lines))

    def test_a_null_or_string_status_is_a_failed_line_with_everything_redacted(self):
        for status in (None, "oops " + self.KEY, 7.5):
            ids, lines = self.upload(lambda *a, s=status: {"status": s, "error": {"x": object()}})
            self.assertTrue(all("FAILED" in line for line in lines[:4]), lines)
            self.assertNotIn(self.KEY, chr(10).join(lines))

    def test_a_partial_failure_does_not_rewrite_the_data_module(self):
        module = self.root / "export" / "Fixture_Scene.luau"
        before = module.read_text(encoding="utf-8")
        up = FakeUploader()

        def half(path, display, description, creator, key):
            if "npc1" in Path(path).name:
                return {"status": 400, "error": "bad"}
            return up(path, display, description, creator, key)

        ids, lines = self.upload(half)
        self.assertEqual(module.read_text(encoding="utf-8"), before)
        text = chr(10).join(lines)
        self.assertIn("data module NOT rewritten", text)
        self.assertIn("Fixture_Scene_npc1_R15", lines[-1])
        self.assertEqual(len(ids), 3)


if __name__ == "__main__":
    unittest.main()
