"""The costume keys of the data-module contract (spec 14): kit/schema.py and CutsceneKit.Data.validate must give the same
problems with the same words. The Luau side runs in the luau CLI when it is installed. Method by fwjelaa (FWJ STUDIOS)."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import clip  # noqa: E402
import luaurun  # noqa: E402
import paths  # noqa: E402
import scenefile  # noqa: E402
import schema  # noqa: E402
import workspace  # noqa: E402


def data(**over):
    d = {"Name": "T", "Kind": "story", "Length": 4, "Anims": {"Stage": "T_Stage"}, "Markers": [[4, "End", ""]],
         "Costumes": ["player", "npc1"], "Config": {"Costume": True}}
    d.update(over)
    return d


CASES = [
    data(),
    data(Costumes=[]),
    data(Costumes="player", Config={}),
    data(Costumes=["hero", "npc1", "npc0"], Config={}),
    data(Costumes=["npc1", "npc1"], Config={}),
    data(Config={"Costume": "yes"}),
    data(Costumes=["npc1"]),
    data(Kind="awakening"),
]
WANT = [
    [],
    ["Config.Costume is true but Costumes has no player"],
    ["Costumes must be a list of roles like player or npc1"],
    ["Costumes entry 1 must be a role (player, target, npc1..npc99)",
     "Costumes entry 3 must be a role (player, target, npc1..npc99)"],
    ["Costumes lists npc1 twice"],
    ["Config.Costume must be true or false"],
    ["Config.Costume is true but Costumes has no player"],
    ["Config.Costume works in story and intro scenes only (the player acts as a local copy there)"],
]


def luau_problems(examples):
    """Data.validate on each example, in the luau CLI (Plan 3's full runner once its VFX library exists)."""
    try:
        import vfxlib  # noqa: F401  Plan 3 Task 4 on: Data.luau also reads the VFX library
        return luaurun.data_problems(examples)
    except ImportError:
        pass
    src = (paths.ROBLOX / "CutsceneKit" / "Data.luau").read_text(encoding="utf-8")
    code = ["local script = { Parent = setmetatable({}, { __index = function() return {} end }) }",
            "local function require(m) return m end",
            "local Data = (function() " + src + " end)()", "local out = {}"]
    for ex in examples:
        code.append("do local ok, problems = Data.validate(" + clip.luau_value(ex) + ") "
                    "table.insert(out, table.concat(problems, '\\n')) end")
    code.append(f"print(table.concat(out, '{luaurun.SEP}'))")
    text = luaurun.run("\n".join(code))
    return [[p for p in chunk.split("\n") if p] for chunk in text.rstrip("\n").split(luaurun.SEP)]


class ContractTest(unittest.TestCase):
    def test_python_rules(self):
        for d, want in zip(CASES, WANT):
            self.assertEqual(schema.validate(d), want, d)

    @unittest.skipUnless(luaurun.find(), "luau is not installed")
    def test_luau_says_the_same(self):
        self.assertEqual(luau_problems(CASES), WANT)


class ModuleDataTest(unittest.TestCase):
    def test_the_data_module_lists_costumes_and_dresses_the_player(self):
        b = beats.draft("T", {"type": "words", "text": "x"}, [beats.shot("HERO", 2.0)])
        b["cast"]["player"]["model"] = "costume"
        b["cast"]["npc2"] = {"name": "Beast", "model": "costume", "place": [0, 0, -8, 0, 180, 0]}
        b["cast"]["npc1"] = {"name": "Guard", "model": "default", "rig": "R15", "place": [0, 0, -6, 0, 180, 0]}
        scene = {"length": 2.0, "fov": [[0, 50]], "clips": {"Stage": "T_Stage", "R15": {}, "R6": {}}}
        d = scenefile.module_data(b, scene)
        self.assertEqual(d["Costumes"], ["npc2", "player"])
        self.assertIs(d["Config"]["Costume"], True)
        self.assertEqual(schema.validate(d), [])
        b["cast"]["player"]["model"] = None
        d = scenefile.module_data(b, scene)
        self.assertNotIn("Costume", d["Config"])

    def test_scenes_without_costumes_keep_their_export_hash(self):
        b = beats.draft("T", {"type": "words", "text": "x"}, [beats.shot("HERO", 2.0)])
        before = beats.export_part(b)
        self.assertNotIn("costume", before["cast"]["player"])
        b["cast"]["player"]["model"] = "costume"
        self.assertIs(beats.export_part(b)["cast"]["player"]["costume"], True)
        with tempfile.TemporaryDirectory() as d:
            root = workspace.create("T", env={"MAKE_CUTSCENE_WORK": d})
            beats.save(b, root)
            self.assertIn("beats.json", scenefile.sources(root))


if __name__ == "__main__":
    unittest.main()
