"""Tests for the film set's costume parts (spec 14) that run without Blender: a creature's rig registered with its own
feet, who gets a derived R6 clip, and the film-set look of a marketplace-dressed character (spec 14.3: the colours its
items show there, R6 with classic items only, and its accessories as coarse boxes on their attachments). The costume's
look in Blender is checked in Blender (Plan 2b Task 7 Step 5).
Method by fwjelaa (FWJ STUDIOS)."""
import copy
import inspect
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import beats  # noqa: E402
import clip  # noqa: E402
import costume  # noqa: E402
import workspace  # noqa: E402
from tests.test_costume import SWORD  # noqa: E402
from tests.test_filmset import cf, load_filmset, stock  # noqa: E402

SKIN, TANK, PANTS, COAT, HAIR = "#e8b896", "#1c1c1c", "#6b4a2e", "#8b1a1a", "#c0622d"


def item(slot, id_, type_, film=None):
    out = {"slot": slot, "id": id_, "type": type_, "name": "n", "creator": "c", "why": "matches the reference"}
    if film:
        out["film"] = film
    return out


# a character dressed from the marketplace: classic tank top and pants (both rigs), a layered coat (R15 only), hair,
# a hat without a film colour, a cape and a left shoe (layered: R15 only)
HEROINE = {"version": 1, "role": "player", "character": "Heroine", "source": "Test reference, CC BY 4.0",
           "kind": "humanoid", "body": {r: SKIN for r in costume.REGIONS}, "scale": {},
           "catalog": [item("shirt", 11, "Shirt", TANK), item("pants", 12, "Pants", PANTS),
                       item("layered_jacket", 13, "JacketAccessory", COAT), item("hair", 14, "HairAccessory", HAIR),
                       item("hat", 15, "Hat"), item("back", 16, "BackAccessory", COAT),
                       item("left_shoe", 17, "LeftShoeAccessory", "#222222")]}


class RegisterTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fs = load_filmset()

    def kit(self):
        return SimpleNamespace(rigs=SimpleNamespace(RIGS={"R15": stock()}, cf=cf, PROPS={}))

    def test_a_creature_brings_its_own_feet_core_and_pairs(self):
        spec = costume.starter("npc1", "creature", "Beast", "credit")
        spec["pairs"] = [["Head", "Body"]]
        cap = costume.creature_rig(spec)
        K = self.kit()
        name = self.fs.register(K, "Try_npc1_rig", cap)
        rig = K.rigs.RIGS[name]
        self.assertEqual(rig["feet"], ["FootL", "FootR"])
        self.assertEqual(rig["body"], ["Body"])
        self.assertEqual(rig["pairs"], [("Head", "Body")])
        self.assertEqual(rig["hip_height"], 1.6)  # ground() and soles() put the floor under the creature's feet

    def test_a_creature_without_a_core_gets_no_stock_parts(self):
        spec = costume.starter("npc1", "creature", "Beast", "credit")
        del spec["core"]
        K = self.kit()
        rig = K.rigs.RIGS[self.fs.register(K, "Try_npc1_rig", costume.creature_rig(spec))]
        self.assertEqual(rig["body"], [])  # never LowerTorso: a prop's pairs would name a part the creature lacks
        self.assertEqual(rig["pairs"], [])

    def test_a_captured_humanoid_keeps_the_stock_feet(self):
        cap = {"rigType": "R15", "stand": 3.192, "parts": {"HumanoidRootPart": [2, 2, 1], "LowerTorso": [2, 0.4, 1],
                                                          "RightFoot": [1, 0.3, 1]},
               "joints": [["Root", "HumanoidRootPart", "LowerTorso", [0, -1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
                           [0, -0.2, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1]]]}
        K = self.kit()
        rig = K.rigs.RIGS[self.fs.register(K, "Try_player_rig", cap)]
        self.assertEqual(rig["feet"], ["RightFoot"])
        self.assertEqual(rig["pairs"], [("RightFoot", "LowerTorso")])

    def test_costume_look_leaves_a_role_without_a_costume_alone(self):
        K = SimpleNamespace(costume=costume)
        self.assertEqual(self.fs.costume_look(K, "nowhere", "Try", "npc1", {"model": "default"}, None, "R15"), "")

    def test_a_bad_costume_stops_the_build_with_a_message_not_an_exit(self):
        # costume.load() raises SystemExit for the command line; inside Blender that must be an ordinary error, which
        # build() reports ("CS_<id> is half built ...") instead of letting SystemExit through
        K = SimpleNamespace(costume=costume)
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError) as e:
                self.fs.costume_look(K, tmp, "Try", "npc1", {"model": "costume"}, None, "R15")
        self.assertIn("cast/npc1.json", str(e.exception))

    def test_the_export_derives_r6_for_every_role_costume_says(self):
        src = inspect.getsource(self.fs.export)
        self.assertEqual(src.count("K.costume.derives_r6(folder, role, c)"), 1)  # once, into clip_plan
        self.assertIn("clip_plan(cid, b, ", src)
        self.assertNotIn('if role == "player":', src)
        self.assertIn("costume", self.fs.MINE)
        self.assertIn("rigcap", self.fs.MINE)

    def cast(self):
        return {"id": "Try", "cast": {"player": {"model": "costume"},
                                      "npc1": {"model": "costume", "rig": "R15"},
                                      "npc2": {"model": "costume", "rig": "R6"},
                                      "npc3": {"model": "default"}}}

    def test_the_name_plan_gives_each_role_its_master_and_derived_clip(self):
        derives = {"player", "npc1"}  # what costume.derives_r6 says for this cast
        plan = self.fs.clip_plan("Try", self.cast(), lambda role, c: role in derives)
        self.assertEqual(plan, {"player": ("Try_player_R15", "Try_player_R6"), "npc1": ("Try_npc1_R15", "Try_npc1_R6"),
                                "npc2": ("Try_npc2_R6", None), "npc3": ("Try_npc3_R15", None)})

    def test_a_derived_name_never_takes_a_masters(self):
        # make-anim's Anim.build deletes whatever has its armature's name: an R6 master must never be derived over
        with self.assertRaises(ValueError) as e:
            self.fs.clip_plan("Try", self.cast(), lambda role, c: True)
        msg = str(e.exception)
        self.assertIn("Try_npc2_R6", msg)
        self.assertIn("npc2", msg)
        self.assertNotIn("npc1", msg)

    def test_a_creatures_rig_colours_are_left_to_its_costume(self):
        # the creature's rigs/<role>.json colours come from its costume spec: costume_look paints them, once
        with tempfile.TemporaryDirectory() as tmp:
            workspace.write_json(Path(tmp) / "rigs" / "npc2.json",
                                 costume.creature_rig(costume.starter("npc2", "creature", "Beast", "credit")))
            self.assertIsNone(self.fs.look_of(tmp, "npc2"))


class R6MasterTest(unittest.TestCase):
    def test_an_npc_acting_its_costume_on_r6_is_its_own_r6_master(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = workspace.create("R6Try", env={"MAKE_CUTSCENE_WORK": tmp})
            beats.save(beats.draft("R6Try", {"type": "words", "text": "x"}, [beats.shot("HERO", 2.0)]), root)
            costume.new(root, beats.load(root), "npc1", "humanoid", "Guard", "credit")
            c = dict(beats.load(root)["cast"]["npc1"])
            self.assertTrue(costume.derives_r6(root, "npc1", c))
            self.assertFalse(costume.derives_r6(root, "npc1", dict(c, rig="R6")))  # one clip, _R6: nothing derived
            self.assertTrue(costume.derives_r6(root, "npc1", dict(c, rig=None)))  # unset means R15
            self.assertTrue(costume.derives_r6(root, "player", {"model": "default"}))


class FilmLookTest(unittest.TestCase):
    def test_the_example_is_valid(self):
        self.assertEqual(costume.validate(HEROINE, "player"), [])

    def test_clothing_paints_its_regions_and_r6_wears_the_classic_items_only(self):
        c15, c6 = costume.colors(HEROINE, "R15"), costume.colors(HEROINE, "R6")
        self.assertEqual(c15["UpperTorso"], COAT)  # the layered coat over the tank top
        self.assertEqual(c15["LeftUpperArm"], COAT)
        self.assertEqual(c15["RightLowerLeg"], PANTS)
        self.assertEqual(c15["Head"], SKIN)
        self.assertEqual(c6["Torso"], TANK)  # R6 never builds layered clothing: the classic tank top shows
        self.assertEqual(c6["Left Arm"], SKIN)
        self.assertEqual(c6["Right Leg"], PANTS)
        self.assertEqual(len(c15), 15)
        self.assertEqual(len(c6), 6)

    def test_the_spec_film_is_the_fallback_under_the_items(self):
        spec = copy.deepcopy(HEROINE)
        spec["film"] = {"torso": "#ffffff", "left_arm": "#00ff00"}
        c6 = costume.colors(spec, "R6")
        self.assertEqual(c6["Torso"], TANK)  # an item that says how it looks wins over the region's film colour
        self.assertEqual(c6["Left Arm"], "#00ff00")  # the tank top has no sleeves: the region's film colour shows

    def test_accessories_stand_in_as_coarse_boxes_on_their_attachments(self):
        s15 = {s["name"]: s for s in costume.silhouettes(HEROINE, "R15")}
        s6 = {s["name"]: s for s in costume.silhouettes(HEROINE, "R6")}
        self.assertEqual(sorted(s15), ["back_16", "hair_14", "hat_15", "left_shoe_17"])  # clothing is colour only
        self.assertEqual(sorted(s6), ["back_16", "hair_14", "hat_15"])  # shoes are layered: R15 only
        at, size, offset = costume.SILHOUETTE["hair"]
        part, pos, _ = costume.ATTACH[at]["R15"]
        self.assertEqual(s15["hair_14"]["part"], part)
        self.assertEqual([round(v, 4) for v in s15["hair_14"]["cf"][:3]],
                         [round(p + o, 4) for p, o in zip(pos, offset)])
        self.assertEqual(s15["hair_14"]["size"], list(size))
        self.assertEqual(s15["hair_14"]["color"], HAIR)
        self.assertEqual(s15["hat_15"]["color"], costume.SILHOUETTE_COLOR)  # no film colour: a neutral box
        self.assertEqual(s6["back_16"]["part"], "Torso")
        self.assertEqual(s15["left_shoe_17"]["part"], "LeftFoot")

    def test_every_silhouette_slot_lands_on_a_part_of_both_rigs(self):
        spec = dict(HEROINE, catalog=[item(slot, i, costume.SLOT_TYPES[slot][0], "#123456")
                                      for i, slot in enumerate(costume.SILHOUETTE, 1)])
        for rig in ("R15", "R6"):
            got = costume.silhouettes(spec, rig)
            self.assertTrue(all(s["part"] in costume.REGION_PARTS[rig] for s in got), rig)
            self.assertEqual(len(got), len(costume.SILHOUETTE) - (2 if rig == "R6" else 0))  # shoes: R15 only

    def test_r15_boxes_follow_the_costume_scale(self):
        # Roblox scales R15 parts and attachments by width (x), height (y), depth (z), the head by head (spike S16:
        # NeckAttachment 0.849 -> 0.807 at height 0.95); R6 never scales
        spec = dict(HEROINE, scale={"height": 0.95, "width": 0.8, "depth": 0.85, "head": 0.95})
        s15 = {s["name"]: s for s in costume.silhouettes(spec, "R15")}
        k = (0.8, 0.95, 0.85)
        _, pos, _ = costume.ATTACH["BodyBackAttachment"]["R15"]
        _, size, offset = costume.SILHOUETTE["back"]
        self.assertEqual([round(v, 4) for v in s15["back_16"]["cf"][:3]],
                         [round((p + o) * f, 4) for p, o, f in zip(pos, offset, k)])
        self.assertEqual([round(v, 4) for v in s15["back_16"]["size"]], [round(a * f, 4) for a, f in zip(size, k)])
        _, hpos, _ = costume.ATTACH["HairAttachment"]["R15"]
        _, _, hoff = costume.SILHOUETTE["hair"]
        self.assertEqual([round(v, 4) for v in s15["hair_14"]["cf"][:3]],
                         [round((p + o) * 0.95, 4) for p, o in zip(hpos, hoff)])
        s6 = {s["name"]: s for s in costume.silhouettes(spec, "R6")}
        self.assertEqual(s6["back_16"]["size"], list(size))
        self.assertEqual(costume.silhouettes(costume.starter("npc1", "creature", "Beast", "credit"), "R15"), [])
        self.assertEqual(costume.proxies(HEROINE, "R15"), [])  # nothing built: proxies() stays for legacy specs

    def test_the_film_hint_is_checked_and_never_reaches_studio(self):
        spec = copy.deepcopy(HEROINE)
        spec["catalog"][0]["film"] = "black"
        self.assertTrue(any("catalog[1].film must be #rrggbb" in p for p in costume.validate(spec, "player")))
        with tempfile.TemporaryDirectory() as tmp:
            root = workspace.create("FilmTry", env={"MAKE_CUTSCENE_WORK": tmp})
            b = beats.draft("FilmTry", {"type": "words", "text": "x"}, [beats.shot("HERO", 2.0)])
            b["cast"]["player"]["model"] = "costume"
            beats.save(b, root)
            workspace.write_json(costume.spec_path(root, "player"), HEROINE)
            got = costume.install_specs(root, beats.load(root))["player"]
        self.assertEqual(len(got["catalog"]), 7)
        for c in got["catalog"]:
            self.assertNotIn("film", c)


def r4(values):
    return [round(v, 4) for v in values]


class HeldPropLookTest(unittest.TestCase):
    """A held prop's stand-in: each of its parts as a box on the hand at the measured grip point, held the way a Roblox
    Tool is (turned (-90, 0, 0) from the hand on both rigs: R15's grip attachment is turned so, R6's is not)."""

    @classmethod
    def setUpClass(cls):
        cls.fs = load_filmset()

    def props(self, spec, rig):
        return {s["name"]: s for s in costume.silhouettes(spec, rig) if s.get("prop")}

    def test_a_right_hand_prop_sits_on_the_grip_of_both_rigs(self):
        spec = dict(HEROINE, props=[SWORD])
        for rig, hand in (("R15", "RightHand"), ("R6", "Right Arm")):
            part, pos, _ = costume.ATTACH["RightGripAttachment"][rig]
            got = self.props(spec, rig)
            self.assertEqual(sorted(got), ["Sword_1", "Sword_2"], rig)
            self.assertEqual({s["part"] for s in got.values()}, {hand}, rig)
            self.assertEqual(part, hand)
            self.assertEqual(r4(got["Sword_1"]["cf"][:3]), list(pos), rig)  # the hilt is in the fist
            # the blade runs forward out of the fist (-Z of the hand) on both rigs
            self.assertEqual(r4(got["Sword_2"]["cf"][:3]), [pos[0], pos[1], -1.5], rig)
            self.assertEqual(r4(got["Sword_2"]["cf"][3:]), r4(clip.cframe(0, 0, 0, -90, 0, 0)[3:]), rig)
            self.assertEqual(got["Sword_2"]["size"], [0.08, 2.2, 0.28])
            self.assertEqual({s["color"] for s in got.values()}, {"#7d848b"})  # the prop's film colour
            self.assertEqual({s["prop"] for s in got.values()}, {"Sword"})

    def test_a_left_hand_prop_and_a_prop_without_a_film_colour(self):
        torch = dict(SWORD, name="Torch", at="LeftGripAttachment")
        del torch["film"]
        got = self.props(dict(HEROINE, props=[torch]), "R6")
        self.assertEqual({s["part"] for s in got.values()}, {"Left Arm"})
        self.assertEqual([got["Torch_1"]["color"], got["Torch_2"]["color"]], ["#2b2420", "#7d848b"])  # its parts'

    def test_the_r15_grip_follows_the_body_scale_but_the_prop_keeps_its_size(self):
        # the prop is built at its own size on the scaled body (Costume.humanoid, after the description is applied)
        spec = dict(HEROINE, scale={"height": 0.95, "width": 0.8, "depth": 0.85}, props=[SWORD])
        got = self.props(spec, "R15")
        self.assertEqual(r4(got["Sword_1"]["cf"][:3]), [0, round(-0.158 * 0.95, 4), 0])
        self.assertEqual(r4(got["Sword_2"]["cf"][:3]), [0, round(-0.158 * 0.95, 4), -1.5])
        self.assertEqual(got["Sword_2"]["size"], [0.08, 2.2, 0.28])
        self.assertEqual(r4(self.props(spec, "R6")["Sword_1"]["cf"][:3]), [0, -1, 0])  # R6 never scales

    def test_the_dressed_line_counts_props_beside_the_accessory_stand_ins(self):
        spec = dict(HEROINE, props=[SWORD])
        for rig, accessories in (("R15", 4), ("R6", 3)):
            boxes = costume.proxies(spec, rig) + costume.silhouettes(spec, rig)
            self.assertEqual(self.fs.dressed_line("Heroine", 15, boxes),
                             f"; dressed as Heroine (15 parts coloured, {accessories} accessory stand-ins, 1 prop)")
        two = dict(spec, props=[SWORD, dict(SWORD, name="Torch", at="LeftGripAttachment")])
        self.assertTrue(self.fs.dressed_line("H", 6, costume.silhouettes(two, "R6")).endswith(", 2 props)"))
        self.assertEqual(self.fs.dressed_line("Heroine", 15, costume.silhouettes(HEROINE, "R15")),
                         "; dressed as Heroine (15 parts coloured, 4 accessory stand-ins)")  # no prop, no count
        self.assertIn("dressed_line(", inspect.getsource(self.fs.costume_look))

    def test_the_r6_stand_in_hides_its_drawn_face_under_a_face_accessory(self):
        # make-anim's R6 head draws a face (eyes and a smile, children marked rbx_deco); Studio hides the default face
        # under a face accessory with no classic face (costume.hides_default_face), so the film set does too
        src = inspect.getsource(self.fs.costume_look)
        self.assertIn("K.costume.hides_default_face(spec, rigtype)", src)
        self.assertIn('o.get("rbx_deco")', src)
        self.assertIn("hide_render = True", src)


if __name__ == "__main__":
    unittest.main()
