"""The side-by-side sheet. Method by fwjelaa (FWJ STUDIOS).

Spec 8 gate 3: for each shot, the reference on top (the video's frame at the shot's middle, the panel, or the beat's
words on a card) and our preview below at the same beat.

    py kit/run.py sidebyside <id> [--rig R15|R6] [--preview path]
        -> preview/side_by_side_<n>.png (R15), preview/side_by_side_R6_<n>.png (R6); 6 shots per sheet

R15 uses preview/<id>.mp4 and R6 uses preview/<id>_R6.mp4 (spec 14: every demo is shown as both). --preview takes any
preview file instead (such sheets never go into a blind packet). Each run first clears that rig's older sheets, and
records the files and the preview stamp they were cut from in preview/sheets.json (review.stamp_sheet); likeness.png
is recorded the same way, with both casts' stamps.
"""
import re
import shutil
import textwrap
from pathlib import Path

import beats
import costume
import media
import review

PER_SHEET = 6
CELL = (480, 270)
RIGS = ("R15", "R6")


SLACK = 0.1


def frame(src, out, label, t=None):
    """media.cell plus a check that a frame really came out (ffmpeg exits 0 and writes nothing for a seek past the end)."""
    try:
        media.cell(src, out, label, CELL, t)
    except media.MediaError as e:
        raise SystemExit(f"could not read a frame for '{label}' from {Path(src).name}: {e}")
    if not Path(out).exists():
        raise SystemExit(f"no frame for '{label}' at {t} s in {Path(src).name}: re-record the take, or check ref/")
    return Path(out)


MIN_FS = 10  # smallest card font; past it the text is cut with an ellipsis (the cell size is fixed for the tiling)
ELLIPSIS = "…"


def fit_words(text, size):
    """(lines, font size) for a text card: wrapped to the card, the font shrunk until ALL the text fits, and only at
    MIN_FS cut, ending in an ellipsis."""
    w, h = size
    text = " ".join(text.split())
    for fs in range(h // 12, MIN_FS - 1, -1):
        lines = textwrap.wrap(text, width=max(10, int((w - 20) / (fs * 0.55))))
        room = max(1, (h - 20) // (fs + 4))
        if len(lines) <= room:
            return lines, fs
    width = max(10, int((w - 20) / (MIN_FS * 0.55)))
    room = max(1, (h - 20) // (MIN_FS + 4))
    lines = textwrap.wrap(text, width=width)[:room]
    lines[-1] = lines[-1][:width - 1].rstrip() + ELLIPSIS
    return lines, MIN_FS


def words_card(text, out, size):
    """A text card (a beat with no reference picture) that fits all of text; see fit_words."""
    lines, fs = fit_words(text, size)
    w, h = size
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    txt = out.with_name(out.stem + "_card.txt")
    f = media.font()
    try:
        txt.write_text("\n".join(lines), encoding="utf-8")
        vf = "null" if not f else (f"drawtext=fontfile={media.ff_path(f)}:textfile={media.ff_path(txt)}:expansion=none:"
                                   f"fontcolor=white:fontsize={fs}:line_spacing=4:x=10:y=10")
        media.ffmpeg("-f", "lavfi", "-i", f"color=c={media.BG}:s={w}x{h}:d=0.1", "-frames:v", "1", "-vf", vf, out)
    finally:
        txt.unlink(missing_ok=True)
    return out


def ours_frame(src, out, label, t):
    """Our frame with its label at the top left: the bottom letterbox bar carries the subtitles, so a label there
    would sit over them."""
    w, h = CELL
    out = Path(out)
    try:
        media.cell(src, out, "", CELL, t)
    except media.MediaError as e:
        raise SystemExit(f"could not read a frame for '{label}' from {Path(src).name}: {e}")
    if not out.exists():
        raise SystemExit(f"no frame for '{label}' at {t} s in {Path(src).name}: re-record the take, or check ref/")
    f = media.font()
    if not f:
        return out
    txt = out.with_name(out.stem + "_label.txt")
    tmp = out.with_name(out.stem + "_lab.png")
    try:
        txt.write_text(label, encoding="utf-8")
        media.ffmpeg("-i", out, "-frames:v", "1", "-vf",
                     f"drawtext=fontfile={media.ff_path(f)}:textfile={media.ff_path(txt)}:expansion=none:"
                     f"fontcolor=white:fontsize={max(12, h // 16)}:box=1:boxcolor=black@0.6:boxborderw=3:x=6:y=4", tmp)
        tmp.replace(out)
    finally:
        txt.unlink(missing_ok=True)
        tmp.unlink(missing_ok=True)
    return out


def top_cell(root, s, i, out):
    ref = s.get("ref") or {}
    if "mid" in ref:
        clip = root / "ref" / "clip.mp4"
        if not clip.exists():
            raise SystemExit(f"shot {i} points at the reference video but ref/clip.mp4 is missing: check ref/ "
                             f"(run py kit/run.py ref video again)")
        length = media.probe(clip)["duration"]
        if ref["mid"] >= length:
            raise SystemExit(f"shot {i} reference time {ref['mid']} s is past the end of ref/clip.mp4 ({length:.2f} s): "
                             f"check ref/ (run py kit/run.py ref video again) or fix ref.mid in beats.json")
        return frame(clip, out, f"reference, shot {i}", ref["mid"])
    if "panel" in ref:
        if not (root / ref["panel"]).exists():
            raise SystemExit(f"shot {i} points at {ref['panel']} but that file is missing: check ref/ "
                             f"(run py kit/run.py ref panels again)")
        return frame(root / ref["panel"], out, f"reference, panel {i}")
    words = f"WORDS ONLY, shot {i} {s['type']}: {s.get('action') or ''}  camera: {s.get('camera') or ''}"
    return words_card(words, out, CELL)


def clear(root, rig):
    """Deletes one rig's numbered side-by-side sheets (side_by_side_<n>.png, or side_by_side_R6_<n>.png for R6) and
    forgets their record, so a shorter run (or a new take) leaves none of the old ones behind."""
    tag = "R6_" if rig == "R6" else ""
    pattern = re.compile(rf"side_by_side_{tag}\d+\.png")
    for p in (Path(root) / "preview").glob(f"side_by_side_{tag}*.png"):
        if pattern.fullmatch(p.name):
            p.unlink()
    review.stamp_sheet(root, "side_by_side_R6" if rig == "R6" else "side_by_side", None)


def side_by_side(root, rig=None, preview=None):
    root = Path(root)
    if rig is not None and rig not in RIGS:
        raise SystemExit(f"--rig takes R15 or R6, not {rig}")
    b = beats.load(root)
    tag = "R6_" if rig == "R6" else ""
    video = Path(preview).resolve() if preview else root / "preview" / (
        f"{b['id']}_R6.mp4" if rig == "R6" else f"{b['id']}.mp4")
    if not video.exists():
        fix = (f"py kit/run.py preview {b['id']}" if rig != "R6" or preview
               else f"record the R6 cast and save the cut as preview/{b['id']}_R6.mp4")
        raise SystemExit(f"no preview yet ({video.name}): {fix}")
    shots = b["shots"]
    scene_end = max(s["start"] + s["length"] for s in shots)
    have = media.probe(video)["duration"]
    if have < scene_end - SLACK:
        raise SystemExit(f"{video.name} is {have:.2f} s but the scene is {scene_end:.2f} s: the take was cut short, "
                         f"re-record it and run py kit/run.py preview {b['id']} again")
    clear(root, rig)
    tmp = root / "preview" / "_sbs"
    tmp.mkdir(parents=True, exist_ok=True)
    paths = []
    try:
        for k in range(0, len(shots), PER_SHEET):
            group = list(enumerate(shots[k:k + PER_SHEET], k + 1))
            tops = [top_cell(root, s, i, tmp / f"top_{i:02d}.png") for i, s in group]
            ours = [ours_frame(video, tmp / f"ours_{i:02d}.png", f"ours, shot {i}  {s['start'] + s['length'] / 2:.2f}s",
                               s["start"] + s["length"] / 2) for i, s in group]
            paths.append(media.sheet(tops + ours, root / "preview" / f"side_by_side_{tag}{k // PER_SHEET + 1}.png",
                                     cols=len(group)))
    finally:
        for f in tmp.glob("*"):
            f.unlink()
        tmp.rmdir()
    # the blind packets carry these only while that preview (take and build) is the current one; --preview is any file
    review.stamp_sheet(root, "side_by_side_R6" if rig == "R6" else "side_by_side", [p.name for p in paths],
                       own=preview is None)
    return paths


LIKE = (360, 360)


def _still(src, out, t, crop):
    """One picture of src (a video at t s, or an image), cut to crop = [x0, y0, x1, y1] (fractions of the picture)."""
    x0, y0, x1, y1 = crop or (0, 0, 1, 1)
    seek = ["-ss", f"{max(0.0, t):.3f}"] if t is not None else []
    try:
        media.ffmpeg(*seek, "-i", src, "-frames:v", "1", "-vf",
                     f"crop=iw*{x1 - x0:.4f}:ih*{y1 - y0:.4f}:iw*{x0:.4f}:ih*{y0:.4f}", out)
    except media.MediaError as e:
        raise SystemExit(f"could not read a reference picture from {Path(src).name}: {e}: check the costume's "
                         f"likeness.ref and ref/ (run py kit/run.py ref video again)")
    if not Path(out).exists():
        raise SystemExit(f"no picture from {Path(src).name} at {t} s: check the costume's likeness.ref")
    return Path(out)


def focus_time(b, role, fallback):
    """(seconds, focused): the middle of the first shot whose subject is this role, else the costume's likeness.look."""
    for s in b["shots"]:
        if s.get("subject") == role:
            return round(s["start"] + s["length"] / 2, 3), True
    return fallback, False


def likeness(root):
    """Spec 14: one row per character the scene adapts: its reference (1-2 crops), then ours with the R15 cast and with
    the R6 cast, sampled in a shot that focuses on that role -> preview/likeness.png (the blind review's C7 evidence)."""
    root = Path(root)
    b = beats.load(root)
    worn = costume.roles(b)
    if not worn:
        raise SystemExit(f'{b["id"]} adapts no character (no role has "model": "costume"): no likeness sheet')
    videos = {rig: root / "preview" / f"{b['id']}{'_R6' if rig == 'R6' else ''}.mp4" for rig in RIGS}
    missing = [videos[rig].name for rig in RIGS if not videos[rig].exists()]
    if missing:
        raise SystemExit(f"record both casts first, no {', '.join(missing)}: py kit/run.py record {b['id']} [--rig R6], "
                         f"then  py kit/run.py preview {b['id']} [--rig R6]")
    (root / "preview" / "likeness.png").unlink(missing_ok=True)  # never an older sheet left after a failed run
    review.stamp_sheet(root, "likeness", None)
    tmp = root / "preview" / "_like"
    shutil.rmtree(tmp, ignore_errors=True)  # a stale picture from a killed run would pass the "frame came out" check
    tmp.mkdir(parents=True)
    cells = []
    try:
        for role in worn:
            spec = costume.load(root, role)
            who = f"{role}: {spec['character']}"
            lk = spec.get("likeness") or {}
            refs = list(lk.get("ref") or [])
            if not refs or "look" not in lk:
                raise SystemExit(f"cast/{role}.json has no likeness (look and ref): add it, then run this again")
            look, focused = focus_time(b, role, lk["look"])
            for k in range(2):
                out = tmp / f"{role}_ref{k}.png"
                if k < len(refs):
                    r = refs[k]
                    if "video" in r:
                        src, t = root / "ref" / "clip.mp4", r["video"]
                    else:
                        src, t = (root / r["panel"]).resolve(), None
                        if (root / "ref").resolve() not in src.parents:
                            raise SystemExit(f"cast/{role}.json likeness.ref[{k + 1}]: {r['panel']} must be inside ref/")
                    if not src.exists():
                        raise SystemExit(f"cast/{role}.json likeness.ref[{k + 1}]: {src.name} is missing (check ref/)")
                    try:
                        cells.append(media.cell(_still(src, tmp / f"{role}_raw{k}.png", t, r.get("crop")), out,
                                                f"{who} (reference)", LIKE))
                    except media.MediaError as e:
                        raise SystemExit(f"likeness for {role}: could not build the reference cell: {e}")
                else:
                    cells.append(words_card(f"{spec['character']} ({role}). {spec['source']}", out, LIKE))
            for rig in RIGS:
                label = f"{who} ours {rig} {look:.2f}s" + ("" if focused else " (not focused)")
                out = tmp / f"{role}_{rig}.png"
                try:
                    media.cell(videos[rig], out, label, LIKE, look)
                except media.MediaError as e:
                    raise SystemExit(f"likeness for {role}: could not read a frame from {videos[rig].name}: {e}: "
                                     f"re-record it, then run py kit/run.py preview {b['id']}")
                if not out.exists():
                    raise SystemExit(f"no frame at {look} s in {videos[rig].name}: re-record it, or fix the shot or "
                                     f"likeness.look for {role}")
                cells.append(out)
        try:
            out = media.sheet(cells, root / "preview" / "likeness.png", cols=4)
        except media.MediaError as e:
            raise SystemExit(f"could not tile the likeness sheet: {e}")
        review.stamp_sheet(root, "likeness", [out.name])  # made from both casts' current previews
        return out
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
