"""The blind score (spec 8 gate 4): a review packet per reviewer, three independent reviewers' replies parsed and scored
on rubrics/cutscene.md, the median against 8.5, at most 3 fix rounds, and the result logged honestly either way in the
fwjelaa quality-score ledger (<work>/.fwjelaa/ledger.jsonl). Method by fwjelaa (FWJ STUDIOS).

    py kit/run.py playtest <id> --set R15=pass [--set ...]     record the Studio play test (gate 2)
    py kit/run.py review <id> --round N                        three blind packets in <work>/blind/<id>-p<n>/
    py kit/run.py score <id> --round N <reply> <reply> <reply> the median, the lowest criterion, pass or not [--force]

Each reviewer gets one folder that holds only the packet. Replies, scores and the packet record live in
review/results/round<N>/. gates.json, playtest.json and the preview stamp must carry the hash of the build being
scored (gates.export_hash, which takes in the costume specs, and gates.module_hash), the sheets must be cut from the
current preview stamps (preview/sheets.json), and the replies must be about the packets of that same build, so evidence
from an older build is refused rather than counted.
"""
import datetime
import json
import re
import shutil
import statistics
from pathlib import Path

import beats
import costume
import gates
import paths
import review_evidence as evidence
import workspace

CRITERIA = (("C1", "Camera language", 3), ("C2", "Timing and weight", 3),
            ("C3", "Screen layer and VFX readability", 2), ("C4", "Sync", 2), ("C5", "Match to the reference", 2),
            ("C6", "Cleanliness", 2))
LIKENESS = ("C7", "Character likeness", 2)  # spec 14: scored only in scenes that adapt a character
PASS = 8.5
MAX_ROUNDS = 3
REVIEWERS = 3
CAP = 5.0  # a failed hard gate caps the score (quality-score's rule)
PLAYTEST = ("R15", "R6", "restore-end", "restore-skip", "restore-death", "console")
# an awakening can't be skipped; it adds its awakened state, the onlooker's view (an NPC caster stands in for a second
# player: the MCP drives one client), the cooldown and the example key bind
AWAKENING_PLAYTEST = ("R15", "R6", "restore-end", "restore-death", "console", "aura", "power-down", "onlooker",
                      "cooldown", "keybind")


def playtest_keys(kind):
    return AWAKENING_PLAYTEST if kind == "awakening" else PLAYTEST
NL = chr(10)
# A criterion line: "C1: 2", "**C1:** 2", "- C1 = 1.5", "C1 - 8.5/10", "| C1 | 2 | ...". Only at the start of a line, so
# prose that mentions "C2: 0" in the middle of a sentence is never read as a score.
LINE = re.compile(r"C([1-7])\b(?:\s*\([^)]*\))?\s*[:=|\-–—]\s*(\d+(?:\.\d+)?)(?:\s*/\s*(\d+(?:\.\d+)?))?")
LEAD = re.compile(r"^[\s>*\-•#|]+")


def set_playtest(root, items):
    path = Path(root) / "review" / "playtest.json"
    state = workspace.read_json(path) if path.exists() else {}
    now, mod, worn = gates.export_hash(root), gates.module_hash(root), gates.costume_hash(root)
    keys = playtest_keys(beats.load(root).get("kind"))
    for item in items:
        key, _, value = item.partition("=")
        if key not in keys or value not in ("pass", "fail"):
            raise SystemExit(f"--set takes KEY=pass or KEY=fail, KEY one of {', '.join(keys)}")
        state[key] = {"result": value, "date": datetime.date.today().isoformat(), "export": now,
                      "module": mod, "costume": worn}
    workspace.write_json(path, state)
    return [f"{k}: {state.get(k, {}).get('result', 'not run')}"
            + (" (STALE: the export changed since)" if k in state and state[k].get("export") != now else "")
            + (" (STALE: the data module changed since)" if k in state and state[k].get("export") == now
               and state[k].get("module") != mod else "")
            for k in keys]


def _video(root, rig):
    b = beats.load(root)
    return Path(root) / "preview" / f"{b['id']}{'_R6' if rig == 'R6' else ''}.mp4"


def stamp_preview(root, rig="R15"):
    """Record which build the preview in preview/ was made from (called when a preview is made), and which take: the
    video's own hash, so a new take on the same build is a new stamp (sheets made from the old take go stale). The R6
    preview has its own stamp, export_R6.json."""
    name = "export_R6.json" if rig == "R6" else "export.json"
    video = _video(root, rig)
    workspace.write_json(Path(root) / "preview" / name, {
        "export": gates.export_hash(root), "module": gates.module_hash(root), "costume": gates.costume_hash(root),
        "video": evidence.digest(video)})


def preview_stamp(root, rig):
    path = Path(root) / "preview" / ("export_R6.json" if rig == "R6" else "export.json")
    # A malformed stamp is missing provenance, not an unhandled reader/type error.
    try:
        stamp = workspace.read_json(path) if path.exists() else None
    except (SystemExit, OSError, UnicodeError, ValueError):
        return None
    return stamp if isinstance(stamp, dict) else None


# The sheets the blind packets carry, each recorded in preview/sheets.json with the preview stamp(s) it was made from
# and the files it wrote (sheets.side_by_side, sheets.likeness): a sheet from an older take or build is refused.
SHEETS = "sheets.json"
SHEET_RIGS = {"overview": ("R15",), "overview_R6": ("R6",), "side_by_side": ("R15",), "side_by_side_R6": ("R6",), "likeness": ("R15", "R6")}
SHEET_NAMES = {"overview": "sheet.png", "overview_R6": "sheet_R6.png", "side_by_side": "the side-by-side sheets (R15)", "side_by_side_R6": "the side-by-side sheets (R6)",
               "likeness": "likeness.png"}
SHEET_FIX = {"overview": "py kit/run.py preview {id}", "overview_R6": "py kit/run.py preview {id} --rig R6", "side_by_side": "py kit/run.py sidebyside {id}", "side_by_side_R6": "py kit/run.py sidebyside {id} --rig R6",
             "likeness": "py kit/run.py likeness {id}"}


def stamp_sheet(root, kind, files, own=True):
    """Record overview, side-by-side or likeness output bytes and the stamp of each preview it
    was cut from. own=False (made from some other video, --preview) records no stamp, so packets refuse it. files=None
    forgets the set (its old files were just cleared)."""
    path = Path(root) / "preview" / SHEETS
    state = workspace.read_json(path) if path.exists() else {}
    if files is None:
        state.pop(kind, None)
    else:
        files = list(files)
        state[kind] = {"files": files, "hashes": evidence.hashes(Path(root) / "preview", files),
                       "preview": {rig: preview_stamp(root, rig) if own else None for rig in SHEET_RIGS[kind]}}
    workspace.write_json(path, state)


def sheet_problems(root, b):
    """[problems] with the sheets a packet would carry: each set must be recorded as cut from the current preview(s)."""
    pv = Path(root) / "preview"
    made = workspace.read_json(pv / SHEETS) if (pv / SHEETS).exists() else {}
    kinds = ["overview", "overview_R6", "side_by_side", "side_by_side_R6"] + (["likeness"] if costume.roles(b) else [])
    out = []
    if not isinstance(made, dict):
        return ["invalid sheet manifest: regenerate previews and sheets"]
    for kind in kinds:
        rec, what, fix = made.get(kind), SHEET_NAMES[kind], SHEET_FIX[kind].format(id=b["id"])
        if not isinstance(rec, dict) or not rec.get("files"):
            out.append(f"{what}: no record of the preview they were made from: {fix}")
            continue
        names = rec["files"]
        fixed = {"overview": ["sheet.png"], "overview_R6": ["sheet_R6.png"], "likeness": ["likeness.png"]}
        pattern = r"side_by_side_R6_[1-9]\d*\.png" if kind == "side_by_side_R6" else r"side_by_side_[1-9]\d*\.png"
        valid = isinstance(names, list) and all(evidence.local_name(n) for n in names)
        if not valid or len(set(names)) != len(names) or (
                names != fixed[kind] if kind in fixed else not all(re.fullmatch(pattern, n) for n in names)):
            out.append(f"{what}: invalid sheet filenames; regenerate: {fix}")
            continue
        stamps = rec.get("preview") or {}
        if not isinstance(stamps, dict) or any(stamps.get(rig) is None or stamps.get(rig) != preview_stamp(root, rig) for rig in SHEET_RIGS[kind]):
            out.append(f"{what}: made from an older take or build, or another file: {fix}")
            continue
        for problem in evidence.problems(pv, rec.get("hashes"), rec["files"]):
            out.append(f"{what}: {problem}: {fix}")
    return out


MODULE_CHANGED = "the data module changed after the play test/preview: install and test again"
COSTUME_CHANGED = ("the costume specs (cast/*.json) changed after them: run the kit checks, install and play-test "
                   "again, then record both casts and make the likeness sheet again")


def _fresh(record, now, mod):
    return isinstance(record, dict) and record.get("export") == now and record.get("module") == mod


def module_changed(root):
    """True when a play test or preview stamp matches the export but not the data module written since."""
    root, now, mod = Path(root), gates.export_hash(root), gates.module_hash(root)
    pt = root / "review" / "playtest.json"
    records = [v for v in (workspace.read_json(pt).values() if pt.exists() else []) if isinstance(v, dict)]
    records += [r for r in (preview_stamp(root, rig) for rig in ("R15", "R6")) if r is not None]
    return any(r.get("export") == now and r.get("module") != mod for r in records)


def costume_changed(root):
    """True when a gate record says which costume specs it was made with, and they aren't the ones on disk now."""
    root, worn = Path(root), gates.costume_hash(root)
    g, pt = root / "export" / "gates.json", root / "review" / "playtest.json"
    records = [workspace.read_json(g)] if g.exists() else []
    records += [v for v in (workspace.read_json(pt).values() if pt.exists() else []) if isinstance(v, dict)]
    records += [r for r in (preview_stamp(root, rig) for rig in ("R15", "R6")) if r]
    return any("costume" in r and r["costume"] != worn for r in records)


def stale(root):
    """The hard gates whose evidence was made on an older export than the current one."""
    root = Path(root)
    now, mod = gates.export_hash(root), gates.module_hash(root)
    out = []
    g, pt, stamp = root / "export" / "gates.json", root / "review" / "playtest.json", root / "preview" / "export.json"
    if g.exists() and workspace.read_json(g).get("export") != now:
        out.append("G1 kit checks")
    if pt.exists() and any(not _fresh(v, now, mod) for v in workspace.read_json(pt).values() if isinstance(v, dict)):
        out.append("G2 play test")
    if (any((root / "preview").glob("*.mp4")) or stamp.exists()) and (
            not stamp.exists() or not _fresh(preview_stamp(root, "R15"), now, mod)):
        out.append("G3 preview")
    elif "G3 preview" not in out:
        r6 = root / "preview" / "export_R6.json"  # an R6 preview made on an older export is stale the same way
        if (any((root / "preview").glob("*_R6.mp4")) or r6.exists()) and (
                not r6.exists() or not _fresh(preview_stamp(root, "R6"), now, mod)):
            out.append("G3 preview")
    return out


def require_current(root):
    out_of_date = gates.export_stale(root)
    if out_of_date:
        raise SystemExit("the export is out of date:" + NL + "  - " + (NL + "  - ").join(out_of_date))
    # Check malformed/missing take evidence before freshness diagnostics read it.
    problems = preview_problems(root)
    if problems:
        raise SystemExit(NL.join(problems))
    old = stale(root)
    if old:
        why = f" {MODULE_CHANGED}." if module_changed(root) else ""
        why += f" {COSTUME_CHANGED}." if costume_changed(root) else ""
        raise SystemExit(f"{', '.join(old)}: made on an older export: re-run gates/playtest/preview for this export "
                         f"(py kit/run.py gates <id>; playtest <id> --set ...; preview <id>), then try again.{why}")


def preview_problems(root):
    """Rehash the actual clips; a stamp is provenance, not proof of decoding or playback."""
    problems = []
    for rig in ("R15", "R6"):
        stamp, video = preview_stamp(root, rig), _video(root, rig)
        actual = evidence.digest(video)
        if not isinstance(stamp, dict) or not actual or stamp.get("video") != actual:
            problems.append(f"{rig} preview missing or bytes differ from its take stamp: regenerate with "
                            f"py kit/run.py preview {beats.load(root)['id']} --rig {rig}")
    return problems


def preview_missing(root, b):
    """What gate 3 still lacks: both previews (spec 14: an R15 cast and an R6 cast) with their side-by-side sheets,
    and the likeness sheet when the scene adapts a character."""
    pv = Path(root) / "preview"
    have = {f"{b['id']}.mp4": (pv / f"{b['id']}.mp4").exists(),
            f"{b['id']}_R6.mp4": (pv / f"{b['id']}_R6.mp4").exists(),
            "side_by_side_<n>.png": any(re.fullmatch(r"side_by_side_\d+\.png", p.name) for p in pv.glob("side_by_side_*")),
            "side_by_side_R6_<n>.png": any(pv.glob("side_by_side_R6_*.png"))}
    if costume.roles(b):
        have["likeness.png"] = (pv / "likeness.png").exists()
    return [name for name, ok in have.items() if not ok]


def hard_gates(root):
    root = Path(root)
    b = beats.load(root)
    g, pt = root / "export" / "gates.json", root / "review" / "playtest.json"
    play = workspace.read_json(pt) if pt.exists() else {}
    old = set(stale(root)) | ({"G1 kit checks", "G2 play test", "G3 preview"} if gates.export_stale(root) else set())
    return {
        "G1 kit checks": "G1 kit checks" not in old and g.exists() and workspace.read_json(g).get("ok") is True,
        "G2 play test": "G2 play test" not in old and all(play.get(k, {}).get("result") == "pass" for k in playtest_keys(b.get("kind"))),
        "G3 preview": "G3 preview" not in old and not preview_missing(root, b)
                      and not preview_problems(root) and not sheet_problems(root, b),
    }


def blind_table(b):
    """The beat sheet for a reviewer: what happens and when, the lines and the markers, but not who approved it, the
    look setting, or the author's own camera and action notes (reviewers judge the picture, not the intent)."""
    trig = b.get("trigger")
    rows = [f"{b.get('id')}  {b.get('kind')}  {beats.length(b):.2f} s  "
            f"trigger={trig.get('type') if isinstance(trig, dict) else trig}", "",
            " #  type        start    end    len  subject"]
    for i, s in enumerate(b.get("shots") or [], 1):
        if not isinstance(s, dict):
            continue
        start = s.get("start", 0.0)
        rows.append(f"{i:>2}  {s.get('type', '?'):<10}  {start:>5.2f}  {start + s.get('length', 0.0):>5.2f}  "
                    f"{s.get('length', 0):>5.2f}  {str(s.get('subject')):<7}  {'CUT' if s.get('cut') else ''}".rstrip())
        marks = ", ".join(f"{m[1]}{'=' + str(m[2]) if len(m) > 2 and m[2] != '' else ''} @{m[0]:g}s"
                          for m in s.get("markers") or [] if isinstance(m, list) and len(m) >= 2)
        if marks:
            rows.append(" " * 8 + marks)
    if b.get("lines"):
        rows += ["", "Lines:"] + [f"  {k}  {v.get('speaker', '')}: {v.get('text', '')}" for k, v in b["lines"].items()]
    return NL.join(rows)


def _work(root):
    return Path(root).parent.parent


def _results(root, round_no):
    return Path(root) / "review" / "results" / f"round{round_no}"


def _check_round(round_no):
    if not isinstance(round_no, int) or not 1 <= round_no <= MAX_ROUNDS:
        raise SystemExit(f"rounds are 1-{MAX_ROUNDS}; after round {MAX_ROUNDS} the result is reported as it stands")


def packet(root, round_no):
    """Three identical packets, one per reviewer, each in a folder of its own that holds only the packet files."""
    root = Path(root)
    _check_round(round_no)
    b = beats.load(root)
    worn = costume.roles(b)
    pv = root / "preview"
    if not (pv / "sheet.png").exists():
        raise SystemExit(f"no preview sheet yet: py kit/run.py preview {b['id']}, then sidebyside")
    if not (pv / "sheet_R6.png").exists():
        raise SystemExit(f"no R6 preview sheet yet: py kit/run.py preview {b['id']} --rig R6 (spec 14: every scene is "
                         "shown with an R15 cast and an R6 cast)")
    if worn and not (pv / "likeness.png").exists():
        raise SystemExit(f"no likeness sheet yet: py kit/run.py likeness {b['id']} (the scene adapts a character)")
    require_current(root)
    old_sheets = sheet_problems(root, b)
    if old_sheets:
        raise SystemExit("the packets would carry sheets that don't show this build's previews:" + NL + "  - "
                         + (NL + "  - ").join(old_sheets))
    made = workspace.read_json(pv / SHEETS)
    side = [f for kind in ("side_by_side", "side_by_side_R6") for f in made[kind]["files"]]  # never a leftover
    src = b.get("source") or {}
    about = {"words": f"The reference was a description in words: {src.get('text', '')}",
             "video": "The reference was a video: its frames are on top of each side-by-side sheet.",
             "panels": "The reference was manga/manhwa panels: they are on top of each side-by-side sheet."}.get(src.get("type"), "")
    blind = _work(root) / "blind"
    for old in list(blind.glob(f"{b['id']}-p*")) + list(blind.glob(f"{b['id']}-r*")):  # nothing of an earlier round stays
        shutil.rmtree(old, ignore_errors=True)
    takes = {rig: preview_stamp(root, rig) for rig in ("R15", "R6")}
    outs = []
    for n in range(1, REVIEWERS + 1):
        out = blind / f"{b['id']}-p{n}"
        out.mkdir(parents=True)
        for rig in ("R15", "R6"):
            shutil.copyfile(_video(root, rig), out / f"preview_{rig}.mp4")
        shutil.copyfile(pv / "sheet.png", out / "frames.png")
        shutil.copyfile(pv / "sheet_R6.png", out / "frames_R6.png")  # spec 14: the same scene with an R6 cast
        if worn:
            shutil.copyfile(pv / "likeness.png", out / "likeness.png")
        for name in side:
            shutil.copyfile(pv / name, out / name)
        (out / "beats.txt").write_text(about + NL + NL + blind_table(b) + NL, encoding="utf-8", newline="\n")
        shutil.copyfile(paths.RUBRICS / "cutscene.md", out / "rubric.md")
        shutil.copyfile(paths.RUBRICS / "review-prompt.md", out / "README.md")
        if worn:  # spec 14: an adapted character is also scored on looking like itself (C7)
            with open(out / "README.md", "a", encoding="utf-8", newline="\n") as f:
                f.write(NL + (paths.RUBRICS / "likeness.md").read_text(encoding="utf-8"))
        outs.append(out)
    manifest = {"version": evidence.VERSION, "dirs": [str(o) for o in outs],
                "export": gates.export_hash(root), "module": gates.module_hash(root),
                "takes": takes, "sheets": made,
                "files": [evidence.hashes(o, [p.name for p in o.iterdir()]) for o in outs]}
    # Read back copied bytes and recheck source evidence before publishing the manifest.
    require_packet_evidence(root, b, manifest)
    workspace.write_json(_results(root, round_no) / "packet.json", manifest)
    return outs


def require_packet_evidence(root, b, manifest):
    """Shared fail-closed generation/scoring check. No score/ledger writes precede it."""
    require_current(root)
    problems = sheet_problems(root, b)
    if problems:
        raise SystemExit("regenerate review sheets: " + NL.join(problems))
    fix = f"regenerate packets: py kit/run.py review {b['id']} --round <N>; obtain fresh replies"
    if not isinstance(manifest, dict) or manifest.get("version") != evidence.VERSION:
        raise SystemExit("missing/legacy packet manifest; " + fix)
    takes = {rig: preview_stamp(root, rig) for rig in ("R15", "R6")}
    sheets = workspace.read_json(Path(root) / "preview" / SHEETS)
    if manifest.get("takes") != takes or manifest.get("sheets") != sheets:
        raise SystemExit("take or sheet identity changed after packets were made; " + fix)
    dirs, files = manifest.get("dirs"), manifest.get("files")
    expected_dirs = [_work(root) / "blind" / f"{b['id']}-p{n}" for n in range(1, REVIEWERS + 1)]
    if dirs != [str(d) for d in expected_dirs] or not isinstance(files, list) or len(files) != REVIEWERS:
        raise SystemExit("missing/invalid packet file manifest; " + fix)
    source_hashes = {"frames.png": sheets["overview"]["hashes"]["sheet.png"],
                     "frames_R6.png": sheets["overview_R6"]["hashes"]["sheet_R6.png"],
                     "preview_R15.mp4": takes["R15"]["video"], "preview_R6.mp4": takes["R6"]["video"]}
    for kind in ["side_by_side", "side_by_side_R6"] + (["likeness"] if costume.roles(b) else []):
        source_hashes.update(sheets[kind]["hashes"])
    expected = set(source_hashes) | {"README.md", "beats.txt", "rubric.md"}
    for directory, hashes in zip(expected_dirs, files):
        issues = evidence.problems(directory, hashes, expected)
        if directory.is_dir() and {p.name for p in directory.iterdir()} != expected:
            issues.append("unlisted or missing packet contents")
        if not issues and any(hashes[name] != sha for name, sha in source_hashes.items()):
            issues.append("packet does not match stamped source evidence")
        if not issues and hashes != files[0]:
            issues.append("reviewer packets differ")
        if issues:
            raise SystemExit(f"{directory.name}: " + "; ".join(issues) + "; " + fix)


SCALES = (2, 10)  # "/2" is the rubric's own scale; "/10" is what a reviewer who thinks in tens will write


def _number(c, value, denom, notes):
    v = float(value)
    if denom is not None:
        if float(denom) not in SCALES:
            raise SystemExit(f"{c}: a score out of {denom} is not understood; answer 0, 1 or 2 (or n/2, or n/10)")
        if float(denom) == 10:
            v = round(v / 10 * 2, 2)
            notes.append(f"{c} scaled from {value}/{denom} to {v:g}")
    if not 0 <= v <= 2:
        raise SystemExit(f"{c} is {value}{'/' + denom if denom else ''}: scores are 0-2 (or a fraction like 8.5/10); "
                         "ask that reviewer to answer in the six-line format")
    if v != int(v) and not any(n.startswith(f"{c} scaled") for n in notes):
        notes.append(f"{c} is fractional ({value})")
    return int(v) if v == int(v) else v


def parse_reply_notes(text, criteria=CRITERIA):
    """({criterion: points}, [notes on replies that were scaled or fractional])."""
    seen, notes = {}, []
    for line in text.splitlines():
        line = LEAD.sub("", line).replace("*", "").replace("`", "")
        m = LINE.match(line)
        if m:
            c = f"C{m.group(1)}"
            seen.setdefault(c, []).append(_number(c, m.group(2), m.group(3), notes))
    for c, values in seen.items():
        if len(set(values)) > 1:
            raise SystemExit(f"{c} appears twice with different scores ({', '.join(map(str, values))}): ask that "
                             "reviewer for one answer per criterion")
    found = {c: v[0] for c, v in seen.items() if c in {k for k, _, _ in criteria}}
    missing = [c for c, _, _ in criteria if c not in found]
    if missing:
        raise SystemExit("a reply is missing " + ", ".join(missing) + ": ask that reviewer to answer in the six-line format")
    return found, list(dict.fromkeys(notes))


def parse_reply(text, criteria=CRITERIA):
    return parse_reply_notes(text, criteria)[0]


def score(points, criteria=CRITERIA):
    total = sum(w for _, _, w in criteria)
    return round(10 * sum(w * points[c] / 2 for c, _, w in criteria) / total, 1)


def criteria_for(b):
    """The rubric's criteria for this scene: C1-C6, and C7 when it adapts a character (spec 14)."""
    return CRITERIA + (LIKENESS,) if costume.roles(b) else CRITERIA


def record(root, round_no, replies, force=False):
    root = Path(root)
    _check_round(round_no)
    b = beats.load(root)
    if not (_results(root, round_no) / "packet.json").exists():
        raise SystemExit(f"no packets for round {round_no}: run  py kit/run.py review {b['id']} --round {round_no}  first")
    scored = _results(root, round_no) / "scores.json"
    if scored.exists() and not force:
        raise SystemExit(f"round {round_no} is already scored (see {scored}); a new score for the same round needs "
                         "--force, and it is logged as a re-score")
    if len(replies) != REVIEWERS:
        raise SystemExit("the blind score needs exactly 3 independent replies")
    require_current(root)
    made = workspace.read_json(_results(root, round_no) / "packet.json")
    if not isinstance(made, dict):
        raise SystemExit("invalid packet manifest: regenerate packets with py kit/run.py review " + b['id'])
    if made.get("export") != gates.export_hash(root) or made.get("module") != gates.module_hash(root):
        raise SystemExit(f"the build changed after the packets were made: run review again (py kit/run.py review "
                         f"{b['id']} --round {round_no}) and send the new packets to fresh reviewers; these replies "
                         "are about the older build")
    require_packet_evidence(root, b, made)
    crit = criteria_for(b)
    parsed = [parse_reply_notes(r, crit) for r in replies]
    points, notes = [p for p, _ in parsed], [n for _, n in parsed]
    gate_state = hard_gates(root)
    ok_gates = all(gate_state.values())
    scores = [score(p, crit) if ok_gates else min(score(p, crit), CAP) for p in points]
    median = statistics.median(scores)
    per = {c: statistics.median(p[c] for p in points) for c, _, _ in crit}
    weight = {c: w for c, _, w in crit}
    lowest = min(per, key=lambda c: (per[c], -weight[c]))
    passed = ok_gates and median >= PASS
    result = {"round": round_no, "scores": scores, "median": median, "criteria": per, "lowest": lowest,
              "gates": gate_state, "notes": notes, "passed": passed, "date": datetime.date.today().isoformat()}
    rescored = scored.exists()
    workspace.write_json(scored, result)
    names = {c: n for c, n, _ in crit}
    lines = [f"Round {round_no}: scores {', '.join(map(str, scores))} -> median {median} (pass mark {PASS})",
             "Hard gates: " + ", ".join(f"{g} {'ok' if v else 'FAILED'}" for g, v in gate_state.items()),
             "Per criterion (median of 3): " + ", ".join(f"{c} {per[c]:g}" for c in per)]
    if any(notes):
        lines.append("Replies not on the plain 0-2 scale: " + "; ".join(f"reviewer {i}: {', '.join(n)}"
                                                                     for i, n in enumerate(notes, 1) if n))
    if passed:
        lines.append("PASSED.")
    elif round_no >= MAX_ROUNDS:
        lines.append(f"NOT PASSED after {MAX_ROUNDS} rounds: report it with these scores and the blocking criterion "
                     f"({lowest} {names[lowest]}); never call it done.")
    else:
        lines.append(f"Lowest: {lowest} {names[lowest]}. Make one targeted change for it, rebuild, re-check, re-record, "
                     f"then  py kit/run.py review {b['id']} --round {round_no + 1}")
    if passed or round_no >= MAX_ROUNDS:
        first = _results(root, 1) / "scores.json"
        entry = {"date": result["date"], "type": "cutscene", "name": b["id"],
                 "first_score": workspace.read_json(first)["median"] if first.exists() else median,
                 "final_score": median, "rounds": round_no, "passed": passed, "low_criteria_last": [lowest],
                 "gates_failed": [g for g, v in gate_state.items() if not v], "rescored": rescored,
                 "scaled_replies": [n for ns in notes for n in ns]}
        ledger = _work(root) / ".fwjelaa" / "ledger.jsonl"
        ledger.parent.mkdir(parents=True, exist_ok=True)
        with open(ledger, "a", encoding="utf-8", newline="\n") as f:
            f.write(json.dumps(entry) + NL)
        lines.append(f"logged to {ledger}")
    return result, lines
