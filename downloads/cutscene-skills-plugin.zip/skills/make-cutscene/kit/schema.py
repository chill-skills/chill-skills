"""The cutscene data-module format contract, in Python. Method by fwjelaa (FWJ STUDIOS).

The same rules and messages as CutsceneKit.Data.validate (roblox/CutsceneKit/Data.luau), applied to the dict form that
kit/fixture.py (and later the exporter) turns into a data module. Change one, change the other.

    problems = schema.validate(data)     # [] means valid
"""
import re

import vfxlib

KINDS = ("story", "intro", "awakening", "ultimate")
REPLAY = ("always", "session", "saved")
MAX_LENGTH = 30  # s: clips are capped at about 30 s until consecutive clip segments exist (spec 5.9)
FOV_MIN, FOV_MAX = 1, 120
LETTERBOX_MAX = 0.2
RIGS = ("R15", "R6")
CUE_KINDS = ("vfx", "screen", "sfx", "face")
SCREEN = vfxlib.SCREEN
LOOKS = vfxlib.LOOKS
GRADE = ("Brightness", "Contrast", "Saturation")
SLOWMO_MIN = 0.05
FOLLOW = re.compile(r"^(player|target|npc[1-9][0-9]?)(\.[A-Za-z0-9_]+)?\Z")
HEX6 = re.compile(r"^[0-9a-fA-F]{6}\Z")
ROLE = re.compile(r"^(player|target|npc[1-9][0-9]?)\Z")  # the cast roles (beats.ROLE; schema can't import beats)


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _seq(v):
    return isinstance(v, (list, tuple))


def _s(v):
    return "nil" if v is None else str(v)  # how Luau's tostring names a missing value


def validate(data):
    if not isinstance(data, dict):
        return ["the module must return a table"]
    problems = []

    def need(cond, msg):
        if not cond:
            problems.append(msg)
        return cond

    d = data
    need(d.get("Name") is None or isinstance(d.get("Name"), str), "Name must be a string")
    need(d.get("Kind") in KINDS, "Kind must be story, intro, awakening or ultimate")
    length = d.get("Length")
    need(_num(length) and 0 < length <= MAX_LENGTH, f"Length must be more than 0 and at most {MAX_LENGTH} s")

    anims = d.get("Anims") if isinstance(d.get("Anims"), dict) else None
    need(anims is not None and isinstance(anims.get("Stage"), str), "Anims.Stage missing (the camera clip)")
    for rig in RIGS:
        refs = anims.get(rig) if anims else None
        if refs is not None:
            need(isinstance(refs, dict) and all(isinstance(r, str) for r in refs.values()),
                 f"Anims.{rig} must map roles to clip refs (strings)")

    places = d.get("Places")
    if places is not None and need(isinstance(places, dict), "Places must be a table of role = {x, y, z, rx, ry, rz}"):
        for role, p in places.items():
            need(_seq(p) and len(p) == 6 and all(_num(x) for x in p),
                 f"Places.{_s(role)} must be 6 numbers {{x, y, z, rx, ry, rz}}")

    fov = d.get("Fov")
    if fov is not None and need(_seq(fov), "Fov must be a list of {time, fov}"):
        last = float("-inf")
        for i, e in enumerate(fov, 1):
            ok = _seq(e) and len(e) >= 2 and _num(e[0]) and _num(e[1])
            need(ok, f"Fov entry {i} must be {{time, fov}}")
            if ok:
                need(e[0] >= last, f"Fov times go backwards at {i}")
                need(FOV_MIN <= e[1] <= FOV_MAX, f"Fov entry {i} must be {FOV_MIN}-{FOV_MAX} degrees")
                need(0 <= e[0] <= (length if _num(length) else 0) + 1e-3, f"Fov entry {i} is outside the scene")
                last = e[0]

    lines = d.get("Lines")
    if lines is not None and need(isinstance(lines, dict), "Lines must be a table of id = {speaker, text}"):
        for key, line in lines.items():
            need(isinstance(key, str), f"Lines key {_s(key)} must be a string")
            need(isinstance(line, dict) and isinstance(line.get("text"), str), f"Lines[{_s(key)}] needs a text")
            if isinstance(line, dict):
                need(line.get("speaker") is None or isinstance(line.get("speaker"), str),
                     f"Lines[{_s(key)}].speaker must be a string")
                hold, voice = line.get("hold"), line.get("voice")
                need(hold is None or (_num(hold) and hold > 0), f"Lines[{_s(key)}].hold must be a number of seconds > 0")
                need(voice is None or isinstance(voice, str), f"Lines[{_s(key)}].voice must be a string")

    markers = d.get("Markers")
    if need(_seq(markers) or isinstance(markers, dict), "Markers missing") and \
            need(_seq(markers), "Markers must be a list with no gaps"):
        end = length if _num(length) else 0
        last = float("-inf")
        for i, m in enumerate(markers, 1):
            ok = _seq(m) and len(m) >= 2 and _num(m[0]) and isinstance(m[1], str)
            need(ok, f"marker {i} malformed")
            if ok:
                need(m[0] >= 0, f"marker {i} is before 0 s")
                need(m[0] >= last, f"markers not sorted at {i}")
                need(m[0] <= end + 1e-3, f"marker {i} after the end")
                last = m[0]
                value = m[2] if len(m) > 2 else None
                if m[1] == "Line":
                    need(isinstance(lines, dict) and isinstance(value, str) and value in lines,
                         f"Line marker {_s(value)} has no Lines entry")
                elif m[1] == "Letterbox":
                    need(value in ("in", "out"), f"Letterbox marker {i} must be in or out")

    costumes = d.get("Costumes")  # spec 14: roles dressed as an adapted character (models in the module's Costumes)
    if costumes is not None and need(_seq(costumes), "Costumes must be a list of roles like player or npc1"):
        seen = set()
        for i, role in enumerate(costumes, 1):
            ok = isinstance(role, str) and ROLE.match(role) is not None
            need(ok, f"Costumes entry {i} must be a role (player, target, npc1..npc99)")
            if ok:
                need(role not in seen, f"Costumes lists {role} twice")
                seen.add(role)
    cfg = d.get("Config")
    need(cfg is None or isinstance(cfg, dict), "Config must be a table")
    if isinstance(cfg, dict):
        need(cfg.get("Replay") is None or cfg.get("Replay") in REPLAY, "Config.Replay must be always, session or saved")
        skip = cfg.get("Skip")
        need(skip is None or skip is False or (_num(skip) and skip >= 0),
             "Config.Skip must be false or a number of seconds >= 0")
        box = cfg.get("Letterbox")
        need(box is None or (_num(box) and 0 <= box <= LETTERBOX_MAX),
             f"Config.Letterbox must be a number from 0 to {LETTERBOX_MAX}")
        need(cfg.get("Style") is None or isinstance(cfg.get("Style"), str), "Config.Style must be a string")
        hide = cfg.get("Hide")
        need(hide is None or (_seq(hide) and all(isinstance(p, str) for p in hide)),
             "Config.Hide must be a list of paths like Gate/Guard")
        if _seq(hide):
            for p in hide:
                if isinstance(p, str):
                    need(p != "" and not p.startswith("/") and p != "Workspace" and not p.startswith("Workspace/"),
                         f"Config.Hide path '{p}' is not valid: use a path like Gate/Guard "
                         "(not empty, no leading /, no Workspace/ prefix)")
        wear = cfg.get("Costume")
        need(wear is None or isinstance(wear, bool), "Config.Costume must be true or false")
        if wear is True:
            need(_seq(costumes) and "player" in costumes, "Config.Costume is true but Costumes has no player")
            need(d.get("Kind") in ("story", "intro"),
                 "Config.Costume works in story and intro scenes only (the player acts as a local copy there)")
    problems += vfx_problems(d)
    return problems


def _nums(v, n):
    return _seq(v) and len(v) == n and all(_num(x) for x in v)


SLOWMO_TEXT = re.compile(r"^ *[0-9]*[.]?[0-9]+ *\Z")  # plain decimals only: the same text Data.luau accepts


def _float(v):
    """A Slowmo value as a float: a real number, or plain decimal text; anything else None (Data.luau's twin)."""
    if _num(v):
        return float(v)
    if isinstance(v, str) and SLOWMO_TEXT.match(v):
        return float(v)
    return None


def first_marker(data, name):
    for m in data.get("Markers") or []:
        if _seq(m) and len(m) >= 2 and m[1] == name:
            return m
    return None


def cue_problems(key, cue, lib=None):
    """What is wrong with one Cues entry (the same messages as Data.luau's cueProblems)."""
    lib = lib or vfxlib.load()
    out = []

    def need(cond, msg):
        if not cond:
            out.append(msg)
        return cond

    label = _s(key)
    need(isinstance(key, str), f"Cues key {label} must be a string like VFX:Burst")
    if not need(isinstance(cue, dict) and cue.get("kind") in CUE_KINDS, f"Cues[{label}] needs a kind: vfx, screen, sfx or face"):
        return out
    if cue["kind"] == "vfx":
        if cue.get("external") is True:
            need(isinstance(cue.get("preset"), str), f"Cues[{label}].preset must be a string")
        else:
            need(isinstance(cue.get("preset"), str) and cue["preset"] in lib["presets"],
                 f"Cues[{label}].preset {_s(cue.get('preset'))} is not a VFX preset")
        need(cue.get("at") is None or _nums(cue["at"], 3), f"Cues[{label}].at must be 3 numbers {{x, y, z}}")
        need(cue.get("yaw") is None or _num(cue["yaw"]), f"Cues[{label}].yaw must be a number of degrees")
        need(cue.get("follow") is None or (isinstance(cue["follow"], str) and FOLLOW.match(cue["follow"]) is not None),
             f"Cues[{label}].follow must be a role or role.Part, like player.Head")
        need(cue.get("scale") is None or (_num(cue["scale"]) and cue["scale"] > 0), f"Cues[{label}].scale must be a number > 0")
        need(cue.get("element") is None or (isinstance(cue["element"], str) and cue["element"] in lib["elements"]),
             f"Cues[{label}].element {_s(cue.get('element'))} is not a VFX element")
    elif cue["kind"] == "screen":
        screen_problems(label, cue, need)
    return out


SCREEN_TEXT = "grade, bloom, flash, speedlines, focus, burst, word or backdrop"
SIZE_MAX = 2  # a burst or word at most twice the screen height
ROLES = vfxlib.ROLES


def _colour(v):
    return isinstance(v, str) and (v in ROLES or (v.startswith("#") and HEX6.match(v[1:]) is not None))


def screen_problems(label, cue, need):
    """A screen cue's fields (Data.luau's screenProblems is the twin): the manga effects' points, sizes, images,
    colours and sound-word text."""
    effect = cue.get("effect")
    need(effect in SCREEN, f"Cues[{label}].effect must be {SCREEN_TEXT}")
    for f in ("at", "focus"):
        v = cue.get(f)
        need(v is None or _nums(v, 2) or _nums(v, 3),
             f"Cues[{label}].{f} must be 2 numbers (x, y on the screen, 0-1) or 3 numbers {{x, y, z}}")
    need(cue.get("follow") is None or (isinstance(cue["follow"], str) and FOLLOW.match(cue["follow"]) is not None),
         f"Cues[{label}].follow must be a role or role.Part, like player.Head")
    life = cue.get("life")
    need(life is None or (_num(life) and life > 0), f"Cues[{label}].life must be a number of seconds > 0")
    need(cue.get("rot") is None or _num(cue["rot"]), f"Cues[{label}].rot must be a number of degrees")
    for f in ("alpha", "density"):
        v = cue.get(f)
        need(v is None or (_num(v) and 0 <= v <= 1), f"Cues[{label}].{f} must be a number from 0 to 1")
    for f in ("color", "fill"):
        need(cue.get(f) is None or _colour(cue[f]), f"Cues[{label}].{f} must be white, black, a colour role or #rrggbb")
    if effect in ("burst", "word"):
        size = cue.get("size")
        need(size is None or (_num(size) and 0 < size <= SIZE_MAX),
             f"Cues[{label}].size must be a share of the screen height, more than 0 and at most {SIZE_MAX}")
    if effect in ("burst", "backdrop"):
        img = cue.get("image")
        known = vfxlib.manga()
        need(img is None or (isinstance(img, str) and (img in known or vfxlib.ASSET_ID.match(img) is not None)),
             f"Cues[{label}].image must be a manga texture ({', '.join(sorted(known))}) or rbxassetid://<number>")
    if effect == "backdrop":
        dist = cue.get("dist")
        need(dist is None or (_num(dist) and dist > 0), f"Cues[{label}].dist must be a number of studs > 0")
    if effect == "word":
        text = cue.get("text")
        need(isinstance(text, str) and 1 <= len(text) <= vfxlib.WORD_TEXT_MAX,
             f"Cues[{label}].text must be 1-{vfxlib.WORD_TEXT_MAX} characters (a sound word like POW!!)")
        stroke = cue.get("stroke")
        need(stroke is None or (_num(stroke) and 0 <= stroke <= vfxlib.STROKE_MAX),
             f"Cues[{label}].stroke must be 0-{vfxlib.STROKE_MAX} of the text size (thicker fills the letters in)")
        need(cue.get("font") is None or (isinstance(cue["font"], str) and cue["font"] in vfxlib.FONTS),
             f"Cues[{label}].font must be one of {', '.join(vfxlib.FONTS)}")


def vfx_problems(d):
    """Plan 3's rules (CutsceneKit.Data.checkVfx is the twin): Slowmo markers, Cues, and the Config keys of awakenings."""
    lib = vfxlib.load()
    problems = []

    def need(cond, msg):
        if not cond:
            problems.append(msg)
        return cond

    length = d.get("Length") if _num(d.get("Length")) else 0
    markers = d.get("Markers")
    if _seq(markers):
        for i, m in enumerate(markers, 1):
            if _seq(m) and len(m) >= 2 and m[1] == "Slowmo":
                k = _float(m[2] if len(m) > 2 else None)
                need(k is not None and SLOWMO_MIN <= k <= 1, f"Slowmo marker {i} must be a number from {SLOWMO_MIN} to 1")
    cues = d.get("Cues")
    # a list is not a cue table (an empty one is fine: JSON can't tell {} from [])
    if cues is not None and need(isinstance(cues, dict) or cues == [], "Cues must be a table of marker = cue"):
        for key, cue in (cues.items() if isinstance(cues, dict) else ()):
            problems += cue_problems(key, cue, lib)
    cfg = d.get("Config")
    if not isinstance(cfg, dict):
        return problems
    cool = cfg.get("Cooldown")
    need(cool is None or (_num(cool) and cool >= 0), "Config.Cooldown must be a number of seconds >= 0")
    el = cfg.get("Element")
    need(el is None or (isinstance(el, str) and el in lib["elements"]), f"Config.Element {_s(el)} is not a VFX element")
    grade = cfg.get("Grade")
    if grade is not None and need(isinstance(grade, dict), "Config.Grade must be a table"):
        for k in GRADE:
            v = grade.get(k)
            need(v is None or (_num(v) and -1 <= v <= 1), f"Config.Grade.{k} must be a number from -1 to 1")
        tint = grade.get("Tint")
        need(tint is None or (isinstance(tint, str) and HEX6.match(tint) is not None),
             "Config.Grade.Tint must be 6 hex digits like ffd9a0")
    a = cfg.get("Awakened")
    if a is not None and need(isinstance(a, dict), "Config.Awakened must be a table"):
        dur = a.get("Duration")
        need(dur is None or (_num(dur) and dur > 0), "Config.Awakened.Duration must be a number of seconds > 0")
        need(a.get("Aura") is None or (isinstance(a["Aura"], str) and a["Aura"] in lib["auras"]), f"Config.Awakened.Aura {_s(a.get('Aura'))} is not an aura style")
        look = a.get("Look")
        need(look is None or (_seq(look) and all(isinstance(x, str) and x in LOOKS for x in look)),
             "Config.Awakened.Look must be a list of eyes, outline or tint")
        at = a.get("At")
        need(at is None or (_num(at) and 0 <= at <= length + 1e-3), "Config.Awakened.At must be a time inside the scene")
        need(a.get("Element") is None or (isinstance(a["Element"], str) and a["Element"] in lib["elements"]),
             f"Config.Awakened.Element {_s(a.get('Element'))} is not a VFX element")
    light = cfg.get("CastLight")  # a neutral key light on each cast member (CutsceneKit.Screen.castLight)
    if light is not None and need(isinstance(light, (bool, dict)),
                                  "Config.CastLight must be true, false or a table {Color, Brightness, Range}"):
        if isinstance(light, dict):
            c, br, rg = light.get("Color"), light.get("Brightness"), light.get("Range")
            need(c is None or (isinstance(c, str) and HEX6.match(c) is not None),
                 "Config.CastLight.Color must be 6 hex digits like ffffff")
            need(br is None or (_num(br) and 0 <= br <= CASTLIGHT_BRIGHT),
                 f"Config.CastLight.Brightness must be a number from 0 to {CASTLIGHT_BRIGHT}")
            need(rg is None or (_num(rg) and 1 <= rg <= CASTLIGHT_RANGE),
                 f"Config.CastLight.Range must be a number from 1 to {CASTLIGHT_RANGE}")
    return problems


CASTLIGHT_BRIGHT, CASTLIGHT_RANGE = 10, 60  # Roblox caps a PointLight's Range at 60
