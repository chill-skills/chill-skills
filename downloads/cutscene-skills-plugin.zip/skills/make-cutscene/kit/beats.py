"""The beat sheet: cutscenes/<id>/beats.json. It says what the scene is, shot by shot, before anything is built
(spec 5.1). refs.py drafts it from a video or panels, from_words() from a description; Claude edits it; the viewer says
"go" (`py kit/run.py beats <id> --go`). The film set, markers, data module and checks all read it.
Method by fwjelaa (FWJ STUDIOS).

beats.json, version 1:
  id, kind (story | intro | awakening | ultimate), look (anime | live), source {type: video | panels | words, ...}
  trigger: {type: zone, size: [x, y, z]} | {type: prompt, text, distance, hold, on} | {type: api}
  dialogue: anime | manhwa | box (needed when there are lines)
  cast: {role: {name, model, rig, place: [x, y, z, rx, ry, rz], hide}}    model: "default" or a path like Gate/Guard
  lines: {id: {speaker, text}}     config: {Skip, Replay, Letterbox}     approved: bool
  shots: [{type, start, length, subject, camera, action, cut, offscreen, markers: [[seconds into the shot, name, value]],
           ref, contacts: [[seconds into the shot, "role.Part", "role.Part", frames]]}]   (contact.py: planned touches)
Times are seconds on 60 fps frames; starts follow from the lengths (retime). Places are studs and degrees from the
scene anchor in Roblox axes (X right, Y up, Z back): the player stands at 0, 0, 0 facing -Z.
"""
import re
from pathlib import Path

import contact
import cues
import paths
import schema
import workspace

VERSION = 1
FPS = 60
SHOT_TYPES = ("ESTABLISH", "HERO", "OTS", "DIALOGUE", "ACTION", "INSERT", "REACTION", "CLIMAX", "IMPACT",
              "AFTERMATH", "RETURN")
TRIGGERS = ("zone", "prompt", "api")
DIALOGUE = ("anime", "manhwa", "box")
LOOKS = ("anime", "live")
ROLE = re.compile(r"^(player|target|npc[1-9][0-9]?)\Z")
MIN_SHOT = 0.2
RETURN = 0.55  # spec 5.1: the RETURN beat
EPS = 1e-3
ZONE = [16, 8, 16]
DEFAULT_CONFIG = {"Skip": 2, "Replay": "saved", "Letterbox": 0.11}
CAMERA = {  # the shot grammar (research/00 section 2, spec 5.1), as camera notes for a words draft
    "ESTABLISH": "wide: the place, the player arriving, the speaker ahead",
    "HERO": "push-in on the speaker, eye level, ending on a medium close-up",
    "OTS": "over the player's shoulder onto the speaker",
    "CLIMAX": "hard cut closer on the climax line: low angle, small shake",
    "AFTERMATH": "wide again, slow pull back",
    "RETURN": "ease toward behind the player (the runtime blends from here once Plan 3 adds the blend)",
}
TEMPLATES = {
    "walkin": "ESTABLISH wide; one shot per line (HERO push-in on the first, OTS reverse after); a hard cut to a "
              "closer CLIMAX shot on the last line; AFTERMATH wide; RETURN 0.55 s",
}


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def snap(t):
    """Seconds -> the nearest 60 fps frame (5 decimals, like the clips)."""
    return round(round(t * FPS) / FPS, 5)


def hold(text):
    """How long a subtitle stays up: the same rule as CutsceneKit.Subtitles.hold."""
    return min(6.0, max(1.6, 1.6 + 0.045 * len(text)))


def shot(kind, length, subject="player", camera="", action="", markers=None, cut=True, ref=None):
    return {"type": kind, "length": length, "subject": subject, "camera": camera, "action": action,
            "markers": markers or [], "cut": cut, "ref": ref}


def retime(shots):
    """Snap every length to frames (at least MIN_SHOT) and derive the starts from them."""
    t = 0.0
    for s in shots:
        s["length"] = max(snap(s["length"]), snap(MIN_SHOT))
        s["start"] = snap(t)
        t += s["length"]
    return shots


def retime_sheet(b):
    """Retime a whole sheet. Changing shots un-approves it: the viewer said go to a different sheet."""
    retime(b["shots"])
    b["approved"] = False
    return b


def length(b):
    shots_ = b.get("shots") or []
    return round(shots_[-1]["start"] + shots_[-1]["length"], 5) if shots_ else 0.0


def draft(cid, source, shots_, look="anime", kind="story"):
    """A new beat sheet. trigger, dialogue and NPC models stay unset until the viewer answers asks()."""
    paths.check_id(cid)
    for i, s in enumerate(shots_):
        s.setdefault("subject", "player")
        s.setdefault("camera", "")
        s.setdefault("action", "")
        s.setdefault("markers", [])
        s.setdefault("cut", i > 0)
        s.setdefault("ref", None)
    return {"version": VERSION, "id": cid, "kind": kind, "source": source, "look": look, "trigger": None,
            "dialogue": None, "cast": {"player": {"place": [0, 0, 0, 0, 0, 0]}}, "lines": {},
            "shots": retime(shots_), "config": cues.config_for(kind, DEFAULT_CONFIG), "approved": False}


def from_words(cid, text, lines, speaker="npc1", template="walkin"):
    """Words -> shots from the shot grammar. lines = [(speaker name, text)]; the speaker is cast as `speaker`."""
    if template not in TEMPLATES:
        raise SystemExit(f"unknown template {template!r}: use one of {', '.join(TEMPLATES)}")
    if not lines:
        raise SystemExit('the walk-in template needs at least one line: --line "Name: text"')
    name = lines[0][0] or "NPC"
    shots_ = [shot("ESTABLISH", 1.6, speaker, CAMERA["ESTABLISH"], text, cut=False)]
    for i, (who, said) in enumerate(lines, 1):
        kind = "CLIMAX" if i == len(lines) and len(lines) > 1 else "HERO" if i == 1 else "OTS"
        marks = [[0.15, "Line", str(i)]] + ([[0.0, "Shake", "0.25"]] if kind == "CLIMAX" else [])
        shots_.append(shot(kind, hold(said) + 0.3, speaker, CAMERA[kind], f'{who}: "{said}"', marks))
    shots_.append(shot("AFTERMATH", 1.2, "player", CAMERA["AFTERMATH"], "the player faces the speaker"))
    shots_.append(shot("RETURN", RETURN, "player", CAMERA["RETURN"], "back to play", cut=False))
    b = draft(cid, {"type": "words", "text": text}, shots_)
    b["lines"] = {str(i): {"speaker": who, "text": said} for i, (who, said) in enumerate(lines, 1)}
    b["cast"][speaker] = {"name": name, "rig": "R15", "place": [0, 0, -8, 0, 180, 0]}
    return b


def markers(b):
    """Every marker of the scene, absolute and sorted by time: the shots' own markers plus Letterbox in at 0,
    Cut at each shot that starts with a cut, Letterbox out (at the RETURN shot, else 0.55 s before the end) and End.
    The end is the scene's last frame N = round(length * 60), like the Stage clip's, even for a length off the grid."""
    shots_, total = b["shots"], snap(length(b))
    box = (b.get("config") or {}).get("Letterbox", DEFAULT_CONFIG["Letterbox"])
    out = [[0.0, "Letterbox", "in"]] if box else []
    for i, s in enumerate(shots_):
        if i > 0 and s.get("cut", True):
            out.append([s["start"], "Cut", ""])
        if box and s["type"] == "RETURN":
            out.append([s["start"], "Letterbox", "out"])
        for m in s.get("markers") or []:
            out.append([round(s["start"] + m[0], 5), m[1], str(m[2]) if len(m) > 2 else ""])
    if box and not any(m[1] == "Letterbox" and m[2] == "out" for m in out):
        out.append([round(max(0.0, total - RETURN), 5), "Letterbox", "out"])
    out.append([total, "End", ""])
    n = round(total * FPS)  # a marker that rounds to the last frame sits on it, as camtrack.stage_clip puts it
    out = [[total if round(m[0] * FPS) >= n else m[0], m[1], m[2]] for m in out]
    return sorted(out, key=lambda m: m[0])


def cut_frames(b):
    return [round(m[0] * FPS) for m in markers(b) if m[1] == "Cut"]


NOTES = ("camera", "action", "ref")  # a shot's notes for people: the export never reads them


def export_part(b):
    """The parts of the sheet an export is made from (the shots' timing, cuts and markers, the cast's places and rig
    types, the letterbox, which adds markers). A change here needs a new export; lines, dialogue, config, models,
    names, hide, trigger and approval only change the data module (scenefile.sources hashes this)."""
    return {"id": b.get("id"),
            "shots": [{k: v for k, v in s.items() if k not in NOTES} if isinstance(s, dict) else s
                      for s in b.get("shots") or []],
            # a costume adds a clip (an NPC in a humanoid costume gets a derived R6 one); only then is it in the hash,
            # so the exports of scenes without costumes stay current
            "cast": {role: dict({"place": (c or {}).get("place"), "rig": (c or {}).get("rig")},
                                **({"costume": True} if (c or {}).get("model") == "costume" else {}))
                     for role, c in (b.get("cast") or {}).items()},
            "letterbox": (b.get("config") or {}).get("Letterbox", DEFAULT_CONFIG["Letterbox"])}


def shots(b):
    out = []
    for i, s in enumerate(b["shots"], 1):
        start, end = s["start"], round(s["start"] + s["length"], 5)
        out.append({"n": i, "type": s["type"], "subject": s.get("subject"), "start": start, "end": end,
                    "last": round(end - 1 / FPS, 5), "first_frame": round(start * FPS), "end_frame": round(end * FPS),
                    "offscreen": bool(s.get("offscreen"))})
    return out


def validate(b):
    if not isinstance(b, dict):
        return ["beats.json must be one JSON object"]
    problems = []

    def need(cond, msg):
        if not cond:
            problems.append(msg)
        return cond

    need(b.get("version") == VERSION, f"version must be {VERSION}")
    need(isinstance(b.get("id"), str) and paths.ID_RULE.match(b["id"]) is not None,
         "id: start with a letter and use only letters, digits and _ (at most 60)")
    need(b.get("kind") in schema.KINDS, "kind must be story, intro, awakening or ultimate")
    need(b.get("look") in LOOKS, "look must be anime or live")
    trig = b.get("trigger")
    if need(isinstance(trig, dict) and trig.get("type") in TRIGGERS,
            "trigger is not set: {\"type\": \"zone\" | \"prompt\" | \"api\"} (ask the viewer how the scene starts)"):
        if trig["type"] == "zone":
            size = trig.get("size")
            need(isinstance(size, list) and len(size) == 3 and all(_num(v) and v > 0 for v in size),
                 "trigger.size must be 3 positive numbers (studs)")
        elif trig["type"] == "prompt":
            need(_num(trig.get("distance", 10)) and trig.get("distance", 10) > 0, "trigger.distance must be more than 0")
            need(isinstance(trig.get("text", "Talk"), str), "trigger.text must be text, like Talk")
            need(trig.get("on") is None or isinstance(trig.get("on"), str), "trigger.on must be a path like Gate/Guard/Head")
    cast = b.get("cast")
    if need(isinstance(cast, dict) and "player" in cast, "cast needs at least the player"):
        for role, c in cast.items():
            need(isinstance(role, str) and ROLE.match(role) is not None,
                 f"cast role {role!r} must be player, target or npc1..npc99")
            if not need(isinstance(c, dict), f"cast.{role} must be an object"):
                continue
            p = c.get("place", [0, 0, 0, 0, 0, 0])
            need(isinstance(p, list) and len(p) == 6 and all(_num(v) for v in p),
                 f"cast.{role}.place must be 6 numbers (x, y, z, rx, ry, rz)")
            need(c.get("hide") is None or isinstance(c.get("hide"), str), f"cast.{role}.hide must be a path like Gate/Guard")
            if role != "player":
                need(c.get("rig", "R15") in schema.RIGS, f"cast.{role}.rig must be R15 or R6")
                need(isinstance(c.get("model"), str) and c["model"].strip() != "",
                     f'cast.{role}.model is not set: "default" (a plain dummy) or the model\'s path, like Gate/Guard')
    lines = b.get("lines") or {}
    if not need(isinstance(lines, dict), "lines must be an object: id -> {speaker, text}"):
        lines = {}
    for key, line in lines.items():
        need(isinstance(line, dict) and isinstance(line.get("text"), str) and line["text"].strip() != "",
             f"line {key} needs a text")
    if lines:
        need(b.get("dialogue") in DIALOGUE, "dialogue is not set: anime, manhwa or box (ask the viewer)")
    shots_ = b.get("shots")
    total = 0.0
    if need(isinstance(shots_, list) and shots_, "shots must be a non-empty list"):
        used = set()
        for i, s in enumerate(shots_, 1):
            if not need(isinstance(s, dict), f"shot {i} must be an object"):
                continue
            need(s.get("type") in SHOT_TYPES, f"shot {i}: type must be one of {', '.join(SHOT_TYPES)}")
            ok_len = need(_num(s.get("length")) and s["length"] >= MIN_SHOT - EPS,
                          f"shot {i}: length must be at least {MIN_SHOT} s")
            need(_num(s.get("start")) and abs(s["start"] - total) <= EPS,
                 f"shot {i} starts at {s.get('start')} but the shot before ends at {round(total, 3)}: "
                 f"run  py kit/run.py beats {b.get('id')} --retime")
            need(s.get("subject") is None or (isinstance(s["subject"], str) and isinstance(cast, dict)
                                              and s["subject"] in cast),
                 f"shot {i}: subject {s.get('subject')!r} is not in the cast")
            for m in s.get("markers") or []:
                ok = (isinstance(m, list) and len(m) >= 2 and _num(m[0]) and isinstance(m[1], str) and m[1] != ""
                      and ":" not in m[1])
                if need(ok, f"shot {i}: marker {m!r} must be [seconds into the shot, name, value]"):
                    need(-EPS <= m[0] <= (s["length"] if ok_len else 0) + EPS,
                         f"shot {i}: marker {m[1]} at {m[0]} s is outside the shot")
                    if m[1] == "Line":
                        key = str(m[2]) if len(m) > 2 else ""
                        need(key in lines, f"shot {i}: Line marker {key!r} has no entry in lines")
                        used.add(key)
            total += s["length"] if ok_len else 0.0
        need(total <= schema.MAX_LENGTH + EPS, f"the scene is {round(total, 2)} s; at most {schema.MAX_LENGTH} s "
             "(trim the reference with --from/--to, or drop shots)")
        for key in lines:
            need(key in used, f"line {key} is never shown: add a Line marker for it")
    probe = {"Kind": b.get("kind") if b.get("kind") in schema.KINDS else "story", "Length": max(1.0, total),
             "Anims": {"Stage": "S"}, "Markers": [], "Config": b.get("config") if b.get("config") is not None else {}}
    problems += [f"config: {p}" for p in schema.validate(probe) if p.startswith("Config")]
    problems += cues.check_beats(b)
    problems += contact.problems(b)  # RS-1: planned contacts for the cast overlap check
    return problems


def asks(b):
    """What to ask the viewer (spec 5.1: only what's missing)."""
    q = []
    if b.get("kind") not in schema.KINDS:
        q.append("What kind of scene is it: a walk-in story scene, an awakening, an ultimate on a target, or a "
                 "boss/area intro?")
    if not isinstance(b.get("trigger"), dict) or b["trigger"].get("type") not in TRIGGERS:
        q.append("How does it start: walking into a zone, a ProximityPrompt (press E to talk), or your own script "
                 "calling CutsceneKit.Play?")
    for role, c in (b.get("cast") or {}).items():
        if role != "player" and isinstance(c, dict) and not c.get("model"):
            q.append(f"Who plays {c.get('name') or role} ({role})? A model in your map (its path, like Gate/Guard) or "
                     "a plain R15 dummy?")
    if b.get("lines") and b.get("dialogue") not in DIALOGUE:
        q.append("Which dialogue style: anime subtitles, manhwa boxes or a dialogue box? (This version draws anime "
                 "subtitles; the other two arrive in a later version.)")
    return q


def table(b):
    """The beat sheet as text, to show the viewer."""
    trig = b.get("trigger")
    head = (f"{b.get('id')}  {b.get('kind')}  {length(b):.2f} s  look={b.get('look')}  "
            f"trigger={trig.get('type') if isinstance(trig, dict) else trig}  dialogue={b.get('dialogue')}  "
            f"approved={b.get('approved')}")
    rows = [head, "", " #  type        start    end    len  subject  camera / action / markers"]
    for i, s in enumerate(b.get("shots") or [], 1):
        if not isinstance(s, dict):
            rows.append(f"{i:>2}  (not a shot: {s!r})")
            continue
        start = s.get("start", 0.0)
        end = start + s.get("length", 0.0)
        rows.append(f"{i:>2}  {s.get('type', '?'):<10}  {start:>5.2f}  {end:>5.2f}  {s.get('length', 0):>5.2f}  "
                    f"{str(s.get('subject')):<7}  {'CUT  ' if s.get('cut') else ''}{s.get('camera', '')}")
        if s.get("action"):
            rows.append(" " * 50 + s["action"])
        marks = ", ".join(f"{m[1]}{'=' + str(m[2]) if len(m) > 2 and m[2] != '' else ''} @{m[0]:g}s"
                          for m in s.get("markers") or [] if isinstance(m, list) and len(m) >= 2)
        if marks:
            rows.append(" " * 50 + marks)
    if b.get("lines"):
        rows += ["", "Lines:"] + [f"  {k}  {v.get('speaker', '')}: {v.get('text', '')}" for k, v in b["lines"].items()]
    return "\n".join(rows)


def load(where):
    p = Path(where)
    return workspace.read_json(p / "beats.json" if p.is_dir() else p)


def save(b, root):
    return workspace.write_json(Path(root) / "beats.json", b)


def save_draft(root, b, force=False):
    """beats.json if there is none yet (or force); otherwise beats.draft.json next to it, so edits are never lost."""
    path = Path(root) / ("beats.json" if force or not (Path(root) / "beats.json").exists() else "beats.draft.json")
    return workspace.write_json(path, b)
