"""The data module (spec 6) for one cutscene: export/scene.json (filmset.export) + beats.json -> export/<id>.luau,
checked with schema.validate (the Python twin of CutsceneKit.Data.validate) before anything is written.
Method by fwjelaa (FWJ STUDIOS).

    py kit/run.py scene <id>     export/<id>.luau and export/manifest.json

Clip refs are asset ids ("rbxassetid://...") for every clip export/ids.json holds an id for and whose .rbxmx hasn't
changed since it was uploaded; any other clip keeps its name (a Studio-only clip in the module's Clips folder).
The module is written only from a current export: scene.json's "sources" (what filmset.export was made from) still
match the working folder, the Stage clip carries the module's markers, and the export didn't stop on clip issues.
"""
import hashlib
import json
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

import beats
import clip
import costume
import cues
import schema
import workspace

LINE_KEYS = ("speaker", "text", "hold", "voice")
MIN_HOLD = 1.2  # seconds a line stays up at least, however short its shot
CAMERA = "CutsceneCamera"  # the Stage clip's one channel (camtrack.stage_clip)
SOURCES = ("anim/*.py", "rigs/*.json")  # besides beats.json: the files an export is made from
AGAIN = "run the export again (filmset.export in Blender)"


def framing_of(root):
    """export/framing.json, or None before the first export (cues with "<role>.face" points need it)."""
    path = Path(root) / "export" / "framing.json"
    return workspace.read_json(path) if path.exists() else None


def module_data(b, scene, ids=None, framing=None):
    def ref(name):
        return f"rbxassetid://{ids[name]}" if ids and name in ids else name

    clips = scene["clips"]
    anims = {"Stage": ref(clips["Stage"])}
    for rig in schema.RIGS:
        if clips.get(rig):
            anims[rig] = {role: ref(n) for role, n in clips[rig].items()}
    cfg = dict(b.get("config") or {})
    hide = [c["hide"] for c in b["cast"].values() if isinstance(c, dict) and c.get("hide")]
    if hide:
        cfg["Hide"] = hide
    if b.get("dialogue"):
        cfg["Style"] = b["dialogue"]
    data = {"Name": b["id"], "Kind": b["kind"], "Length": scene["length"], "Anims": anims,
            "Places": {role: list((c or {}).get("place") or [0, 0, 0, 0, 0, 0]) for role, c in b["cast"].items()},
            "Fov": scene["fov"], "Markers": beats.markers(b), "Config": cfg}
    worn = costume.roles(b)  # spec 14: Studio builds these roles' costume models into the module's Costumes folder
    if worn:
        data["Costumes"] = sorted(worn)
        if "player" in worn:
            cfg["Costume"] = True  # the player's local copy wears it; their own avatar is never changed
    found = cues.module_cues(data["Markers"], b.get("cues"), framing)
    if found:
        data["Cues"] = found
    if b.get("lines"):
        data["Lines"] = {k: {kk: v[kk] for kk in LINE_KEYS if kk in v} for k, v in b["lines"].items()}
        for k, hold in line_holds(b).items():
            data["Lines"][k]["hold"] = hold
    return data


def line_holds(b):
    """{line id: seconds} for each line that has no hold of its own: it clears at the end of the shot that shows it
    (the runtime clears at marker time + hold), at least MIN_HOLD so a short shot stays readable, but never past the
    next line's marker. Lines only change the data module, never the export (beats.export_part ignores them)."""
    lines = b.get("lines") or {}
    ends = [(s["start"], round(s["start"] + s["length"], 5)) for s in b["shots"]]
    shows = [m for m in beats.markers(b) if m[1] == "Line"]
    out = {}
    for i, (t, _, key) in enumerate(shows):
        if key in out or key not in lines or "hold" in lines[key]:
            continue
        end = next((e for s, e in ends if s <= t < e), ends[-1][1])
        nxt = next((m[0] for m in shows[i + 1:] if m[2] != key and m[0] > t), None)
        hold = max(end - t, MIN_HOLD)
        out[key] = round(min(hold, nxt - t) if nxt is not None else hold, 5)
    return out


def clip_names(scene):
    clips = scene["clips"]
    return [clips["Stage"]] + [n for rig in schema.RIGS for n in (clips.get(rig) or {}).values()]


def current_ids(root):
    path = Path(root) / "export" / "ids.json"
    if not path.exists():
        return {}
    out = {}
    for name, v in workspace.read_json(path).items():
        entry = v if isinstance(v, dict) else {"id": str(v), "sha": None}
        rbxmx = Path(root) / "export" / f"{name}.rbxmx"
        if entry.get("sha") is None or (rbxmx.exists() and hashlib.sha256(rbxmx.read_bytes()).hexdigest() == entry["sha"]):
            out[name] = str(entry["id"])
    return out


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def sources(root):
    """What an export is made from, hashed: beats.export_part of the sheet, every anim/*.py and rigs/*.json.
    filmset.export records it in scene.json; write() refuses when the working folder no longer matches it."""
    root = Path(root)
    part = json.dumps(beats.export_part(beats.load(root)), sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    out = {"beats.json": _sha(part.encode("utf-8"))}
    for pattern in SOURCES:
        for p in sorted(root.glob(pattern)):
            out[p.relative_to(root).as_posix()] = _sha(p.read_bytes())
    return out


def stale(root, scene):
    """[problems] when the working folder changed after the export (a new, changed or deleted source file)."""
    made = scene.get("sources")
    if not isinstance(made, dict):
        return [f"export/scene.json doesn't say what it was exported from (an older export): {AGAIN}"]
    now = sources(root)
    return [f"{f} changed after the export: {AGAIN}" for f in sorted(set(now) | set(made)) if now.get(f) != made.get(f)]


def marker_problems(root, scene, b):
    """The second net: the Stage clip's KeyframeMarkers, read back from its file, are the module's Markers."""
    path = Path(root) / "export" / f"{scene['clips']['Stage']}.json"
    if not path.exists():
        return []  # check_files names the missing clip
    got = [[k["time"], n, v] for k in workspace.read_json(path)["keyframes"] for n, v in k.get("markers") or []]
    want = beats.markers(b)

    def by_name(ms):
        return sorted(ms, key=lambda m: (m[1], m[2], m[0]))
    if len(got) == len(want) and all(g[1:] == w[1:] and abs(g[0] - w[0]) < 1e-4
                                     for g, w in zip(by_name(got), by_name(want))):
        return []

    def label(ms):
        return Counter(f"{m[1]}{'=' + m[2] if m[2] else ''} @{m[0]:.2f}" for m in ms)
    only_module, only_clip = label(want) - label(got), label(got) - label(want)
    return [f"the Stage clip's markers differ from the module's (only in the module: {', '.join(only_module) or '-'}; "
            f"only in the clip: {', '.join(only_clip) or '-'}): {AGAIN}"]


def check_files(root, scene):
    """Every clip is there, parses, lasts the scene and has keys at frame 0 and at its last frame N (Roblox treats a
    one-key clip as not loaded: Plan 1). Marker-only keyframes don't count: the Stage clip's camera channel needs its
    own keys at 0 and N, and every role clip needs pose keys there."""
    out, problems = Path(root) / "export", []
    stage = scene["clips"]["Stage"]
    for name in clip_names(scene):
        js, xml = out / f"{name}.json", out / f"{name}.rbxmx"
        if not js.exists() or not xml.exists():
            problems.append(f"clip {name}: export/{name}.json or .rbxmx is missing (run filmset.export again)")
            continue
        try:
            ET.parse(xml)
        except ET.ParseError as e:
            problems.append(f"clip {name}: {xml.name} is not valid XML ({e})")
        data = workspace.read_json(js)
        n, end = data["length"], data["length"] / data["fps"]
        what = f"{CAMERA} keys" if name == stage else "pose keys"
        times = [k["time"] for k in data["keyframes"]
                 if k.get("poses") and (name != stage or CAMERA in k["poses"])]
        if len(times) < 2:
            problems.append(f"clip {name} has fewer than 2 keyframes with {what} (Roblox would treat it as not loaded)")
        else:
            missing = [str(f) for f, t in ((0, 0.0), (n, end)) if not any(abs(x - t) < 1e-4 for x in times)]
            if missing:
                problems.append(f"clip {name} needs {what} at frame 0 and at its last frame {n} (marker-only keys "
                                f"don't count); none at frame {' or '.join(missing)}")
            if max(times) > end + 1e-4:
                problems.append(f"clip {name} has {what} after its last frame ({max(times)} s; it ends at {end} s)")
        if abs(end - scene["length"]) > 1e-3:
            problems.append(f"clip {name} lasts {end} s; the scene is {scene['length']} s")
    return problems


def write(root, ids=None):
    root = Path(root)
    b = beats.load(root)
    scene = workspace.read_json(root / "export" / "scene.json")
    if scene.get("id") != b["id"]:
        raise SystemExit(f"export/scene.json is for {scene.get('id')}, not {b['id']}: run filmset.export again")
    ids = current_ids(root) if ids is None else ids
    data = module_data(b, scene, ids, framing_of(root))
    problems = stale(root, scene)
    if scene.get("ok") is False:
        count = sum(len(v) for v in (scene.get("issues") or {}).values())
        problems.append(f"the export STOPPED on {count} clip issues (export/scene.json \"issues\"): fix them in "
                        f"anim/*.py, then {AGAIN}")
    problems += schema.validate(data) + check_files(root, scene) + marker_problems(root, scene, b)
    if problems:
        raise SystemExit("data module not written:\n  - " + "\n  - ".join(problems))
    path = root / "export" / f"{b['id']}.luau"
    path.write_text(f"-- {b['id']}: generated by /make-cutscene (kit/scenefile.py). Method by fwjelaa (FWJ STUDIOS).\n"
                    "return " + clip.luau_value(data) + "\n", encoding="utf-8", newline="\n")
    mp = root / "map.json"
    workspace.write_json(root / "export" / "manifest.json", {
        "name": b["id"], "clips": clip_names(scene), "data": path.name, "trigger": b.get("trigger"),
        "anchor": workspace.read_json(mp)["anchor"] if mp.exists() else None})
    return path
