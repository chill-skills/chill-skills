"""The test cutscene Fixture_Walkin: a 6 s walk-in story scene. Method by fwjelaa (FWJ STUDIOS).

    py kit/run.py fixture     writes kit/fixtures/Fixture_Walkin/ (clip .json + .rbxmx, data module, manifest)

Anchor = the zone's floor centre. The player stands on the anchor facing -Z; the guard (npc1) stands 8 studs ahead,
facing the player, and waves. Camera: a wide push-in on the guard, a hard cut at 2.5 s to over the guard's shoulder.
"""
import json
from pathlib import Path

import camtrack
import clip
import paths

NAME = "Fixture_Walkin"
LENGTH = 6.0
CUT = 2.5
FRAME = 1 / 60
MARKERS = [
    (0.0, "Letterbox", "in"), (0.6, "Line", "1"), (CUT, "Cut", ""), (2.6, "Shake", "0.35"),
    (3.2, "Line", "2"), (5.4, "Letterbox", "out"), (LENGTH, "End", ""),
]

R15_PARENTS = {
    "LowerTorso": "HumanoidRootPart", "UpperTorso": "LowerTorso", "Head": "UpperTorso",
    "RightUpperArm": "UpperTorso", "RightLowerArm": "RightUpperArm", "RightHand": "RightLowerArm",
    "LeftUpperArm": "UpperTorso", "LeftLowerArm": "LeftUpperArm", "LeftHand": "LeftLowerArm",
    "RightUpperLeg": "LowerTorso", "RightLowerLeg": "RightUpperLeg", "RightFoot": "RightLowerLeg",
    "LeftUpperLeg": "LowerTorso", "LeftLowerLeg": "LeftUpperLeg", "LeftFoot": "LeftLowerLeg",
}
R6_PARENTS = {"Torso": "HumanoidRootPart", "Head": "Torso", "Right Arm": "Torso", "Left Arm": "Torso",
              "Right Leg": "Torso", "Left Leg": "Torso"}
# R6 joint C0 rotations (make-anim AnimKit.luau R6_ROOT / R6_R / R6_L); a pose-language rotation q becomes r^T q r
_ROOT = [[-1, 0, 0], [0, 0, 1], [0, 1, 0]]
_RIGHT = [[0, 0, 1], [0, 1, 0], [-1, 0, 0]]
_LEFT = [[0, 0, -1], [0, 1, 0], [1, 0, 0]]
R6_C0 = {"Torso": _ROOT, "Head": _ROOT, "Right Arm": _RIGHT, "Right Leg": _RIGHT, "Left Arm": _LEFT, "Left Leg": _LEFT}


def pose(rig, part, rx=0.0, ry=0.0, rz=0.0, style="CubicV2", direction="InOut"):
    """make-anim pose language: degrees in the parent's axes (+x forward/up, +y turn left, +z right limb out)."""
    q = clip.rot_xyz(rx, ry, rz)
    if rig == "R6":
        q = clip.conj(R6_C0[part], q)
    return {"cf": clip.cf_from(q), "style": style, "dir": direction}


def _key(t, poses=None, markers=None):
    return {"time": t, "poses": poses or {}, "markers": markers or []}


def stage_clip(markers=None):
    """markers: [[t, name, value]] (default: Fixture_Walkin's MARKERS; Fixture_Scene passes its beats.markers)."""
    def cam(t, eye, target, style="CubicV2", direction="InOut"):
        return _key(t, {"CutsceneCamera": {"cf": clip.look_at(eye, target), "style": style, "dir": direction}})

    keys = [
        cam(0.0, (10, 6, 6), (0, 4, -4)),                                  # wide on both
        cam(CUT - FRAME, (3, 5, -2), (0, 4.5, -8), "Constant", "Out"),     # pushed in on the guard, held...
        cam(CUT, (-2, 5.5, -11), (0, 4.5, 0), "Linear", "In"),             # ...hard cut: over the guard's shoulder
        cam(LENGTH, (-1.5, 5.5, -10.5), (0, 4.5, 0), "Linear", "In"),      # slow drift
    ]
    keys += [_key(t, markers=[[n, v]]) for t, n, v in (MARKERS if markers is None else markers)]
    return clip.clip_data(f"{NAME}_Stage", "StageRoot", {"CutsceneCamera": "StageRoot"}, keys, LENGTH)


def npc_clip(rig):
    arm = "RightUpperArm" if rig == "R15" else "Right Arm"
    keys = [
        _key(0.0, {arm: pose(rig, arm)}),
        _key(0.8, {arm: pose(rig, arm, rz=150)}),
        _key(2.4, {arm: pose(rig, arm, rz=150)}),
        _key(3.0, {arm: pose(rig, arm)}),
        _key(LENGTH, {arm: pose(rig, arm, style="Linear", direction="In")}),
    ]
    if rig == "R15":  # the forearm waves; R6 has no elbow
        for t, z in [(0.8, 0), (1.1, 25), (1.4, -15), (1.7, 25), (2.0, 0), (LENGTH, 0)]:
            keys.append(_key(t, {"RightLowerArm": pose(rig, "RightLowerArm", rz=z)}))
    parents = R15_PARENTS if rig == "R15" else R6_PARENTS
    return clip.clip_data(f"{NAME}_npc1_{rig}", "HumanoidRootPart", parents, keys, LENGTH)


def player_clip(rig):
    keys = [
        _key(0.0, {"Head": pose(rig, "Head")}),
        _key(1.0, {"Head": pose(rig, "Head", rx=5)}),
        _key(4.5, {"Head": pose(rig, "Head")}),
        _key(LENGTH, {"Head": pose(rig, "Head", style="Linear", direction="In")}),
    ]
    parents = R15_PARENTS if rig == "R15" else R6_PARENTS
    return clip.clip_data(f"{NAME}_player_{rig}", "HumanoidRootPart", parents, keys, LENGTH)


def clips():
    return [stage_clip(), npc_clip("R15"), npc_clip("R6"), player_clip("R15"), player_clip("R6")]


def module_data(ids=None):
    def ref(name):
        return f"rbxassetid://{ids[name]}" if ids and name in ids else name

    return {
        "Name": NAME, "Kind": "story", "Length": LENGTH,
        "Anims": {
            "Stage": ref(f"{NAME}_Stage"),
            "R15": {"npc1": ref(f"{NAME}_npc1_R15"), "player": ref(f"{NAME}_player_R15")},
            "R6": {"npc1": ref(f"{NAME}_npc1_R6"), "player": ref(f"{NAME}_player_R6")},
        },
        "Places": {"player": [0, 0, 0, 0, 0, 0], "npc1": [0, 0, -8, 0, 180, 0]},
        "Fov": [[0.0, 50], [CUT, 40], [CUT, 55], [LENGTH, 52]],
        "Markers": [[t, n, v] for t, n, v in MARKERS],
        "Lines": {"1": {"speaker": "Guard", "text": "Stop right there."},
                  "2": {"speaker": "Guard", "text": "Nobody passes this gate."}},
        "Config": {"Skip": 2, "Replay": "saved", "Letterbox": 0.11, "Style": "anime"},
    }


def module_source(ids=None):
    return "-- Generated by kit/fixture.py. Method by fwjelaa (FWJ STUDIOS).\nreturn " + clip.luau_value(module_data(ids)) + "\n"


def build(out_dir=None, ids=None):
    out = Path(out_dir) if out_dir else paths.FIXTURES / NAME
    out.mkdir(parents=True, exist_ok=True)
    all_clips = clips()
    for d in all_clips:
        (out / f"{d['name']}.json").write_text(json.dumps(d, separators=(",", ":")), encoding="utf-8", newline="\n")
        clip.write_rbxmx(d, out / f"{d['name']}.rbxmx")
    (out / f"{NAME}.luau").write_text(module_source(ids), encoding="utf-8", newline="\n")
    manifest = {"name": NAME, "clips": [d["name"] for d in all_clips], "data": f"{NAME}.luau",
                "zone": {"position": [0, 4, -40], "size": [16, 8, 16]}}
    (out / "manifest.json").write_text(json.dumps(manifest, indent=1), encoding="utf-8", newline="\n")
    return out


SCENE = "Fixture_Scene"
HEAD = 4.586  # a stock R15 head's centre above the floor: root 3.0 + 1.586 (make-anim rigs.R15: Root, Waist, Neck)


def _alpha(style, direction, t):
    """Copy of make-anim export.roblox_alpha (how far Roblox is between two poses, measured in Studio) for the styles
    this file's clips use, because make-anim's export imports bpy and can't be imported here."""
    if style == "Linear":
        return t
    if style == "Constant":  # In snaps to the next pose at once, Out holds, InOut switches halfway
        return {"In": float(t > 0), "Out": float(t >= 1)}.get(direction, float(t >= 0.5))
    if style == "CubicV2":
        if direction == "In":
            return t ** 3
        if direction == "Out":
            return 1 - (1 - t) ** 3
        return 4 * t ** 3 if t < 0.5 else 1 - (-2 * t + 2) ** 3 / 2
    raise ValueError(f"no Roblox model for {style} {direction}")


def fov_at(track, t):
    """CutsceneKit.Fov.sample in Python: linear between entries; two entries at one time are a cut."""
    if t <= track[0][0]:
        return track[0][1]
    if t >= track[-1][0]:
        return track[-1][1]
    i = max(j for j, e in enumerate(track[:-1]) if e[0] <= t)  # the last entry at or before t
    a, b = track[i], track[i + 1]
    return b[1] if b[0] <= a[0] else a[1] + (b[1] - a[1]) * (t - a[0]) / (b[0] - a[0])


def framing(stage, fov, cuts, places, fps=60):
    """export/framing.json in filmset.export's format ({fps, frames, camera, fov, cuts, heads}) without Blender: the
    Stage clip's camera played the Roblox way and the data module's Fov track, one value per frame 0..N, and each
    role's head standing still on its place (a stock R15 head). Preflight W2: py kit/run.py expect works on it."""
    keys = [(k["time"], k["poses"]["CutsceneCamera"]) for k in stage["keyframes"] if "CutsceneCamera" in k["poses"]]
    frames = stage["length"]
    cams, fovs = [], []
    for f in range(frames + 1):
        t = f / fps
        i = max(j for j, (kt, _) in enumerate(keys) if kt <= t + 1e-6)
        a, alpha = keys[i][1], 0.0
        if i < len(keys) - 1:
            alpha = _alpha(a["style"], a["dir"], (t - keys[i][0]) / (keys[i + 1][0] - keys[i][0]))
        if alpha <= 0:
            cams.append(list(a["cf"]))
        elif alpha >= 1:
            cams.append(list(keys[i + 1][1]["cf"]))
        else:
            cams.append(camtrack.lerp_cf(a["cf"], keys[i + 1][1]["cf"], alpha))
        fovs.append(round(fov_at(fov, t), 3))
    heads = {role: [[p[0], round(p[1] + HEAD, 3), p[2]]] * (frames + 1) for role, p in places.items()}
    return {"fps": fps, "frames": frames, "camera": cams, "fov": fovs, "cuts": list(cuts), "heads": heads}


# spec 14: Fixture_Scene in costume (`testscene --costume`). Spec 14.3: a character wears real catalog items by id, so
# these are marketplace items (found with `costume search`, thumbnails looked at, nothing bought). Studio checks each id
# with the catalog when it builds them; the kit's Python tests never go online. A classic Shirt and Pants each, so the
# R6 cast is dressed too; film colours for the Blender film set's stand-ins.
def _item(slot, asset_id, kind, name, creator, film):
    return {"slot": slot, "id": asset_id, "type": kind, "name": name, "creator": creator,
            "why": f"test fixture: {name.lower()}", "film": film}


COSTUMES = {
    "player": {"version": 1, "role": "player", "character": "Fixture Hero", "source": "make-cutscene test fixture",
               "kind": "humanoid", "body": {"head": "#f1c9a5", "torso": "#2f5d8a", "left_arm": "#f1c9a5",
                                            "right_arm": "#f1c9a5", "left_leg": "#2b2b30", "right_leg": "#2b2b30"},
               "catalog": [_item("hat", 13724930536, "Hat", "Red Cap", "dvdko", "#c0392b"),
                           _item("back", 12786033042, "BackAccessory", "Red Cape", "Eternos Digital", "#b0242a"),
                           _item("shirt", 2023246318, "Shirt", "blue shirt", "uglyskies", "#1f3f9a"),
                           _item("pants", 3890514537, "Pants", "Black Pants", "Aria TM", "#22232a")]},
    "npc1": {"version": 1, "role": "npc1", "character": "Fixture Guard", "source": "make-cutscene test fixture",
             "kind": "humanoid", "body": {"head": "#cc8e69", "torso": "#5b5f66", "left_arm": "#5b5f66",
                                          "right_arm": "#5b5f66", "left_leg": "#2b2b30", "right_leg": "#2b2b30"},
             "catalog": [_item("hat", 115414507300321, "Hat", "Knight Helmet", "Hallowed Ground", "#6d7077"),
                         _item("back", 100898685446059, "BackAccessory", "Shield", "antepenultimate", "#8a8d92"),
                         _item("shirt", 1030776069, "Shirt", "Armor", "PowerGamingDK", "#a4a7ab"),
                         _item("pants", 6349116204, "Pants", "Black pants", "MXIII", "#1d1e22")]},
}


def write_scene(env=None, hide=None, costume=False):
    """A working folder for Studio tests that need a whole cutscene without Blender: Fixture_Walkin's clips exported
    as a two-shot scene (cutscenes/Fixture_Scene), anchored at (0, 0, -80) so its zone doesn't overlap the fixture's.
    The Stage clip carries the beat sheet's markers, like the data module (preflight M13), and export/framing.json is
    sampled from it (preflight W2). costume=True (spec 14) dresses the player and the guard in COSTUMES (cast/*.json,
    "model": "costume") and adds the guard's R6 clip; without it those files are removed again."""
    import beats
    import scenefile
    import workspace
    root = workspace.create(SCENE, env=env)
    shots = [beats.shot("ESTABLISH", CUT, "npc1", "wide push-in on the guard", "the guard waves", [[0.6, "Line", "1"]],
                        cut=False),
             beats.shot("OTS", LENGTH - CUT, "player", "over the guard's shoulder onto the player", "the guard warns",
                        [[0.1, "Shake", "0.35"], [0.7, "Line", "2"]])]
    b = beats.draft(SCENE, {"type": "words", "text": "Fixture_Walkin as a scene"}, shots)
    b["trigger"] = {"type": "zone", "size": [16, 8, 16]}
    b["dialogue"] = "anime"
    b["cast"]["npc1"] = {"name": "Guard", "model": "default", "rig": "R15", "place": [0, 0, -8, 0, 180, 0]}
    if hide:
        b["cast"]["npc1"]["hide"] = hide
    if costume:
        b["cast"]["player"]["model"] = "costume"
        b["cast"]["npc1"]["model"] = "costume"
    b["lines"] = {"1": {"speaker": "Guard", "text": "Stop right there."},
                  "2": {"speaker": "Guard", "text": "Nobody passes this gate."}}
    b["config"]["Replay"] = "always"
    b["approved"] = True
    beats.save(b, root)
    for role, spec in COSTUMES.items():
        if costume:
            workspace.write_json(root / "cast" / f"{role}.json", spec)
        else:
            (root / "cast" / f"{role}.json").unlink(missing_ok=True)
    out = root / "export"
    clips = {f"{SCENE}_Stage": stage_clip(beats.markers(b)), f"{SCENE}_npc1_R15": npc_clip("R15"),
             f"{SCENE}_player_R15": player_clip("R15"), f"{SCENE}_player_R6": player_clip("R6")}
    if costume:  # the guard is built as R15 and R6 too, so the cast follows the player's rig
        clips[f"{SCENE}_npc1_R6"] = npc_clip("R6")
    for name, d in clips.items():
        d = dict(d, name=name)
        (out / f"{name}.json").write_text(json.dumps(d, separators=(",", ":")), encoding="utf-8", newline="\n")
        clip.write_rbxmx(d, out / f"{name}.rbxmx")
    fov, cuts = [[0.0, 50], [CUT, 40], [CUT, 55], [LENGTH, 52]], [round(CUT * 60)]
    workspace.write_json(out / "scene.json", {
        "id": SCENE, "length": LENGTH, "fps": 60, "frames": round(LENGTH * 60),
        "clips": {"Stage": f"{SCENE}_Stage", "R15": {"npc1": f"{SCENE}_npc1_R15", "player": f"{SCENE}_player_R15"},
                  "R6": dict({"player": f"{SCENE}_player_R6"}, **({"npc1": f"{SCENE}_npc1_R6"} if costume else {}))},
        "fov": fov, "cuts": cuts, "issues": {}, "r6": {}, "ok": True, "sources": scenefile.sources(root)})
    places = {role: (c or {}).get("place") or [0] * 6 for role, c in b["cast"].items()}
    workspace.write_json(out / "framing.json", framing(clips[f"{SCENE}_Stage"], fov, cuts, places))
    workspace.write_json(root / "map.json", {"v": 1, "name": SCENE, "anchor": [0, 0, -80, 1, 0, 0, 0, 1, 0, 0, 0, 1],
                                             "radius": 150, "boxes": [], "terrain": {"step": 6, "n": 0, "cells": []},
                                             "skipped": 0, "found": 0})
    return root
