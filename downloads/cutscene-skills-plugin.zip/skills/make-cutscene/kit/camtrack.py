"""Camera maths for the Stage clip (spec 5.5): the Blender camera -> its CFrame relative to the scene anchor, lens ->
Roblox's vertical FieldOfView, key reduction with hard cuts as constant keys, the FOV track, and CamPlan, the camera
Claude writes in anim/camera.py. No bpy here; kit/filmset.py applies it inside Blender. Method by fwjelaa (FWJ STUDIOS).

Roblox: X right, Y up, Z back; a camera looks down its own -Z with +Y up. Blender: Z up, the scene's forward is -Y; a
Blender camera also looks down its own -Z with +Y up, so only the world basis changes: R_roblox = B2R * R_blender,
p_roblox = B2R * p_blender (B2R is its own inverse; the same matrix as make-anim's rigs.B2R).
The film set's camera has sensor fit VERTICAL and a 24 mm sensor, so FieldOfView = 2 atan(24 / (2 lens)).
"""
import math

import clip

FPS = 60
SENSOR = 24.0
B2R = [[-1.0, 0.0, 0.0], [0.0, 0.0, 1.0], [0.0, 1.0, 0.0]]
TOL_DEG = 0.35  # key reduction: how far Roblox's in-between may stray from Blender's camera
TOL_STUDS = 0.05
MAX_STEP_DEG = 30.0  # make-anim measured: Roblox's in-betweens drift on bigger steps, so they are split
FOV_TOL = 0.25
EASES = ("linear", "constant", "cubic_in", "cubic_out", "cubic_inout", "elastic_out", "bounce_out", "sine_inout",
         "quad_in", "quad_out", "quart_out", "quint_out", "expo_in", "expo_out", "back_out", "bezier")


def last_frame(length, fps=FPS):
    """The scene's last frame. A scene of L seconds has frames 0..N, N = round(L * fps): frame N (t = L) is a real frame
    (the End marker and every clip's last key sit on it), so the film set runs frames 0..N and the Stage clip is N / fps
    long, never a frame more."""
    return round(length * fps)


def vfov(lens, sensor=SENSOR):
    return math.degrees(2 * math.atan(sensor / (2 * lens)))


def lens_for(fov, sensor=SENSOR):
    return sensor / (2 * math.tan(math.radians(fov) / 2))


_rot = clip.rot3
_apply = clip.apply3


def blender_to_cframe(m):
    r = [[m[i][j] for j in range(3)] for i in range(3)]
    return clip.cf_from(clip.matmul(B2R, r), _apply(B2R, [m[0][3], m[1][3], m[2][3]]))


def cframe_to_blender(cf):
    r = clip.matmul(B2R, _rot(cf))
    t = _apply(B2R, cf[:3])
    return [r[0] + [t[0]], r[1] + [t[1]], r[2] + [t[2]], [0.0, 0.0, 0.0, 1.0]]


def look_cf(eye, target, roll=0.0):
    """CFrame.lookAt(eye, target), then roll degrees about the view axis (+ leans the camera's top to the left)."""
    if math.hypot(eye[0] - target[0], eye[2] - target[2]) < 1e-4:
        raise ValueError("the camera looks straight up or down: move the eye or the target a little sideways")
    cf = clip.look_at(eye, target)
    if roll:
        cf = clip.cf_from(clip.matmul(_rot(cf), clip.rot_xyz(0, 0, roll)), cf[:3])
    return cf


def _quat(m):
    t = m[0][0] + m[1][1] + m[2][2]
    if t > 0:
        s = math.sqrt(t + 1) * 2
        q = (s / 4, (m[2][1] - m[1][2]) / s, (m[0][2] - m[2][0]) / s, (m[1][0] - m[0][1]) / s)
    elif m[0][0] > m[1][1] and m[0][0] > m[2][2]:
        s = math.sqrt(1 + m[0][0] - m[1][1] - m[2][2]) * 2
        q = ((m[2][1] - m[1][2]) / s, s / 4, (m[0][1] + m[1][0]) / s, (m[0][2] + m[2][0]) / s)
    elif m[1][1] > m[2][2]:
        s = math.sqrt(1 + m[1][1] - m[0][0] - m[2][2]) * 2
        q = ((m[0][2] - m[2][0]) / s, (m[0][1] + m[1][0]) / s, s / 4, (m[1][2] + m[2][1]) / s)
    else:
        s = math.sqrt(1 + m[2][2] - m[0][0] - m[1][1]) * 2
        q = ((m[1][0] - m[0][1]) / s, (m[0][2] + m[2][0]) / s, (m[1][2] + m[2][1]) / s, s / 4)
    n = math.sqrt(sum(c * c for c in q))
    return tuple(c / n for c in q)


def _mat(q):
    w, x, y, z = q
    return [[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]]


def _slerp(qa, qb, t):
    d = sum(a * b for a, b in zip(qa, qb))
    if d < 0:
        qb, d = tuple(-c for c in qb), -d
    if d > 0.9995:
        q = tuple(a + (b - a) * t for a, b in zip(qa, qb))
    else:
        th = math.acos(d)
        sa, sb = math.sin((1 - t) * th) / math.sin(th), math.sin(t * th) / math.sin(th)
        q = tuple(a * sa + b * sb for a, b in zip(qa, qb))
    n = math.sqrt(sum(c * c for c in q))
    return tuple(c / n for c in q)


def _qangle(qa, qb):
    return math.degrees(2 * math.acos(min(1.0, abs(sum(a * b for a, b in zip(qa, qb))))))


def angle(a, b):
    return _qangle(_quat(_rot(a)), _quat(_rot(b)))


def lerp_cf(a, b, alpha):
    pos = [x + (y - x) * alpha for x, y in zip(a[:3], b[:3])]
    return clip.cf_from(_mat(_slerp(_quat(_rot(a)), _quat(_rot(b)), alpha)), pos)


def _segments(n, cuts):
    """(first, last, a cut follows) per shot over frames 0..n; a cut at c starts a new shot on frame c."""
    edges = sorted({0, n + 1} | {c for c in cuts if 0 < c <= n})
    return [(a, b - 1, b <= n) for a, b in zip(edges, edges[1:])]


def reduce(frames, cuts=(), tol_deg=TOL_DEG, tol_studs=TOL_STUDS):
    """One CFrame per frame -> Linear keys wherever Roblox's in-between stays within tolerance of every frame. The last
    frame of a shot that ends in a cut is (Constant, Out): Roblox holds it and jumps exactly on the cut frame."""
    quats = [_quat(_rot(cf)) for cf in frames]

    def err(i, j, f):
        a = (f - i) / (j - i)
        pos = [x + (y - x) * a for x, y in zip(frames[i][:3], frames[j][:3])]
        return max(_qangle(_slerp(quats[i], quats[j], a), quats[f]) / tol_deg,
                   math.dist(pos, frames[f][:3]) / tol_studs)

    keys = []
    for a, b, cut_after in _segments(len(frames) - 1, cuts):
        kept, stack = {a, b}, [(a, b)]
        while stack:
            i, j = stack.pop()
            if j - i < 2:
                continue
            worst, wf = max((err(i, j, f), f) for f in range(i + 1, j))
            if worst <= 1.0 and _qangle(quats[i], quats[j]) > MAX_STEP_DEG:
                worst, wf = 2.0, (i + j) // 2
            if worst > 1.0:
                kept.add(wf)
                stack += [(i, wf), (wf, j)]
        for f in sorted(kept):
            hold = cut_after and f == b
            keys.append((f, frames[f], "Constant" if hold else "Linear", "Out" if hold else "In"))
    return keys


def fov_track(fovs, cuts=(), fps=FPS, tol=FOV_TOL):
    """One vertical FOV per frame -> [[time, fov]] for the data module. A cut gives two entries at the same time
    (CutsceneKit.Fov): the old shot's value held to the cut, then the new shot's."""
    vals = [min(120.0, max(1.0, float(v))) for v in fovs]
    out = []
    for a, b, cut_after in _segments(len(vals) - 1, cuts):
        kept, stack = {a, b}, [(a, b)]
        while stack:
            i, j = stack.pop()
            if j - i < 2:
                continue
            worst, wf = max((abs(vals[i] + (vals[j] - vals[i]) * (f - i) / (j - i) - vals[f]), f) for f in range(i + 1, j))
            if worst > tol:
                kept.add(wf)
                stack += [(i, wf), (wf, j)]
        out += [[round(f / fps, 5), round(vals[f], 2)] for f in sorted(kept)]
        if cut_after:
            out.append([round((b + 1) / fps, 5), round(vals[b], 2)])
    return out


def stage_clip(name, frames, cuts, markers, fps=FPS):
    """frames: one CFrame per frame 0..N (N + 1 of them), so the clip is N / fps long. A marker that rounds to frame N
    or later (an End from a length off the frame grid) sits exactly on frame N, as beats.markers puts it, so nothing
    lands after the clip's end and both marker lists agree."""
    n = len(frames) - 1
    end = n / fps
    keys = [{"time": f / fps, "poses": {"CutsceneCamera": {"cf": cf, "style": st, "dir": d}}}
            for f, cf, st, d in reduce(frames, cuts)]
    keys += [{"time": end if round(m[0] * fps) >= n else m[0], "markers": [[m[1], m[2] if len(m) > 2 else ""]]}
             for m in markers]
    return clip.clip_data(name, "StageRoot", {"CutsceneCamera": "StageRoot"}, keys, end, fps=fps)


class CamPlan:
    """The camera Claude writes in anim/camera.py:   def build(cam): ...   (anchor space, studs, seconds)

        s = cam.shot(2)          # {"n", "type", "subject", "start", "end", "last", ...} from the beat sheet
        cam.key(s["start"], eye=(3, 5, -2), look=(0, 4.5, -8), fov=40, ease="cubic_inout")
        cam.key(s["last"], eye=(2, 5, -4), look=(0, 4.5, -8), fov=36)    # last = the shot's last frame

    Every shot that starts with a cut needs a key exactly at its start. The last key before a cut holds until the cut
    (resolved() makes it constant), so the camera jumps on the cut frame and never drifts toward the next shot.
    A cut at frame 0 is just the first shot. Keys run from 0 to the scene's length: t = length is the last frame, and
    resolved() holds the last key onto it when no key is there.
    fov is Roblox's vertical field of view in degrees; roll leans the camera's top to the left; ease shapes the move
    from this key to the next (make-anim's ease names).
    """

    def __init__(self, length, cuts=(), shots=(), fps=FPS):
        self.length, self.fps = length, fps
        self.frames = last_frame(length, fps)
        self.cuts = sorted({c for c in cuts if c > 0})
        self._shots = [dict(s) for s in shots]
        self.keys = []

    def shot(self, n):
        for s in self._shots:
            if s["n"] == n:
                return dict(s)
        raise ValueError(f"no shot {n}: the beat sheet has {len(self._shots)}")

    def key(self, t, eye, look, fov=50.0, roll=0.0, ease="cubic_inout"):
        if ease not in EASES:
            raise ValueError(f"unknown ease {ease!r}; use one of {', '.join(EASES)}")
        if not 1 <= fov <= 120:
            raise ValueError(f"fov {fov} is outside 1-120 degrees (Roblox's vertical field of view)")
        f = round(t * self.fps)
        if not 0 <= f <= self.frames:
            raise ValueError(f"a camera key at {t} s is outside the scene (0-{self.length} s)")
        self.keys = [k for k in self.keys if k["frame"] != f]
        self.keys.append({"frame": f, "cf": look_cf(eye, look, roll), "fov": float(fov), "ease": ease})
        return self

    def resolved(self):
        keys = sorted((dict(k) for k in self.keys), key=lambda k: k["frame"])
        if not keys or keys[0]["frame"] != 0:
            raise ValueError("the camera needs a key at 0 s")
        frames = {k["frame"] for k in keys}
        for c in self.cuts:
            if c > self.frames:
                raise ValueError(f"the cut at {c / self.fps:.3f} s is past the end of the scene ({self.length} s): "
                                 "fix the beat sheet's shot lengths")
            if c not in frames:
                raise ValueError(f"the cut at {c / self.fps:.3f} s needs a camera key exactly there (the new shot's "
                                 "first frame)")
            before = [k for k in keys if k["frame"] < c]
            before[-1]["ease"] = "constant"
        if keys[-1]["frame"] < self.frames:
            keys.append(dict(keys[-1], frame=self.frames))  # held onto the last frame, so the camera ends there too
        return keys
