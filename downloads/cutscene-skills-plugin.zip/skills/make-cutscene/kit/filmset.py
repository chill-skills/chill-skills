"""The Blender film set for one cutscene (spec 5.2-5.5, 5.7, 5.8). Runs inside Blender through the Blender MCP:

    import sys; sys.path.insert(0, r"<absolute path to skills/make-cutscene/kit>")
    import importlib, filmset; importlib.reload(filmset)
    print(filmset.build(r"<cutscene folder>"))     # stand-ins, cast, camera, markers -> scene CS_<id>, <id>.blend
    print(filmset.export(r"<cutscene folder>"))    # rebuilds, then clips, the Stage clip, framing.json, scene.json

The files are the source and Blender is the stage: build() makes everything again from beats.json, map.json, rigs/
and anim/*.py, so changes made by hand in Blender are lost on the next build. The cast reuses make-anim's kit
unchanged (rigs, animkit, export, checks, and anims/_r15.py's IK helpers). Only what this kit made is removed:
everything a build makes (objects, meshes, armatures, cameras, actions, materials, collections) gets the custom
property cs_set = <id>, the scene's markers are listed on the scene, and clear(<id>) takes exactly those, never
anything by name (ids can be prefixes of each other, like Gate and Gate_Intro).

anim/<role>.py (and anim/<role>_R6.py) runs with these names already defined:
  ak      make-anim's animkit                 NAME    the clip name, e.g. GateGuard_npc1_R15
  RIG     the rig to give ak.Anim             ROLE    player, target, npc1 ...
  FRAMES  the scene's length in frames        FPS     60
  SHOTS   beats.shots(beats)                  F       seconds -> frame
  PLACE   the role's place [x, y, z, rx, ry, rz]       BEATS   the beat sheet
  DERIVED (anim/<role>_R6.py only) {frame: (R6 pose, ease)} derived from the R15 master
and defines build() returning ak.Anim(NAME, rig=RIG, length=FRAMES, fps=FPS, priority="Action4") with its keys (not
built). anim/camera.py defines build(cam) and calls cam.key(...) (camtrack.CamPlan; SHOTS, FPS, BEATS defined too).
Frames run 0..FRAMES: frame FRAMES (t = the scene's length) is the last frame; every role clip needs keys at 0 and at
FRAMES (build() checks), and the camera is held onto FRAMES.
Method by fwjelaa (FWJ STUDIOS).
"""
import importlib
import json
import math
import sys
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

import bmesh
import bpy
from mathutils import Matrix, Vector

KIT = Path(__file__).resolve().parent
MAKE_ANIM = (KIT.parent.parent / "make-anim").resolve()
for _p in (KIT, MAKE_ANIM / "kit", MAKE_ANIM / "anims"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from rigs import B2R  # noqa: E402  make-anim's: Roblox <-> Blender axes, its own inverse (one copy, preflight M9)

FPS = 60
TAG = "cs_set"
OWN_SCENE = True  # spike S10: the film set lives in its own scene CS_<id>
CAPTURED_OK = True  # spike S10: captured rigs may be registered as make-anim rigs (clip matched Studio to 0.000 studs)
NEAR_STOCK = (0.14, 0.236)  # spike S10: (part-size ratio, joint offset in studs) under which the stock rig is used
DEFAULT_STAND = 3.0  # make-anim's rigs stand their root 3 studs up; a captured rig says where Roblox stands it
FLOOR_TOL = 0.02  # studs: the stock rig stands in only if its soles reach the floor under the captured stand this well
KINDS = ("objects", "meshes", "armatures", "cameras", "actions", "materials", "collections")  # what a build makes
MARKERS = "cs_markers"  # scene property: the [name, frame] of the timeline markers the kit put there
CS_RIG = "cs_rig"  # armature property: the registered rig's name (rbx_rig stays R15 / R6 for make-anim)
# Both kits' folders are on sys.path and make-anim's comes first, so this kit never imports a name make-anim also has
# (its run.py: preflight M17). _kit() checks every module came from the folder it should.
THEIRS = ("rigs", "animkit", "checks", "export")  # make-anim; reloaded in this order (dependencies first)
MINE = ("paths", "vfxlib", "cues", "schema", "clip", "workspace", "contact", "beats", "camtrack", "mapcap", "r6", "rigcap",
        "costume", "scenefile")


def _kit(reload=True):
    mods = {n: importlib.import_module(n) for n in THEIRS + MINE}
    for n, m in mods.items():
        home = KIT if n in MINE else MAKE_ANIM / "kit"
        if Path(m.__file__).resolve().parent != home:
            raise ImportError(f"the module {n} came from {m.__file__}, not {home}: another folder on sys.path has a "
                              f"{n}.py (rename one of them)")
    if reload:
        for m in mods.values():
            importlib.reload(m)
        if "_r15" in sys.modules:  # make-anim's IK helpers (anims/_r15.py): bound per anim file, so keep them current
            importlib.reload(sys.modules["_r15"])
    return SimpleNamespace(rigs=mods["rigs"], ak=mods["animkit"], checks=mods["checks"], export=mods["export"],
                           beats=mods["beats"], camtrack=mods["camtrack"], clip=mods["clip"], mapcap=mods["mapcap"],
                           r6=mods["r6"], workspace=mods["workspace"], scenefile=mods["scenefile"],
                           costume=mods["costume"], contact=mods["contact"])


def _bl(p):
    """A point in the anchor's Roblox space -> Blender (the anchor is Blender's origin)."""
    return Vector((-p[0], p[2], p[1]))


def _scene(cid):
    windows = bpy.context.window_manager.windows
    if not OWN_SCENE:
        return windows[0].scene
    scene = bpy.data.scenes.get(f"CS_{cid}") or bpy.data.scenes.new(f"CS_{cid}")
    scene[TAG] = cid
    for w in windows:
        w.scene = scene
    return scene


def _collection(scene, name):
    coll = bpy.data.collections.get(name) or bpy.data.collections.new(name)
    if coll.name not in scene.collection.children:
        scene.collection.children.link(coll)
    return coll


def clear(cid):
    """Remove what the kit made for this cutscene: objects and data tagged cs_set == cid (data only once nothing uses
    it, collections only once empty) and the markers it listed on its scene. Never by name."""
    for o in [o for o in bpy.data.objects if o.get(TAG) == cid]:
        bpy.data.objects.remove(o, do_unlink=True)
    for kind in ("meshes", "armatures", "cameras", "actions", "materials"):  # meshes before the materials they use
        blocks = getattr(bpy.data, kind)
        for d in [d for d in blocks if d.get(TAG) == cid and d.users == 0]:
            blocks.remove(d)
    for c in [c for c in bpy.data.collections if c.get(TAG) == cid and not c.objects and not c.children]:
        bpy.data.collections.remove(c)
    for s in bpy.data.scenes:
        if s.get(TAG) == cid:
            made = json.loads(s.get(MARKERS, "[]"))
            for m in [m for m in s.timeline_markers if [m.name, m.frame] in made]:
                s.timeline_markers.remove(m)
            s[MARKERS] = "[]"


@contextmanager
def tagging(cid):
    """Everything made inside the block gets cs_set = cid, even when the block fails, so clear(cid) takes it next time.
    Task 13's export wraps what it makes (the derived R6 rig) in it too."""
    before = {k: {d.session_uid for d in getattr(bpy.data, k)} for k in KINDS}
    try:
        yield
    finally:
        for k in KINDS:
            for d in getattr(bpy.data, k):
                if d.session_uid not in before[k]:
                    d[TAG] = cid


def kit_names(cid, b):
    """(object names, collection names) build() gives its set; Task 13 finds the rigs and camera by these names."""
    roles = [f"{cid}_{role}_{rigtype_of(role, c)}" for role, c in b["cast"].items()]
    return [f"{cid}_Map", f"{cid}_Camera", f"{cid}_Anchor"] + roles, [f"{cid}_Set"] + roles


def in_the_way(cid, b):
    """Kit names held by something not tagged cid. build() stops on them: Blender would rename the kit's copy, and
    make-anim's Anim.build deletes whatever has its armature's name."""
    objs, colls = kit_names(cid, b)
    held = [(n, bpy.data.objects.get(n)) for n in objs] + [(n, bpy.data.collections.get(n)) for n in colls]
    return [n for n, d in held if d is not None and d.get(TAG) != cid]


def _quant(rgb):
    """Four shades per channel are plenty for stand-ins and keep the material count small."""
    return "".join("05af"[min(3, round(int(ch, 16) / 5))] for ch in rgb.lower())


def _material(rgb):
    name = f"CS_rgb_{rgb}"
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
        lin = tuple((int(ch, 16) / 15) ** 2.2 for ch in rgb)
        mat.diffuse_color = (*lin, 1.0)
        mat.use_nodes = True
        bsdf = next(n for n in mat.node_tree.nodes if n.type == "BSDF_PRINCIPLED")
        bsdf.inputs[0].default_value = (*lin, 1.0)
    return mat


def build_map(K, cid, mapdata, coll):
    mesh = bpy.data.meshes.new(f"{cid}_Map")
    bm = bmesh.new()
    slots = {}
    for b in mapdata.get("boxes", []):
        if not K.mapcap.visible(b):  # play-bound walls: in the game you see the sky through them
            continue
        verts = [bm.verts.new(_bl(c)) for c in K.mapcap.corners(b)]
        idx = slots.setdefault(_quant(b[9]), len(slots))
        for face in K.mapcap.FACES:
            bm.faces.new([verts[i] for i in face]).material_index = idx
    t = mapdata.get("terrain") or {}
    step = t.get("step", 6)
    tv = {(c[0], c[1]): bm.verts.new(_bl((c[0] * step, c[2], c[1] * step))) for c in t.get("cells", [])}
    if tv:
        ground = slots.setdefault("5a5", len(slots))
        for (i, j) in list(tv):
            quad = [(i, j), (i, j + 1), (i + 1, j + 1), (i + 1, j)]
            if all(q in tv for q in quad):
                bm.faces.new([tv[q] for q in quad]).material_index = ground
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(f"{cid}_Map", mesh)
    obj[TAG] = cid
    coll.objects.link(obj)
    for rgb, _ in sorted(slots.items(), key=lambda kv: kv[1]):
        mesh.materials.append(_material(rgb))
    return obj


def place_matrix(K, place, stand):
    """The armature's world matrix: the root (HumanoidRootPart) at place's x, y + stand, z, turned rx, ry, rz."""
    x, y, z, rx, ry, rz = (list(place or []) + [0] * 6)[:6]
    m = B2R @ K.rigs.angles(rx, ry, rz) @ B2R
    m.translation = _bl((x, y + stand, z))
    return m


def rigtype_of(role, c):
    return "R15" if role == "player" else (c or {}).get("rig", "R15")


def near_stock(cap, stock):
    """The stock rig can stand in for the captured one: its soles reach the floor under the captured stand (a stock
    rig's hip_height is its sole depth), and the parts, sizes and joints are within NEAR_STOCK. The default avatar
    (stand 3.192) is not: its legs are 0.19 longer than the block rig's, so it gets its captured proportions."""
    if abs(float(cap["stand"]) - stock["hip_height"]) > FLOOR_TOL:
        return False
    if set(cap["parts"]) != set(stock["parts"]):
        return False
    for p, size in cap["parts"].items():
        if any(abs(a / b - 1) > NEAR_STOCK[0] for a, b in zip(size, stock["parts"][p])):
            return False
    joints = {j[2]: j for j in stock["joints"]}
    for j in cap["joints"]:
        s = joints.get(j[2])
        if s is None:
            return False
        for c, m in ((j[3], s[3]), (j[4], s[4])):
            if math.dist(c[:3], (m[0][3], m[1][3], m[2][3])) > NEAR_STOCK[1]:
                return False
    return True


def register(K, name, cap):
    """A captured rig as a make-anim rig (rigs.RIGS[name]): its own parts and joints, the floor where Roblox stands it
    (hip_height = stand, so ak.ground() and ak.soles() plant the feet on the game's floor), stock colours, feet, body
    and part pairs, and the stock hand grip for props."""
    base = K.rigs.RIGS[cap["rigType"]]
    for prop in K.rigs.PROPS.values():
        prop["attach"].setdefault(name, prop["attach"][cap["rigType"]])
    K.rigs.RIGS[name] = {
        "root": "HumanoidRootPart", "hip_height": float(cap["stand"]),
        "parts": {k: tuple(v) for k, v in cap["parts"].items()},
        "joints": [(j[0], j[1], j[2], K.rigs.cf(*j[3]), K.rigs.cf(*j[4])) for j in cap["joints"]],
        "colors": {k: base["colors"].get(k, (0.6, 0.6, 0.6)) for k in cap["parts"]},
        # a creature (spec 14, kit/costume.py) brings its own feet, core and pairs (an empty core stays empty: the stock
        # body parts aren't in it); a captured humanoid uses the stock ones
        "feet": list(cap["feet"] if "feet" in cap else base["feet"]),
        "body": list(cap["core"] if "core" in cap else base["body"]),
        "pairs": ([tuple(p) for p in cap["pairs"]] if "pairs" in cap else
                  [p for p in base["pairs"] if p[0] in cap["parts"] and p[1] in cap["parts"]]),
    }
    return name


def role_rig(K, folder, cid, role, rigtype):
    """(rig name for ak.Anim, where Roblox stands the root, a note for the report)."""
    path = Path(folder) / "rigs" / f"{role}.json"
    if not path.exists():
        return rigtype, DEFAULT_STAND, " (no captured rig: height assumed)"
    cap = json.loads(path.read_text(encoding="utf-8"))
    if cap["rigType"] != rigtype:
        return rigtype, DEFAULT_STAND, f" (its captured rig is {cap['rigType']}: not used for {rigtype})"
    if not CAPTURED_OK or near_stock(cap, K.rigs.RIGS[rigtype]):
        return rigtype, float(cap["stand"]), ""
    return register(K, f"{cid}_{role}_rig", cap), float(cap["stand"]), " (captured proportions)"


def look_of(folder, role):
    """The captured rig's own colours as {part: (r, g, b)} (0-1 sRGB), so the film set shows the cast as the game
    dresses them (Task 22). None for a default dummy or no capture: those colours say nothing about the character."""
    path = Path(folder) / "rigs" / f"{role}.json"
    if not path.exists():
        return None
    cap = json.loads(path.read_text(encoding="utf-8"))
    if cap.get("source") == "default" or cap.get("creature") or not isinstance(cap.get("colors"), dict):
        return None  # a creature's rig colours come from its costume spec: costume_look paints them, once
    out = {}
    for part, hexrgb in cap["colors"].items():
        h = str(hexrgb).lstrip("#")
        if len(h) == 6:
            out[part] = tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    return out or None


def dress(cid, role, arm, look):
    """Give the cast's part boxes their captured colours. make-anim names its materials Rbx_<part> and shares them
    between rigs, so each role gets its own <id>_<role>_<part> materials (tagged like everything a build makes)."""
    if not look:
        return 0
    n = 0
    for obj in arm.children:
        part = obj.get("rbx_part")
        rgb = look.get(part)
        if rgb is None or obj.type != "MESH" or not obj.data.materials:
            continue
        name = f"{cid}_{role}_{part}"
        mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
        lin = tuple(ch ** 2.2 for ch in rgb)
        mat.diffuse_color = (*lin, 1.0)
        mat.use_nodes = True
        bsdf = next(nd for nd in mat.node_tree.nodes if nd.type == "BSDF_PRINCIPLED")
        bsdf.inputs[0].default_value = (*lin, 1.0)
        obj.data.materials[0] = mat
        n += 1
    return n


def _names(K, b, role, c, rig, name, frames, **extra):
    names = {"ak": K.ak, "ROLE": role, "RIG": rig, "NAME": name, "FRAMES": frames, "FPS": FPS,
             "SHOTS": K.beats.shots(b), "F": lambda s: round(s * FPS), "PLACE": list((c or {}).get("place") or [0] * 6),
             "BEATS": b}
    names.update(extra)
    return names


def _r15_for(rig):
    """make-anim's anims/_r15 module when `rig` (a name in rigs.RIGS) is R15-shaped, else None (R6, a creature, the
    camera). Its IK helpers are bound to that rig while an anim file builds (RS-1)."""
    rigs = sys.modules.get("rigs")  # make-anim's, loaded by _kit(); absent in Blender-free tests
    r = rigs.RIGS.get(rig) if rigs is not None and isinstance(rig, str) and isinstance(getattr(rigs, "RIGS", None),
                                                                                         dict) else None
    if not r or not all(p in r["parts"] for p in ("LowerTorso", "UpperTorso", "RightFoot", "RightHand")):
        return None
    return importlib.import_module("_r15")


def load_anim(path, names):
    ns = {"__name__": "cutscene_anim", "__file__": str(path)}
    ns.update(names)
    # the anim file's `plant`/`reach` work on the rig it keys, not make-anim's stock lengths (RS-1: fists through heads)
    r15 = _r15_for(names.get("RIG")) if "cam" not in names else None
    old = r15.bind(names["RIG"]) if r15 else None
    try:
        exec(compile(Path(path).read_text(encoding="utf-8"), str(path), "exec"), ns)
        if not callable(ns.get("build")):
            raise ValueError(f"{Path(path).name} needs a build() that returns an ak.Anim")
        return ns["build"]() if "cam" not in names else ns["build"](names["cam"])
    finally:
        if r15:
            r15.bind(old)


def placeholder(K, name, rig, frames, rigtype):
    a = K.ak.Anim(name, rig=rig, length=frames, fps=FPS, priority="Action4")
    idle = K.ak.IDLE_R15 if rigtype == "R15" else K.ak.IDLE_R6
    a.full(0, idle, "linear")
    a.full(frames, idle, "linear")
    return a


def key_problems(keys, frames):
    """The clip rule (spec 5.7): a key at frame 0 and at the scene's last frame, and none after it."""
    at = {k[0] for k in keys}
    out = [] if 0 in at else ["no key at frame 0"]
    if frames not in at:
        out.append(f"no key at frame {frames} (the scene's last frame)")
    late = sorted(f for f in at if f > frames)
    if late:
        out.append(f"keys after the scene's last frame ({frames}): {', '.join(str(f) for f in late[:5])}")
    return out


def build_role(K, folder, b, role, c, frames):
    cid = b["id"]
    rigtype = rigtype_of(role, c)
    rig, stand, note = role_rig(K, folder, cid, role, rigtype)
    name = f"{cid}_{role}_{rigtype}"
    path = Path(folder) / "anim" / f"{role}.py"
    anim = (load_anim(path, _names(K, b, role, c, rig, name, frames)) if path.exists()
            else placeholder(K, name, rig, frames, rigtype))
    if anim.name != name or anim.length != frames:
        raise ValueError(f"anim/{role}.py must return ak.Anim(NAME, rig=RIG, length=FRAMES, ...): got {anim.name!r}, "
                         f"{anim.length} frames (the scene is {frames})")
    problems = key_problems(anim.keys, frames)
    if problems:
        raise ValueError(f"anim/{role}.py: {'; '.join(problems)} (key every joint on both: a.full(0, pose) and "
                         "a.hold(<last key>, FRAMES))")
    arm = anim.build()
    if rig != rigtype:  # a registered captured rig: rbx_rig stays R15 / R6 for make-anim; rbx_anim["rig"] keeps the
        arm["rbx_rig"], arm[CS_RIG] = rigtype, rig  # registered name, whose joints export and framing need
    arm.matrix_world = place_matrix(K, (c or {}).get("place"), stand)
    dressed = dress(cid, role, arm, look_of(folder, role))
    worn = costume_look(K, folder, cid, role, c, arm, rigtype)  # spec 14: the costume's colours and accessories, last
    src = f"anim/{role}.py" if path.exists() else f"a placeholder pose (write anim/{role}.py)"
    return (f"{role}: {rig} rig, root at {stand:.2f}{note}, {src}, {len({k[0] for k in anim.keys})} key frames"
            + (f", its own colours on {dressed} parts" if dressed else "") + worn)


def costume_look(K, folder, cid, role, c, arm, rigtype):
    """Spec 14: a role in costume looks like its character on the film set, painted after dress()'s captured colours:
    the costume's colours on its parts (body colours, the regions' film colours, then the film colour of each catalog
    item the rig wears; R6 never builds layered clothing, so an R6 stand-in shows the classic items only) and its
    accessories as coarse boxes on their attachment points (costume.silhouettes; costume.proxies for a legacy spec's
    built parts), and each held prop as its parts in the hand at the grip point, in its film colour (silhouettes):
    enough to frame and review shots. Characters wear marketplace items (spec 14.3), which the film set only stands in
    for. dress() makes each role's own materials. Only the acted rig is dressed (the derived R6 rig stays hidden); on
    an R6 rig the same call puts the props on the R6 grip."""
    if not K.costume.is_costume(c):
        return ""
    try:
        spec = K.costume.load(folder, role, (c or {}).get("rig"))
    except SystemExit as e:  # the command line's way out; inside Blender it is an error that build() reports
        raise ValueError(str(e)) from None
    colors = K.costume.colors(spec, rigtype)
    coloured = dress(cid, role, arm, {part: tuple(int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
                                      for part, h in colors.items()})
    parts = {o.get("rbx_part"): o for o in arm.children if o.get("rbx_part")}
    if K.costume.hides_default_face(spec, rigtype) and "Head" in parts:
        # Studio hides the default face under a face accessory with no classic face; make-anim's R6 head draws one
        # (eyes and a smile, its children marked rbx_deco), so it goes too. An R15 stand-in head has none.
        for o in parts["Head"].children:
            if o.get("rbx_deco"):
                o.hide_set(True)
                o.hide_render = True
    bpy.context.view_layer.update()
    coll = arm.users_collection[0]
    made = []
    for px in K.costume.proxies(spec, rigtype) + K.costume.silhouettes(spec, rigtype):
        holder = parts.get(px["part"])
        if holder is None:
            continue
        target = holder.matrix_world @ K.rigs.R2B @ K.rigs.cf(*px["cf"]) @ K.rigs.R2B
        obj = K.rigs._box(f"{arm.name}_{px['name']}", px["size"], coll)
        obj.data.materials.append(_material(K.costume.hex3(px["color"])))
        obj.parent, obj.parent_type, obj.parent_bone = arm, "BONE", px["part"]
        bpy.context.view_layer.update()
        obj.matrix_world = target
        made.append(px)
    return dressed_line(spec["character"], coloured, made)


def dressed_line(character, coloured, boxes):
    """The build line's costume part: parts coloured, accessory stand-ins (one box each), then held props (a prop's
    parts are its boxes, counted once per prop; no count when there is none)."""
    props = len({px["prop"] for px in boxes if px.get("prop")})
    held = f", {props} prop{'' if props == 1 else 's'}" if props else ""
    return (f"; dressed as {character} ({coloured} parts coloured, "
            f"{sum(1 for px in boxes if not px.get('prop'))} accessory stand-ins{held})")


def default_camera(K, plan, b):
    """Placeholder: a slow push on each shot's subject, so the set can be looked at before anim/camera.py exists."""
    for s in K.beats.shots(b):
        p = ((b["cast"].get(s["subject"]) or {}).get("place") or [0] * 6)
        x, z = p[0], p[2]
        plan.key(s["start"], eye=(x + 7, 5.5, z + 9), look=(x, 4.5, z), fov=50)
        plan.key(s["last"], eye=(x + 6, 5.3, z + 7.5), look=(x, 4.5, z), fov=46)


def apply_camera(K, cam, keys):
    cam.animation_data_clear()
    cam.data.animation_data_clear()
    cam.rotation_mode = "QUATERNION"
    last = None
    for k in keys:
        loc, q, _ = Matrix(K.camtrack.cframe_to_blender(k["cf"])).decompose()
        if last is not None and last.dot(q) < 0:
            q.negate()  # the short way round, like Roblox
        last = q
        cam.location, cam.rotation_quaternion = loc, q
        cam.data.lens = K.camtrack.lens_for(k["fov"])
        cam.keyframe_insert("location", frame=k["frame"])
        cam.keyframe_insert("rotation_quaternion", frame=k["frame"])
        cam.data.keyframe_insert("lens", frame=k["frame"])
    ease = {k["frame"]: K.ak.EASES[k["ease"]] for k in keys}
    for fc in K.ak.all_fcurves(cam) + K.ak.all_fcurves(cam.data):
        for kp in fc.keyframe_points:
            e = ease.get(int(round(kp.co.x)))
            if e:
                kp.interpolation, kp.easing = e[0], e[1]
                if e[0] == "BEZIER":
                    kp.handle_left_type = kp.handle_right_type = "AUTO_CLAMPED"
        fc.update()


def build_camera(K, folder, b, coll, scene):
    cid = b["id"]
    data = bpy.data.cameras.new(f"{cid}_Camera")
    data.sensor_fit = "VERTICAL"
    data.sensor_height = K.camtrack.SENSOR
    data.clip_start, data.clip_end = 0.1, 2000.0
    cam = bpy.data.objects.new(f"{cid}_Camera", data)
    cam[TAG] = cid
    coll.objects.link(cam)
    scene.camera = cam
    plan = K.camtrack.CamPlan(K.beats.length(b), K.beats.cut_frames(b), K.beats.shots(b))
    path = Path(folder) / "anim" / "camera.py"
    if path.exists():
        load_anim(path, {"cam": plan, "SHOTS": K.beats.shots(b), "FPS": FPS, "BEATS": b})
    else:
        default_camera(K, plan, b)
    keys = plan.resolved()
    apply_camera(K, cam, keys)
    src = "anim/camera.py" if path.exists() else "a placeholder push per shot (write anim/camera.py)"
    return f"camera: {src}, {len(keys)} keys, cuts at " + (" ".join(f"{c / FPS:.2f}" for c in plan.cuts) or "none")


def save(folder, cid, scene):
    path = Path(folder) / f"{cid}.blend"
    bpy.data.libraries.write(str(path), {scene}, fake_user=True)
    return f"saved {path}"


def build(folder):
    K = _kit()
    folder = Path(folder)
    b = K.beats.load(folder)
    cid = b["id"]
    lines = [f"FILM SET {cid}" + ("" if b.get("approved") else "  (beat sheet not approved: show it and wait for go)")]
    problems = K.beats.validate(b)
    if problems:
        return "\n".join(lines + ["  fix the beat sheet first:"] + [f"    - {p}" for p in problems])
    scene = _scene(cid)
    taken = in_the_way(cid, b)
    if taken:
        raise ValueError(f"FILM SET {cid}: {', '.join(taken)} already exist and this kit didn't make them (no {TAG} = "
                         f"{cid}): rename them, then build again. Nothing was cleared.")
    clear(cid)
    try:
        with tagging(cid), bpy.context.temp_override(scene=scene):
            lines += _build_set(K, folder, b, scene)
        lines.append(f"  {save(folder, cid, scene)}")  # after tagging, so the file keeps the tags too
    except Exception as e:
        raise RuntimeError(f"FILM SET {cid} stopped after the old set was cleared: {type(e).__name__}: {e}. CS_{cid} is "
                           f"half built and not saved ({cid}.blend still holds the last good build): fix it and build "
                           "again.") from e
    return "\n".join(lines)


def _build_set(K, folder, b, scene):
    cid = b["id"]
    lines = []
    frames = K.camtrack.last_frame(K.beats.length(b), FPS)  # frames 0..frames; the last one is t = length
    scene.render.fps, scene.render.fps_base = FPS, 1.0
    scene.frame_start, scene.frame_end = 0, frames
    scene.render.resolution_x, scene.render.resolution_y = 1920, 1080
    coll = _collection(scene, f"{cid}_Set")
    anchor = bpy.data.objects.new(f"{cid}_Anchor", None)
    anchor.empty_display_type = "ARROWS"
    anchor[TAG] = cid
    coll.objects.link(anchor)
    mpath = folder / "map.json"
    if mpath.exists():
        m = json.loads(mpath.read_text(encoding="utf-8"))
        build_map(K, cid, m, coll)
        lines.append(f"  map: {len(m['boxes'])} stand-ins, {len(m['terrain']['cells'])} terrain samples")
    else:
        lines.append("  map: none yet (studio <id> anchor, then map)")
    lines += [f"  {build_role(K, folder, b, role, c, frames)}" for role, c in b["cast"].items()]
    lines.append(f"  {build_camera(K, folder, b, coll, scene)}")
    if OWN_SCENE:  # clear() took the markers listed last time; the viewer's own markers stay
        made = []
        for t, name, value in K.beats.markers(b):
            m = scene.timeline_markers.new(f"{name}:{value}" if value else name, frame=round(t * FPS))
            made.append([m.name, m.frame])
        scene[MARKERS] = json.dumps(made)
    lines.append(f"  {vfx_guides(K, b, coll, cid)}")
    scene.frame_set(0)
    mids = [round((s["start"] + s["end"]) / 2 * FPS) for s in K.beats.shots(b)]
    lines.append(f'  look: look(mode="frames", view="camera", frames={mids}, shading="solid")')
    return lines


# ---- export (Task 13): clips, the derived R6 clip, the Stage clip, framing.json and scene.json -----------------------

IGNORED = ("attack without a marker",)  # cutscene acting isn't an attack; the scene's markers live on the Stage clip


def _write_clip(K, arm, out, frames):
    data, report, samples = K.export.to_data(arm)
    if data["length"] != frames:
        raise ValueError(f"{arm.name} lasts {data['length']} frames; the scene is {frames}")
    found = [i for i in K.checks.run(arm, data, samples) if not i.startswith(IGNORED)]  # checks need the registered rig
    if arm.get(CS_RIG):  # a registered captured rig: the clip file names the real rig type, like every other clip
        data = dict(data, rig=arm["rbx_rig"])
    with open(out / f"{arm.name}.json", "w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, separators=(",", ":"))
    K.clip.write_rbxmx(data, out / f"{arm.name}.rbxmx")
    baked = sum(r["baked"] for r in report.values())
    return found, (f"  {arm.name}: {len(data['keyframes'])} keyframes ({baked} baked), checks: "
                   + ("all clear" if not found else f"{len(found)} to look at: " + "; ".join(found)))


def pose_now(K, arm, rig):
    """Pose-language values of every joint of the rig named `rig` at the current frame, read by make-anim's own
    animkit.Anim._pose_now through a throwaway Anim of that rig (nothing is built; preflight M9: no copy of it)."""
    return K.ak.Anim(arm.name, rig=rig)._pose_now(arm)


def derive_r6(K, folder, b, role, c, arm15, frames):
    """The R6 clip from the R15 master (spec 5.8): R6 keys on the R15 key frames, eases kept; anim/<role>_R6.py, when it
    exists, gets DERIVED and replaces it (re-posed beats)."""
    rig15 = json.loads(arm15["rbx_anim"])["rig"]  # a registered captured rig keeps its own name here (Task 12)
    path = Path(folder) / "anim" / f"{role}.py"
    anim15 = (load_anim(path, _names(K, b, role, c, rig15, arm15.name, frames)) if path.exists()
              else placeholder(K, arm15.name, rig15, frames, "R15"))
    eases = {}
    for f, _, _, ease in anim15.keys:
        if 0 <= f <= frames:
            eases.setdefault(f, []).append(ease)
    scene = bpy.context.scene
    derived, flags = {}, []
    for f in sorted(set(eases) | {0, frames}):
        scene.frame_set(f)
        p15 = pose_now(K, arm15, rig15)
        e = eases.get(f, ["cubic_inout"])
        derived[f] = (K.r6.derive(p15), "constant" if "constant" in e else max(set(e), key=e.count))
        flags += [f"frame {f} ({f / FPS:.2f} s): {j} bent {d:.0f} deg" for j, d in K.r6.bends(p15)]
    anim, over = r6_anim(K, folder, b, role, c, frames, derived)
    arm = anim.build()
    arm.matrix_world = place_matrix(K, (c or {}).get("place"), DEFAULT_STAND)
    return arm, flags, over


def r6_anim(K, folder, b, role, c, frames, derived):
    """(the R6 ak.Anim, not built yet; whether anim/<role>_R6.py made it). Without that file the derived keys
    {frame: (R6 pose, ease)} are the clip; with it, its build() gets them as DERIVED and returns the clip."""
    name = f"{b['id']}_{role}_R6"
    over = Path(folder) / "anim" / f"{role}_R6.py"
    if over.exists():
        anim = load_anim(over, _names(K, b, role, c, "R6", name, frames, DERIVED=derived))
    else:
        anim = K.ak.Anim(name, rig="R6", length=frames, fps=FPS, priority="Action4")
        for f, (pose, ease) in sorted(derived.items()):
            anim.key(f, pose, ease)
    if anim.name != name or anim.length != frames or anim.rig_type != "R6":
        raise ValueError(f"anim/{role}_R6.py must return ak.Anim(NAME, rig=RIG, length=FRAMES, ...): got "
                         f"{anim.name!r} on {anim.rig_type}, {anim.length} frames (the scene is {frames})")
    problems = key_problems(anim.keys, frames)
    if problems:
        raise ValueError(f"anim/{role}_R6.py: {'; '.join(problems)} (key every joint on both: a.full(0, pose) and "
                         "a.hold(<last key>, FRAMES))")
    return anim, over.exists()


def verdict(cid, issues):
    """(ok, the export's last line): the next step, or STOPPED when any clip has check issues left to fix."""
    n = sum(len(v) for v in issues.values())
    if not n:
        return True, f"  wrote export/scene.json and export/framing.json; next:  py kit/run.py scene {cid}"
    where = ", ".join(f"{clip}: {len(v)}" for clip, v in issues.items() if v)
    return False, (f"STOPPED: {n} clip issues ({where}), listed above: fix them in anim/*.py and export again "
                   "(the files are written for a look; py kit/run.py scene refuses them)")


def _sample(K, cam, arms, frames):
    """Per frame: the camera's CFrame and FOV, and each role's head position, all in the anchor's Roblox space."""
    scene = bpy.context.scene
    rig_of = {role: K.rigs.with_props(json.loads(arm["rbx_anim"])["rig"]) for role, arm in arms.items()}
    cams, fovs, heads, bodies = [], [], {role: [] for role in arms}, []
    for f in range(frames + 1):
        scene.frame_set(f)
        ce = cam.evaluated_get(bpy.context.evaluated_depsgraph_get())
        cams.append(K.camtrack.blender_to_cframe([list(ce.matrix_world[i]) for i in range(4)]))
        fovs.append(K.camtrack.vfov(ce.data.lens, ce.data.sensor_height))
        cast = {}
        for role, arm in arms.items():
            root = B2R @ arm.matrix_world @ B2R
            parts = K.rigs.part_frames(arm, rig_of[role])
            head = root @ parts["Head"].to_translation()
            heads[role].append([round(v, 3) for v in head])
            sizes = rig_of[role]["parts"]
            # every body part as a box in the anchor's space, for the cast overlap check (RS-1)
            cast[role] = {p: K.contact.box(root @ m, sizes[p]) for p, m in parts.items()
                          if p in sizes and p != rig_of[role]["root"]}
        bodies.append(cast)
    return cams, fovs, heads, bodies


def clip_plan(cid, b, derives):
    """{role: (master armature name, derived R6 name or None)} for the export. derives(role, c) says whether the role's
    R15 master gets a derived R6 clip (costume.derives_r6). A derived name is never a master's: make-anim's Anim.build
    deletes whatever has its armature's name, so a role acted on R6 (it is its own R6 master) that is asked to derive
    is refused before anything is made."""
    plan = {role: (f"{cid}_{role}_{rigtype_of(role, c)}", f"{cid}_{role}_R6" if derives(role, c) else None)
            for role, c in b["cast"].items()}
    masters = {m: role for role, (m, _) in plan.items()}
    clash = [(role, r6, masters[r6]) for role, (_, r6) in plan.items() if r6 in masters]
    if clash:
        raise ValueError(f"EXPORT {cid}: " + "; ".join(
            f"{role}'s derived R6 clip would be {r6}, the name of {who}'s own master clip (a role acted on R6 is its "
            "own R6 master: nothing is derived from it)" for role, r6, who in clash) + ". Nothing was exported.")
    return plan


def export(folder):
    """build(), then every clip into export/ (see the module docstring). Whatever it makes in Blender (the derived R6
    rig) is made inside tagging(cid), so the next build's clear() takes it."""
    folder = Path(folder)
    report = build(folder)
    K = _kit(reload=False)
    b = K.beats.load(folder)
    cid = b["id"]
    if K.beats.validate(b):
        return report + "\nEXPORT STOPPED: fix the beat sheet first"
    made = K.scenefile.sources(folder)  # what this export is made from: scenefile.write refuses once it changes
    # the player, and an NPC acting a humanoid costume on R15 (spec 14), get a derived R6 clip; an R6 role never does
    plan = clip_plan(cid, b, lambda role, c: K.costume.derives_r6(folder, role, c))
    r6names = [r6 for _, r6 in plan.values() if r6]
    held = [(n, bpy.data.objects.get(n)) for n in r6names] + [(n, bpy.data.collections.get(n)) for n in r6names]
    taken = sorted({n for n, d in held if d is not None and d.get(TAG) != cid})
    if taken:  # build() cleared the kit's own; make-anim's Anim.build would delete whatever has its armature's name
        raise ValueError(f"EXPORT {cid}: {', '.join(taken)} already exist and this kit didn't make them (no {TAG} = "
                         f"{cid}): rename them, then export again.")
    out = folder / "export"
    out.mkdir(parents=True, exist_ok=True)
    frames = K.camtrack.last_frame(K.beats.length(b), FPS)
    clips, issues, r6info, arms = {"Stage": f"{cid}_Stage", "R15": {}, "R6": {}}, {}, {}, {}
    lines = [f"EXPORT {cid}: {frames} frames"]
    with tagging(cid), bpy.context.temp_override(scene=_scene(cid)):
        for role, c in b["cast"].items():
            master, r6name = plan[role]
            arm = bpy.data.objects[master]
            arms[role] = arm
            found, line = _write_clip(K, arm, out, frames)
            clips[rigtype_of(role, c)][role], issues[arm.name] = arm.name, found
            lines.append(line)
            if r6name:
                arm6, flags, over = derive_r6(K, folder, b, role, c, arm, frames)
                found6, line6 = _write_clip(K, arm6, out, frames)
                clips["R6"][role], issues[arm6.name] = arm6.name, found6
                r6info[role] = {"override": over, "flags": flags}
                if flags:
                    line6 += f"; R6 loses {len(flags)} bends" + ("" if over else f": re-pose them in anim/{role}_R6.py")
                lines.append(line6)
                for o in [arm6] + list(arm6.children_recursive):  # recursive: the R6 head's face meshes too
                    o.hide_set(True)
                    o.hide_render = True
        cam = bpy.data.objects[f"{cid}_Camera"]
        cams, fovs, heads, bodies = _sample(K, cam, arms, frames)
        # RS-1: no limb inside another cast member except on the beat sheet's planned contacts (R15 masters)
        overlap = K.contact.scan(bodies, K.contact.allowed(b, FPS))
        issues["cast overlap"] = overlap
        lines.append("  cast overlap: " + ("all clear" if not overlap else f"{len(overlap)} to look at: "
                                           + "; ".join(overlap)))
        cuts = K.beats.cut_frames(b)
        stage = K.camtrack.stage_clip(clips["Stage"], cams, cuts, K.beats.markers(b))
        with open(out / f"{clips['Stage']}.json", "w", encoding="utf-8", newline="\n") as f:
            json.dump(stage, f, separators=(",", ":"))
        K.clip.write_rbxmx(stage, out / f"{clips['Stage']}.rbxmx")
        lines.append(f"  {clips['Stage']}: {sum(1 for k in stage['keyframes'] if k['poses'])} camera keys, "
                     f"{len(cuts)} cuts")
        K.workspace.write_json(out / "framing.json", {"fps": FPS, "frames": frames, "camera": cams,
                                                      "fov": [round(v, 3) for v in fovs], "cuts": cuts, "heads": heads})
        ok, last = verdict(cid, issues)
        K.workspace.write_json(out / "scene.json", {"id": cid, "length": round(frames / FPS, 5), "fps": FPS,
                                                    "frames": frames, "clips": clips,
                                                    "fov": K.camtrack.fov_track(fovs, cuts), "cuts": cuts,
                                                    "issues": issues, "r6": r6info, "ok": ok, "sources": made})
        bpy.context.scene.frame_set(0)
    lines.append(last)
    return report + "\n" + "\n".join(lines)


def guide_name(cid, n, kind):
    """`<id>_VFX<n>c` (circle) or `<id>_VFX<n>a` (arrow): short, because Blender's object names stop at 63 bytes; the
    preset is in the object's cs_preset property."""
    return f"{cid}_VFX{n}{kind}"


def vfx_guides(K, b, coll, cid):
    """An empty pair per VFX cue where it plays: a circle of the preset's radius on the floor and an arrow of its
    height, so the camera keys can frame the effect (Studio's preview shows the real thing; spec 7)."""
    import cues
    import vfxlib
    importlib.reload(vfxlib)
    importlib.reload(cues)
    lib = vfxlib.load()
    found = cues.module_cues(K.beats.markers(b), b.get("cues"), None, lib, strict=False)
    made = 0
    for n, (k, cue) in enumerate(sorted(found.items()), 1):
        preset = lib["presets"].get(cue.get("preset")) if cue.get("kind") == "vfx" and not cue.get("external") else None
        if not preset:
            continue
        radius, height = preset["extent"]
        scale = cue.get("scale", 1)
        at = cue["at"] if isinstance(cue.get("at"), list) else [0, 0, 0]
        role = (cue.get("follow") or (cue["at"] if isinstance(cue.get("at"), str) else "")).split(".")[0]
        place = ((b["cast"].get(role) or {}).get("place") or [0, 0, 0])[:3] if role else [0, 0, 0]
        lift = 4.5 if isinstance(cue.get("at"), str) else 0  # a head or face point: about head height
        p = [place[0] + at[0], place[1] + at[1] + lift, place[2] + at[2]]
        for shape, kind, size in (("CIRCLE", "c", radius), ("SINGLE_ARROW", "a", height)):
            obj = bpy.data.objects.new(guide_name(cid, n, kind), None)
            obj.empty_display_type = shape
            obj.empty_display_size = size * scale
            obj.location = _bl(p)
            if shape == "CIRCLE":
                obj.rotation_euler = (math.pi / 2, 0, 0)  # Blender draws the circle upright; lay it on the floor
            obj[TAG] = cid
            obj["cs_preset"] = cue["preset"]
            coll.objects.link(obj)
        made += 1
    return f"vfx guides: {made} ({', '.join(sorted(k for k in found))})" if made else "vfx guides: none"
