# Animation skill bridge: R15, R6 and cutscene acting

Method by fwjelaa (FWJ STUDIOS). This reference adds routing and handoff rules; it does not replace the FWJ make-anim pose language, exporters or CutsceneKit runtime.

## Read before assigning acting

Read [the cutscene method](../CLAUDE.md), [the sibling make-anim entry point](../../make-anim/SKILL.md), and the relevant route below before writing `anim/<role>.py`. Prefer the user-authorized bundled copies by opening these exact relative entry points:

- [animation](../../animation/SKILL.md)
- [universal-r15-animation-director](../../universal-r15-animation-director/SKILL.md)
- [universal-r6-blender-animation-director](../../universal-r6-blender-animation-director/SKILL.md)
- [animate-roblox-characters](../../animate-roblox-characters/SKILL.md)

Resolve each skill's resource paths from its own directory, not the project working directory. When its prose says `skill_view`, prefer direct reads of the bundled entry point and referenced files; a host registry may instead return a different active-profile version. If a bundled skill is missing, discover the exact registered name through the host registry (in Hermes, `skill_view(name=...)`) and record which source/version was used. Do not assume a developer profile path or legacy folder alias. The R15 source's legacy-directory sentence is historical; this pack uses `skills/universal-r15-animation-director/`. Do not install dependencies or copy additional private skills without authorization. See the bundle inventory and limitations (development archive; not bundled).

**Loading instructions is not code interoperability.** The supported integration today is specialist guidance applied to the pack's existing scripts and checks. There is no bridge importer here for arbitrary Blender Actions, `.rbxanim`, FBX, native Studio KeyframeSequences or animation asset IDs. An independently authored clip is not a full-scene cutscene export.

### Routing matrix

| Request / target | Skills to load when available | Deliver through this pack | Boundary |
|---|---|---|---|
| R15 acting, default pack route | `animation`; `universal-r15-animation-director` | `anim/<role>.py` returning `ak.Anim`; captured-rig calibration, grounded poses, camera-led acting | Apply measured joint-space/contact guidance, not a foreign control-rig script |
| R6 acting / R6 player support | `animation`; `universal-r6-blender-animation-director` | R6 NPC: `anim/<role>.py`; player or derived humanoid costume: `anim/<role>_R6.py` | Six rigid body parts; no exportable elbow/knee/waist joints; reinterpret acting |
| Both player rigs | Both directors plus `animation` | R15 master plus explicitly reviewed R6 override, same scene timebase | R15 success and automatic derivation do not certify R6 acting |
| Existing clip, Action or asset | `roblox-animation`; corresponding rig director; `animate-roblox-characters` for Blender provenance/export | Preserve source; manually reconstruct verified motion into pose scripts, or stop at a documented adapter requirement | Asset ID replacement alone bypasses source, duration, marker and framing contracts |
| Explicit native Studio authoring / no Blender | `roblox-native-animation-studio`; R15 director for R15; `roblox-animation` for lifecycle | Native authoring is a separate clip workflow; hand off calibrated poses, timing and evidence | This pack's full-scene build/export still requires Blender. Do not claim a native-only cutscene adapter |
| Explicit authentic Blender authoring / premade rig | `animate-roblox-characters`; corresponding director | Separate protected authoring source and export; manually port into reproducible pose scripts only after mapping | Cautioned `.rbxanim` / skinned FBX and make-anim `.rbxmx` are different pipelines |
| Creature / nonhumanoid costume | `animation`; pack costume contract; native skill only if separately authoring in Studio | `cast/<role>.json`, generated captured-rig schema, `anim/<role>.py` using actual part names | One R15-typed custom rig is not human R15 anatomy; no automatic R6 derivation or `_r15` IK assumption |
| Playback, markers, interruptions | `roblox-animation`; native verification reference | Existing CutsceneKit Stage clock, cast tracks and restore tests | Do not introduce a competing Animator driver, camera loop or marker dispatcher |

### Required specialist references

- `universal-r15-animation-director`: `references/r15-calibration-contract.md` before poses; `references/r15-diagnosis-and-acceptance.md` before acceptance. Load `references/r15-native-studio-and-boxing.md` for native work, not as a claim that every scene needs boxing.
- `universal-r6-blender-animation-director`: `references/authoring-export-evidence.md` before recipes; `references/r6-motor6d-procedural-and-ik-physics.md` for Motor6D rest-space reasoning. V2.22 control names, clamps and numerical recipes do not apply directly to make-anim bones.
- `animate-roblox-characters`: `references/toolchain.md`, `references/roblox-rigs-export.md`, `references/authoring-export-contract.md` before taking its external Blender route. Inspect actual scripts before calling their interfaces.
- `roblox-native-animation-studio`: `references/native-authoring.md` and `references/verification.md`; use its production passes for independently authored native clips.
- `roblox-animation`: `references/playback-lifecycle.md` and `references/integration-and-events.md`; retain CutsceneKit's ownership and Stage dispatch rather than transplanting general runtime examples.
- `animation`: `references/timing-sampling-contact.md`; distinguish artistic timing choices from engine guarantees.

If these skills are unavailable, record which could not be loaded and use the bundled [make-anim method](../../make-anim/CLAUDE.md), [pose implementation](../../make-anim/kit/animkit.py), [rig definitions](../../make-anim/kit/rigs.py), [R15 helpers](../../make-anim/anims/_r15.py), and the checks below. This fallback retains the pack's existing behavior; it does not satisfy an explicit request for an unavailable premade-rig/native workflow. If sibling make-anim itself is missing, stop: it is a code dependency, unlike the optional installed specialists. Never invent tools, download a replacement rig silently, or label an unverified path ready.

## Handoff contract

Before authoring, the cutscene owner supplies the specialist with:

1. Scene ID, role, shot intent and shot intervals; approved `beats.json`; exact cue names/values and contact windows.
2. Target topology and rig class evidence, actual parent/child names, rest transforms, part sizes, root/stand height, costume/prop requirements and capture provenance. Supply `rigs/<role>.json` plus original capture identity where available; it is not interchangeable with an imported premade rig.
3. Timebase: pack `FPS = 60`, integer frame conversion `F(seconds) = round(seconds * FPS)`, inclusive `0..FRAMES`, scene duration and any source FPS/offset/retiming. Use the injected `FRAMES`, not a guessed clip length.
4. Spaces and ownership: anchor-relative `PLACE`, character-local motion, root-travel owner, contact support frame, channel mask and declared tolerances. Distinguish an intended slide/pivot/release from a planted interval.
5. Selected route, allowed write files and evidence required. Do not grant uploads, installs, Studio mutations or credentials merely by loading a skill.

The specialist returns:

- Source `anim/<role>.py`, or `anim/<role>_R6.py` for a derived replacement, using the injected namespace below. Return the unbuilt `ak.Anim`; filmset owns building, placement and exporting.
- A per-rig motion record: source identity/hash, capture identity, mapping/calibration, seconds/frame map, contacts, root strategy, marker correspondence, intentional exceptions and unresolved defects with timestamps.
- Separate evidence statuses (`pass`, `fail`, `unverified`) for source inspection, offline math/tests, Blender evaluation/export, native playback, visual acceptance, restore and publication. Report only performed stages.
- No edits solely in the generated `.blend`, `export/scene.json`, exported clips or data module as a substitute for source changes. `filmset.export()` rebuilds and discards hand-only scene edits.

### Exact pack interface

[filmset.py](../kit/filmset.py) injects `ak`, `NAME`, `RIG`, `ROLE`, `FRAMES`, `FPS`, `SHOTS`, `F`, `PLACE`, `BEATS`; R6 override scripts additionally receive `DERIVED`, a mapping from frame to `(pose, ease)`. Define `build()` returning `ak.Anim(NAME, rig=RIG, length=FRAMES, fps=FPS, priority="Action4")`. `RIG` can be a registered captured-rig name, not literally `R15`.

Use `a.full(0, pose)` and a full final pose or `a.hold(last_key_frame, FRAMES)`; author every needed channel. The current `key_problems()` checks endpoint frame presence, not that every channel is fully keyed, so inspect channel coverage separately. `a.key(frame, pose, ease)` expects child body-part names and tuples `(x, y, z)` in degrees or `(x, y, z, px, py, pz)` in studs. Its ease controls the interval leaving the key. `a.marker(frame, name, value)` adds actor markers; these are not a substitute for scene cues in `beats.json`.

For an R6 override, `for frame, (pose, ease) in sorted(DERIVED.items()): a.key(frame, pose, ease)` is an existing starting pattern, **not an acceptable finished adaptation by itself**. Replace or add poses at the meaning-bearing beats and inspect intervening motion. An R6 NPC's own master remains `<role>.py`; do not create a conflicting derived master.

### Coordinates, joints and root motion

- Pack coordinates: one Blender unit per stud. Roblox character axes are X right, Y up, Z back, facing -Z. The pack's basis maps a point to Blender `(-x, z, y)`; use the existing `rigs.B2R`/`R2B`, not an imported workflow's basis or another conversion.
- Pose rotations are `Rx * Ry * Rz` (`CFrame.Angles`, degrees converted internally). They are **not raw `Motor6D.Transform` Euler angles**: `animkit.pose_transforms()` conjugates by the C0 rotation. Evaluated transforms come from `rigs.motor_transforms(arm, rig)` using `(P0 * C0)^-1 * (P1 * C1)`.
- Map child part names, parents and bind/rest transforms explicitly. R6 uses `Torso`, `Head`, `Right Arm`, `Left Arm`, `Right Leg`, `Left Leg`; R15 uses its segmented body names. Names alone do not prove bind-space equivalence. A foreign rig's `MasterControl`, `LowerTorso-FK` or IK target is not a make-anim joint.
- `PLACE` places the anchored clone relative to the scene anchor; the armature root includes captured stand height. Acting travel belongs to `LowerTorso` (R15) or `Torso` (R6) translation channels. Do not also translate the clone or foreign master control and double the travel. Do not key `HumanoidRootPart` as an animatable make-anim joint.
- `filmset.load_anim()` currently binds `_r15` helpers to the selected R15-shaped rig and restores the prior binding in `finally`. This supersedes older prose saying these helpers always use stock lengths. Reach remains a target to verify, not proof of contact.
- Assign the result of grounding: `pose = ak.ground(pose, RIG)`. It returns a new dictionary and corrects lowest-foot height only; it does not lock horizontal contact or prove both feet/hand contacts valid. R6 `a.lock_feet(...)` exists but must be evaluated on the intended intervals; release the lock for steps.
- `Capture.rigOf` handles Motor6D and AnimationConstraint attachment frames, preferring Motor6D for duplicate children. The normalized capture does not retain joint-class identity. Keep that provenance separately; static support in Capture is not proof that a foreign solver/exporter supports the live rig class.

## Compatibility: what is and is not automated

| Interface inspected | Actual scope | Bridge decision |
|---|---|---|
| `filmset.build(folder)`, `filmset.export(folder)` | Rebuild source, make full-scene actor/Stage clips, framing and issues | Existing pack delivery path |
| `r6.derive(pose15)`, `r6.bends(pose15)` | Upper-segment orientation mapping, half waist contribution, root translation; bend flags | Seed R6 acting, then independently re-pose/review |
| `filmset.r6_anim(...)` | Loads `<role>_R6.py`, injects `DERIVED`, checks name/length/R6/end frames | Existing supported override seam |
| `authentic_rig.export_rbxanim(output_path, armature_name, action_name=None, frame_start=None, frame_end=None)` in bundled `animate-roblox-characters` | Requires verified metadata-backed rig; invokes Cautioned exporter | Separate export, not a cutscene importer |
| `animation_tools.audit_action(...)` in bundled `animate-roblox-characters` | Authenticity, curve and sampled contact/loop checks | Not a drop-in gate on pack proxies or all valid baked/stylized clips |
| R15 director `scripts/r15_math.py` and tests | Offline rigid-transform/IK utilities | Synthetic math evidence only, no engine/filmset adapter |
| Native Studio skill | Authoring, calibration, construction/playback and persistence workflow | Instruction handoff, no native-to-filmset converter supplied |

The bundled `animate-roblox-characters` auditor currently flags final LINEAR and CONSTANT keys. That conflicts with valid dense sampled exports and deliberate anime-on-twos in this pack; its companion reference acknowledges the limitation. Do not alter the motion merely to obtain that auditor's green result or silently suppress findings. Use the pack checks and representation-aware source/output comparisons, report which auditor was inapplicable, and retain the source action.

The authentic Blender route forbids generated stand-ins and requires its verified premade/imported rig. This pack intentionally builds captured-dimension stand-ins for film blocking. Keep them separate: a stand-in is neither an authentic V2.22 rig nor a complete likeness/accessory certificate. Do not attach forged authenticity metadata, bypass HMAC/security checks, or silently switch to the external pipeline. The Cautioned add-on source ZIP and its GPL license are bundled unchanged; the downloaded V2.22 `.blend` and `.rbxm` are intentionally excluded because redistribution permission is unstated. Obtain those assets separately through the source-pinned fetcher only with authorization. Authentic R15 requires the Studio-derived workflow, not generated geometry or a reference skeleton. Personal lineage keys and receipts are not portable assets and must not be copied.

## R6 adaptation is a separate acceptance task

Current derivation samples the R15 authored key frames plus endpoints, not every possible between-key bend peak; the bend thresholds in [r6.py](../kit/r6.py) are warnings about representation loss, not a semantic acting test. The torso combines LowerTorso and half the waist rotation; straight limbs inherit upper-segment orientation, not hand/foot target preservation.

For each beat, preserve intent and screen silhouette using torso lean/turn, arm arcs, leg splits, root lowering, head aim and explicit anticipation/recovery. Re-solve prop reach and floor contact. Inspect bends below warning thresholds and midpoints too. An existing override changes bend flags to informational; `override: true` means the file exists, not that adaptation passed.

The derived route currently uses stock `R6` and `DEFAULT_STAND`, not a separately captured R6 player rig. Ordinary R6 NPC masters can use matching captures through `role_rig()`. Unusual player proportions therefore require explicit R6 runtime evidence or a separately scoped, tested adapter change; do not promise captured R6 player support from the override name alone. `rigtype_of()` always treats the player master as R15, even when the requested viewing target is R6.

## Verification gates, repeated for each delivered rig

1. **Topology and provenance:** compare expected and actual joint graph, child names, C0/C1 or attachment rest frames, scale, stand/sole geometry and prop sockets. Calibrate left/right signs and one-joint motion independently. Record unsupported classes or missing channels; do not pass by guessing.
2. **Contact and clearance:** measure intended sole/hand contact points against original targets in world or moving-support space, including orientation and permitted pivots. Sample keys, midpoints, contact boundaries and fast-motion extrema; refine around residuals. Inspect actual mesh/accessory/prop bounds in Studio, not only stand-in centers. Declare tolerances and sampling limits before review.
3. **Root and timing:** compare intended travel without duplicate root drivers; ensure starts, scene-wide duration, inclusive final key and recovery match both rigs. Resample source FPS using seconds, preserve authored spins and source easing, and compare keys and in-betweens after export. Dense LINEAR sampling can be correct; finite samples are not a continuous guarantee.
4. **Markers and camera:** scene cues come from `beats.json` into Stage and module markers; `scenefile.marker_problems()` checks correspondence. Do not rely on actor markers to dispatch scene UI/VFX. Check opening cue, impact/contact/dialogue beats and cuts for both rigs, including cold playback. R6 must preserve event meaning, not merely event timestamps.
5. **Pack export and gates:** run the existing `filmset.export`, `py kit/run.py scene <Id>` and `py kit/run.py gates <Id>` in the authorized workflow. Re-export after source changes. Never bypass clip issues or stale-source checks. `framing.json` and cast-overlap sampling use master rigs, not the hidden derived R6 cast: separate R6 visual/contact evidence is mandatory.
6. **Playback and restoration:** follow [CLAUDE.md play tests](../CLAUDE.md) for R15 and R6: natural end, permitted skip and death/respawn; camera returns to saved gameplay state, local cast disappears, root anchoring and lock restore, owned tracks/connections/temporary effects are cleaned up. Costume/accessory counts match before/during/after as specified. Check console, cold-start cues and repeat entry. Respect unskippable scenes; record skip as not applicable where intentional rather than faking a pass.
7. **Delivery:** keep separate R15/R6 takes, scene evidence and defect records; a passing R15 take, export file, synthetic test or specialist skill installation is never evidence of R6 native playback. Publication/permission validation is a separate authorized gate.

## Source of truth and provenance

`beats.json`, `anim/*.py`, captures and costume specifications are authored inputs; `.blend` and `export/` are derived products. The existing source-staleness fingerprint covers the export-relevant beat data, `anim/*.py` and `rigs/*.json`; it does not automatically track an external Action, installed skill version or remote asset. Record external source hashes, exact rig/action identity, source/effective FPS, mapping choices, author/license credits and manual conversion decisions alongside review evidence. This record is a handoff artifact, not a newly implemented schema or automatic invalidation feature.

Keep the FWJ STUDIOS/fwjelaa attribution on the portable method and files. Attribute third-party rigs and source clips separately and preserve their licensing/security restrictions. Only the four linked animation skills are included by this bundle operation; `roblox-animation`, `roblox-native-animation-studio`, `rigging`, `blender-rig-animate` and the separately named `fwjelaa` skill remain registry-discovered dependencies, not silently bundled code. The pack's FWJ methods are available locally but are not a claim that the separate `fwjelaa` skill is installed. When contracts conflict, retain the existing pack API and disclose the incompatible route; ask the cutscene owner to authorize any runtime/adapter change before promising it.
