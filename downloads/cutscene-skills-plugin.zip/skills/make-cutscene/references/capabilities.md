# Capabilities and production boundaries

Method by fwjelaa (FWJ STUDIOS). Read before promising an output. “Implemented” below means source exists; it does not mean this documentation upgrade exercised a live engine. [Operational instructions](../CLAUDE.md) remain the execution contract.

## Choose the scope first

| Scope | Allowed output | Additional prerequisites |
|---|---|---|
| Offline research/planning | Source analysis, briefs, timing hypotheses, documentation and authorized local checks | Readable inputs; no Studio/Blender connection or cloud key required for prose work |
| Connected authoring | Capture, pose-script film set, export, kit checks and authorized Studio preview | Sibling make-anim, actual Python/Blender/Studio toolchain; explicit target place and mutation scope |
| Publication | Upload authorized assets, install and verify in the target experience | Creator/owner permissions and authorized credential use; presence of a key alone proves neither |

Do not run legacy `check` under a no-credential restriction: its setup implementation loads the configured key. Do not install software globally, change a live place or inspect secrets to answer a planning question. Discover actual tools rather than copying a host-specific MCP name. The complete capture workflow is Windows-oriented; offline Python portability does not make Windows screen recording cross-platform.

## Truth table

| Request | Current boundary | Evidence / next acceptance |
|---|---|---|
| Story, walk-in, NPC dialogue text | Implemented zone/prompt/API trigger, personal camera/cast, subtitle/letterbox presentation | `CutsceneKit.Play`, Server/Director/Subtitles; target-place end/skip/death and trigger tests |
| Simple intro | Implemented personal scene; join example exists | No promised sky/environment replacement; test spawn and gameplay handoff |
| Awakening | Implemented `Awaken` / `EndAwakening`, VFX, aura and onlookers | Unskippable by default; wall, cooldown, death, power-down and onlooker tests |
| R15 and R6 | R15 player master with derived R6 seed/override; matching-rig NPC masters | Separate R6 meaning/contact/playback acceptance, not automatic equivalence |
| Captured R6 player proportions | Not injected by the current derived-player route, which uses stock R6/default stand | Ordinary captured R6 NPC masters are different; see [animation bridge](animation-skill-bridge.md) |
| Adapted costumes | Catalog-based humanoids, classic R6 clothing requirements, shaped creature/held-prop contracts | No purchase, arbitrary model ingestion or uploading copied art; verify actual dressed rigs and likeness |
| Manga screen treatment | Implemented speedlines, burst, word TextLabels and backdrop | Not a full manhwa or dialogue-box UI style |
| Slowmo | VFX/particle time scaling | Not a synchronized actor/camera/audio or game-world time-remapping service; author clip timing |
| Targeted ultimate / environment-changing boss intro | Reserved or partial concepts, not supported end-to-end | No public Ultimate API; stop at a plan or separately scoped engineering |
| SFX, voice, facial cue performance | Not dispatched end-to-end by the current Director | [Sound planning](production-brief.md) is a worksheet, not executable cue data |
| Native/foreign clips | Specialist guidance is available; no automatic filmset importer | Manual pose-script re-authoring or a separately designed/tested adapter |
| Keyless scene | Studio preview only | Publication requires authorized upload/permissions and real playback verification |
| Play-test record | Stores the operator's result | `playtest --set` does not execute the test or prove it happened |
| Blind score | Packet/reply/scoring workflow | Actual independent evidence required; no guaranteed score, quality or safety |

Primary implementation: [CLI](../kit/run.py), [filmset](../kit/filmset.py), [Director](../roblox/CutsceneKit/Director.luau), [Screen](../roblox/CutsceneKit/Screen.luau), [review](../kit/review.py). A schema enum or accepted cue dictionary is not proof that runtime dispatch implements it. Keep future ideas in prose, not unsupported runtime fields.

## Constraints that must survive documentation shortcuts

- Authoring IDs: ASCII letter first, then ASCII letters/digits/underscore, maximum **43**; runtime's separate 60-character acceptance is not the authoring limit.
- Pack authoring timebase: **60 fps**, full-scene clips, inclusive keys at `0` and `FRAMES`. Source footage may use a different or variable timebase. Schema scene duration is capped at 30 seconds; awakening gates are more restrictive. These are pack contracts, not engine limits.
- Studio transfer budget: **60,000 UTF-8 bytes** per emitted part, not a universal Roblox limit. Send all generated parts unchanged in printed order; never assume a fixed part/module count.
- Sibling make-anim is a code dependency. Prefer the bundled animation/director instructions through the [animation bridge](animation-skill-bridge.md); exact-name installed versions are fallbacks when copies are unavailable, not additional code dependencies. No native-only full-cutscene path is created by loading a skill.
- Grounding returns a new pose: `pose = ak.ground(pose, RIG)`. Lowest-foot height correction is not horizontal locking, two-foot placement or a hand-contact solve.
- The captured R15-shaped rig is bound while `filmset.load_anim` executes/builds the source; previous helper binding is restored in `finally`. Binding does not remove reach limits or prove arbitrary rig anatomy is compatible.

## Gameplay return

`Director.blendBack` already implements camera return (`Director.BLEND = 0.55`); the legacy manual's “arrives in a later version” note is stale. Source presence is not evidence of successful restoration in a given scene. Test normal end, permitted skip, death/respawn and interrupted return in the authorized target place.

## Accessibility and rights: say precisely what is protected

Reduced Motion currently removes selected effects and camera roll/shake, **not** authored camera translation, cuts or FOV animation. The preference is read at scene start in the inspected implementation. Direct flashes require separate review. The event flash limiter cannot count every luminance reversal in the final composite, including world effects, UI, cuts and repeat playback.

The subtitle label uses `TextScaled`; automatic response to PreferredTextSize is not established. Test reading time, long/localized lines, contrast, safe areas and action occlusion on the actual target viewport. A static sheet cannot establish comfort, synchronization or accessible timing. Do not expose sensitive reviewers to suspected hazardous sequences as a test.

Roblox supports suitably configured non-R15 layered accessories; the **pack's stock R6 costume path** instead requires classic shirt and pants and omits layered extras. Preserve that scoped requirement rather than claiming an engine-wide ban. Similarly, this pack uses TextLabels for sound words; do not turn a historical asset rejection into a universal moderation policy.

Reference viewing, catalog availability and asset playability are not rights clearance. Record creator/license/permission and permitted adaptation/re-upload uses. Follow platform policy; no bypass of access controls or moderation.

## Sources and access limits

This reference synthesizes the council's source inspection and retrieved documentation, not new live playback tests. Remote claims below were retrieved by the research workers; links identify their sources, not a claim of a fresh fetch by this documentation pass.

- [Character appearance](https://create.roblox.com/docs/characters/appearance#layered-accessories-on-non-r15) — official non-R15 cage/wrap/weld conditions; extracted in architecture research. Does not prove this pack implements them.
- [Accessibility guidelines](https://create.roblox.com/docs/production/publishing/accessibility) — relevant sections extracted; TextScaled/preference and non-reliance guidance.
- [Xbox Accessibility Guideline 117: Visual distractions and motion settings](https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/117) — game-design guidance, not certification.
- [Understanding Success Criterion 2.3.1: Three Flashes or Below Threshold](https://www.w3.org/WAI/WCAG22/Understanding/three-flashes-or-below-threshold) — web flash definitions inform review; no medical or universal game-safety guarantee.
