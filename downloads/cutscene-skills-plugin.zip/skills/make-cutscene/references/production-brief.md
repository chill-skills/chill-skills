# Production brief and director worksheets

Method by fwjelaa (FWJ STUDIOS). These are copyable **prose worksheets**, not additions to `beats.json`, commands or runtime features. Keep them in the scene's authorized notes. Use the existing [method](../CLAUDE.md) for actual schema fields and approval. Do not make the viewer fill out every box: infer reversible choices from their reference, record assumptions, and ask only unresolved blocking questions.

## 1. One-page brief

```text
Scene / revision / owner:
Audience and use: first view / repeated conversation / combat / other
Before -> after: knowledge, relationship, physical advantage, playable state
Character objectives / obstacle / stakes:
Viewpoint owner (whose experience guides attention):
Essential information (must survive muted audio/reduced optional effects):
Reference file/URL, creator, rights, precise interval or panel:
Observed choices / inferred intention (keep separate):
Style and deliberate omissions:
Supported rig(s), real costumes/props, viewport/aspect targets:
Environment/contact/camera-collision constraints:
Current kit mechanisms / unsupported requests / fallback:
Duration/timebase: source FPS or PTS; authoring FPS; mapping/offset
Return to play: heading, objective, position, control and danger
Acceptance question an uninformed viewer can answer:
Approval / unresolved dependency / next evidence:
```

**Useful target:** “The player understands that the guard recognizes the badge and chooses to conceal that recognition.” **Weak target:** “Seven cinematic shots, more shake.” The former can be falsified by a viewer's account; the latter counts treatments without evaluating meaning.

## 2. Beat sheet: a change, not a mandatory cut

| Beat | Before → after | Stimulus → choice | Visible evidence | Attention / listening | Sound or caption intention | Exit evidence |
|---|---|---|---|---|---|---|
| B01 | Routine inspection → recognition | Badge appears; guard chooses concealment | Hand pauses, head orients to badge then away | Player waits rather than gesturing over the discovery | Supported subtitle carries essential line; no voice assumed | Viewer locates the hesitation |
| B02 | Refusal → negotiated passage | Player yields; guard opens a route | Whole-body shift clears the gate | Listener changes weight/heading toward the opening | Gate sound is planned only; opening remains visible | Viewer understands where to go after control returns |

This is a **new design example**, not a claim about what the GateGuard footage already communicates. Set durations after blocking; a long take can hold both beats. Preserve approved data semantics when transferring the plan into supported fields.

## 3. Shot card

```text
Shot / included beats / revision:
Job: “Look here because…” / reveals or withholds:
Primary subject and exact essential detail:
Scale, camera distance/height/angle, FOV and delivery viewport:
Blocking, eyelines, screen direction, landmarks:
Start -> end state:
Fixed or moving camera, and why:
Cut/transition in and out, and why:
Timing: estimate -> observed; authoring frames + FPS; source PTS
Actor phases: preparation / thought / choice / action / reaction / recovery
Contact: point, support frame, interval, tolerance, intended release/pivot
Required cues / optional accents / current runtime support:
Accessory, hand, story-prop, letterbox and subtitle clearance:
Small-screen and alternate-rig risk:
Reduced-effects/flash treatment and implementation status:
Evidence capture and falsification question:
```

**Concrete stop gesture:** R15 can bend an elbow to separate palm from face; R6 must solve the same “stop” meaning with a straight-arm silhouette, torso/head angle and staging. Avoid pointing directly down the lens. In both variants check the held pose and its entry/exit at delivery size, without the subtitle giving away the answer. No finger animation is required.

**Contact card:** For a hand on a gate latch, identify palm or grip point rather than the arm-part origin; measure residual against the original latch target through the hold, including in-betweens. Name the coordinate space and studs tolerance before judging. Move body/staging if out of reach; do not move the target silently to obtain zero error. For a planted foot, distinguish a locked sole from an intentional toe pivot; `ak.ground` does not prevent horizontal slip. Recheck after camera/export changes and on the actual dressed R6 and R15 casts.

**Small-screen card:** Declare a real supported viewport; check crest, hand, badge and largest intended text occupancy together. A clear head center does not establish accessory clearance. Record “not tested on phone” when only a desktop crop exists; do not invent device validation.

## 4. Sound plan — not runtime-supported playback

The current kit does not supply end-to-end SFX/voice/Face cue dispatch. Keep this table as design or a clearly labeled editorial reference until separately implemented and tested. Do not invent `SFX` commands or claim an audio file was rendered.

| Cue / beat | Purpose and source/perspective | Onset / duration / timebase | Priority and mix relationship | Rights / playable asset evidence | Visual/caption equivalent | Status |
|---|---|---|---|---|---|---|
| Gate latch / B02 | Confirms route opens; at gate | Contact time, measured later | Yield under dialogue | Not selected/cleared | Visible latch/gate movement; caption if important and supported | Planned only |
| Guard line / B01 | Warns player while concealing doubt | Speech timing unknown; subtitle tested separately | Essential speech above decorative ambience | No voice provided | Supported subtitle, legible speaker identification | Text only |
| Ambience bridge | Preserve location across coverage | Span cut if editorially useful | Below essential speech/events | Pending | Not every decorative sound needs captioning | Planned only |

Decide whether silence or sound helps the beat; neither is mandatory. Future audio acceptance needs actual listening, synchronization, intelligibility and rights checks. Written dialogue is not evidence of audible dialogue.

## 5. A/B experiment

```text
Question / intended improvement:
Baseline take + build identity:
Variant take + build identity:
Only variable changed (hold vs cut, fixed vs moving, restrained vs accented):
Held constant (acting, duration where relevant, captions, viewport/settings):
Uninformed viewer question:
Prediction / what would disprove it:
Evidence seen/heard, exact intervals:
Observed response (do not infer unreported feelings):
Result: supported / falsified / inconclusive / not tested
Decision / disagreement / regression checks:
```

Do not label a variant “improved” before the comparison. If removing shake makes contact unreadable, fix body staging before restoring accents. If shortening a reaction hides the decision, retain the hold. Small informal samples diagnose issues; they are not population-level proof.

## 6. Acceptance and handoff

```text
Build/export/module and input identity:
Supported rigs / takes / viewport/settings / evidence paths:
Requirement | Test and evidence | Status | Owner / next action
Technical release blockers:
Evidence gaps / non-assessable criteria:
Craft findings tied to brief (criterion, timestamp, reason):
Actual independent scores, round and disagreement:
Rights/permissions and publication status:
Untested runtime/accessibility/device conditions:
Final status: draft / blocked / not assessable / accepted within named scope
```

Use [Review checklist](review-checklist.md) for gate order and [Reference analysis](reference-analysis.md) for evidence records. Keep the existing approval/export/review lifecycle; these worksheets improve decisions, not bypass it.
