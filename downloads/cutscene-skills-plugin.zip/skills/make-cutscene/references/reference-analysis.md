# Reference analysis: observations before interpretation

Method by fwjelaa (FWJ STUDIOS). Use the [brief](production-brief.md) to turn evidence into choices, not to disguise guesses as source facts.

## Capture a trustworthy record

1. Record file/URL, creator, permission/license, permitted adaptation uses and access method. Viewing access and catalog availability are not re-upload permission. Keep private references within the authorized workspace.
2. Inventory duration, dimensions, actual frame rate/timebase, variable-rate status and audio presence when tools can establish them. Record unknowns explicitly; subtitles do not prove audible speech.
3. Preserve source identity and the extraction method. For each sample retain requested seek time, actual decoded presentation timestamp (PTS), timebase and frame identifier where available. Rounded sheet labels are navigation aids, not exact timing evidence.
4. Begin with an overview, then sample densely around meaningful changes: gesture entry/hold/release, contact, reaction, cuts, accessory extrema and return. Samples leave gaps. Consecutive decoded frames are needed to identify an exact edit boundary; continuous permitted playback is needed for rhythm and smoothness.
5. Keep source time, recording time and authoring time separate. Document offsets and known alignment events before comparing them. Authoring uses 60 fps; never transfer frame-count recipes from another timebase without conversion. Do not infer matching-build identity from similar scene names.
6. Separate **observed**, **inferred**, **proposed**, and **not assessed** in every finding. State the evidence mode: article text, transcript, sheet, consecutive frames, continuous playback or actual listening.

```text
Evidence ID / source identity / creator / rights:
File or URL / build / take / cast variant:
Source timebase / requested seek / decoded PTS / displayed label:
Coverage and sampling gaps / output dimensions:
Observed (visible or audible fact):
Inferred (interpretation, confidence and alternative):
Proposed change / question that could falsify it:
Not assessed / evidence needed next:
```

## Worked example: GateGuard dialogue

The council inspected **three contact sheets extracted from two preview videos**: R15 overview, R15 dense interval and R6 overview. This was still-frame analysis, **not continuous playback or audio listening**. The source inventory reports no audio stream; this documentation pass did not independently probe it. The R6 preview label identifies the player/cast variant, not proof every actor is R6; the example guard is authored R15.

| Evidence / sampled time | Observed | Inference or proposed test | Not established |
|---|---|---|---|
| Overview, 0.283 / 0.850 / 1.417 s | Listener foreground, guard above stairs beneath gate | Preserve destination, height difference and landmarks | Walk speed or foot contact |
| Overview, 1.983–3.117 s samples | Projecting arm/hand mass accompanies “Halt. Nobody enters after dark.”; open palm not distinctly readable | Test stop meaning without text; separate whole arm from torso/face and avoid lens-axis foreshortening | Malformed hand, collision, or readability at all intervening frames |
| R15 dense, 4.900 s | Frontal composition; crest reaches or may clip upper edge | Inspect full-resolution crest extrema with actual mask/accessories | Definitive clipping from thumbnail |
| R15 dense, 4.950 s | First sampled low oblique view with sky/gate beams | Review paired attention location, facing and landmarks | Exact cut frame or a proven axis violation |
| R15 dense, 4.950–5.200 s samples; 5.250 s | No subtitle in earlier samples; second subtitle present at 5.250 s | Check if pre-line hold serves intention before shortening it | Audible silence, speech onset or emotion |
| Overview, 7.650 / 8.217 / 8.783 s | Wide geography returns; listener seen from behind | If decision matters, stage readable head/shoulder/root response or useful reaction coverage | Missing animation, emotional response or runtime restoration |

The observed framing change is **after 4.900 through 4.950 s**. Authored CLIMAX `start: 4.9` is intent evidence, not proof the recording cut occurred at 4.900. Alignment or build differences are possibilities, not verified explanations. Sampled changes in subject size cannot distinguish dolly from zoom or prove camera acceleration.

**Actionable comparison:** retain the useful gate/stair geography; compare baseline against one clearer stop silhouette, then separately against accessory-safe framing and a legible listener response. Keep each take's identity. Ask an uninformed viewer what happened rather than describing the intended improvement first. No A/B result is claimed here.

## Panels and words

Panels provide composition and event order, not measured motion timing or implied audio. Record panel identifiers and separate visible pose from inferred transition. One panel need not equal one cut; several can become one staged take. A written brief is intended action, not observed performance. Label invented connecting action as adaptation and obtain approval for material changes.

## Blocked or unavailable references

- A download failure is not permission to bypass authentication, rights controls or a paywall. Use authorized article/transcript access, ask for a permitted file, or document the gap.
- If an image request is rejected by a safety system, do not resubmit, transform or route that rejected material through another provider. Continue with an independently permissible reference or prose-only planning; do not import conclusions about imagery never inspected.
- Do not claim to have watched embedded talks from an abstract or read a complete page from snippets. Preserve exact source URLs and access limitations. Do not repeat blocked imagery in the deliverable.

## Sources and evidence trail

- Council GateGuard visual study (development archive; not bundled) — timestamped observations, manifests, verification and explicit limitations; repository-only research dependency, not required to execute the portable skill.
- R15 overview PTS manifest (development archive; not bundled), R15 dense PTS manifest (development archive; not bundled), R6 overview PTS manifest (development archive; not bundled) — decoded timing records from the study, not fresh playback by this author.
- [What is continuity editing in film - Adobe](https://www.adobe.com/creativecloud/video/hub/ideas/what-is-continuity-editing-in-film.html) — full article text extracted by research; no embedded visual analysis.
- [Blender Fundamentals 4.5 LTS: Camera Settings](https://studio.blender.org/training/blender-fundamentals-45-lts/blender_4-5_lts_camera-settings/) — lesson text extracted; video not watched.
- [Different types of shots and camera angles in film](https://www.adobe.com/creativecloud/video/production/cinematography/camera-shots-and-angles.html) — search-result text only; not a full article extraction.
