# Review checklist: release, evidence and craft are separate

Method by fwjelaa (FWJ STUDIOS). Use with the [rubric](../rubrics/cutscene.md), [method](../CLAUDE.md) and [acceptance worksheet](production-brief.md). Do not let a numeric median erase a technical failure, missing evidence or access barrier.

## A. Establish identity and technical eligibility

- Identify current beats, animation sources, captures, export, data module, costume specifications, rig variants, preview takes and settings. Preserve generated provenance records; never edit stamps to make stale evidence look current.
- Resolve kit/clip failures without disabling checks. Validate actual authorized installation and assets; keyless Studio playback does not establish published-game readiness.
- Test R15 and R6. Record actual end, permitted skip, death/respawn and console results, plus scene-specific triggers/replays and awakening wall/aura/power-down/onlooker/cooldown behavior. `playtest --set` records an operator result; it does not execute a test.
- Confirm camera/HUD/movement and costume restoration, ownership/permissions and safe gameplay return. Missing or failed required tests remain blockers regardless of craft score.
- Before connected authoring, run `python -B kit/authoring_audit.py <scene-directory>` from PACK (the directory must contain `beats.json`). This read-only standalone audit rejects unsupported executable capabilities; it is not a `run.py` subcommand and does not run automatically with gates. Advisory findings do not block. It does not certify live playback.
- Packet creation and scoring now rehash both preview clips, stamped sheets and packet contents. Packets include `preview_R15.mp4` and `preview_R6.mp4`; reviewers must actually open moving evidence. Hashes establish byte identity, not successful decoding, truthful capture provenance or good motion.
- Legacy evidence intentionally expires. Regenerate both previews and their stamped overviews, side-by-side sheets, applicable likeness and review packets using the operational workflow; obtain fresh reviews. Map additions, edits or deletion invalidate gate/evidence fingerprints. Rerun affected checks and downstream evidence; map-only edits do not by themselves require animation re-export. Never manually transplant hashes to bypass regeneration.

## B. Determine what the evidence can support

| Evidence | Can support | Cannot establish alone |
|---|---|---|
| Source or approved beat sheet | Intended timing, data and implementation | What actually played or what viewers understood |
| Contact sheets | Sampled composition, silhouette, captions, visible costume | Continuous timing/weight/sync, smoothness, comfort or sound |
| Matching decoded moving takes | Visible motion over reviewed intervals | Unseen runtime outcomes, untested devices or unplayed audio |
| Actual listening to an audio-bearing take | Audible content and sync in that setup | Rights, universal intelligibility or unsupported runtime audio integration |
| Recorded runtime probes/tests | Named behaviors in the tested build/context | Unexercised platforms, rigs or multiplayer conditions |

**Non-assessable is not zero.** If C2 timing/weight or C4 synchronization lacks moving evidence, record the gap and request the appropriate take. Do not manufacture numeric values to satisfy the parser or call a still-only packet a completed quality review. A zero is an observed poor result, not a missing observation. If the current packet/reviewer tool cannot expose the necessary media, stop complete scoring and hand off the evidence limitation; do not change criterion IDs or parser format.

## C. Review the craft

1. **Blind comprehension:** show the actual moving take without coaching intended emotion. Ask what happened, what each character wanted, where attention shifted and where play resumes; disclose the brief afterward.
2. **Staging and acting:** inspect primary silhouettes, stimuli/choices, listener responses, support/contact and consequence. Review clean body/camera staging before decorative accents. R6 derivation/override existence is not semantic acceptance.
3. **Framing and continuity:** inspect cuts, maximum gesture/accessory reach, first/last visible frames, eyelines, landmarks and gameplay return. Master head-center gates omit important hand/prop/accessory bounds and derived-R6 coverage.
4. **Timing:** watch full speed and focused intervals. Motivated stillness, long takes and soft acting can earn full marks. Test whether changes serve intention rather than counting cuts, snaps or effects.
5. **Delivery and access:** inspect actual mask/UI and small supported viewport, reading time, contrast and essential information without sound/color alone. Record untested localizations/devices. Reduced Motion retains base camera translation/FOV/cuts; flash-event counts are not final-composite analysis.
6. **Sound:** if only the planning worksheet exists, mark audio not implemented/not assessed. Written subtitles do not establish a mix or voice performance. Never expose sensitive reviewers to suspected hazardous flashing to test safety.

## D. Score only assessable work

Preserve C1–C6 and conditional C7, existing weights, three independent reviewers, the 8.5 median project target and maximum three fix rounds. Keep actual replies and disagreement. The parser's legacy hard-gate cap is not permission to release a blocked scene. A high score is a project summary, not certification of quality, accessibility, rights or safety.

Each finding needs exact take/rig, time or sampled frame, observed fact, relevance to the brief, confidence and smallest useful change. Use separate categories: **technical blocker**, **evidence gap**, **access barrier**, **comprehension issue**, **taste**. Technical blockers cannot be averaged away; stylistic disagreement is not automatically a safety defect.

```text
Review identity / revision / reviewer independence:
Evidence opened and mode (sheet / moving playback / listening / probe):
Observed interval and fact:
Intended result / interpretation / alternative explanation:
Category / affected criterion / confidence:
A/B variable / prediction / evidence required:
Observed outcome: supported / falsified / inconclusive / not tested
Regression checks and remaining disagreement:
```

## E. Deliver a scoped verdict

Report technical status, evidence sufficiency and craft outcome separately. Supply both rig previews, sources, current tests, actual scores when assessable, remaining blockers and next owner/action. “Draft,” “blocked,” and “not assessable” are useful honest outcomes. After the last fix round retain scores and previews; never relabel below-target or untested work finished.

The [capability reference](capabilities.md) identifies current implementation and accessibility limits; [reference analysis](reference-analysis.md) defines sampling/rights discipline. This checklist introduces no runtime support, automatic human review or new CLI interface.
