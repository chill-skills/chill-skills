# Movie-cinematic routing

Method by **fwjelaa (FWJ STUDIOS)**. This is an instruction bridge, not a new renderer, importer or runtime feature. Read [capabilities](capabilities.md), [animation bridge](animation-skill-bridge.md) and [review checklist](review-checklist.md) alongside it.

## Select the requested mode

When the user asks for a cinematic/movie-type scene, prioritize dramatic objectives, motivated coverage, listening and a readable return to play before spectacle. Load **both bundled siblings** below before blocking. Do not force this treatment onto every short intro, repeatable NPC exchange or stylized awakening; retain the requested tone and scope. Movie-like does not mean mandatory black bars, shallow focus, camera drift, frequent cuts or a fixed lens.

## Load instructions explicitly

| Need | Bundled instructions to read | Output |
|---|---|---|
| Movie-style scene, blocking, coverage, geography | [cinematic-scene-direction](../../cinematic-scene-direction/SKILL.md), then its coverage reference and direction packet | Objectives, attention/coverage map, continuity states |
| Performance, dialogue reactions, cut/hold, animatic comparison, handback | [cinematic-performance-editing](../../cinematic-performance-editing/SKILL.md), then its editorial reference and comparison record | Performance ledger, chosen edit rationale, evidence and handback plan |
| Cast motion on either rig | [Animation skill bridge](animation-skill-bridge.md) and available scoped directors | Supported pose scripts, calibrated motion and separate R15/R6 acceptance |
| Offline checks and review evidence | [Review checklist](review-checklist.md) | Separate technical, evidence and craft findings; no manufactured passes |

These siblings ship as files in this repository. If registered in the host, load by their exact names; otherwise read their linked `SKILL.md` files directly and follow the task-relevant references. Do not assume global installation or copy them into an active profile. If a partial distribution omitted a sibling, report it and use bundled [cinematic direction](cinematic-direction.md) and [production brief](production-brief.md) for a reduced planning fallback. If sibling make-anim is missing, connected authoring is blocked: it is a code dependency, unlike optional editorial expertise.

### Optional installed video-edit skills

Discover availability through the actual host registry. In Hermes, use `skill_view(name=...)` when that tool is exposed; other hosts use their own loader or file reader. Never invent a tool name or promise an unavailable editor.

| Task | Optional skill(s) | Bundled fallback |
|---|---|---|
| Scope an actual media edit and route its stages | `video-edit-hub`, `video-edit-brief` | Direction packet and current production brief |
| Story turn and rhythm | `video-edit-story-pacing`, `video-edit-cut-decisions` | Performance editing: information gained/lost, hold/cut comparison |
| Listening and spoken performance | `video-edit-dialogue` | Performance ledger; audio cleanup only in a supported external edit |
| Screen geography and action continuity | `video-edit-continuity` | Scene-direction continuity ledger |
| Audio bridges | `video-edit-split-edits` | Prose sound intentions; no new pack sound dispatch |
| Refine cut boundaries | `video-edit-trim-craft` | Animatic A/B record, caption/contact/cue recheck |

Load the hub and relevant installed specialists when available; do not require every skill for every task or install missing ones. Their external timeline/audio workflows do not establish interoperability with the pack. Bundled siblings contain enough planning guidance to proceed without them.

## Handoff sequence

1. Use the existing [brief](production-brief.md) to state before/after, objectives, viewpoint, audience knowledge, rights and supported output. Keep extra director metadata in authorized prose notes, **not invented `beats.json` fields**.
2. Direction produces blocking, minimum useful coverage, attention targets, continuity/prop/contact states and playable exit. Choose a fixed or moving view for a reason; test accessory and caption clearance with the actual rig and mask.
3. Performance editing identifies listening, subtext, reaction and consequence. Compare a held/shared-view animatic with alternative coverage only where it answers a real uncertainty. Preserve deliberate stillness and the time needed to read essential captions.
4. Apply the [animation bridge](animation-skill-bridge.md). Existing user R15/R6 directors retain authority within their calibration/authoring/export scopes. Translate intent into the pack's pose scripts; do not transplant foreign control names or replace source with a native clip/asset ID. Review derived R6 meaning and contact independently.
5. Map approved choices to supported beats and scripts, rebuild/export, then follow current checks and review. Camera and actor timing share the pack's 60 fps, full-scene, inclusive-endpoint contract. Keep source footage timing distinct. No standalone executable camera/pose recipe is introduced here.
6. Follow [review checklist](review-checklist.md) for the standalone authoring audit and evidence migration guidance. From PACK, its command is `python -B kit/authoring_audit.py <scene-directory>`; the target requires `beats.json`. This is **not** a `run.py` subcommand, scene execution, or engine acceptance. Preserve historical evidence instead of fabricating current review scores.
7. On authorized playback, verify both delivered rigs, captions, dressed framing, natural end, permitted skip, death/respawn and interrupted return. Record actual cleanup/control restoration; an orienting final view or offline suite cannot establish gameplay handback.

## Implementation boundaries that survive film language

- Sound, voice, facial performance and J/L-cut concepts remain **planning/editorial only** in this pack. No SFX/voice dispatch or new cue field is provided. A subtitle gap is not observed audible silence.
- `Slowmo` affects VFX time scaling, not a synchronized actor/camera/audio clock. Plan authored timing rather than inventing a global retiming command.
- Do not alter the real map, create competing camera/Animator owners, bypass permissions or assume clip viewing confers reuse rights.
- Reduced Motion and flash-event limits are partial; inspect actual output and disclose untested accessibility behavior. Do not expose sensitive reviewers to suspected hazards.
- Preserve the protected [CLAUDE.md](../CLAUDE.md) reconciliation warning in the main skill. Corrected references supplement its valid operational/safety instructions; this document does not authorize editing it.

## Evidence provenance

Read [research-derived lessons](movie-research-lessons.md) for the relayed Piano/Jurassic nominal scrub-preview evidence and GOW/LIS decoded-still evidence, including one LIS consecutive-frame cut. Neither study establishes continuous viewing, sound or restored game input. The siblings now include original worked proposals, per-character/audience knowledge maps and reaction-exit fields; these are testable prose guidance, not runtime schema or proven audience outcomes.

Prior council craft research (development archive; not bundled) remains abstract-level for GDC talks; the GateGuard study (development archive; not bundled) remains sampled stills. Preserve source/rights and nominal-versus-PTS distinctions; do not redistribute study media. The initial integration report (development archive; not bundled) records the earlier pending state; the research integration review (development archive; not bundled) records this follow-up and its limits.
