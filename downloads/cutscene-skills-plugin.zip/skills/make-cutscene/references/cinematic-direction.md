# Cinematic direction: meaning before treatments

Method by fwjelaa (FWJ STUDIOS). Use with the [brief and worksheets](production-brief.md), [capability boundary](capabilities.md) and [animation bridge](animation-skill-bridge.md). These are testable craft heuristics, not universal aesthetic gates or new runtime features.

## 1. Direct a change

Write what changes in knowledge, intention, relationship or physical advantage. A beat is that change, not necessarily a cut. Identify the viewpoint owner and playable state before/after: position, heading, objective, control and danger. Block the essential information before decorative motion.

For each character write **objective → stimulus → interpretation → choice → visible action**. Separate the spoken line from its subtext. Include listening: a guard's paused routine or a listener yielding space may communicate more than another talking-hand pose. A held attitude can change meaning through the other character's response. Stillness must carry intention, not disguise unfinished animation.

**Test:** show an uninformed viewer the permitted moving take and ask what each character wanted and when it changed. Then reveal the brief. If spoken wording is essential, do not demand impossible silent comprehension; check that visible attitude supports it. Do not infer an emotion the viewer did not report.

## 2. Stage action and soft acting differently

For physical action, annotate preparation, commitment, decisive contact, reaction and recovery. These are meanings, not fixed frame recipes. Surprise may hide preparation; consequence must still read. Separate limb/weapon and target, show force direction and weight transfer, and reserve the strongest accent for the event that changes the encounter.

For hesitation or grief, a softened settle, delayed head turn or interrupted reach may be the decisive event. Do not add a snap merely to satisfy an action-oriented rubric. Avoid constant idle noise and symmetric gestures unless character-specific. Body-only rigs communicate through head/torso direction, hands, distance and prop tasks; that is not facial animation.

**Rig example:** a stopping palm can use elbow bend on R15; R6 needs a straight-arm silhouette plus torso/head staging. Avoid aiming the arm into the lens or hiding it against the chest. Judge the meaning without subtitles, then restore actual captions and inspect their occupancy. Re-author R6 rather than assuming derived rotations preserve intent.

**Contact example:** a planted sole must stay near its original support-space target over the declared interval, including midpoints. Ground height is not horizontal locking. For a hand on a latch, inspect the grip point and orientation, not the arm origin; move body/staging if unreachable. Declare tolerances before measurement and record intentional pivots/releases.

**Accent test:** compare body-only and accented takes. If shake or flash is the only evidence of contact, repair staging first. Current `Slowmo` scales VFX, not the entire actor/camera/audio clock; use authored holds where appropriate, not fictional hit-stop commands.

## 3. Give each shot a job

Write “Look here, because…” and “This reveals or withholds…”. Choose distance, scale, height, angle, foreground and movement from the answer. A shared two-shot may show a relationship better than automatic reverses; a close shot may isolate a consequential detail. A fixed camera can be the strongest choice.

- Move to reveal, follow meaningful action, alter proximity or express viewpoint, not because every shot must move.
- FOV is only one variable. Camera distance, rig size and viewport determine the actual composition.
- Track screen directions, look directions and landmarks. Crossing the axis deliberately is possible; a hard cut does not itself clarify new geography.
- At each cut compare outgoing/incoming attention position, facing direction, action phase and landmarks. A large eye-trace jump is a review question, not automatic failure.
- Frame head **and** accessory extrema, acting hand and story prop within the actual mask/UI. Head-center gates are incomplete, and derived R6 needs separate visual review.
- At the smallest supported viewport, ask what viewers notice first. Simplify background competition or staging before enlarging effects. A desktop crop is not a tested phone build.

**GateGuard lesson:** sampled 1.983–3.117 s views show an arm mass whose stopping meaning is helped by “Halt”; strengthen the silhouette. At sampled 4.900 s, crest clearance is questionable, requiring full-resolution inspection. The framing change is bracketed **after 4.900 through 4.950 s**, not an established edit at 4.900. See [evidence limitations](reference-analysis.md).

## 4. Cut on information, not a stopwatch

Make a blocking animatic before polishing curves. A long take can contain several changes of attention and relationship; fast coverage still needs orientation. Cut when a new view helps information, emotion, concealment, rhythm or continuity. Cuts on action are useful options, not mandatory. A listener's response can justify coverage before, during or after a line.

Compare hold versus cut while keeping the dramatic goal fixed. Remove redundant information, not the only evidence of a thought. Reaction is not a synonym for “very short.” Allow caption reading and response time. A musical beat may support an edit but does not override comprehension; audio is currently planning-only in this kit.

**GateGuard lesson:** the return-wide samples at 7.650, 8.217 and 8.783 s preserve gate/stair geography but do not establish listener emotion from behind. If a decision matters, stage a visible head/shoulder/root change or add useful reaction coverage. This is an evidence gap, not proof of absent animation. Preserve readable gameplay heading on return and test actual restoration separately.

## 5. Select sound and accessibility deliberately

Use the [sound worksheet](production-brief.md) to assign story purpose, perspective, onset, duration, priority, mix relationship, rights and visual/caption equivalent. Silence is an option, not a compulsory pre-impact formula. Do not promise SFX/voice playback: the current Director lacks end-to-end dispatch.

Respect reduced optional effects, text/contrast needs and essential information without sound/color alone. Current Reduced Motion does not remove authored camera travel, cuts or FOV motion. Flash-event limits do not analyze every rendered luminance reversal. Test actual output and report untested settings; never use sensitive participants to discover suspected hazards by exposure. Calmer paths, new caption controls or synchronized sound require separately scoped implementation.

## 6. Iterate with a falsifiable question

Change one disputed choice at a time; keep identities and observations in the [A/B record](production-brief.md). “More cinematic” is not a measurable finding. “The listener's choice is unreadable at this interval on this viewport” is actionable. Keep disagreement, counterexamples and inconclusive results. Technical blockers, missing evidence and craft ratings are separate verdicts; use the [review checklist](review-checklist.md).

## Sources and access limits

Synthesized from council research, not fresh viewing by this documentation pass. GDC abstracts were read, **not full talks**. Local GateGuard lessons come from three inspected contact sheets extracted from two preview videos, not continuous playback/audio. Practitioner guidance informs hypotheses, not guaranteed quality.

- [Keyframes and Cardboard Props: The Cinematic Process Behind 'God of War'](https://gdcvault.com/play/1026025/Keyframes-and-Cardboard-Props-The) — official abstract: no-cut camera/previs; counters compulsory cuts, not proof every scene needs a long take.
- [Behind the Scenes: Uncharted 2's Unique Cinematic Production Process](https://gdcvault.com/play/1012327/Behind-the-Scenes-Uncharted-2) — official abstract only; integrated writing/animation process.
- [10 Advanced Acting Performance Tips for Animators](https://www.animationmentor.com/blog/10-advanced-acting-performance-tips-for-animators/) — accessible opening sections on stillness and acting within a pose, not a complete extraction.
- [How to Approach an Acting Test](https://www.animationmentor.com/blog/how-to-approach-an-acting-test/) — article read; motivation/subtext, not rights clearance.
- [Eight Hit Stop Techniques [Design Specifics]](https://www.youtube.com/watch?v=tycbMSjDDLg) — official metadata/Japanese transcript with indexed translations; no visual analysis. Smash-specific, not a Roblox timing rule or camera-shake prescription.
- [Introduction to film grammar](https://www.khanacademy.org/computing/pixar/storytelling/film-grammar/v/film-grammar-overview) and [Glossary: Film grammar](https://www.khanacademy.org/computing/pixar/storytelling/film-grammar/a/glossary-grammar) — indexed transcript/definition excerpts; direct extraction challenge, no shot-level viewing claims.
- [Aural Immersion: Audio Technology in The Last of Us](https://www.gdcvault.com/play/1020444/Aural-Immersion-Audio-Technology-in) — indexed official abstract; direct extraction login/paywall. No full talk or attributed mix algorithm.
- [What is continuity editing in film - Adobe](https://www.adobe.com/creativecloud/video/hub/ideas/what-is-continuity-editing-in-film.html) — full article text; axis, eyelines, eye trace.
- [Solid Drawing: The 12 Basic Principles of Animation](https://www.animationmentor.com/blog/solid-drawing-the-12-basic-principles-of-animation/) — full article text; silhouette, thumbnails, balance.
- [Sprite Fright: Set Dressing Tips](https://studio.blender.org/blog/sprite-fright-set-dressing-tips/) — production article text. Apply layout/contact lessons without editing the player's read-only real map.
