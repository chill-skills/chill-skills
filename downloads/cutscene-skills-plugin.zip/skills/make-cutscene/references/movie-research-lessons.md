# Research-derived cinematic lessons

Method by **fwjelaa (FWJ STUDIOS)**. This is a compact instruction-only synthesis of relayed visual research, not a new viewing, runtime feature or acceptance result. Original worked proposals live in [scene direction](../../cinematic-scene-direction/references/coverage-and-geography.md) and [performance editing](../../cinematic-performance-editing/references/performance-and-edit-decisions.md).

## Evidence → testable choice

| Reported observation | Proposed lesson, not proven effect | Limit |
|---|---|---|
| Piano: nominal 15–28 s social triangle; 29–35 s recipient/partner-context compositions. | Map audience/each character's knowledge before → after; preserve the response that changes meaning. Compare shared hold against listener coverage. | Speech alignment, private thought, continuous holds and exact cuts unknown. |
| Jurassic: nominal 32–48 s changed human attention; 50 s shared clearing with vehicle/people and dinosaur. | Withhold cause only for a reason; reveal its relation to established people/landmarks. A small object or doorway can serve the same job. | Samples do not establish exact reveal frame, tilt path or reaction duration. |
| GOW: decoded excerpt samples 48–78 s show attention/scale change, doorway depth and path-oriented staging. | Test a shared-staging alternative before adding an insert; let existing thresholds explain destination. | No proof of an unbroken take, camera mechanics or control handback. |
| LIS: sampled group/isolated coverage; one consecutive-frame cut; later rear framing and objective UI. | Test whether a listener insert adds needed information; separate visual handback from actual restoration. | No aligned speech, audio bridge, emotional response or input verification. |

For every reaction record a **readable exit condition** (decision, necessary caption reading, next-action clarity), then test timing in the authored build. No fixed reaction duration or source-frame recipe follows from this research. Distinguish observation, interpretation and proposed adaptation in the [direction packet](../../cinematic-scene-direction/templates/direction-packet.md) and [edit comparison](../../cinematic-performance-editing/templates/edit-comparison.md).

## Timing and provenance

- **Movie study:** Piano previews at nominal 12–48 s, 1 s interval, 160×90; Jurassic at nominal 12–76 s, 2 s interval, 320×180. Labels derive from storyboard tile indices, **not decoded PTS**. Piano samples 39–48 are packaging, not dramatic exit. Sparse composition changes only bracket candidate edits.
- **Game study:** decoded 1280×720 excerpts; GOW average rate 30000/1001, timebase 1/30000; LIS 60/1, timebase 1/15360. Requested excerpt starts were source zero, but source alignment is nominal, not independently verified. Retain requested seconds separately from actual decoded PTS/file identity.
- **LIS's one resolved cut:** outgoing PTS 2352384 (153.150000 s), incoming PTS 2352640 (153.166667 s), timebase 1/15360, in the retained excerpt. This is not a general reaction-length rule or a speech-onset measurement.
- Neither study included continuous viewing, listening or game-input observation. Game excerpts were video-only; absence of audio streams is not artistic silence. Full manifests and limitations remain in the movie report (development archive; not bundled) and game report (development archive; not bundled); these repository links are supplemental provenance, not production assets.

## Boundaries that must survive adaptation

- Use **original prose and re-authored staging**, not source dialogue, imagery, animation, characters or sound. Official/public access is not permission to adapt, redistribute or upload; rights remain uncleared. Keep local research media out of portable skills and Roblox assets.
- Preserve [capabilities](capabilities.md), existing gates/fix-round limits and [animation bridge](animation-skill-bridge.md). Worksheets add no `beats.json` fields, imports or cue dispatch. Approved source authoring remains 60 fps, full-scene/inclusive endpoints, within the documented duration contract; never copy nominal preview times into it.
- Re-author body-only R6 meaning and contact independently; no fingers/elbows/facial performance promise. Separate current-build R15/R6 evidence is mandatory. Derived player R6 is stock/default stand, not captured-player-proportion support.
- Text is supported; voice/SFX/facial/J/L-cut intentions remain editorial prose. Use existing set states rather than promising environment-changing scenes. Fixed framing is valid; Reduced Motion does not remove all authored camera travel, cuts or FOV animation.
- A route-readable final view is **visual preparation only**. Authorized normal-end, permitted-skip, death/respawn and interrupted-return tests must exercise actual movement/look, camera state and owned cleanup. Respect unskippable scenes; neither source footage nor offline checks certify handback.

## Official source links

These links identify sources inspected by the research workers, not a fresh network verification in this integration pass.

- [PRIDE & PREJUDICE (2005) - “Piano” Official Clip](https://www.youtube.com/watch?v=lcHtdtT9YU0) — Focus Features; public scrub previews.
- [Jurassic Park | Welcome to Jurassic Park In 4K HDR](https://www.youtube.com/watch?v=jiw0TcGV7Hk) — Jurassic World; public scrub previews, not a 4K/HDR analysis.
- [A Solitary Classic: Joe Wright’s Pride & Prejudice Turns 15](https://www.focusfeatures.com/article/joe-wright_jane-austen_joys-of-solitude) — official text supports relational interpretation, not performance timing.
- [God of War - E3 2016-Gameplay-Demo [PS4]](https://www.youtube.com/watch?v=6SIwvWrHAXk) — PlayStation DACH; decoded still evidence.
- [Life is Strange: Double Exposure – Extended Gameplay (ESRB)](https://www.youtube.com/watch?v=Tduc_auVpeo) — Life is Strange; decoded stills and the one adjacent-frame boundary.
