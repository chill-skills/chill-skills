# GateGuard (demo, data only)

Method by fwjelaa (FWJ STUDIOS). This folder holds the data of the walk-in demo, no media: `beats.json`, `anim/*.py`
(the acting and the camera), `GateGuard.luau` (the written data module), and `set/gate_set.luau` (the first,
hand-built set, kept only as a fallback; the shipped version uses the make-map build below).

## What the scene is

A story scene, 9.05 s, walk-in zone. A guard on the top step of a ruined shrine gate at dusk stops the player. Two
lines: "Halt. Nobody enters after dark." and "Turn back now, or I make you." Five shots: wide establish, a push-in on
the guard, a hard cut with a shake to a low-angle climax on the second line, a wide aftermath from behind the player,
and a return that eases back to the player's camera. R15 and R6 players both work.

## How it was made

- **Set.** The make-map build "shrine-gate-dusk" (Workspace.Map_shrine-gate-dusk), captured by the kit
  (`studio <Id> anchor`, `map`, `chunk`). The old hand-built `Workspace.Gate` set is in `set/gate_set.luau`.
- **Three guard lights that are NOT in the map's build file.** They live in `Map_shrine-gate-dusk.GuardLights` in the
  demo place, each a 0.4 stud cube (Transparency 1, Anchored, no collision, no shadow) with a SpotLight on its Front
  face. A rebuild of the map drops them: set lights belong in the map's own build.

  | Part | Position (studs) | Aimed at | SpotLight |
  |---|---|---|---|
  | GuardKey (warm key, camera side, above) | (3.5, 14.5, -141.0) | (0, 11, -147.3), chest and helmet | Color (255, 190, 130), Brightness 3, Range 16, Angle 45, Shadows false |
  | GuardRim (cool rim, behind, upper left) | (-2.5, 14.5, -151.8) | (0, 11.3, -147.3) | Color (150, 185, 255), Brightness 2.5, Range 12, Angle 60, Shadows false |
  | GuardFill (soft warm fill, just below the face) | (1.8, 9.2, -142.3) | (0, 10.8, -147.3), the mask | Color (255, 205, 165), Brightness 2.2, Range 11, Angle 60, Shadows false |

- **The guard.** A map NPC (Gate/Guard, hidden while the scene runs and replaced by a cast copy), dressed by hand from
  the Roblox marketplace with a HumanoidDescription (nothing bought):
  - helmet 95484542421857 "Samurai Helmet" (Nexus Exchange);
  - armour 117362897615815 "Black Samurai Armor" (Nexus Exchange, layered jacket);
  - hakama 131254524112441 "Hakama Type A (Black)" (Haririkuro's house, layered pants);
  - katana 93624803291644 "Realistic Traditional Samurai Katana - Waist" (Only Costumes);
  - face 78267893394166 "Samurai Menpo Mask" (90s Tapes, 72 R$); backup 125179188636251 "Steel Fang Mempo".
- **Acting and camera** are `anim/*.py` (guard `npc1.py`, `player.py`, `player_R6.py`, `camera.py`). The camera stays
  on the player's right so the guard always looks screen-left; the climax is a low angle from the guard's left because
  a pointing arm aimed at the lens covers his face.
- **Uploaded clips** (TJ's own uploads, from `export/ids.json`; they only matter for his Open Cloud account):
  Stage 124257925717155, npc1 R15 108110773493697, player R15 118484303172480, player R6 126169698004626. A new
  owner must run `upload` again.

## Checks measured

- Kit checks: all clear. Play tests on R15 and R6: end, skip and death all pass. A cold first play gave
  `cues=Letterbox,...` at T=5 for both rigs. Record and preview sync: scene start 5.17-5.18 s in a 25.98 s take,
  announced at 0.41 s.

## Blind score: NOT PASSED

| Round | Scores | Median |
|---|---|---|
| 1 | 6.4 / 5.7 / 5.7 | 5.7 |
| 2 | 5.7 / 6.8 / 6.4 | 6.4 |
| 3 | 8.2 / 6.8 / 7.5 | 7.5 |

The bar is 8.5. The blocking criterion is C2, timing and weight (1 of 2 in every round): the guard is nearly static
between the push-in and the climax, and the player barely moves in shot 4. Reported as it is, never called done.

What the reviewers asked for:
- a bigger, snappier guard acting in the holds (anticipation, snap, commit);
- a visible player turn with a weight shift in shot 4;
- a return shot that eases instead of cutting;
- the guard's arm mass near the lens at about 2 s cleaned up;
- the player's white top no longer blowing out (over-bright in the wides);
- an impact frame or accent on the climax cut (suggested once).
