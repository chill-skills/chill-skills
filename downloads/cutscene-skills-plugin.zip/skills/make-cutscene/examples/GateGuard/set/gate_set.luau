-- gate_set.luau: rebuilds the GateGuard demo set (Workspace.Gate), its guard and the place lighting in "cuttt".
-- Dumped from the live place on 2026-11-08 (Task 23), because the place was never saved. Method by fwjelaa (FWJ STUDIOS).
-- Run it with execute_luau (Edit) or paste it into the Command Bar. It is re-runnable: set OPTIONS below (or put a table
-- in _G.GateSetOptions before running, which wins over OPTIONS).
--   replace  false: refuse when <parent>.<name> already exists; true: destroy it and build again
--   lighting "new": the dusk look Task 22 set (the live state when dumped); "old": the values before Task 22;
--            "keep": leave Lighting alone
--   guard    true: build the guard at his post (Workspace.Gate.Guard, the cast npc1 of GateGuard)
--   dress    "marketplace": catalog items by asset id (Task 23, TJ's ruling); "oldgear": the 22 built parts Task 22
--            welded on (helmet, mask, plates, katana; TJ called them "buns"); "none": armour colours only
-- Every part is a plain anchored Part; nothing here needs HTTP. The guard is a default R15 (all body ids 0, the
-- default scales) from a HumanoidDescription, so the GateGuard clips keep fitting his rig.
local OPTIONS = {
	parent = workspace,
	name = "Gate",
	replace = false,
	lighting = "new",
	guard = true,
	dress = "marketplace",
}

-- { group, name, shape, sx, sy, sz, 12 CFrame components, colour hex, material, transparency, reflectance, flags }
-- flags: A Anchored, C CanCollide, S CastShadow, Q CanQuery, T CanTouch, M Massless
local PARTS = {
	{ "Ground", "Path", "Block", 6, 1, 46.5, 0,-0.45,-113.25,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Ground", "CourtLeft", "Block", 23, 1, 46.5, -14.5,-0.45,-113.25,1,0,0,0,1,0,0,0,1, "767a68", "Cobblestone", 0, 0, "ACSQT" },
	{ "Ground", "CourtRight", "Block", 23, 1, 46.5, 14.5,-0.45,-113.25,1,0,0,0,1,0,0,0,1, "767a68", "Cobblestone", 0, 0, "ACSQT" },
	{ "Ground", "GrassBack", "Block", 120, 1, 63.5, 0,-0.45,-168.25,1,0,0,0,1,0,0,0,1, "58823e", "Grass", 0, 0, "ACSQT" },
	{ "Ground", "GrassLeft", "Block", 34, 1, 46.5, -43,-0.45,-113.25,1,0,0,0,1,0,0,0,1, "58823e", "Grass", 0, 0, "ACSQT" },
	{ "Ground", "GrassRight", "Block", 34, 1, 46.5, 43,-0.45,-113.25,1,0,0,0,1,0,0,0,1, "58823e", "Grass", 0, 0, "ACSQT" },
	{ "Ground", "GrassFront", "Block", 120, 1, 50, 0,-0.45,-65,1,0,0,0,1,0,0,0,1, "58823e", "Grass", 0, 0, "ACSQT" },
	{ "Ground", "LooseStone1", "Block", 2.2, 0.3, 1.8, -8,0.08,-126,0.9391,0.0328,0.342,-0.017,0.9986,-0.0492,-0.3432,0.0404,0.9384, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Ground", "LooseStone2", "Block", 1.8, 0.3, 1.5, 9.5,0.08,-121,0.818,-0.0429,-0.5736,0.0723,0.997,0.0286,0.5706,-0.0649,0.8187, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Ground", "LooseStone3", "Block", 2.4, 0.3, 2, -11,0.06,-108,0.6427,-0.0112,0.766,0.0442,0.9988,-0.0224,-0.7649,0.0483,0.6424, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Ground", "LooseStone4", "Block", 1.6, 0.3, 1.6, 12,0.06,-104,0.9653,-0.0337,0.2588,0.0213,0.9985,0.0506,-0.2601,-0.0433,0.9646, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Steps", "Platform", "Block", 20, 1.2, 9.5, 0,0.65,-141.25,1,0,0,0,1,0,0,0,1, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Steps", "StepUpper", "Block", 14, 0.8, 1, 0,0.45,-136,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Steps", "StepLower", "Block", 14, 0.4, 1, 0,0.25,-135,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "WallL1", "Block", 10, 7.95, 2, -29,4.025,-140,1,0,0,0,1,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "WallL2", "Block", 12, 12.45, 2, -18,6.275,-140,1,0,0,0,1,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "WallL3", "Block", 8, 13.95, 2, -8,7.025,-140,1,0,0,0,1,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "WallR3", "Block", 8, 13.95, 2, 8,7.025,-140,1,0,0,0,1,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "WallR2", "Block", 10, 10.45, 2, 17,5.275,-140,1,0,0,0,1,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "WallR1", "Block", 12, 12.95, 2, 28,6.525,-140,1,0,0,0,1,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "Lintel", "Block", 8, 3.5, 2.2, 0,12.25,-140,1,0,0,0,1,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "CopingCentre", "Block", 25, 0.6, 3.2, 0,14.3,-140,1,0,0,0,1,0,0,0,1, "282c36", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "CopingL2", "Block", 12.4, 0.5, 3, -18,12.75,-140,1,0,0,0,1,0,0,0,1, "282c36", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "CopingR1", "Block", 12.4, 0.5, 3, 28,13.25,-140,0.9986,-0.0523,0,0.0523,0.9986,0,0,0,1, "282c36", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "BrokenL1a", "Block", 2.5, 1.8, 2, -31,8.6,-140,0.9659,-0.2588,0,0.2588,0.9659,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "BrokenL1b", "Block", 2, 1.2, 2, -26.5,8.4,-140,0.9848,0.1736,0,-0.1736,0.9848,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "BrokenR2a", "Block", 2.4, 1.6, 2, 14.5,11.2,-140,0.9511,0.309,0,-0.309,0.9511,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "BrokenR2b", "Block", 2, 1.2, 2, 19.5,11,-140,0.9781,-0.2079,0,0.2079,0.9781,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "Rubble1", "Block", 2.2, 1.1, 1.8, 15,0.6,-136.8,0.9029,-0.079,0.4226,0.1449,0.9814,-0.1261,-0.4048,0.1751,0.8975, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "Rubble2", "Block", 1.6, 0.9, 1.4, 18.2,0.45,-135.6,0.8529,-0.1504,-0.5,0.1736,0.9848,0,0.4924,-0.0868,0.866, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "Rubble3", "Block", 1.2, 0.6, 1, 16.5,0.35,-134.4,0.5,0,0.866,0.0755,0.9962,-0.0436,-0.8627,0.0872,0.4981, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "Rubble4", "Block", 1.8, 1, 1.6, 20,0.5,-137.4,0.9752,0.1371,0.1736,-0.1564,0.9823,0.1029,-0.1565,-0.1275,0.9794, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "Rubble5", "Block", 2, 1, 1.7, -29,0.5,-137.5,0.9345,-0.0982,-0.342,0.0805,0.9946,-0.0655,0.3466,0.0337,0.9374, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "Rubble6", "Block", 1.4, 0.8, 1.2, -26,0.4,-136.2,0.765,-0.0401,0.6428,-0.0038,0.9978,0.0668,-0.644,-0.0535,0.7631, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Wall", "DoorLeft", "Block", 3.95, 9.25, 0.5, -1.99,5.875,-140.6,1,0,0,0,1,0,0,0,1, "6e4628", "WoodPlanks", 0, 0, "ACSQT" },
	{ "Wall", "DoorRight", "Block", 3.95, 9.25, 0.5, 1.99,5.875,-140.6,1,0,0,0,1,0,0,0,1, "6e4628", "WoodPlanks", 0, 0, "ACSQT" },
	{ "Wall", "DoorBandHigh", "Block", 8, 0.35, 0.6, 0,7.5,-140.3,1,0,0,0,1,0,0,0,1, "221e20", "Metal", 0, 0, "ACSQT" },
	{ "Wall", "DoorBandLow", "Block", 8, 0.35, 0.6, 0,3.5,-140.3,1,0,0,0,1,0,0,0,1, "221e20", "Metal", 0, 0, "ACSQT" },
	{ "Torii", "PlinthL", "Block", 2.4, 0.9, 2.4, -5.5,1.7,-138.6,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Torii", "PillarL", "Block", 1.5, 12.45, 1.5, -5.5,8.375,-138.6,1,0,0,0,1,0,0,0,1, "a8241e", "Wood", 0, 0, "ACSQT" },
	{ "Torii", "SleeveL", "Block", 1.8, 1, 1.8, -5.5,2.65,-138.6,1,0,0,0,1,0,0,0,1, "221e20", "SmoothPlastic", 0, 0, "ACSQT" },
	{ "Torii", "BeamEndL", "Block", 3, 0.9, 1.7, -10.2,16.25,-138.6,0.9848,0.1736,0,-0.1736,0.9848,0,0,0,1, "221e20", "Wood", 0, 0, "ACSQT" },
	{ "Torii", "LanternL", "Block", 1.1, 1.5, 1.1, -3,10.9,-138.6,1,0,0,0,1,0,0,0,1, "f0783c", "Neon", 0, 0, "ACSQT" },
	{ "Torii", "LanternTopL", "Block", 1.2, 0.18, 1.2, -3,11.74,-138.6,1,0,0,0,1,0,0,0,1, "221e20", "SmoothPlastic", 0, 0, "ACSQT" },
	{ "Torii", "LanternFootL", "Block", 1.2, 0.18, 1.2, -3,10.06,-138.6,1,0,0,0,1,0,0,0,1, "221e20", "SmoothPlastic", 0, 0, "ACSQT" },
	{ "Torii", "PlinthR", "Block", 2.4, 0.9, 2.4, 5.5,1.7,-138.6,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Torii", "PillarR", "Block", 1.5, 12.45, 1.5, 5.5,8.375,-138.6,1,0,0,0,1,0,0,0,1, "a8241e", "Wood", 0, 0, "ACSQT" },
	{ "Torii", "SleeveR", "Block", 1.8, 1, 1.8, 5.5,2.65,-138.6,1,0,0,0,1,0,0,0,1, "221e20", "SmoothPlastic", 0, 0, "ACSQT" },
	{ "Torii", "BeamEndR", "Block", 3, 0.9, 1.7, 10.2,16.25,-138.6,0.9848,-0.1736,0,0.1736,0.9848,0,0,0,1, "221e20", "Wood", 0, 0, "ACSQT" },
	{ "Torii", "LanternR", "Block", 1.1, 1.5, 1.1, 3,10.9,-138.6,1,0,0,0,1,0,0,0,1, "f0783c", "Neon", 0, 0, "ACSQT" },
	{ "Torii", "LanternTopR", "Block", 1.2, 0.18, 1.2, 3,11.74,-138.6,1,0,0,0,1,0,0,0,1, "221e20", "SmoothPlastic", 0, 0, "ACSQT" },
	{ "Torii", "LanternFootR", "Block", 1.2, 0.18, 1.2, 3,10.06,-138.6,1,0,0,0,1,0,0,0,1, "221e20", "SmoothPlastic", 0, 0, "ACSQT" },
	{ "Torii", "Nuki", "Block", 15.6, 0.9, 0.9, 0,12.2,-138.6,1,0,0,0,1,0,0,0,1, "a8241e", "Wood", 0, 0, "ACSQT" },
	{ "Torii", "Shimaki", "Block", 16.4, 0.8, 1.3, 0,15,-138.6,1,0,0,0,1,0,0,0,1, "a8241e", "Wood", 0, 0, "ACSQT" },
	{ "Torii", "Kasagi", "Block", 18, 1, 1.7, 0,15.9,-138.6,1,0,0,0,1,0,0,0,1, "221e20", "Wood", 0, 0, "ACSQT" },
	{ "Torii", "Plaque", "Block", 1.6, 1.85, 0.35, 0,13.62,-138.3,1,0,0,0,1,0,0,0,1, "221e20", "SmoothPlastic", 0, 0, "ACSQT" },
	{ "Torii", "PlaqueRim", "Block", 1.9, 2.1, 0.2, 0,13.62,-138.5,1,0,0,0,1,0,0,0,1, "d4aa46", "Metal", 0, 0, "ACSQT" },
	{ "Lanterns", "Base1", "Block", 1.8, 0.5, 1.8, -6.5,0.3,-125,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Shaft1", "Block", 0.7, 2.4, 0.7, -6.5,1.75,-125,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Deck1", "Block", 1.6, 0.35, 1.6, -6.5,3.125,-125,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Fire1", "Block", 1, 0.95, 1, -6.5,3.775,-125,1,0,0,0,1,0,0,0,1, "ffb45a", "Neon", 0, 0, "ACSQT" },
	{ "Lanterns", "Roof1", "Block", 2.2, 0.45, 2.2, -6.5,4.475,-125,0.7071,0,0.7071,0,1,0,-0.7071,0,0.7071, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Finial1", "Block", 0.5, 0.55, 0.5, -6.5,4.975,-125,0.7071,0,0.7071,0,1,0,-0.7071,0,0.7071, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Base2", "Block", 1.8, 0.5, 1.8, 6.5,0.3,-125,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Shaft2", "Block", 0.7, 2.4, 0.7, 6.5,1.75,-125,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Deck2", "Block", 1.6, 0.35, 1.6, 6.5,3.125,-125,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Fire2", "Block", 1, 0.95, 1, 6.5,3.775,-125,1,0,0,0,1,0,0,0,1, "ffb45a", "Neon", 0, 0, "ACSQT" },
	{ "Lanterns", "Roof2", "Block", 2.2, 0.45, 2.2, 6.5,4.475,-125,0.7071,0,0.7071,0,1,0,-0.7071,0,0.7071, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Finial2", "Block", 0.5, 0.55, 0.5, 6.5,4.975,-125,0.7071,0,0.7071,0,1,0,-0.7071,0,0.7071, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Base3", "Block", 1.8, 0.5, 1.8, -6.5,0.3,-113,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Shaft3", "Block", 0.7, 2.4, 0.7, -6.5,1.75,-113,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Deck3", "Block", 1.6, 0.35, 1.6, -6.5,3.125,-113,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Fire3", "Block", 1, 0.95, 1, -6.5,3.775,-113,1,0,0,0,1,0,0,0,1, "ffb45a", "Neon", 0, 0, "ACSQT" },
	{ "Lanterns", "Roof3", "Block", 2.2, 0.45, 2.2, -6.5,4.475,-113,0.7071,0,0.7071,0,1,0,-0.7071,0,0.7071, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Finial3", "Block", 0.5, 0.55, 0.5, -6.5,4.975,-113,0.7071,0,0.7071,0,1,0,-0.7071,0,0.7071, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Base4", "Block", 1.8, 0.5, 1.8, 6.5,0.3,-113,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Shaft4", "Block", 0.7, 2.4, 0.7, 6.5,1.75,-113,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Deck4", "Block", 1.6, 0.35, 1.6, 6.5,3.125,-113,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Fire4", "Block", 1, 0.95, 1, 6.5,3.775,-113,1,0,0,0,1,0,0,0,1, "ffb45a", "Neon", 0, 0, "ACSQT" },
	{ "Lanterns", "Roof4", "Block", 2.2, 0.45, 2.2, 6.5,4.475,-113,0.7071,0,0.7071,0,1,0,-0.7071,0,0.7071, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "Finial4", "Block", 0.5, 0.55, 0.5, 6.5,4.975,-113,0.7071,0,0.7071,0,1,0,-0.7071,0,0.7071, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "FallenBase", "Block", 1.8, 0.5, 1.8, -14,0.3,-128,0.9781,0,0.2079,0,1,0,-0.2079,0,0.9781, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "FallenShaft", "Block", 0.7, 2.4, 0.7, -12.4,0.4,-127.5,0,-0.9397,0.342,1,0,0,0,0.342,0.9397, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Lanterns", "FallenRoof", "Block", 2.2, 0.45, 2.2, -10.6,0.55,-126.4,0.2962,-0.8138,0.5,0.9239,0.1114,-0.366,0.2421,0.5704,0.7849, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Guardians", "PedestalL", "Block", 2.2, 2.4, 2.2, -8.8,1.25,-134,1,0,0,0,1,0,0,0,1, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Guardians", "LionL", "Block", 1.4, 1.5, 2, -8.8,3.2,-134,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Guardians", "LionHeadL", "Block", 1.3, 1.2, 1.1, -8.8,4.4,-133.3,0.9848,0,0.1736,0,1,0,-0.1736,0,0.9848, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Guardians", "PedestalR", "Block", 2.2, 2.4, 2.2, 8.8,1.25,-134,1,0,0,0,1,0,0,0,1, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Guardians", "LionR", "Block", 1.4, 1.5, 2, 8.8,3.2,-134,1,0,0,0,1,0,0,0,1, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Guardians", "LionHeadR", "Block", 1.3, 1.2, 1.1, 10.6,0.55,-132.2,0.133,-0.7544,-0.6428,0.9224,0.3316,-0.1983,0.3627,-0.5665,0.7399, "a8a296", "Slate", 0, 0, "ACSQT" },
	{ "Banners", "PoleL", "Block", 0.25, 9, 0.25, -11,4.55,-131,1,0,0,0,1,0,0,0,1, "463428", "Wood", 0, 0, "ACSQT" },
	{ "Banners", "ClothL", "Block", 0.1, 6, 1.6, -11,5.6,-131.9,1,0,0,0,1,0,0,0,1, "28286e", "Fabric", 0, 0, "ACSQT" },
	{ "Banners", "PoleR", "Block", 0.25, 9, 0.25, 11,4.55,-131,1,0,0,0,1,0,0,0,1, "463428", "Wood", 0, 0, "ACSQT" },
	{ "Banners", "ClothR", "Block", 0.1, 6, 1.6, 11,5.6,-131.9,1,0,0,0,1,0,0,0,1, "28286e", "Fabric", 0, 0, "ACSQT" },
	{ "Ruins", "SideWall", "Block", 2, 4.5, 14, -26,2.3,-128,1,0,0,0,1,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Ruins", "SideWall", "Block", 2, 2.6, 10, -26,1.35,-112,1,0,0,0,1,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Ruins", "SideWall", "Block", 2, 1.5, 6, -26,0.8,-101,1,0,0,0,1,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Ruins", "SideWall", "Block", 2, 3.5, 10, 26,1.8,-130,1,0,0,0,1,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Ruins", "SideWall", "Block", 2, 5, 12, 26,2.55,-117,1,0,0,0,1,0,0,0,1, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Ruins", "SideCoping", "Block", 2.8, 0.45, 12.4, 26,5.27,-117,1,0,0,0,1,0,0,0,1, "282c36", "Slate", 0, 0, "ACSQT" },
	{ "Ruins", "SideRubble1", "Block", 1.6, 1, 1.4, -24.5,0.5,-119.5,0.8639,0.0604,0.5,-0.0172,0.9957,-0.0905,-0.5033,0.0696,0.8613, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Ruins", "SideRubble2", "Block", 1.2, 0.7, 1.1, -23.6,0.35,-106,0.3387,-0.0476,0.9397,0.0739,0.997,0.0239,-0.938,0.0614,0.3412, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Ruins", "SideRubble3", "Block", 1.8, 1, 1.5, 24.4,0.5,-123.4,0.9587,-0.1177,-0.2588,0.1083,0.9928,-0.0506,0.2629,0.0204,0.9646, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Ruins", "SideRubble4", "Block", 1.3, 0.8, 1.2, 23.9,0.4,-108.5,0.7071,0,0.7071,-0.0862,0.9925,0.0862,-0.7018,-0.1219,0.7018, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Ruins", "SideRubble5", "Block", 1, 0.6, 0.9, -24.2,0.3,-133,0.9254,-0.1632,0.342,0.1736,0.9848,0,-0.3368,0.0594,0.9397, "706c64", "Slate", 0, 0, "ACSQT" },
	{ "Shrine", "HallBase", "Block", 32, 1.5, 22, 0,0.8,-162,1,0,0,0,1,0,0,0,1, "96928a", "Slate", 0, 0, "ACSQT" },
	{ "Shrine", "Hall", "Block", 24, 14, 16, 0,8.55,-162,1,0,0,0,1,0,0,0,1, "5a3a28", "Wood", 0, 0, "ACSQT" },
	{ "Shrine", "RoofFront", "Block", 34, 1, 13, 0,19.05,-156.21,1,0,0,0,0.891,-0.454,0,0.454,0.891, "282c36", "Slate", 0, 0, "ACSQT" },
	{ "Shrine", "RoofBack", "Block", 34, 1, 13, 0,19.05,-167.79,1,0,0,0,0.891,0.454,0,-0.454,0.891, "282c36", "Slate", 0, 0, "ACSQT" },
	{ "Shrine", "Ridge", "Block", 35, 0.8, 0.8, 0,22.2,-162,1,0,0,0,1,0,0,0,1, "221e20", "Wood", 0, 0, "ACSQT" },
	{ "Trees", "TrunkL", "Block", 1.4, 20, 1.4, -22,10,-150,0.9976,-0.0698,0,0.0698,0.9976,0,0,0,1, "463428", "Wood", 0, 0, "ACSQT" },
	{ "Trees", "PineL1", "Block", 9, 1.6, 7, -21.3,19,-150,0.9781,0,0.2079,0,1,0,-0.2079,0,0.9781, "286032", "Grass", 0, 0, "ACSQT" },
	{ "Trees", "PineL2", "Block", 7, 1.4, 6, -24,22,-150.5,0.9397,0,-0.342,0,1,0,0.342,0,0.9397, "286032", "Grass", 0, 0, "ACSQT" },
	{ "Trees", "PineL3", "Block", 5, 1.2, 4.5, -22.3,24.5,-149.6,0.8192,0,0.5736,0,1,0,-0.5736,0,0.8192, "286032", "Grass", 0, 0, "ACSQT" },
	{ "Trees", "PineL4", "Block", 6, 1.3, 5, -18.6,15.5,-149,0.9903,0,-0.1392,0,1,0,0.1392,0,0.9903, "286032", "Grass", 0, 0, "ACSQT" },
	{ "Trees", "TrunkR", "Block", 1.5, 22, 1.5, 24,11,-153,0.9962,0.0872,0,-0.0872,0.9962,0,0,0,1, "463428", "Wood", 0, 0, "ACSQT" },
	{ "Trees", "PineR1", "Block", 10, 1.6, 7.5, 23.2,21,-153,0.9659,0,-0.2588,0,1,0,0.2588,0,0.9659, "286032", "Grass", 0, 0, "ACSQT" },
	{ "Trees", "PineR2", "Block", 7, 1.4, 6, 25.6,24.2,-152.4,0.9063,0,0.4226,0,1,0,-0.4226,0,0.9063, "286032", "Grass", 0, 0, "ACSQT" },
	{ "Trees", "PineR3", "Block", 6.5, 1.3, 5, 20.8,17.5,-153.5,0.9962,0,0.0872,0,1,0,-0.0872,0,0.9962, "286032", "Grass", 0, 0, "ACSQT" },
	{ "Trees", "PineR4", "Block", 4.5, 1.1, 4, 24.2,26.5,-153,0.766,0,-0.6428,0,1,0,0.6428,0,0.766, "286032", "Grass", 0, 0, "ACSQT" },
	{ "Trees", "DeadTrunk", "Block", 1, 9, 1, 21,4.5,-124,0.9903,0.1392,0,-0.1392,0.9903,0,0,0,1, "463428", "Wood", 0, 0, "ACSQT" },
	{ "Trees", "DeadBranch1", "Block", 0.5, 4, 0.5, 19.6,8.6,-124.3,0.766,-0.6428,0,0.6428,0.766,0,0,0,1, "463428", "Wood", 0, 0, "ACSQT" },
	{ "Trees", "DeadBranch2", "Block", 0.45, 3.4, 0.45, 23,8.2,-123.6,0.6428,0.766,0,-0.7544,0.633,-0.1736,-0.133,0.1116,0.9848, "463428", "Wood", 0, 0, "ACSQT" },
	{ "Trees", "DeadBranch3", "Block", 0.4, 2.6, 0.4, 21.4,10.2,-125.2,0.9848,0.1736,0,-0.1422,0.8067,0.5736,0.0996,-0.5649,0.8192, "463428", "Wood", 0, 0, "ACSQT" },
}

-- part = index into PARTS (the two torii lanterns and the four stone-lantern fires)
local LIGHTS = {
	{ part = 43, class = "PointLight", brightness = 1.2, range = 12, color = "ffaa64", shadows = true, enabled = true },
	{ part = 50, class = "PointLight", brightness = 1.2, range = 12, color = "ffaa64", shadows = true, enabled = true },
	{ part = 61, class = "PointLight", brightness = 1.4, range = 14, color = "ffaa64", shadows = true, enabled = true },
	{ part = 67, class = "PointLight", brightness = 1.4, range = 14, color = "ffaa64", shadows = true, enabled = true },
	{ part = 73, class = "PointLight", brightness = 1.4, range = 14, color = "ffaa64", shadows = true, enabled = true },
	{ part = 79, class = "PointLight", brightness = 1.4, range = 14, color = "ffaa64", shadows = true, enabled = true },
}

-- The guard: a default R15 at his post on the platform, facing +Z (towards the player's mark at z = -130).
local GUARD = {
	pivot = { 0, 4.44242, -138, -1, 0, 0, 0, 1, 0, 0, 0, -1 },
	description = {
		HeadColor = Color3.fromRGB(196, 140, 108),
		TorsoColor = Color3.fromRGB(62, 66, 76),
		LeftArmColor = Color3.fromRGB(62, 66, 76),
		RightArmColor = Color3.fromRGB(62, 66, 76),
		LeftLegColor = Color3.fromRGB(38, 40, 56),
		RightLegColor = Color3.fromRGB(38, 40, 56),
		BodyTypeScale = 0.3,
		DepthScale = 1,
		HeadScale = 1,
		HeightScale = 1,
		ProportionScale = 1,
		WidthScale = 1,
	},
	-- armour colours and materials per body part: { colour hex, material, transparency }
	parts = {
		HumanoidRootPart = { "a3a2a5", "Plastic", 1 },
		Head = { "c48c6c", "Plastic", 0 },
		UpperTorso = { "3e424c", "Metal", 0 },
		LowerTorso = { "801a1e", "Fabric", 0 },
		LeftUpperArm = { "3e424c", "Metal", 0 },
		RightUpperArm = { "3e424c", "Metal", 0 },
		LeftLowerArm = { "461c1e", "Fabric", 0 },
		RightLowerArm = { "461c1e", "Fabric", 0 },
		LeftHand = { "221e1e", "SmoothPlastic", 0 },
		RightHand = { "221e1e", "SmoothPlastic", 0 },
		LeftUpperLeg = { "262838", "Fabric", 0 },
		RightUpperLeg = { "262838", "Fabric", 0 },
		LeftLowerLeg = { "3e424c", "Metal", 0 },
		RightLowerLeg = { "3e424c", "Metal", 0 },
		LeftFoot = { "1c1a1a", "SmoothPlastic", 0 },
		RightFoot = { "1c1a1a", "SmoothPlastic", 0 },
	},
	-- Task 23 marketplace dress (avatar catalog, checked with MarketplaceService:GetProductInfo; nothing bought)
	marketplace = {
		{ AssetId = 95484542421857, AccessoryType = Enum.AccessoryType.Hat, IsLayered = false }, -- Samurai Helmet (Nexus Exchange)
		{ AssetId = 93624803291644, AccessoryType = Enum.AccessoryType.Waist, IsLayered = false }, -- Realistic Traditional Samurai Katana - Waist (Only Costumes)
		{ AssetId = 131254524112441, AccessoryType = Enum.AccessoryType.Pants, IsLayered = true, Order = 2 }, -- Hakama Type A (Black) (Haririkuro's house)
		{ AssetId = 117362897615815, AccessoryType = Enum.AccessoryType.Jacket, IsLayered = true, Order = 5 }, -- Black Samurai Armor (Nexus Exchange)
	},
	-- Task 22's built gear, CFrames relative to the body part each was welded to: same record layout as PARTS
	oldgear = {
		{ "Head", "HelmetBowl", "Block", 1.2981, 0.4964, 1.2999, 0,0.3371,0.04,1,0,0,0,1,0,0,0,1, "343840", "Metal", 0, 0, "SM" },
		{ "Head", "HelmetBrim", "Block", 1.6457, 0.12, 1.532, 0,0.2364,0.1,1,0,0,0,0.9703,-0.2419,0,0.2419,0.9703, "343840", "Metal", 0, 0, "SM" },
		{ "Head", "NeckGuard", "Block", 1.7385, 0.5319, 0.14, 0,-0.112,0.7196,1,0,0,0,0.9659,-0.2588,0,0.2588,0.9659, "343840", "Metal", 0, 0, "SM" },
		{ "Head", "CrestLeft", "Block", 0.1, 1.0047, 0.06, -0.255,0.8336,-0.5803,0.9272,-0.3746,0,0.3746,0.9272,0,0,0,1, "d4aa46", "Metal", 0, 0, "SM" },
		{ "Head", "CrestRight", "Block", 0.1, 1.0047, 0.06, 0.255,0.8336,-0.5803,0.9272,0.3746,0,-0.3746,0.9272,0,0,0,1, "d4aa46", "Metal", 0, 0, "SM" },
		{ "Head", "CrestBase", "Block", 0.3, 0.25, 0.1, 0,0.4081,-0.65,1,0,0,0,1,0,0,0,1, "d4aa46", "Metal", 0, 0, "SM" },
		{ "Head", "FaceMask", "Block", 0.904, 0.4255, 0.16, 0,-0.3721,-0.6203,1,0,0,0,1,0,0,0,1, "301618", "SmoothPlastic", 0, 0, "SM" },
		{ "LeftUpperArm", "ShoulderPlate", "Block", 0.18, 1.1174, 1.3525, -0.6284,0.0026,0,0.9903,0.1392,0,-0.1392,0.9903,0,0,0,1, "343840", "Metal", 0, 0, "SM" },
		{ "LeftUpperArm", "ShoulderLace", "Block", 0.2, 0.18, 1.3625, -0.6284,0.1889,0,1,0,0,0,1,0,0,0,1, "801a1e", "Fabric", 0, 0, "SM" },
		{ "LeftUpperArm", "ShoulderCap", "Block", 1.3014, 0.2, 1.3024, -0.0779,0.6213,0,1,0,0,0,1,0,0,0,1, "343840", "Metal", 0, 0, "SM" },
		{ "RightUpperArm", "ShoulderPlate", "Block", 0.18, 1.1174, 1.3525, 0.6284,0.0026,0,0.9903,-0.1392,0,0.1392,0.9903,0,0,0,1, "343840", "Metal", 0, 0, "SM" },
		{ "RightUpperArm", "ShoulderLace", "Block", 0.2, 0.18, 1.3625, 0.6284,0.1889,0,1,0,0,0,1,0,0,0,1, "801a1e", "Fabric", 0, 0, "SM" },
		{ "RightUpperArm", "ShoulderCap", "Block", 1.3014, 0.2, 1.3024, 0.0779,0.6213,0,1,0,0,0,1,0,0,0,1, "343840", "Metal", 0, 0, "SM" },
		{ "UpperTorso", "ChestPlate", "Block", 1.7878, 1.0528, 0.18, 0,0.0863,-0.542,1,0,0,0,1,0,0,0,1, "343840", "Metal", 0, 0, "SM" },
		{ "UpperTorso", "ChestLace", "Block", 1.8072, 0.1, 0.2, 0,-0.1514,-0.552,1,0,0,0,1,0,0,0,1, "801a1e", "Fabric", 0, 0, "SM" },
		{ "LowerTorso", "TassetFront", "Block", 0.9559, 0.85, 0.12, -0.5178,-0.2407,-0.552,1,0,0,0,0.9903,-0.1392,0,0.1392,0.9903, "343840", "Metal", 0, 0, "SM" },
		{ "LowerTorso", "TassetSide", "Block", 0.12, 0.85, 0.9036, -1.0457,-0.2407,0,1,0,0,0,1,0,0,0,1, "343840", "Metal", 0, 0, "SM" },
		{ "LowerTorso", "TassetFront", "Block", 0.9559, 0.85, 0.12, 0.5178,-0.2407,-0.552,1,0,0,0,0.9903,-0.1392,0,0.1392,0.9903, "343840", "Metal", 0, 0, "SM" },
		{ "LowerTorso", "TassetSide", "Block", 0.12, 0.85, 0.9036, 1.0457,-0.2407,0,1,0,0,0,1,0,0,0,1, "343840", "Metal", 0, 0, "SM" },
		{ "LowerTorso", "Scabbard", "Block", 0.2, 0.26, 3.4, -1.2056,-0.3874,0.9871,0.9272,0,-0.3746,-0.0779,0.9781,-0.1928,0.3664,0.2079,0.9069, "1e1c1e", "SmoothPlastic", 0, 0, "SM" },
		{ "LowerTorso", "SwordGuard", "Block", 0.5, 0.5, 0.08, -0.55,-0.05,-0.6,0.9272,0,-0.3746,-0.0779,0.9781,-0.1928,0.3664,0.2079,0.9069, "d4aa46", "Metal", 0, 0, "SM" },
		{ "LowerTorso", "SwordGrip", "Block", 0.2, 0.22, 1, -0.344,0.056,-1.0988,0.9272,0,-0.3746,-0.0779,0.9781,-0.1928,0.3664,0.2079,0.9069, "28283c", "Fabric", 0, 0, "SM" },
	},
}

-- Lighting. "new" is the live state when dumped. "old": only ClockTime, Brightness, Ambient and OutdoorAmbient were
-- recorded before Task 22 changed them (task-t22-report.md); the other "old" values are Roblox's new-place defaults,
-- an assumption, and GateGrade did not exist before Task 22. Sky, SunRays, Bloom and DepthOfField were not changed.
local LIGHTING = {
	new = {
		Lighting = { Ambient = Color3.fromRGB(70, 62, 82), Brightness = 2.2, ClockTime = 17.7, ColorShift_Bottom = Color3.fromRGB(0, 0, 0),
			ColorShift_Top = Color3.fromRGB(255, 214, 170), EnvironmentDiffuseScale = 1, EnvironmentSpecularScale = 1,
			ExposureCompensation = 0, FogColor = Color3.fromRGB(192, 192, 192), FogEnd = 100000, FogStart = 0,
			GeographicLatitude = 0, GlobalShadows = true, OutdoorAmbient = Color3.fromRGB(120, 106, 128), ShadowSoftness = 0.2 },
		Atmosphere = { Color = Color3.fromRGB(232, 190, 170), Decay = Color3.fromRGB(120, 92, 130), Density = 0.36, Glare = 0.25,
			Haze = 1.4, Offset = 0.15 },
		GateGrade = { Enabled = true, Brightness = 0, Contrast = 0.08, Saturation = 0.08, TintColor = Color3.fromRGB(255, 244, 236) },
	},
	old = {
		Lighting = { Ambient = Color3.fromRGB(70, 70, 70), Brightness = 3, ClockTime = 14.5, OutdoorAmbient = Color3.fromRGB(70, 70, 70),
			ColorShift_Top = Color3.fromRGB(0, 0, 0) }, -- ColorShift_Top: default, assumed
		Atmosphere = { Color = Color3.fromRGB(199, 199, 199), Decay = Color3.fromRGB(106, 112, 125), Density = 0.3, Glare = 0,
			Haze = 0, Offset = 0.25 }, -- Roblox defaults, assumed
		GateGrade = false, -- removed
	},
	-- unchanged by Task 22; kept here so the place's look is complete in one file
	unchanged = {
		Sky = { CelestialBodiesShown = true, MoonAngularSize = 11, MoonTextureId = "rbxassetid://6444320592",
			SkyboxBk = "rbxassetid://6444884337", SkyboxDn = "rbxassetid://6444884785", SkyboxFt = "rbxassetid://6444884337",
			SkyboxLf = "rbxassetid://6444884337", SkyboxRt = "rbxassetid://6444884337", SkyboxUp = "rbxassetid://6412503613",
			SkyboxOrientation = Vector3.new(0, 0, 0), StarCount = 3000, SunAngularSize = 11, SunTextureId = "rbxassetid://6196665106" },
		SunRays = { Enabled = true, Intensity = 0.01, Spread = 0.1 },
		Bloom = { Enabled = true, Intensity = 1, Size = 24, Threshold = 2 },
		DepthOfField = { Enabled = false, FarIntensity = 0.1, FocusDistance = 0.05, InFocusRadius = 30, NearIntensity = 0.75 },
	},
}

-- ---------------------------------------------------------------------------------------------------------------------
local Players = game:GetService("Players")
local Lighting = game:GetService("Lighting")

local opt = table.clone(OPTIONS)
if type(_G.GateSetOptions) == "table" then
	for k, v in _G.GateSetOptions do
		opt[k] = v
	end
end

local function hex(h)
	return Color3.fromHex(h)
end

local function makePart(r)
	local p = Instance.new("Part")
	p.Name = r[2]
	p.Shape = Enum.PartType[r[3]]
	p.Size = Vector3.new(r[4], r[5], r[6])
	p.CFrame = CFrame.new(table.unpack(r, 7, 18))
	p.Color = hex(r[19])
	p.Material = Enum.Material[r[20]]
	p.Transparency = r[21]
	p.Reflectance = r[22]
	local f = r[23]
	p.Anchored = string.find(f, "A", 1, true) ~= nil
	p.CanCollide = string.find(f, "C", 1, true) ~= nil
	p.CastShadow = string.find(f, "S", 1, true) ~= nil
	p.CanQuery = string.find(f, "Q", 1, true) ~= nil
	p.CanTouch = string.find(f, "T", 1, true) ~= nil
	p.Massless = string.find(f, "M", 1, true) ~= nil
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	return p
end

local function setProps(inst, props)
	for k, v in props do
		inst[k] = v
	end
end

local function lightChild(className, name)
	local c = Lighting:FindFirstChild(name) or Lighting:FindFirstChildOfClass(className)
	if not c then
		c = Instance.new(className)
		c.Name = name
		c.Parent = Lighting
	end
	return c
end

local function applyLighting(mode)
	if mode == "keep" then
		return "lighting kept"
	end
	local set = LIGHTING[mode]
	assert(set, "lighting must be new, old or keep")
	setProps(Lighting, set.Lighting)
	setProps(lightChild("Atmosphere", "Atmosphere"), set.Atmosphere)
	if set.GateGrade then
		setProps(lightChild("ColorCorrectionEffect", "GateGrade"), set.GateGrade)
	else
		local g = Lighting:FindFirstChild("GateGrade")
		if g then
			g:Destroy()
		end
	end
	setProps(lightChild("Sky", "Sky"), LIGHTING.unchanged.Sky)
	setProps(lightChild("SunRaysEffect", "SunRays"), LIGHTING.unchanged.SunRays)
	setProps(lightChild("BloomEffect", "Bloom"), LIGHTING.unchanged.Bloom)
	setProps(lightChild("DepthOfFieldEffect", "DepthOfField"), LIGHTING.unchanged.DepthOfField)
	return "lighting " .. mode
end

local function buildGuard(dress)
	local desc = Instance.new("HumanoidDescription")
	setProps(desc, GUARD.description)
	if dress == "marketplace" then
		desc:SetAccessories(GUARD.marketplace, true)
	end
	local g = Players:CreateHumanoidModelFromDescription(desc, Enum.HumanoidRigType.R15)
	g.Name = "Guard"
	for name, look in GUARD.parts do
		local p = g:FindFirstChild(name)
		if p then
			p.Color = hex(look[1])
			p.Material = Enum.Material[look[2]]
			p.Transparency = look[3]
		end
	end
	local hum = g:FindFirstChildOfClass("Humanoid")
	hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
	hum.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
	g.PrimaryPart = g.HumanoidRootPart
	g.HumanoidRootPart.Anchored = true
	g:PivotTo(CFrame.new(table.unpack(GUARD.pivot)))
	if dress == "oldgear" then
		local gear = Instance.new("Folder")
		gear.Name = "Gear" -- a Folder, not a Model: the rig capture still reads 16 body parts
		for _, r in GUARD.oldgear do
			local body = g:FindFirstChild(r[1])
			local p = makePart(r)
			p.CFrame = body.CFrame * CFrame.new(table.unpack(r, 7, 18))
			local w = Instance.new("WeldConstraint")
			w.Part0, w.Part1 = body, p
			w.Parent = p
			p.Parent = gear
		end
		gear.Parent = g
	end
	local n = 0
	for _, a in g:GetChildren() do
		if a:IsA("Accessory") then
			n += 1
		end
	end
	return g, n
end

local parent = opt.parent or workspace
local old = parent:FindFirstChild(opt.name)
if old then
	assert(opt.replace, ("%s.%s already exists: set replace = true to rebuild it (this destroys the current one)"):format(parent:GetFullName(), opt.name))
	old:Destroy()
end

local root = Instance.new("Model")
root.Name = opt.name
local groups, order, made = {}, {}, {}
for i, r in PARTS do
	local m = groups[r[1]]
	if not m then
		m = Instance.new("Model")
		m.Name = r[1]
		groups[r[1]] = m
		table.insert(order, m)
	end
	local p = makePart(r)
	p.Parent = m
	made[i] = p
end
for _, l in LIGHTS do
	local light = Instance.new(l.class)
	light.Brightness, light.Range, light.Color = l.brightness, l.range, hex(l.color)
	light.Shadows, light.Enabled = l.shadows, l.enabled
	light.Parent = made[l.part]
end
root.Parent = parent
for _, m in order do -- one group per frame keeps each parent write small
	m.Parent = root
	task.wait()
end
local guardNote = "no guard"
if opt.guard then
	local g, accessories = buildGuard(opt.dress)
	g.Parent = root
	guardNote = ("guard (%s, %d accessories)"):format(opt.dress, accessories)
end
local lightNote = applyLighting(opt.lighting)
return ("built %s: %d parts in %d groups, %d lights, %s, %s"):format(root:GetFullName(), #PARTS, #order, #LIGHTS, guardNote, lightNote)
