"""GateGuard camera, on the shrine set. Anchor space: the player at (0, 0, 0) facing -Z at the foot of ten stone steps;
the guard on the top step at (0, 5.86, -16.3) facing him (his eyes about (0, 10.8, -16.3)); the stone torii 5.7 studs
behind him (pillars x = +-6.5, top at y 21). The line of action runs along Z; every shot sits on its +X side (the
player's right), so the guard always looks screen-left at the player. The bottom letterbox bar (0.11 of the frame)
carries the subtitles: nothing that matters is framed into it.
Round 2 (blind score 5.7): an eye-level hero push that ends on a true medium close-up, a climax that escalates.
Round 3 (6.4): shot 2 framed between the pillars with a fast push into the cut; a bigger kick on the climax; the
crest whole in every guard shot (never cut mid-horn); shot 4 lower so both casts' heads clear the subtitle bar.
1 ESTABLISH: wide behind the player's right shoulder, a lit lantern in the right foreground; a slow push.
2 HERO: eye level on the steps, a medium shot for the "Halt." palm, then a strong eased push (cubic in-out over
  1.1 s) to a medium close-up of the helmet and mask, held through "Nobody enters after dark" and the pull-back.
3 CLIMAX: hard cut on the action (the lean-in) to a low-angle close-up of the helmet and mask, tighter than shot 2's
  end, with a camera kick on the cut (a jolt in with a little roll, an overshoot, a settle in 12 frames) on top of
  the Shake marker; a hard hold, a slight creep, then a tilt up with him as he stands tall.
4 AFTERMATH: wide from higher behind the player, inside the lantern pair, his head and shoulders in the lower
  third; a slow pull back.  5 RETURN: flows to behind the player at fov 70.
Method by fwjelaa (FWJ STUDIOS)."""


def build(cam):
    s1, s2, s3, s4, s5 = (cam.shot(n) for n in range(1, 6))
    cam.key(s1["start"], eye=(4.6, 5.8, 16.5), look=(-0.4, 9.2, -16), fov=46)
    cam.key(s1["last"], eye=(4.4, 5.6, 15.0), look=(-0.4, 9.4, -16), fov=44)
    # 2: eye level, square between the torii pillars (they frame him); a medium shot for the palm, a slight drift, the
    # push to the medium close-up (the whole crest in), a hold, then a fast push into the cut
    cam.key(s2["start"], eye=(0.7, 10.6, -5.4), look=(0, 10.05, -16.3), fov=33, ease="sine_inout")
    cam.key(s2["start"] + 0.9, eye=(0.7, 10.62, -5.7), look=(0, 10.1, -16.3), fov=33, ease="cubic_inout")
    cam.key(s2["start"] + 2.0, eye=(0.9, 10.8, -9.9), look=(0, 10.62, -16.3), fov=37.5, ease="sine_inout")
    cam.key(s2["start"] + 3.15, eye=(0.9, 10.8, -10.1), look=(0, 10.62, -16.3), fov=37, ease="expo_in")
    cam.key(s2["last"], eye=(0.8, 10.75, -10.75), look=(0, 10.68, -16.3), fov=35.8)
    # 3: the kick on the cut, readable in one frame: jolted back and up with a 10-degree roll, then a fast push in
    # past the rest position (overshoot, counter-roll) and a settle in 12 frames; a hold, a creep, a tilt up with him
    cam.key(s3["start"], eye=(3.25, 7.8, -10.1), look=(0.3, 11.15, -15.6), fov=45, roll=10, ease="cubic_out")
    cam.key(s3["start"] + 0.05, eye=(2.78, 8.05, -10.8), look=(0, 11.0, -15.6), fov=38, roll=-3, ease="sine_inout")
    cam.key(s3["start"] + 0.2, eye=(2.9, 8.0, -10.6), look=(0, 11.0, -15.6), fov=39, ease="sine_inout")
    cam.key(s3["start"] + 1.95, eye=(2.85, 8.02, -10.7), look=(0, 11.0, -15.6), fov=38.6, ease="cubic_inout")
    cam.key(s3["last"], eye=(2.9, 8.45, -10.4), look=(0, 11.5, -16.0), fov=41)
    # 4: wide, higher behind the player; his head and shoulders in the lower third (R15 and R6)
    cam.key(s4["start"], eye=(3.3, 6.6, 8.6), look=(-0.6, 5.9, -14), fov=46)
    cam.key(s4["last"], eye=(3.6, 7.0, 10.8), look=(-0.6, 6.0, -14), fov=49)
    cam.key(s5["last"], eye=(0, 6.5, 12.5), look=(0, 4.5, -4), fov=70)
