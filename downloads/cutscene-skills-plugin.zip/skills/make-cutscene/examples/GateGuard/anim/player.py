"""GateGuard, the player (the game's own avatar in play; the captured default avatar here). Takes the last step onto the
mark and stops (0-34), looks up the steps at the guard; a small start at the "Halt." palm; flinches back on the
climax cut (in 3 frames, out slowly) and again, smaller, on "or I make you"; then he reacts toward the guard: the
weight rocks back, the chest and head turn a little and tip up at him. Feet stay on their marks after the step; poses are grounded on the captured rig (it stands at 3.192).
Method by fwjelaa (FWJ STUDIOS)."""
from _r15 import plant

RIGHT = ("Right", 0.5, 0.0, 0)
LEFT = ("Left", -0.5, -0.25, 4)

BASE = {"LowerTorso": (0, 0, 0, 0, -0.05, 0), "UpperTorso": (1, 0, 0), "Head": (-3, 0, 0),
        "RightUpperArm": (2, 0, 6), "RightLowerArm": (10, 0, 0), "RightHand": (0, 0, 0),
        "LeftUpperArm": (2, 0, -6), "LeftLowerArm": (10, 0, 0), "LeftHand": (0, 0, 0)}
LISTEN = dict(BASE, UpperTorso=(4, 0, 0), Head=(15, 0, 0))  # eyes up the steps at the guard, 6 studs higher
WARY = dict(BASE, LowerTorso=(3, 0, 0, 0, -0.08, 0.12), UpperTorso=(7, 0, 0), Head=(15, 0, 0),
            RightUpperArm=(10, 0, 10), LeftUpperArm=(10, 0, -10), RightLowerArm=(24, 0, 0), LeftLowerArm=(24, 0, 0))


def pose(base, left=LEFT, **joints):
    """Both feet planted (the left one can be given: the step), grounded on the captured rig."""
    p = dict(base)
    p.update(joints)
    plant(p, RIGHT[0], x=RIGHT[1], z=RIGHT[2], yaw=RIGHT[3])
    if isinstance(left, dict):
        plant(p, "Left", **left)
    else:
        plant(p, left[0], x=left[1], z=left[2], yaw=left[3])
    return ak.ground(p, RIG)


def build():
    a = ak.Anim(NAME, rig=RIG, length=FRAMES, fps=FPS, priority="Action4")
    s2, s3, s4 = SHOTS[1]["start"], SHOTS[2]["start"], SHOTS[3]["start"]
    # 1: the last step: the left foot pushes off behind, swings through and lands on its mark; the body stops
    a.full(0, pose(BASE, left={"x": -0.5, "z": 1.05, "lift": 0.12, "pitch": -18},  # just off its toe: in the air
                   LowerTorso=(-4, -4, 0, 0, -0.08, 0.72), Head=(-6, 0, 0),
                   RightUpperArm=(-16, 0, 6), LeftUpperArm=(18, 0, -6), RightLowerArm=(14, 0, 0),
                   LeftLowerArm=(18, 0, 0)), "linear")
    a.full(F(0.2), pose(BASE, left={"x": -0.5, "z": 0.4, "lift": 0.24, "pitch": 6},
                        LowerTorso=(-3, 0, 0, 0, 0.0, 0.38), Head=(-5, 0, 0),
                        RightUpperArm=(-4, 0, 6), LeftUpperArm=(6, 0, -6)), "linear")
    a.full(F(0.37), pose(BASE, LowerTorso=(-2, 3, 0, 0, -0.1, 0.08), Head=(-4, 0, 0),
                         RightUpperArm=(11, 0, 6), LeftUpperArm=(-9, 0, -6)), "cubic_out")
    a.full(F(0.57), pose(BASE, LowerTorso=(1, 0, 0, 0, -0.07, 0), RightUpperArm=(4, 0, 6), LeftUpperArm=(0, 0, -6)),
           "sine_inout")
    a.full(F(0.85), pose(BASE), "sine_inout")
    a.full(F(1.2), pose(LISTEN, Head=(8, 0, 0)), "cubic_inout")  # looks up at the guard
    a.full(F(1.5), pose(LISTEN), "sine_inout")
    # 2: a small start at the palm (in 3, out 16), then listening, a moving hold
    a.full(F(s2 + 0.18), pose(LISTEN), "cubic_out")
    a.full(F(s2 + 0.23), pose(LISTEN, UpperTorso=(6, 0, 0), Head=(18, 0, 0), LowerTorso=(1, 0, 0, 0, -0.06, 0.04)),
           "sine_inout")
    a.full(F(s2 + 0.5), pose(LISTEN), "sine_inout")
    a.full(F(s2 + 2.0), pose(ak.drift(LISTEN, 1.5)), "sine_inout")
    a.full(F(s2 + 3.1), pose(LISTEN, UpperTorso=(3, 0, 0), Head=(14, 0, 0)), "cubic_out")
    # 3: the flinch lands with the cut (in 3 frames, out 18), a smaller one on "or I make you"
    a.full(F(s3), pose(LISTEN, UpperTorso=(3, 0, 0), Head=(14, 0, 0)), "cubic_out")
    a.full(F(s3 + 0.05), pose(WARY, LowerTorso=(5, 0, 0, 0, -0.1, 0.2), UpperTorso=(10, 0, 0), Head=(17, 0, 0),
                              RightUpperArm=(22, 0, 16), LeftUpperArm=(22, 0, -16), RightLowerArm=(40, 0, 0),
                              LeftLowerArm=(40, 0, 0)), "sine_inout")
    a.full(F(s3 + 0.35), pose(WARY), "sine_inout")
    a.full(F(s3 + 1.15), pose(ak.drift(WARY, 1.5)), "cubic_out")
    a.full(F(s3 + 1.21), pose(WARY, LowerTorso=(5, -4, 0, 0, -0.1, 0.17), UpperTorso=(9, -6, 0), Head=(16, 5, 0),
                              RightUpperArm=(16, 0, 12)), "sine_inout")
    a.full(F(s3 + 1.6), pose(WARY, UpperTorso=(7, -3, 0), Head=(15, 2, 0)), "sine_inout")
    # 4-5: he reacts toward the guard: the weight rocks back onto his right foot, the chest and head turn a little
    # to his left and tip up at the guard (a read from behind: the head shows a quarter profile), then settle
    a.full(F(s4 + 0.1), pose(ak.drift(WARY, 2), UpperTorso=(6, -3, 0), Head=(14, 2, 0)), "cubic_inout")
    a.full(F(s4 + 0.6), pose(BASE, LowerTorso=(2, 6, -2, 0.1, -0.07, 0.06), UpperTorso=(4, 12, 0), Head=(14, 16, 3),
                             RightUpperArm=(4, 0, 6), LeftUpperArm=(4, 0, -6), RightLowerArm=(14, 0, 0),
                             LeftLowerArm=(14, 0, 0)), "sine_inout")
    a.full(F(s4 + 1.1), pose(BASE, LowerTorso=(1, 5, -1, 0.08, -0.06, 0.04), UpperTorso=(3, 10, 0), Head=(12, 14, 2)),
           "sine_inout")
    a.full(FRAMES, pose(BASE, UpperTorso=(1, 4, 0), Head=(6, 6, 0)), "linear")
    return a
