"""GateGuard, npc1: the shrine guard on the top step, under the torii (5.86 studs above the player and 16.3 away),
facing down the lane at him; so every look at the player pitches the head about 20 degrees down (world).
His marketplace katana rides at his left hip; its tsuba (guard) is at (-1.14, -0.48, -0.59) in LowerTorso axes
(measured in Studio). The film set doesn't show the katana, so the left hand is put on it by IK.
Round 2 (blind score 5.7): bigger, clearer acting for the two cameras that see it. Round 3 (6.4): the hero hold
keeps moving (a slow palm push, a head tilt, weight shifts, an inhale into the cut); a harder lean-in on the cut.
1 ESTABLISH 0-96: dozing at his post (head well down); hears the steps (f48), squares up heavily and fixes his
  eyes on the player below.
2 HERO 96-294 "Halt. Nobody enters after dark.": a real anticipation from the cut (the RIGHT arm, the far side from
  the camera, so the hand never covers the frame, draws down and back, the chest coils away), a 3-frame snap up on
  the line into a raised palm (marked Hit), overshoot, a hold that reads, then the hand settles down; a nod on
  "Nobody"; then the anticipation for the climax: he rears back, chin up, and holds it into the cut.
3 CLIMAX 294-426 "Turn back now, or I make you.": ON the cut he snaps into a lean-in and his left thumb slaps onto
  the tsuba (koiguchi, marked Hit: the cut lands on the action), overshoot, a hard hold; a second push on "or I
  make you"; then he rises, lets go and stands tall, so shot 4 opens on him upright (the pose runs on across the cut).
4-5 426-531: he holds his post, then settles into the world guard's rest pose for the hand-back.
Method by fwjelaa (FWJ STUDIOS)."""
from mathutils import Vector

from _r15 import fk, plant, reach

FEET = (("Right", 0.52, 0.0, -4), ("Left", -0.52, -0.12, 4))  # the same marks all scene: nothing slides
TSUBA = (-1.14, -0.48, -0.59)  # the katana's guard in LowerTorso axes, measured in Studio
# left wrist just behind and above the tsuba, thumb on its back face (LowerTorso axes; corrected for the
# captured rig against TSUBA, see notes.md)
THUMB = (-1.44, -0.26, -0.26)


def stand(pose):
    """Both feet planted on their marks, the pose grounded on the captured rig's floor."""
    p = dict(pose)
    for side, x, z, yaw in FEET:
        plant(p, side, x=x, z=z, yaw=yaw)
    return ak.ground(p, RIG)


def pose(base, **joints):
    p = dict(base)
    p.update(joints)
    return stand(p)


def on_katana(base, **joints):
    """The left thumb on the tsuba, ready to push it out (koiguchi), wherever the hips are; the right hand hangs
    ready at his side. (A cross-body grip put the blocky forearm through his chest.)"""
    p = dict(base)
    p.update(joints)
    for side, x, z, yaw in FEET:
        plant(p, side, x=x, z=z, yaw=yaw)
    lt = fk(p)["LowerTorso"]
    reach(p, "Left", tuple(lt @ Vector(THUMB)), elbow=(-1.6, -0.2, 0.3), hand=(0, 0, -15))
    return ak.ground(p, RIG)


REST = {"LowerTorso": (0, 0, 0, 0, 0, 0), "UpperTorso": (0, 0, 0), "Head": (0, 0, 0),
        "RightUpperArm": (0, 0, 2), "RightLowerArm": (3, 0, 0), "RightHand": (0, 0, 0),
        "LeftUpperArm": (0, 0, -2), "LeftLowerArm": (3, 0, 0), "LeftHand": (0, 0, 0)}
SENTRY = dict(REST, LowerTorso=(0, 0, 0, 0, -0.04, 0), UpperTorso=(3, 0, 0), Head=(-20, 0, 0),
              RightUpperArm=(4, 0, 7), RightLowerArm=(12, 0, 0), LeftUpperArm=(4, 0, -7), LeftLowerArm=(12, 0, 0))
DOZE = dict(SENTRY, LowerTorso=(2, 0, 0, 0, -0.07, 0), UpperTorso=(-6, 0, 0), Head=(-34, -3, 0),
            RightUpperArm=(2, 0, 4), RightLowerArm=(8, 0, 0), LeftUpperArm=(2, 0, -4), LeftLowerArm=(8, 0, 0))
# "Halt.": the RIGHT palm (the far side from the camera) raised beside his head, pushed down the steps at the player;
# the chest turns to bring that shoulder in, the head turns back onto the player
PALM = dict(SENTRY, UpperTorso=(-6, 9, 0), Head=(-17, -9, 0), RightUpperArm=(104, 0, 16),
            RightLowerArm=(28, 0, 0), RightHand=(-55, 0, 0), LeftUpperArm=(-4, 0, -9))
# the anticipation for "Halt.": the right arm draws down and back, the chest coils away, the body sinks a little
COIL = dict(SENTRY, LowerTorso=(1, -3, 0, 0, -0.08, 0.06), UpperTorso=(3, -8, 0), Head=(-23, 6, 0),
            RightUpperArm=(-22, 0, 12), RightLowerArm=(55, 0, 0), RightHand=(10, 0, 0))
# the anticipation for the climax: he rears back, chin up, shoulders up, the left hand drifting forward to the hilt
REAR = dict(SENTRY, LowerTorso=(3, 3, 0, 0, -0.05, 0.16), UpperTorso=(9, 4, -4), Head=(-9, 3, 4),
            LeftUpperArm=(12, 0, -16), LeftLowerArm=(40, 0, 0), RightUpperArm=(8, 0, 14), RightLowerArm=(20, 0, 0))
# the lean-in: the katana hangs below the reach of a straight arm, so the chest pitches in and rolls to his left (+z)
# to bring the left shoulder down over the hilt; the head rolls back level and glares down from under the brim
LEAN = dict(SENTRY, LowerTorso=(-6, -7, 0, 0, -0.21, -0.38), UpperTorso=(-15, -5, 23), Head=(-5, 10, -22),
            RightUpperArm=(8, 0, 18), RightLowerArm=(28, 0, 0), RightHand=(0, 0, -10))  # hangs low, out of the close-up
# round 3: the slow palm push of the hold (the weight forward, the head tilting toward the player) and the harder lean
PALM_PUSH = dict(PALM, LowerTorso=(-3, 2, 0, 0, -0.06, -0.14), UpperTorso=(-10, 10, 0), Head=(-20, -8, 7),
                 RightUpperArm=(96, 0, 12), RightLowerArm=(10, 0, 0), RightHand=(-70, 0, 0))
LEAN_HARD = dict(LEAN, LowerTorso=(-9, -7, 0, 0, -0.24, -0.45), UpperTorso=(-18, -5, 23), Head=(-3, 12, -22))


def build():
    a = ak.Anim(NAME, rig=RIG, length=FRAMES, fps=FPS, priority="Action4")
    s2, s3, s4 = SHOTS[1]["start"], SHOTS[2]["start"], SHOTS[3]["start"]
    # 1: dozing; he hears the steps, lifts his head, then squares up (heavy: 18 frames) and fixes on the player
    a.full(0, pose(DOZE), "sine_inout")
    a.full(F(0.5), pose(DOZE, Head=(-35, -2, 0), LowerTorso=(2, 0, 0, 0, -0.09, 0)), "sine_inout")
    a.full(F(0.73), pose(DOZE, Head=(-34, -3, 0)), "cubic_out")
    a.full(F(0.8), pose(DOZE, Head=(-24, 7, 0)), "sine_inout")  # hears: in 4 frames
    a.full(F(1.1), pose(DOZE, Head=(-23, 6, 0), UpperTorso=(-5, 0, 0)), "cubic_inout")
    a.full(F(1.4), pose(SENTRY, UpperTorso=(5, 0, 0), Head=(-21, 0, 0)), "cubic_out")  # squares up, overshoots
    a.full(F(1.55), pose(SENTRY), "sine_inout")
    # 2: "Halt." (Line at s2 + 0.15): anticipation from the cut (7 frames), snap in 3, overshoot 2, settle 12
    a.full(F(s2 + 0.02), pose(SENTRY), "cubic_in")
    a.full(F(s2 + 0.13), pose(COIL), "linear")
    a.full(F(s2 + 0.18), pose(PALM, UpperTorso=(-8, 11, 0), Head=(-19, -10, 0), RightUpperArm=(112, 0, 17),
                              RightHand=(-62, 0, 0)), "linear")
    a.marker(F(s2 + 0.18), "Hit", "palm")
    a.full(F(s2 + 0.22), pose(PALM, UpperTorso=(-8, 11, 0), Head=(-19, -10, 0), RightUpperArm=(113, 0, 17),
                              RightHand=(-62, 0, 0)), "cubic_out")
    a.full(F(s2 + 0.42), pose(PALM), "sine_inout")
    # the hold stays alive: a slow palm push down the steps, the weight onto the front foot, the head tilting in
    a.full(F(s2 + 1.3), pose(PALM_PUSH), "cubic_inout")
    # the palm settles to the chest, the weight comes back; a nod and a tilt on "Nobody"
    a.full(F(s2 + 1.65), pose(SENTRY, UpperTorso=(0, 4, 0), Head=(-21, -3, 2), RightUpperArm=(30, 0, 12),
                              RightLowerArm=(50, 0, 0)), "sine_inout")
    a.full(F(s2 + 1.95), pose(SENTRY, LowerTorso=(0, 0, 2, 0.08, -0.05, 0), UpperTorso=(0, 2, 0), Head=(-26, -2, -3),
                              RightUpperArm=(22, 0, 11), RightLowerArm=(40, 0, 0)), "sine_inout")
    a.full(F(s2 + 2.15), pose(SENTRY, LowerTorso=(0, 0, 2, 0.08, -0.05, 0), UpperTorso=(1, 2, 0), Head=(-20, -2, 2),
                              RightUpperArm=(18, 0, 10), RightLowerArm=(32, 0, 0)), "sine_inout")
    # "...enters after dark": the weight rolls to the other foot, the hand drops to his side
    a.full(F(s2 + 2.65), pose(SENTRY, LowerTorso=(0, 0, -2, -0.06, -0.04, 0), UpperTorso=(2, -3, 0), Head=(-19, 3, -2),
                              RightUpperArm=(10, 0, 10), RightLowerArm=(25, 0, 0)), "cubic_inout")
    # the anticipation for the climax: an inhale and a pull-back, chin up, shoulders up, held into the cut
    a.full(F(s2 + 2.85), pose(SENTRY, LowerTorso=(0, 0, -1, -0.04, -0.05, 0.02), UpperTorso=(3, -2, 0), Head=(-18, 2, -1),
                              RightUpperArm=(10, 0, 10), RightLowerArm=(25, 0, 0)), "cubic_in")
    a.full(F(s2 + 3.12), pose(REAR, UpperTorso=(11, 4, -4), Head=(-6, 3, 4)), "cubic_out")
    a.full(F(s2 + 3.22), pose(REAR, UpperTorso=(12, 4, -4), Head=(-5, 3, 4)), "constant")
    # 3: ON the cut: the hard lean-in, the thumb on the tsuba (a deliberate smear from the held pull-back: Hit)
    a.full(F(s3), on_katana(LEAN_HARD), "linear")
    a.marker(F(s3), "Hit", "koiguchi")
    a.full(F(s3 + 0.05), on_katana(LEAN_HARD, UpperTorso=(-19, -5, 23), Head=(-2, 12, -22)), "cubic_out")
    a.full(F(s3 + 0.2), on_katana(LEAN), "sine_inout")
    a.full(F(s3 + 0.33), on_katana(LEAN, UpperTorso=(-15, -5, 23), Head=(-5, 10, -22)), "cubic_in")
    # a held beat, then he speaks: the chin drops on "Turn back now"
    a.full(F(s3 + 0.4), on_katana(LEAN, UpperTorso=(-16, -5, 23), Head=(-8, 11, -22)), "cubic_out")
    a.full(F(s3 + 1.1), on_katana(LEAN, UpperTorso=(-14, -4, 22), Head=(-7, 10, -22)), "cubic_in")
    # "or I make you": a second push in, 3 frames, then hold
    a.full(F(s3 + 1.15), on_katana(LEAN, LowerTorso=(-7, -7, 0, 0, -0.22, -0.42), UpperTorso=(-17, -5, 24),
                                   Head=(-10, 12, -23)), "cubic_out")
    a.full(F(s3 + 1.4), on_katana(LEAN, UpperTorso=(-16, -5, 23), Head=(-9, 11, -22)), "sine_inout")
    a.full(F(s3 + 1.95), on_katana(LEAN, UpperTorso=(-15, -5, 23), Head=(-9, 10, -22)), "cubic_inout")
    # he rises, lets go of the hilt and stands tall before the cut: shot 4 opens on the same upright pose
    a.full(F(s3 + 2.3), pose(SENTRY, UpperTorso=(2, 0, 0), Head=(-19, 0, 0), LeftUpperArm=(8, 0, -10),
                             LeftLowerArm=(20, 0, 0)), "sine_inout")
    # 4-5: he holds his post, then settles into the world guard's rest pose for the hand-back
    a.full(F(s4 + 0.45), pose(SENTRY, UpperTorso=(1, 0, 0), Head=(-19, 0, 0)), "cubic_inout")
    a.full(F(s4 + 1.0), pose(SENTRY, LowerTorso=(0, 0, 0, 0, -0.02, 0), UpperTorso=(1, 0, 0), Head=(-12, 0, 0),
                             RightUpperArm=(1, 0, 3), RightLowerArm=(5, 0, 0), LeftUpperArm=(1, 0, -3),
                             LeftLowerArm=(5, 0, 0)), "sine_inout")
    a.full(FRAMES, pose(REST), "linear")
    return a
