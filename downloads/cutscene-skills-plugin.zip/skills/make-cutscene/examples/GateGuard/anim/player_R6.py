"""GateGuard, the player's R6 clip: the R15 master's derived keys (DERIVED), re-posed the R6 way (spec 5.8).
R6 has no knees, so the last step becomes a weight settle on the marks (the body rocks forward off the walk, then
back), and every key's legs are swung to keep both soles on their marks (ak.plant), which also grounds the pose.
The flinch's raised forearms (an elbow bend R6 can't show) become straight arms raised higher.
Method by fwjelaa (FWJ STUDIOS)."""

MARKS = ak.soles(ak.ground({"Torso": (0, 0, 0), "Right Leg": (0, 0, 0), "Left Leg": (7, 0, 0)}, "R6"))


def build():
    a = ak.Anim(NAME, rig=RIG, length=FRAMES, fps=FPS, priority="Action4")
    s3 = SHOTS[2]["start"]
    settle = {0: -8, F(0.2): -5, F(0.37): -1.5, F(0.57): 2}  # the walk's momentum: lean forward, then rock back
    guard_up = {F(s3 + 0.05): 52, F(s3 + 0.35): 24}  # the flinch: straight arms up in front of the chest
    for f, (pose, ease) in sorted(DERIVED.items()):
        p = dict(pose)
        if f in settle:
            x, y, z, px, py, pz = (tuple(p["Torso"]) + (0, 0, 0, 0, 0, 0))[:6]
            p["Torso"] = (settle[f], y, z, 0.0, py, 0.0)
        if f in guard_up:
            p["Right Arm"] = (guard_up[f], 0, 12)
            p["Left Arm"] = (guard_up[f], 0, -12)
        a.key(f, ak.plant(p, MARKS), ease)
    return a
