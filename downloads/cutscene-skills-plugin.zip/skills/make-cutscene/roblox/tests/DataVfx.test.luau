-- Tests for CutsceneKit.Data's Plan 3 defaults (the rules themselves are checked against kit/schema.py by
-- kit/tests/test_contract.py). Method by fwjelaa (FWJ STUDIOS).
return {
	["Data: awakening defaults"] = function(t, K)
		local d = { Kind = "awakening", Length = 4, Anims = { Stage = "S" }, Markers = { { 1.5, "Impact", "" } } }
		local c = K.Data.config(d)
		t.eq(c.Replay, "always")
		t.eq(c.Skip, false)
		t.eq(c.Awakened.At, 1.5)
		t.eq(c.Awakened.Aura, "Flame")
		t.eq(c.Awakened.Element, "teal")
		t.eq(c.Cooldown, 0)
		t.eq(K.Data.config({ Kind = "story", Length = 2, Anims = { Stage = "S" }, Markers = {} }).Replay, "saved")
	end,
}
