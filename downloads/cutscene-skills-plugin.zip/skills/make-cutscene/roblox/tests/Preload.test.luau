-- Tests for CutsceneKit.Preload, with fake scene modules, folder and ContentProvider (no engine objects needed). Method by fwjelaa (FWJ STUDIOS).
local function fakeModule(name, data)
	return { Name = name, data = data, IsA = function(self, cls) return cls == "ModuleScript" end }
end
local function fakeFolder(modules)
	return { GetChildren = function() return modules end }
end
local function id(n)
	return "rbxassetid://" .. n
end
local function rig(t, K, modules, opts)
	opts = opts or {}
	local calls = {}
	local provider = {}
	function provider.PreloadAsync(self, list)
		table.insert(calls, list)
		if opts.fail then
			error("PreloadAsync boom")
		end
	end
	local warnings = {}
	local env_folder = fakeFolder(modules)
	local env
	env = {
		contentProvider = provider,
		getFolder = function() return env_folder end,
		distanceOf = function(m) return (opts.dist or {})[m.Name] end,
		spawn = function(fn) fn() end,
		newAnimation = function(aid) return { AnimationId = aid } end,
		require = function(m)
			if m.data == "boom" then
				error("bad module")
			end
			return m.data
		end,
		warn = function(msg) table.insert(warnings, msg) end,
	}
	return K.Preload.new(env), calls, warnings, env
end
local function set(list)
	local s = {}
	for _, v in ipairs(list) do s[v] = true end
	return s
end
local sceneA = { Anims = { Stage = id(1), R15 = { player = id(2), npc = id(3) }, R6 = { player = id(4), npc = id(5) } } }
local sceneClips = { Anims = { Stage = "StageClip", R15 = { player = "PlayerClip" }, R6 = {} } }

return {
	["collect gives stage, own-rig roles and other-rig npc clips but not the other rig's player clip"] = function(t, K)
		local got = set(K.Preload.collect(sceneA, "R15"))
		t.ok(got[id(1)] and got[id(2)] and got[id(3)], "stage + R15 roles")
		t.ok(got[id(5)], "R6 npc clip")
		t.ok(not got[id(4)], "R6 player clip is not needed on R15")
		local r6 = set(K.Preload.collect(sceneA, "R6"))
		t.ok(r6[id(4)] and not r6[id(2)], "R6 player yes, R15 player no")
	end,
	["clips-based refs are skipped"] = function(t, K)
		t.eq(#K.Preload.collect(sceneClips, "R15"), 0)
		local mixed = { Anims = { Stage = id(9), R15 = { player = "PlayerClip", npc = id(8) } } }
		t.eq(#K.Preload.collect(mixed, "R15"), 2)
	end,
	["collect tolerates junk data"] = function(t, K)
		t.eq(#K.Preload.collect(nil, "R15"), 0)
		t.eq(#K.Preload.collect({ Anims = 3 }, "R15"), 0)
	end,
	["run preloads the right ids through ContentProvider in one batch"] = function(t, K)
		local p, calls = rig(t, K, { fakeModule("A", sceneA), fakeModule("C", sceneClips) })
		local ids = p.run("R15")
		t.eq(#ids, 4)
		t.eq(#calls, 1)
		t.eq(#calls[1], 4)
		t.eq(#p.kept, 4, "animations stay referenced")
		t.eq(calls[1][1].AnimationId:sub(1, 13), "rbxassetid://")
	end,
	["a new module triggers a preload of only its ids; a rig change adds the other rig"] = function(t, K)
		local modules = { fakeModule("A", sceneA) }
		local p, calls, _, env = rig(t, K, modules)
		p.run("R15")
		t.eq(#p.run("R15"), 0, "nothing new, no call")
		t.eq(#calls, 1)
		table.insert(modules, fakeModule("B", { Anims = { Stage = id(20), R15 = { player = id(21) } } }))
		local ids = p.run("R15")
		t.eq(#ids, 2)
		t.eq(#calls, 2)
		local more = p.run("R6")
		t.eq(#more, 1, "only the R6 player clip of A is new")
		t.eq(more[1], id(4))
			end,
	["batches of 20"] = function(t, K)
		local roles = {}
		for i = 1, 45 do roles["r" .. i] = id(100 + i) end
		local p, calls = rig(t, K, { fakeModule("Big", { Anims = { Stage = id(1), R15 = roles } }) })
		p.run("R15")
		t.eq(#calls, 3)
		t.eq(#calls[3], 6)
	end,
	["a failing PreloadAsync does not error and is reported"] = function(t, K)
		local p, calls, warnings = rig(t, K, { fakeModule("A", sceneA) }, { fail = true })
		local ok = pcall(p.run, "R15")
		t.ok(ok, "run must not throw")
		t.eq(#calls, 1)
		t.ok(#warnings >= 1, "the failure is logged")
	end,
	["a module that errors on require is skipped"] = function(t, K)
		local p, calls, warnings = rig(t, K, { fakeModule("Bad", "boom"), fakeModule("A", sceneA) })
		t.eq(#p.run("R15"), 4)
		t.eq(#calls, 1)
		t.ok(#warnings >= 1)
	end,
	["no Cutscenes folder is fine"] = function(t, K)
		local p, calls, _, env = rig(t, K, {})
		env.getFolder = function() return nil end
		t.eq(#p.run("R15"), 0)
		t.eq(#calls, 0)
	end,
	["now loads that scene in its own task ahead of the queue, and nothing loads twice"] = function(t, K)
		local queue = {}
		local p, calls, _, env = rig(t, K, { fakeModule("A", sceneA), fakeModule("B", { Anims = { Stage = id(50), R15 = { player = id(51) } } }) })
		env.spawn = function(fn) table.insert(queue, fn) end -- tasks pile up unrun: a busy background queue
		p.run("R15")
		t.eq(#queue, 1)
		local ids = p.now("B", "R15")
		t.eq(#ids, 2, "B is queued but not loaded: now() loads it")
		t.eq(#queue, 2)
		queue[2]() -- the now() task runs first
		t.eq(#calls, 1)
		t.eq(#calls[1], 2)
		queue[1]() -- the background task then skips what is already loaded
		local total = 0
		for _, c in ipairs(calls) do total += #c end
		t.eq(total, 6, "4 from A + 2 from B, each exactly once")
		t.eq(#p.now("B", "R15"), 0, "already loaded")
		t.eq(#p.now("Missing", "R15"), 0)
	end,
	["background queue goes nearest scene first, unknown anchors last"] = function(t, K)
		local mods = {
			fakeModule("Far", { Anims = { Stage = id(1) } }),
			fakeModule("Unknown", { Anims = { Stage = id(2) } }),
			fakeModule("Near", { Anims = { Stage = id(3) } }),
		}
		local p = rig(t, K, mods, { dist = { Far = 500, Near = 10 } })
		local ids = p.run("R15")
		t.eq(ids[1], id(3))
		t.eq(ids[2], id(1))
		t.eq(ids[3], id(2))
	end,
	["MAX_CLIPS caps the background queue nearest-first but not now()"] = function(t, K)
		t.eq(K.Preload.MAX_CLIPS, 200)
		local old = K.Preload.MAX_CLIPS
		K.Preload.MAX_CLIPS = 3
		local mods = {
			fakeModule("Far", { Anims = { Stage = id(1), R15 = { a = id(2), b = id(3) } } }),
			fakeModule("Near", { Anims = { Stage = id(10), R15 = { a = id(11) } } }),
		}
		local p = rig(t, K, mods, { dist = { Far = 90, Near = 5 } })
		local ids = p.run("R15")
		K.Preload.MAX_CLIPS = old
		t.eq(#ids, 3)
		t.eq(ids[1], id(10))
		t.eq(ids[2], id(11))
		t.eq(ids[3], id(1))
		t.eq(#p.now("Far", "R15"), 2, "now() ignores the cap: the two clips the cap left out")
	end,
	["a failed id is retried on the next run; a broken module warns once"] = function(t, K)
		local mods = { fakeModule("Bad", "boom"), fakeModule("A", sceneA) }
		local fail = true
		local p, calls, warnings, env = rig(t, K, mods)
		env.contentProvider.PreloadAsync = function(self, list)
			table.insert(calls, list)
			if fail then error("net") end
		end
		p.run("R15")
		fail = false
		t.eq(#p.run("R15"), 4, "the four failed ids are queued again")
		local bad = 0
		for _, w in ipairs(warnings) do if w:find("Bad", 1, true) then bad += 1 end end
		t.eq(bad, 1)
	end,
	["start wires game load, ChildAdded, CharacterAdded rig change and now"] = function(t, K)
		local function signal()
			local s = { handlers = {} }
			function s:Connect(fn) table.insert(self.handlers, fn) return { Disconnect = function() end } end
			function s:fire(...) for _, h in ipairs(self.handlers) do h(...) end end
			return s
		end
		local list = {}
		local folder = { added = signal(), mods = { fakeModule("A", sceneA) } }
		folder.ChildAdded = folder.added
		function folder:GetChildren() return self.mods end
		local calls = {}
		local provider = { PreloadAsync = function(self, l) table.insert(calls, l) end }
		local waited = false
		local loaded = false
		local rs = {
			FindFirstChild = function() return folder end,
			WaitForChild = function() return folder end,
		}
		local fakeGame = {
			GetService = function(_, n) return n == "ContentProvider" and provider or rs end,
			IsLoaded = function() return loaded end,
			Loaded = { Wait = function() waited = true loaded = true end },
		}
		local player = { CharacterAdded = signal() }
		local queue = {}
		local function flush()
			local n = 0
			while #queue > 0 do
				table.remove(queue, 1)()
				n += 1
			end
			return n
		end
		local handle = K.Preload.start(player, {
			game = fakeGame,
			spawn = function(fn) table.insert(queue, fn) end,
			defer = function(fn) table.insert(queue, fn) end,
			newAnimation = function(aid) return { AnimationId = aid } end,
			distanceOf = function() return nil end,
			require = function(m) return m.data end,
			warn = function() end,
		})
		t.eq(#calls, 0, "nothing loads before the game has")
		t.eq(#handle.now("A"), 4, "now() does not wait for the game")
		flush()
		t.eq(#calls, 1)
		t.ok(waited, "waited for game.Loaded")
		t.eq(#folder.added.handlers, 1, "ChildAdded connected")
		t.eq(#player.CharacterAdded.handlers, 1, "CharacterAdded connected")
		table.insert(folder.mods, fakeModule("B", { Anims = { Stage = id(60) } }))
		folder.added:fire()
		flush()
		t.eq(#calls[#calls], 1, "a new module loads only its own clip")
		local before = #calls
		local char = {
			WaitForChild = function(self) return self.hum end,
			FindFirstChildOfClass = function(self) return self.hum end,
			hum = { RigType = { Name = "R6" } },
		}
		player.CharacterAdded:fire(char)
		flush()
		t.eq(#calls, before + 1, "rig change loads the R6 player clip")
		t.eq(calls[#calls][1].AnimationId, id(4))
	end,
}
