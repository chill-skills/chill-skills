-- Tests for the authoring module Capture (Edit mode). Method by fwjelaa (FWJ STUDIOS).
local HttpService = game:GetService("HttpService")
local ServerStorage = game:GetService("ServerStorage")

local function part(t, size, cf, parent)
	local p = Instance.new("Part")
	p.Anchored = true
	p.Size = size
	p.CFrame = cf
	p.Parent = parent or t.sandbox
	return p
end
local function dropZone(t, name)
	t.defer(function()
		local zones = workspace:FindFirstChild("CutsceneZones")
		local z = zones and zones:FindFirstChild(name)
		if z then
			z:Destroy()
		end
	end)
end

return {
	["adler matches zlib"] = function(t, K)
		t.eq(K.Capture.adler("Wikipedia"), "11e60398")
	end,
	["a box is tenths of studs and degrees, colour in 3 hex digits, transparency in percent"] = function(t, K)
		local rec = K.Capture.encodeBox(CFrame.new(1, 2, 3) * CFrame.Angles(0, math.rad(90), 0), Vector3.new(4, 2, 2), Color3.new(1, 0, 0), 0)
		t.eq(rec, "b,10,20,30,40,20,20,0,900,0,f00,0")
	end,
	["the 12th field is the part's transparency, rounded to a percent"] = function(t, K)
		local function last(transparency)
			local rec = K.Capture.encodeBox(CFrame.new(), Vector3.one, Color3.new(), transparency)
			local fields = string.split(rec, ",")
			t.eq(#fields, 12, "12 fields in " .. rec)
			return fields[12]
		end
		t.eq(last(1), "100")
		t.eq(last(0.25), "25")
		t.eq(last(0.333), "33")
		t.eq(last(0.996), "100")
	end,
	["collect keeps an invisible colliding wall and marks it 100 percent transparent"] = function(t, K)
		local anchor = CFrame.new(0, 300, 0)
		local wall = part(t, Vector3.new(4, 40, 30), anchor * CFrame.new(10, 20, 0))
		wall.Transparency, wall.CanCollide = 1, true -- a map's invisible play bound
		local glass = part(t, Vector3.new(2, 2, 2), anchor * CFrame.new(0, 1, -6))
		glass.Transparency = 0.5
		local boxes = K.Capture.collect(anchor, { root = t.sandbox, radius = 150 })
		t.eq(#boxes, 2)
		local seen = {}
		for _, b in boxes do
			local f = string.split(b, ",")
			seen[f[5] .. "x" .. f[6]] = f[12]
		end
		t.eq(seen["40x400"], "100", "the bound wall: " .. table.concat(boxes, " | "))
		t.eq(seen["20x20"], "50", "the half-clear part")
	end,
	["a trigger part is invisible and can only be touched, whatever its kind"] = function(t, K)
		for _, kind in { "zone", "prompt", "api" } do
			local name = "_CapTestHidden_" .. kind
			dropZone(t, name)
			K.Capture.placeTrigger({ name = name, at = { 0, 900, 0, 0 }, trigger = { type = kind } })
			local zone = workspace.CutsceneZones[name]
			t.eq(zone.Transparency, 1, kind .. " Transparency")
			t.eq(zone.CanCollide, false, kind .. " CanCollide")
			t.eq(zone.CanQuery, false, kind .. " CanQuery")
			t.eq(zone.CanTouch, true, kind .. " CanTouch")
		end
	end,
	["chunks split between records and stay under the size"] = function(t, K)
		local recs = {}
		for i = 1, 25 do
			table.insert(recs, "b," .. i .. ",7")
		end
		local chunks = K.Capture.chunks(recs, 20)
		t.ok(#chunks > 1, "more than one chunk")
		for _, c in chunks do
			t.ok(#c <= 20, "chunk of " .. #c)
		end
		t.eq(table.concat(chunks, ";"), table.concat(recs, ";"))
	end,
	["characters, invisible helpers and cutscene zones are not set"] = function(t, K)
		local npc = Instance.new("Model")
		Instance.new("Humanoid").Parent = npc
		npc.Parent = t.sandbox
		t.ok(K.Capture.ignored(part(t, Vector3.one * 2, CFrame.new(), npc)), "part of a character")
		local helper = part(t, Vector3.one * 4, CFrame.new())
		helper.Transparency, helper.CanCollide = 1, false
		t.ok(K.Capture.ignored(helper), "invisible helper")
		t.ok(not K.Capture.ignored(part(t, Vector3.one * 4, CFrame.new())), "a wall")
		local zones = workspace:FindFirstChild("CutsceneZones") or Instance.new("Folder")
		zones.Name = "CutsceneZones"
		zones.Parent = workspace
		local z = part(t, Vector3.one * 4, CFrame.new(), zones)
		t.defer(function()
			z:Destroy()
		end)
		t.ok(K.Capture.ignored(z), "a cutscene zone")
	end,
	["collect keeps near and big parts first and leaves out tiny and far ones"] = function(t, K)
		local anchor = CFrame.new(0, 100, 0)
		part(t, Vector3.new(8, 8, 8), anchor * CFrame.new(0, 4, -10))
		part(t, Vector3.new(2, 2, 2), anchor * CFrame.new(0, 1, -30))
		part(t, Vector3.new(0.2, 0.2, 0.2), anchor * CFrame.new(1, 0, 0))
		part(t, Vector3.new(4, 4, 4), anchor * CFrame.new(0, 0, -400))
		local boxes, skipped, found = K.Capture.collect(anchor, { root = t.sandbox, radius = 150, maxBoxes = 1 })
		t.eq(found, 2, "found")
		t.eq(#boxes, 1, "kept")
		t.eq(skipped, 2, "the tiny one and the one over maxBoxes")
		t.eq(#boxes + skipped, 3, "kept plus left out is every part considered, none counted twice (found is only those in range)")
		t.ok(string.find(boxes[1], ",80,80,80,", 1, true) ~= nil, "the big near one is kept: " .. boxes[1])
	end,
	["placeTrigger puts the zone's anchor on the floor below the point"] = function(t, K)
		part(t, Vector3.new(40, 1, 40), CFrame.new(10, 219.5, -20))
		dropZone(t, "_CapTestScene")
		local out = HttpService:JSONDecode(K.Capture.placeTrigger({ name = "_CapTestScene", at = { 10, 250, -20, 90 },
			trigger = { type = "zone", size = { 16, 8, 16 } } }))
		t.near(out.anchor[2], 220, 1e-3, "anchor height")
		local zone = workspace.CutsceneZones._CapTestScene
		t.eq(zone:GetAttribute("Cutscene"), "_CapTestScene")
		t.eq(zone:GetAttribute("Trigger"), "zone")
		t.ok((zone.Anchor.WorldPosition - Vector3.new(10, 220, -20)).Magnitude < 1e-3, "anchor attachment")
		t.ok((zone.Anchor.WorldCFrame.LookVector - Vector3.new(-1, 0, 0)).Magnitude < 1e-3, "faces yaw 90")
		t.eq(zone.Size, Vector3.new(16, 8, 16))
	end,
	["a prompt trigger makes a named prompt carrying the scene's name"] = function(t, K)
		local npc = Instance.new("Model")
		npc.Name = "Npc"
		npc.Parent = t.sandbox
		part(t, Vector3.one * 2, CFrame.new(0, 300, 0), npc).Name = "Head"
		dropZone(t, "_CapTestPrompt")
		K.Capture.placeTrigger({ name = "_CapTestPrompt", at = { 0, 300, 0, 0 },
			trigger = { type = "prompt", text = "Talk", distance = 9, on = "_CutsceneKitTest/Npc/Head" } })
		local prompt = t.sandbox.Npc.Head:FindFirstChild("CutscenePrompt__CapTestPrompt")
		t.ok(prompt and prompt:IsA("ProximityPrompt"), "prompt on the head")
		t.eq(prompt:GetAttribute("Cutscene"), "_CapTestPrompt")
		t.eq(prompt.MaxActivationDistance, 9)
		t.eq(prompt.RequiresLineOfSight, false)
		t.eq(workspace.CutsceneZones._CapTestPrompt:GetAttribute("Trigger"), "prompt")
		t.eq(workspace.CutsceneZones._CapTestPrompt.Transparency, 1)
	end,
	["storeMap stores a header and records whose checksums match"] = function(t, K)
		part(t, Vector3.new(40, 1, 40), CFrame.new(0, 399.5, 0))
		part(t, Vector3.new(4, 4, 4), CFrame.new(0, 402, -6))
		part(t, Vector3.new(4, 10, 1), CFrame.new(6, 405, 0))
		dropZone(t, "_CapTestMap")
		t.defer(function()
			local f = ServerStorage:FindFirstChild("CutsceneCapture__CapTestMap")
			if f then
				f:Destroy()
			end
		end)
		K.Capture.placeTrigger({ name = "_CapTestMap", at = { 0, 410, 0, 0 } })
		local summary = K.Capture.storeMap({ name = "_CapTestMap", root = "_CutsceneKitTest", chunk = 40, terrain = false })
		t.ok(string.find(summary, "stored 3 boxes", 1, true) ~= nil, summary)
		local folder = ServerStorage.CutsceneCapture__CapTestMap
		local total = #folder:GetChildren()
		t.ok(total >= 3, "header + at least 2 record chunks with chunk = 40")
		for i = 0, total - 1 do
			local text = folder[tostring(i)].Value
			local head, payload = string.match(text, "^([^\n]*)\n(.*)$")
			local idx, tot, nonce, sum, len = string.match(head, "^MAPCAP _CapTestMap (%d+)/(%d+) (%x+) (%x+) (%d+)$")
			t.ok(nonce and #nonce == 8, "an 8 hex digit capture nonce")
			t.eq(tonumber(idx), i)
			t.eq(tonumber(tot), total)
			t.eq(sum, K.Capture.adler(payload))
			t.eq(tonumber(len), #payload)
		end
		local header = HttpService:JSONDecode(string.match(folder["0"].Value, "\n(.*)$"))
		t.eq(header.boxes, 3)
		t.near(header.anchor[2], 400, 1e-3, "anchor on the floor part")
	end,
	["anchorFrom selection uses the selected part's spot and front"] = function(t, K)
		local Selection = game:GetService("Selection")
		local before = Selection:Get()
		t.defer(function()
			Selection:Set(before)
		end)
		part(t, Vector3.new(20, 1, 20), CFrame.new(50, 499.5, 0))
		local marker = part(t, Vector3.new(1, 1, 1), CFrame.new(50, 503, 0) * CFrame.Angles(0, math.rad(180), 0))
		Selection:Set({ marker })
		local cf = K.Capture.anchorFrom({ from = "selection" })
		t.ok((cf.Position - Vector3.new(50, 500, 0)).Magnitude < 1e-3, "on the floor below the selection")
		t.ok((cf.LookVector - Vector3.new(0, 0, 1)).Magnitude < 1e-3, "facing the part's front")
	end,
	["rigOf reads a default R15's parts and joints, parents first"] = function(t, K)
		local model = game:GetService("Players"):CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType.R15)
		t.defer(function()
			model:Destroy()
		end)
		local r = K.Capture.rigOf(model)
		t.eq(r.rigType, "R15")
		t.eq(#r.joints, 15)
		local placed = { HumanoidRootPart = true }
		for _, j in r.joints do
			t.ok(placed[j[2]], j[3] .. " comes after its parent " .. j[2])
			t.eq(#j[4], 12)
			placed[j[3]] = true
		end
		t.ok(r.parts.LeftFoot ~= nil and r.colors.Head ~= nil, "parts and colours")
	end,
	["captureRig returns JSON with the role and source"] = function(t, K)
		local out = game:GetService("HttpService"):JSONDecode(K.Capture.captureRig({ role = "npc1", source = "default", rig = "R6" }))
		t.eq(out.role, "npc1")
		t.eq(out.rigType, "R6")
		t.eq(#out.joints, 6)
	end,
	["captureRig reports the default avatar when the starter character is missing or a play-test stand-in"] = function(t, K)
		local sp = game:GetService("StarterPlayer")
		local json = game:GetService("HttpService")
		if sp:FindFirstChild("StarterCharacter") then
			return -- a place with its own StarterCharacter cannot show the fallback, and its model must stay untouched
		end
		local plain = json:JSONDecode(K.Capture.captureRig({ role = "player", source = "starter", rig = "R15" }))
		t.eq(plain.source, "default", "no StarterCharacter")
		local stand = Instance.new("Model")
		stand.Name = "StarterCharacter"
		stand:SetAttribute("CutsceneKitPlayTest", true)
		stand.Parent = sp
		t.defer(function()
			stand:Destroy()
		end)
		local skipped = json:JSONDecode(K.Capture.captureRig({ role = "player", source = "starter", rig = "R15" }))
		t.eq(skipped.source, "default", "play-test stand-in skipped")
	end,
}
