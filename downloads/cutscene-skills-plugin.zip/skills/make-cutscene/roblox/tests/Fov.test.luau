-- Tests for CutsceneKit.Fov. Method by fwjelaa (FWJ STUDIOS).
local track = { { 0, 50 }, { 2.5, 40 }, { 2.5, 55 }, { 6, 52 } }
return {
	["holds the ends"] = function(t, K)
		t.near(K.Fov.sample(track, -1), 50)
		t.near(K.Fov.sample(track, 9), 52)
	end,
	["lerps between entries"] = function(t, K)
		t.near(K.Fov.sample(track, 1.25), 45)
	end,
	["two entries at one time are a cut"] = function(t, K)
		t.near(K.Fov.sample(track, 2.4999), 40, 0.01)
		t.near(K.Fov.sample(track, 2.5), 55)
	end,
	["an empty track gives nil"] = function(t, K)
		t.eq(K.Fov.sample({}, 1), nil)
	end,
}
