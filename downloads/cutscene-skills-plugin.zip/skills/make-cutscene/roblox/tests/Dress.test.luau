-- Tests for the Director's costumes (spec 14, Edit mode): which model plays each role, and the player's own avatar
-- left exactly as it was. Method by fwjelaa (FWJ STUDIOS).
local Players = game:GetService("Players")

local function body(t, rig, name)
	local m = Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType[rig])
	m.Name = name
	m.Parent = t.sandbox
	return m
end

-- a scene module whose Costumes folder holds <role>_<rig> models; source = the data module's text
local function scene(t, roles, source)
	local m = Instance.new("ModuleScript")
	m.Name = "_DressScene"
	m.Source = source or "return {}"
	local f = Instance.new("Folder")
	f.Name = "Costumes"
	for role, rigs in roles do
		for _, rig in rigs do
			local c = body(t, rig, role .. "_" .. rig)
			c:SetAttribute("Costume", "Test " .. role)
			local hat = Instance.new("Accessory")
			hat.Name = "CostumeHat"
			hat.Parent = c
			c.Parent = f
		end
	end
	f.Parent = m
	m.Parent = t.sandbox
	t.defer(function()
		local left = workspace:FindFirstChild("CutsceneLocal")
		if left then
			left:Destroy()
		end
	end)
	return m
end

-- a stand-in Player for Director.play in Edit mode, with a real character
local function fakePlayer(t, character)
	local attrs = {}
	local removing = Instance.new("BindableEvent")
	removing.Parent = t.sandbox
	return {
		Character = character,
		CharacterRemoving = removing.Event,
		FindFirstChild = function()
			return nil
		end,
		FindFirstChildOfClass = function()
			return nil
		end,
		SetAttribute = function(_, k, v)
			attrs[k] = v
		end,
		GetAttribute = function(_, k)
			return attrs[k]
		end,
	}
end

local function countClass(model, class)
	local n = 0
	for _, d in model:GetDescendants() do
		if d:IsA(class) then
			n += 1
		end
	end
	return n
end

-- everything that makes an avatar look the way it does: class:name of every descendant, plus the head colour
local function fingerprint(model)
	local parts = { tostring(model.Head.Color) }
	for _, d in model:GetDescendants() do
		table.insert(parts, d.ClassName .. ":" .. d.Name)
	end
	table.sort(parts)
	return table.concat(parts, "|")
end

local function folder(t)
	local f = Instance.new("Folder")
	f.Parent = t.sandbox
	return f
end

return {
	["costume picks the player's rig, else the other one"] = function(t, K)
		local m = scene(t, { player = { "R15", "R6" }, npc1 = { "R15" } })
		t.eq(K.Director.costume(m, "player", "R6").Name, "player_R6")
		t.eq(K.Director.costume(m, "player", "R15").Name, "player_R15")
		t.eq(K.Director.costume(m, "npc1", "R6").Name, "npc1_R15", "a creature has one rig")
		t.eq(K.Director.costume(m, "npc2", "R15"), nil)
	end,
	["the player's copy wears it only with Config.Costume, and the character is never touched"] = function(t, K)
		local m = scene(t, { player = { "R15", "R6" } })
		local f = folder(t)
		local me = body(t, "R6", "Me")
		local before = #me:GetDescendants()
		local copy = Instance.new("Model")
		copy.Name = "CutscenePlayer"
		copy.Parent = f
		local cast = { player = copy }
		K.Director.dress(m, { Costumes = { "player" } }, { Costume = false }, cast, f, me)
		t.eq(cast.player, copy, "no Config.Costume: the player plays as themselves")
		K.Director.dress(m, { Kind = "story", Costumes = { "player" } }, { Costume = true }, cast, f, me)
		t.ok(cast.player ~= copy and cast.player.Parent == f, "the costume copy acts")
		t.eq(cast.player.Name, "CutscenePlayer")
		t.eq(cast.player:GetAttribute("Costume"), "Test player")
		local hum = cast.player:FindFirstChildOfClass("Humanoid")
		t.ok(hum ~= nil and hum.RigType == Enum.HumanoidRigType.R6, "the player's own rig")
		t.eq(copy.Parent, nil, "the plain copy is gone")
		t.eq(#me:GetDescendants(), before, "the character is untouched")
	end,
	["a character that acts itself is never dressed"] = function(t, K)
		local m = scene(t, { player = { "R15" } })
		local me = body(t, "R15", "Me")
		local cast = { player = me } -- a live scene (Plan 3): the real character plays the clip
		K.Director.dress(m, { Kind = "story", Costumes = { "player" } }, { Costume = true }, cast, folder(t), me)
		t.eq(cast.player, me)
	end,
	["costumed NPCs get their model; a missing one is skipped"] = function(t, K)
		local m = scene(t, { npc1 = { "R15", "R6" } })
		local f = folder(t)
		local cast = {}
		K.Director.dress(m, { Costumes = { "npc1", "npc2" } }, {}, cast, f, body(t, "R6", "Me"))
		t.eq(cast.npc1.Name, "npc1")
		t.eq(cast.npc1.Parent, f)
		local hum = cast.npc1:FindFirstChildOfClass("Humanoid")
		t.ok(hum ~= nil and hum.RigType == Enum.HumanoidRigType.R6, "the R6 costume for an R6 player")
		t.eq(cast.npc2, nil)
	end,
	["a costume is never put on an awakening or ultimate"] = function(t, K)
		local m = scene(t, { player = { "R15" } })
		local f = folder(t)
		local me = body(t, "R15", "Me")
		local copy = Instance.new("Model")
		copy.Parent = f
		local cast = { player = copy }
		K.Director.dress(m, { Kind = "awakening", Costumes = { "player" } }, { Costume = true }, cast, f, me)
		t.eq(cast.player, copy)
	end,
	["a costumed scene that ends early dresses a copy, then leaves the avatar exactly as it was"] = function(t, K)
		local me = body(t, "R15", "Me")
		local hat = Instance.new("Accessory")
		hat.Name = "RealHat"
		hat.Parent = me
		Instance.new("Shirt").Parent = me
		Instance.new("Pants").Parent = me
		Instance.new("BodyColors").Parent = me
		local before = fingerprint(me)
		-- spy: the real dress runs, and what it made is looked at while the scene is alive
		local realDress = K.Director.dress
		local seen
		K.Director.dress = function(module, data, cfg, cast, folder, character)
			realDress(module, data, cfg, cast, folder, character)
			seen = {
				copy = cast.player,
				costume = cast.player and cast.player:GetAttribute("Costume"),
				accessories = cast.player and countClass(cast.player, "Accessory"),
				realAccessories = countClass(character, "Accessory"),
				inFolder = cast.player ~= nil and cast.player.Parent == folder,
			}
		end
		t.defer(function()
			K.Director.dress = realDress
		end)
		local source = 'return { Kind = "story", Length = 2, Anims = { Stage = "NoSuchClip" }, Costumes = { "player" }, Config = { Costume = true }, Markers = { { 2, "End", "" } } }'
		local m = scene(t, { player = { "R15", "R6" } }, source)
		local handle = K.Director.play({
			module = m,
			player = fakePlayer(t, me),
			anchor = CFrame.new(0, -500, 0),
			startAt = os.clock() + 0.75,
			now = os.clock,
		})
		t.eq(handle.reason, "load-failed")
		t.ok(seen ~= nil, "Director.play dressed the cast")
		t.eq(seen.costume, "Test player", "the player's copy was the costume")
		t.ok(seen.inFolder, "in the scene's folder")
		t.eq(seen.accessories, 1, "the copy wore the costume's accessory, not the avatar's")
		t.eq(seen.realAccessories, 1, "the avatar kept its own while the scene ran")
		t.ok(not seen.copy:IsDescendantOf(workspace), "the costume copy is gone with the folder")
		t.eq(workspace:FindFirstChild("CutsceneLocal"), nil, "the scene's folder is gone")
		t.eq(fingerprint(me), before, "accessories, clothing and body colours as before")
		t.eq(me.Head.LocalTransparencyModifier, 0, "the avatar shows again")
		t.eq(me.HumanoidRootPart.Anchored, false, "and moves again")
	end,
	["a costumed scene that errors after dressing leaves the avatar exactly as it was"] = function(t, K)
		local me = body(t, "R15", "Me")
		Instance.new("Accessory").Parent = me
		local before = fingerprint(me)
		local realDress = K.Director.dress
		local copy
		K.Director.dress = function(module, data, cfg, cast, folder, character)
			realDress(module, data, cfg, cast, folder, character)
			copy = cast.player
			error("boom after dress") -- the setup xpcall must turn this into finish("error")
		end
		t.defer(function()
			K.Director.dress = realDress
		end)
		local m = scene(t, { player = { "R15", "R6" } },
			'return { Kind = "story", Length = 2, Anims = { Stage = "NoSuchClip" }, Costumes = { "player" }, Config = { Costume = true }, Markers = { { 2, "End", "" } } }')
		local handle = K.Director.play({
			module = m,
			player = fakePlayer(t, me),
			anchor = CFrame.new(0, -500, 0),
			startAt = os.clock() + 0.75,
			now = os.clock,
		})
		t.eq(handle.reason, "error")
		t.ok(copy ~= nil and copy:GetAttribute("Costume") == "Test player", "the costume copy was made")
		t.ok(not copy:IsDescendantOf(workspace), "and is gone")
		t.eq(fingerprint(me), before, "the avatar is as before")
		t.eq(me.Head.LocalTransparencyModifier, 0)
		t.eq(me.HumanoidRootPart.Anchored, false)
	end,
}
