-- Tests for CutsceneKit.Aura (Edit mode, ramps stepped by hand). Method by fwjelaa (FWJ STUDIOS).
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local function rig(t, rigType)
	local m = Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType[rigType or "R15"])
	m.Name = "AuraDummy"
	m:PivotTo(workspace.CurrentCamera.CFrame * CFrame.new(0, 0, -12)) -- near the camera, so nothing is out of range
	m.HumanoidRootPart.Anchored = true
	m.Parent = t.sandbox
	return m
end

local function count(model, name)
	local n = 0
	for _, d in ipairs(model:GetDescendants()) do
		if string.sub(d.Name, 1, #name) == name then
			n += 1
		end
	end
	return n
end

local function fx(t, K)
	local folder = Instance.new("Folder")
	folder.Parent = t.sandbox
	return K.Vfx.new({ parent = folder, manual = true, important = true, quality = 1 })
end

local function classCount(model, class)
	local n = 0
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA(class) and string.sub(d.Name, 1, 12) == "CutsceneAura" then
			n += 1
		end
	end
	return n
end

local function scene(t)
	local module = Instance.new("ModuleScript")
	module.Name = "_AuraTest" .. math.random(1, 1e6)
	module.Source = 'return { Kind = "awakening", Length = 4, Anims = { Stage = "S" }, Markers = { { 1, "Impact", "" }, { 4, "End", "" } }, Config = { Element = "azure", Awakened = { Aura = "Flame", Look = { "eyes", "outline" } } } }'
	module.Parent = ReplicatedStorage:WaitForChild("Cutscenes")
	t.defer(function()
		module:Destroy()
	end)
	return module
end

local function awaken(subject, module, at, endsAt)
	subject:SetAttribute("Awakened", module.Name)
	subject:SetAttribute("AwakenedAt", at)
	subject:SetAttribute("AwakenedEndsAt", endsAt)
	subject:SetAttribute("AwakenedEnd", "expire")
end

return {
	["decor needs quality above 0.5: 0.6 keeps it, 0.5 drops it"] = function(t, K)
		local m = rig(t, "R15")
		local a = K.Aura.attach(m, "Flame", "azure", { "eyes", "outline" }, { quality = 0.6 })
		t.eq(#a.emitters, 10, "phones keep the specks")
		t.eq(#a.eyes, 2, "and the eye trails")
		t.ok(a.light ~= nil, "and the light")
		K.Aura.destroy(a)
		local b = K.Aura.attach(m, "Flame", "azure", { "eyes", "outline" }, { quality = 0.5 })
		t.eq(#b.emitters, 9, "wisps and eye sparks stay, the specks go")
		t.eq(#b.eyes, 0, "no eye trails")
		t.eq(b.light, nil, "no light")
		t.ok(b.highlight ~= nil, "the outline stays")
		t.eq(classCount(m, "Trail"), 0)
		K.Aura.destroy(b)
		t.eq(count(m, "CutsceneAura"), 0)
	end,
	["a not-full aura is the outline only"] = function(t, K)
		local m = rig(t, "R15")
		local a = K.Aura.attach(m, "Flame", "azure", { "eyes" }, { quality = 1, full = false })
		t.eq(#a.emitters, 0)
		t.ok(a.highlight ~= nil, "outline even when the look did not ask for one")
		t.eq(a.light, nil)
		K.Aura.step(a, 1)
		t.near(a.highlight.OutlineTransparency, 0.3)
		K.Aura.destroy(a)
		t.eq(count(m, "CutsceneAura"), 0)
	end,
	["at most four auras are full, two on touch, the nearest first"] = function(t, K)
		t.eq(K.Aura.maxFull(false), 4)
		t.eq(K.Aura.maxFull(true), 2)
		local module = scene(t)
		local npcs = {}
		for i = 1, 6 do
			local m = rig(t, "R15")
			m:PivotTo(workspace.CurrentCamera.CFrame * CFrame.new(0, 0, -(30 - i * 3))) -- 6 is the nearest
			awaken(m, module, 10, 20)
			table.insert(npcs, m)
		end
		local set = K.Aura.fullSet(npcs, 12)
		local n = 0
		for _, m in ipairs(npcs) do
			n += set[m] and 1 or 0
		end
		t.eq(n, 4)
		t.ok(set[npcs[6]] and set[npcs[3]] and not set[npcs[2]] and not set[npcs[1]], "the nearest four")
		local touch = 0
		for _ in pairs(K.Aura.fullSet(npcs, 12, K.Aura.maxFull(true))) do
			touch += 1
		end
		t.eq(touch, 2)
		local states, p = {}, fx(t, K)
		K.Aura.update(states, npcs[6], 12, p, { quality = 1, full = true })
		K.Aura.update(states, npcs[1], 12, p, { quality = 1, full = false })
		t.eq(#states[npcs[6]].aura.emitters, 10)
		t.eq(#states[npcs[1]].aura.emitters, 0, "the far one is the outline only")
		t.ok(states[npcs[1]].aura.highlight ~= nil)
		K.Aura.update(states, npcs[1], 12.1, p, { quality = 1, full = true })
		t.eq(#states[npcs[1]].aura.emitters, 10, "promoted when it becomes one of the nearest")
		t.eq(classCount(npcs[1], "Highlight"), 1, "the outline-only aura was replaced, not doubled")
		K.Vfx.clear(p)
	end,
	["a body swap leaves nothing of the old aura and starts clean"] = function(t, K)
		local module = scene(t)
		local subject = Instance.new("Folder")
		subject.Parent = t.sandbox
		local old, new = rig(t, "R15"), rig(t, "R15")
		local body = old
		local real = K.Aura.characterOf
		K.Aura.characterOf = function()
			return body
		end
		t.defer(function()
			K.Aura.characterOf = real
		end)
		awaken(subject, module, 10, 20)
		local states, p = {}, fx(t, K)
		K.Aura.update(states, subject, 12, p, { quality = 1 })
		t.eq(classCount(old, "ParticleEmitter"), 10)
		body = new -- respawn: attributes unchanged, another character
		K.Aura.update(states, subject, 12.1, p, { quality = 1 })
		t.eq(count(old, "CutsceneAura"), 0, "nothing of the old aura survives")
		t.eq(states[subject].aura.character, new)
		t.eq(classCount(new, "ParticleEmitter"), 10)
		t.eq(classCount(new, "Highlight"), 1)
		subject:SetAttribute("AwakenedAt", nil) -- the server clears the state on the new body
		subject:SetAttribute("AwakenedEndsAt", nil)
		subject:SetAttribute("AwakenedEnd", nil)
		K.Aura.update(states, subject, 12.2, p, { quality = 1 })
		t.eq(states[subject].aura, nil)
		t.eq(count(new, "CutsceneAura"), 0, "a plain body stays plain")
		K.Vfx.clear(p)
	end,
	["a second awakening restarts cleanly with no doubled layers"] = function(t, K)
		local module = scene(t)
		local npc = rig(t, "R15")
		awaken(npc, module, 10, 20)
		local states, p = {}, fx(t, K)
		K.Aura.update(states, npc, 12, p, { quality = 1 })
		local first = states[npc].aura
		K.Aura.update(states, npc, 15, p, { quality = 1 })
		t.ok(states[npc].aura == first, "the same awakening keeps its aura")
		npc:SetAttribute("AwakenedEnd", "ended")
		K.Aura.update(states, npc, 21, p, { quality = 1 })
		t.eq(states[npc].aura.down, true)
		awaken(npc, module, 30, 40) -- awakened again before the power-down finished
		K.Aura.update(states, npc, 31, p, { quality = 1 })
		t.ok(states[npc].aura ~= first and first.dead == true, "the old aura is gone")
		t.eq(states[npc].aura.k, 0, "the new one ramps in from nothing")
		t.eq(classCount(npc, "ParticleEmitter"), 10)
		t.eq(classCount(npc, "Highlight"), 1)
		t.eq(count(npc, "CutsceneAuraLight"), 1, "one light")
		t.eq(classCount(npc, "Trail"), 2)
		K.Vfx.clear(p)
	end,
	["out of range removes the aura and back in range rebuilds it once"] = function(t, K)
		local module = scene(t)
		local npc = rig(t, "R15")
		awaken(npc, module, 10, 20)
		local states, p = {}, fx(t, K)
		K.Aura.update(states, npc, 12, p, { quality = 1 })
		local first = states[npc].aura
		npc:PivotTo(workspace.CurrentCamera.CFrame * CFrame.new(0, 0, -(K.Aura.FAR + 80)))
		K.Aura.update(states, npc, 12.1, p, { quality = 1 })
		t.eq(states[npc].aura, nil)
		t.eq(count(npc, "CutsceneAura"), 0, "nothing left while far away")
		K.Aura.update(states, npc, 12.2, p, { quality = 1 })
		t.eq(count(npc, "CutsceneAura"), 0, "and it is not rebuilt out there")
		npc:PivotTo(workspace.CurrentCamera.CFrame * CFrame.new(0, 0, -12))
		K.Aura.update(states, npc, 12.3, p, { quality = 1 })
		t.ok(states[npc].aura ~= nil and states[npc].aura ~= first and first.dead == true)
		K.Aura.update(states, npc, 12.4, p, { quality = 1 })
		t.eq(classCount(npc, "ParticleEmitter"), 10, "rebuilt once")
		t.eq(classCount(npc, "Highlight"), 1)
		K.Vfx.clear(p)
	end,
	["phase follows the attributes"] = function(t, K)
		t.eq(K.Aura.phase(nil, nil, nil, 5), "off")
		t.eq(K.Aura.phase(10, 20, "expire", 5), "wait")
		t.eq(K.Aura.phase(10, 20, "expire", 15), "on")
		t.eq(K.Aura.phase(10, 20, "ended", 25), "down")
		t.eq(K.Aura.phase(10, 20, "died", 15), "gone")
	end,
	["an R15 aura ramps in with its look and stays under 60 particles"] = function(t, K)
		local m = rig(t, "R15")
		local a = K.Aura.attach(m, "Flame", "azure", { "eyes", "outline" }, { quality = 1 })
		t.eq(#a.emitters, 10, "7 wisp points, the specks and 2 eyes")
		t.eq(a.highlight.OutlineTransparency, 1, "invisible before the ramp")
		K.Aura.step(a, 1)
		t.eq(a.k, 1)
		t.near(a.highlight.OutlineTransparency, 0.3)
		t.near(a.light.Brightness, 0.9)
		local live = 0
		for _, em in ipairs(a.emitters) do
			live += em.e.Rate * em.e.Lifetime.Max
		end
		t.ok(live <= 60, ("about %.1f live particles"):format(live))
		K.Aura.destroy(a)
		t.eq(count(m, "CutsceneAura"), 0, "nothing of the aura is left on the character")
	end,
	["an R6 character gets the same aura on its own parts"] = function(t, K)
		local m = rig(t, "R6")
		local a = K.Aura.attach(m, "Flame", "teal", { "eyes" }, { quality = 1 })
		t.eq(#a.emitters, 10)
		t.eq(a.highlight, nil, "no outline was asked for")
		t.ok(m["Left Arm"]:FindFirstChild("CutsceneAura_LeftHand") ~= nil, "hands map to the arms")
		K.Aura.destroy(a)
	end,
	["the power-down ramps out and plays its preset"] = function(t, K)
		local m = rig(t, "R15")
		local a = K.Aura.attach(m, "Flame", "azure", { "outline" })
		K.Aura.step(a, 1)
		local p = fx(t, K)
		K.Aura.powerDown(a, p)
		t.eq(#p.effects, 1, "PowerDown plays at the feet")
		t.eq(p.effects[1].name, "PowerDown")
		K.Aura.step(a, 1)
		t.eq(a.k, 0)
		K.Vfx.clear(p)
		K.Aura.destroy(a)
	end,
	["a crimson aura builds and ramps in"] = function(t, K)
		local m = rig(t, "R15")
		local a = K.Aura.attach(m, "Flame", "crimson", { "eyes", "outline" }, { quality = 1 })
		t.eq(#a.emitters, 10)
		K.Aura.step(a, 1)
		t.eq(a.k, 1)
		t.eq(a.highlight.OutlineColor, Color3.fromHex("b3101f"), "the outline is crimson's main, not the teal fallback")
		K.Aura.destroy(a)
		t.eq(count(m, "CutsceneAura"), 0)
	end,
	["update draws an NPC's aura from its attributes and drops it on death"] = function(t, K)
		local module = Instance.new("ModuleScript")
		module.Name = "_AuraTest" .. math.random(1, 1e6)
		module.Source = 'return { Kind = "awakening", Length = 4, Anims = { Stage = "S" }, Markers = { { 1, "Impact", "" }, { 4, "End", "" } }, Config = { Element = "azure", Awakened = { Aura = "Flame", Look = { "eyes", "outline" } } } }'
		module.Parent = ReplicatedStorage:WaitForChild("Cutscenes")
		t.defer(function()
			module:Destroy()
		end)
		local npc = rig(t, "R15")
		npc:SetAttribute("Awakened", module.Name)
		npc:SetAttribute("AwakenedAt", 10)
		npc:SetAttribute("AwakenedEndsAt", 20)
		npc:SetAttribute("AwakenedEnd", "expire")
		local states, p = {}, fx(t, K)
		K.Aura.update(states, npc, 5, p)
		t.eq(states[npc], nil, "nothing before the burst")
		K.Aura.update(states, npc, 12, p)
		t.ok(states[npc] and states[npc].aura ~= nil, "on after AwakenedAt")
		t.eq(states[npc].aura.element, "azure")
		K.Aura.update(states, npc, 21, p)
		t.eq(states[npc].aura.down, true, "the power-down starts at AwakenedEndsAt")
		npc:SetAttribute("AwakenedEnd", "died")
		K.Aura.update(states, npc, 21.1, p)
		t.eq(states[npc].aura, nil, "a death drops it at once")
		K.Vfx.clear(p)
	end,
}
