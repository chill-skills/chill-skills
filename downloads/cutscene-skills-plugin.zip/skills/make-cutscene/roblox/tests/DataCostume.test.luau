-- Tests for the costume keys of CutsceneKit.Data.validate (spec 14; the Python twin is kit/tests/test_costume_contract.py).
-- Method by fwjelaa (FWJ STUDIOS).
local function data(over)
	local d = { Name = "T", Kind = "story", Length = 4, Anims = { Stage = "T_Stage" }, Markers = { { 4, "End", "" } },
		Costumes = { "player", "npc1" }, Config = { Costume = true } }
	for k, v in over or {} do
		d[k] = v
	end
	return d
end

local function problems(K, d)
	local _, list = K.Data.validate(d)
	return table.concat(list, " | ")
end

return {
	["a costumed scene is valid"] = function(t, K)
		t.eq(problems(K, data()), "")
		t.eq(problems(K, data({ Costumes = {}, Config = {} })), "")
	end,
	["Costumes must list roles, each once"] = function(t, K)
		t.eq(problems(K, data({ Costumes = "player", Config = {} })), "Costumes must be a list of roles like player or npc1")
		t.eq(problems(K, data({ Costumes = { "hero", "npc1", "npc0" }, Config = {} })),
			"Costumes entry 1 must be a role (player, target, npc1..npc99) | Costumes entry 3 must be a role (player, target, npc1..npc99)")
		t.eq(problems(K, data({ Costumes = { "npc1", "npc1" }, Config = {} })), "Costumes lists npc1 twice")
	end,
	["Config.Costume needs a player costume in a story or intro scene"] = function(t, K)
		t.eq(problems(K, data({ Config = { Costume = "yes" } })), "Config.Costume must be true or false")
		t.eq(problems(K, data({ Costumes = { "npc1" } })), "Config.Costume is true but Costumes has no player")
		t.eq(problems(K, data({ Kind = "awakening" })),
			"Config.Costume works in story and intro scenes only (the player acts as a local copy there)")
	end,
}
