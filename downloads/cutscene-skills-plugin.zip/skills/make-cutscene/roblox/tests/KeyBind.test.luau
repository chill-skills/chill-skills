-- Tests for the example key bind's installer (SceneInstall.keyBind, Edit mode). Method by fwjelaa (FWJ STUDIOS).
-- The key bind's server script itself (rate, minimum gap, ignored client values, bad types, invalid scene) is tested
-- in the real Luau against stubs: kit/tests/test_keybind.py ServerScriptInLuauTest.
local ServerScriptService = game:GetService("ServerScriptService")
local StarterPlayer = game:GetService("StarterPlayer")

return {
	["the key bind installs a Script and a LocalScript, and comes out again"] = function(t, K)
		t.defer(function()
			K.SceneInstall.keyBind({ name = "_KeyBindTest", remove = true })
		end)
		local said = K.SceneInstall.keyBind({ name = "_KeyBindTest", server = "-- server", client = "-- client" })
		t.ok(string.find(said, "installed the key bind", 1, true) ~= nil, said)
		local server = ServerScriptService:FindFirstChild("_KeyBindTest")
		local client = StarterPlayer.StarterPlayerScripts:FindFirstChild("_KeyBindTest")
		t.ok(server and server:IsA("Script") and server.Source == "-- server", "the Script")
		t.ok(client and client:IsA("LocalScript") and client.Source == "-- client", "the LocalScript")
		K.SceneInstall.keyBind({ name = "_KeyBindTest", remove = true })
		t.eq(ServerScriptService:FindFirstChild("_KeyBindTest"), nil)
		t.eq(StarterPlayer.StarterPlayerScripts:FindFirstChild("_KeyBindTest"), nil)
	end,
	["installing the key bind again replaces it, never adds a second copy"] = function(t, K)
		t.defer(function()
			K.SceneInstall.keyBind({ name = "_KeyBindTest", remove = true })
		end)
		K.SceneInstall.keyBind({ name = "_KeyBindTest", server = "-- one", client = "-- one" })
		K.SceneInstall.keyBind({ name = "_KeyBindTest", server = "-- two", client = "-- two" })
		for _, parent in { ServerScriptService, StarterPlayer.StarterPlayerScripts } do
			local n = 0
			for _, c in parent:GetChildren() do
				if c.Name == "_KeyBindTest" then
					n += 1
					t.eq(c.Source, "-- two", parent.Name)
				end
			end
			t.eq(n, 1, parent.Name)
		end
	end,
	["keyBind refuses a call without sources"] = function(t, K)
		t.errors(function()
			K.SceneInstall.keyBind({ name = "_KeyBindTest" })
		end, "server")
		t.eq(ServerScriptService:FindFirstChild("_KeyBindTest"), nil)
	end,
}
