-- Tests for the Director's Plan 3 parts: live casts, cue lookup, the camera guard, Reduced Motion, the blend back, VFX
-- markers, FwjelaaVFX cues (Edit mode). Method by fwjelaa (FWJ STUDIOS).
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

-- a stand-in FwjelaaVFX whose play() makes one part in the test sandbox and returns a stop function that removes it
local FAKE_FWJELAA = [[
local L = { made = {} }
function L.play(name, cf)
	local p = Instance.new("Part")
	p.Name = "External_" .. tostring(name)
	p.Anchored = true
	p.CanCollide, p.CanQuery = false, false
	p.CFrame = cf
	p.Parent = workspace:FindFirstChild("_CutsceneKitTest")
	table.insert(L.made, p)
	return function()
		p:Destroy()
	end
end
return L
]]

local function body(t, name)
	local c = Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType.R15)
	c.Name = name
	c.Parent = t.sandbox
	return c
end

local function inside(part, pos)
	local rel = part.CFrame:PointToObjectSpace(pos)
	local h = part.Size / 2
	return math.abs(rel.X) < h.X and math.abs(rel.Y) < h.Y and math.abs(rel.Z) < h.Z
end

-- An awakening that is set up and waiting for its start (far ahead: Edit mode never plays a frame), acted by `char` as
-- the player's real character. The case ends it with handle.finish; the defer ends it if the case fails first.
local function liveScene(t, K, char, extra)
	local attrs = {}
	local removing = Instance.new("BindableEvent")
	removing.Parent = t.sandbox
	local player = {
		Name = "LivePlayer",
		Character = char,
		CharacterRemoving = removing.Event,
		FindFirstChild = function()
			return nil
		end,
		FindFirstChildOfClass = function()
			return nil
		end,
		SetAttribute = function(_, k, v)
			attrs[k] = v
		end,
		GetAttribute = function(_, k)
			return attrs[k]
		end,
	}
	local module = Instance.new("ModuleScript")
	module.Name = "_LiveScene"
	module.Source = 'return { Kind = "awakening", Length = 6, Anims = { Stage = "Stage" }, Markers = { { 0, "Letterbox", "in" } }'
		.. (extra or "") .. " }"
	local clips = Instance.new("Folder")
	clips.Name = "Clips"
	local kfs = K.ClipBuilder.build(K.clip("Fixture_Walkin_Stage"))
	kfs.Name = "Stage"
	kfs.Parent = clips
	clips.Parent = module
	module.Parent = t.sandbox
	local handle = K.Director.play({ module = module, player = player, anchor = char:GetPivot(),
		startAt = os.clock() + 100, now = os.clock })
	t.defer(function()
		handle.finish("replaced")
	end)
	t.eq(handle.done, false, "the scene is set up and waiting for its start")
	return handle
end

-- installs source as ReplicatedStorage.FwjelaaVFX for this case (a real one the place has is moved aside meanwhile)
local function fakeFwjelaa(t, source)
	local real = ReplicatedStorage:FindFirstChild("FwjelaaVFX")
	if real then
		real.Parent = nil
	end
	local fake = Instance.new("ModuleScript")
	fake.Name = "FwjelaaVFX"
	fake.Source = source
	fake.Parent = ReplicatedStorage
	t.defer(function()
		fake:Destroy()
		if real then
			real.Parent = ReplicatedStorage
		end
	end)
	return fake
end

return {
	["Director: live casts, parts by R15 name, cue lookup"] = function(t, K)
		t.eq(K.Director.liveCast("awakening"), true)
		t.eq(K.Director.liveCast("story"), false)
		local r6 = Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType.R6)
		r6.Parent = t.sandbox
		t.eq(K.Director.partOf(r6, "RightHand"), r6["Right Arm"])
		t.eq(K.Director.partOf(r6, "Nope"), r6.HumanoidRootPart)
		local a, b = { kind = "vfx" }, { kind = "screen" }
		local data = { Cues = { ["VFX:Burst"] = a, VFX = b } }
		t.eq(K.Director.cueFor(data, "VFX", "Burst"), a)
		t.eq(K.Director.cueFor(data, "VFX", "Other"), b)
		t.eq(K.Director.cueFor({}, "VFX", "Burst"), nil)
	end,
	["Director: the camera stays in front of a wall"] = function(t, K)
		local wall = Instance.new("Part")
		wall.Anchored = true
		wall.Size = Vector3.new(20, 20, 1)
		wall.CFrame = CFrame.new(0, -300, 10)
		wall.Parent = t.sandbox
		local params = RaycastParams.new()
		params.FilterType = Enum.RaycastFilterType.Include
		params.FilterDescendantsInstances = { wall }
		local cf = CFrame.lookAt(Vector3.new(0, -300, 20), Vector3.new(0, -300, 0))
		local got = K.Director.clearCamera(Vector3.new(0, -300, 0), cf, params)
		t.near(got.Position.Z, 9.5 - K.Director.POP_MARGIN, 1e-3, "pulled to the near face of the wall")
		t.ok((got.LookVector - cf.LookVector).Magnitude < 1e-6, "still looking the same way")
		local clear = K.Director.clearCamera(Vector3.new(50, -300, 0), cf + Vector3.new(50, 0, 0), params)
		t.ok((clear.Position - Vector3.new(50, -300, 20)).Magnitude < 1e-6, "nothing in the way: unchanged")
	end,
	["Director: a wall right behind the caster fades it, no drawn part holds the camera, finish undoes the fade"] = function(t, K)
		t.eq(K.Director.fadeFor(K.Director.FADE_NEAR + 0.1), 0, "no fade from FADE_NEAR out")
		t.eq(K.Director.fadeFor(0), 1, "full fade at the head")
		local char = body(t, "LiveCaster")
		char:PivotTo(CFrame.new(0, -300, 0))
		char.Head.LocalTransparencyModifier = 0.25 -- the game's own value, which must come back
		local handle = liveScene(t, K, char)
		local guard = handle.ctx.guard
		t.ok(guard ~= nil, "a live scene guards its camera")
		t.eq(guard.params.IgnoreWater, true, "water never stops the guard's ray")
		local head = char.HumanoidRootPart.Position + Vector3.new(0, 1.5, 0)
		local box, size = char:GetBoundingBox()
		local back = box.Position.Z + size.Z / 2 -- the caster faces -Z: its back is the +Z side
		local wall = Instance.new("Part")
		wall.Anchored = true
		wall.Size = Vector3.new(20, 20, 1)
		wall.CFrame = CFrame.new(head.X, head.Y, back + 0.3 + 0.5) -- its near face 0.3 studs behind the caster
		wall.Parent = t.sandbox
		local cf = CFrame.lookAt(head + Vector3.new(0, 0, 10), head)
		local got = K.Director.guardCamera(guard, cf)
		t.ok((got.LookVector - cf.LookVector).Magnitude < 1e-6, "still looking the same way")
		t.ok(not inside(wall, got.Position), "not inside the wall")
		t.ok(got.Position.Z < back + 0.3, "on the caster's side of the wall")
		for _, p in ipairs(t.sandbox:GetDescendants()) do
			if p:IsA("BasePart") and inside(p, got.Position) then
				t.ok(p:IsDescendantOf(char) and p.LocalTransparencyModifier >= 0.999, p:GetFullName() .. " is drawn around the camera")
			end
		end
		t.near(char.Head.LocalTransparencyModifier, 1, 1e-6, "the caster's head is faded")
		t.near(char.UpperTorso.LocalTransparencyModifier, 1, 1e-6, "and the rest of it")
		wall.CFrame += Vector3.new(0, 0, 50) -- the camera is clear again: the caster comes back
		got = K.Director.guardCamera(guard, cf)
		t.ok((got.Position - cf.Position).Magnitude < 1e-6, "nothing in the way: unchanged")
		t.near(char.Head.LocalTransparencyModifier, 0.25, 1e-6, "back to its own value mid-scene")
		t.near(char.UpperTorso.LocalTransparencyModifier, 0, 1e-6)
		wall.CFrame -= Vector3.new(0, 0, 50)
		K.Director.guardCamera(guard, cf)
		t.near(char.UpperTorso.LocalTransparencyModifier, 1, 1e-6, "faded again")
		handle.finish("skip")
		t.near(char.Head.LocalTransparencyModifier, 0.25, 1e-6, "finish puts the caster's own look back")
		t.near(char.UpperTorso.LocalTransparencyModifier, 0, 1e-6)
	end,
	["Director: no roll for reduced motion, and the blend's curve and target"] = function(t, K)
		local cf = CFrame.lookAt(Vector3.new(0, 5, 10), Vector3.zero) * CFrame.Angles(0, 0, 0.5)
		local flat = K.Director.noRoll(cf)
		t.near(flat.RightVector.Y, 0, 1e-6)
		t.ok((flat.LookVector - cf.LookVector).Magnitude < 1e-6)
		t.eq(K.Director.blendAlpha(0), 0)
		t.near(K.Director.blendAlpha(0.5), 0.5)
		t.eq(K.Director.blendAlpha(2), 1)
		local s = { camera = { Rel = CFrame.new(0, 2, 8), CFrame = CFrame.new(1, 2, 3) } }
		local char = body(t, "BlendDummy")
		char:PivotTo(CFrame.new(10, -300, 0))
		t.ok((K.Director.blendTarget(s, char).Position - (char.HumanoidRootPart.CFrame * CFrame.new(0, 2, 8)).Position).Magnitude < 1e-3)
		t.eq(K.Director.blendTarget(s, nil), CFrame.new(1, 2, 3))
	end,
	["Director: a VFX marker fires its prepared effect; Slowmo slows it"] = function(t, K)
		local folder = Instance.new("Folder")
		folder.Parent = t.sandbox
		local m = { 1, "VFX", "Dust" }
		local ctx = { data = { Markers = { m }, Cues = { ["VFX:Dust"] = { kind = "vfx", preset = "Dust" } } },
			cfg = { Element = "teal" }, anchor = CFrame.new(0, -300, 0), cast = {}, cues = {},
			fx = K.Vfx.new({ parent = folder, manual = true, important = true, quality = 1 }) }
		K.Director.prepareVfx(ctx)
		local e = ctx.prepared[m]
		t.eq(type(e), "table", "built before the scene starts (an effect, not false)")
		t.eq(e.started, false, "built, not started")
		t.eq(#ctx.fx.effects, 0, "nothing plays before its marker")
		K.Director.cue(ctx, m)
		t.eq(#ctx.fx.effects, 1)
		t.eq(ctx.fx.effects[1], e, "the marker fires the prepared effect, not a late rebuild")
		K.Director.cue(ctx, { 2, "Slowmo", "0.25" })
		t.near(ctx.fx.timeScale, 0.25)
		K.Director.cue(ctx, { 2, "Impact", "" }) -- no screen layer here (an onlooker): nothing happens, nothing breaks
		K.Vfx.clear(ctx.fx)
	end,
	["Director: a FwjelaaVFX effect fades through the tail after a normal end, and stops at once on a skip"] = function(t, K)
		local fake = fakeFwjelaa(t, FAKE_FWJELAA)
		local tail = K.Director.VFX_TAIL
		K.Director.VFX_TAIL = 0.2 -- a short tail keeps the case quick
		t.defer(function()
			K.Director.VFX_TAIL = tail
		end)
		local cues = ', Cues = { ["VFX:Slash"] = { kind = "vfx", preset = "Slash", external = true } }'
		local endCaster = body(t, "EndCaster")
		endCaster:PivotTo(CFrame.new(0, -300, 0))
		local ended = liveScene(t, K, endCaster, cues)
		K.Director.cue(ended.ctx, { 1, "VFX", "Slash" })
		local lib = require(fake)
		local a = lib.made[1]
		t.ok(a ~= nil and a.Parent ~= nil, "the external effect plays")
		t.eq(#ended.ctx.externals, 1, "and the scene keeps its stop function")
		ended.finish("end")
		t.ok(a.Parent ~= nil, "a normal end leaves it fading through the tail")
		local skipCaster = body(t, "SkipCaster")
		skipCaster:PivotTo(CFrame.new(20, -300, 0))
		local skipped = liveScene(t, K, skipCaster, cues)
		K.Director.cue(skipped.ctx, { 1, "VFX", "Slash" })
		local b = lib.made[2]
		t.ok(b ~= nil and b.Parent ~= nil, "the second scene's effect plays")
		skipped.finish("skip")
		t.eq(b.Parent, nil, "a skip stops it at once")
		t.ok(a.Parent ~= nil, "the ended scene's effect is still in its tail")
		task.wait(0.2 + 0.3)
		t.eq(a.Parent, nil, "stopped once the tail is over")
	end,
	["Director: a FwjelaaVFX that fails to load or to play warns once and never throws"] = function(t, K)
		local ctx = { data = {}, cfg = { Element = "teal" }, anchor = CFrame.new(0, -300, 0), cast = {}, cues = {} }
		local cue = { kind = "vfx", preset = "Slash", external = true }
		local broken = fakeFwjelaa(t, 'error("broken on purpose")')
		K.Director.warned["fwjelaa:require"] = nil
		local ok, err = pcall(K.Director.external, ctx, cue)
		t.ok(ok, "a failing require must not throw: " .. tostring(err))
		t.eq(K.Director.warned["fwjelaa:require"], true, "the failed require warned")
		broken:Destroy()
		fakeFwjelaa(t, 'return { play = function() error("no such preset") end }')
		K.Director.warned["fwjelaa:play:Slash"] = nil
		ok, err = pcall(K.Director.external, ctx, cue)
		t.ok(ok, "a failing play must not throw: " .. tostring(err))
		t.eq(K.Director.warned["fwjelaa:play:Slash"], true, "the failed play warned")
		t.eq(ctx.externals, nil, "nothing to stop")
	end,
}
