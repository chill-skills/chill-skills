-- Tests for the authoring module Costume (spec 14, Edit mode). Method by fwjelaa (FWJ STUDIOS).
-- A character (humanoid) is dressed only with catalog items by id (spec 14.3); parts are for creatures and props (a
-- humanoid's held props, at a hand grip only).
-- Some cases load from the catalog over the network: the "doesn't arrive" ones (asset 1 never arrives as a hair or a
-- face accessory), the lineup, which wears one real hat, and the default-face ones, which wear one real face accessory.
local HttpService = game:GetService("HttpService")
local StarterPlayer = game:GetService("StarterPlayer")

-- a costume as kit/costume.py's install_specs hands it to Studio (no credits, every catalog item with its rigs)
local function hero(over)
	local s = {
		role = "player", character = "Hero", kind = "humanoid",
		body = { head = "#f1c9a5", torso = "#d9d4c7", left_arm = "#f1c9a5", right_arm = "#f1c9a5", left_leg = "#4e3d30",
			right_leg = "#4e3d30" },
		scale = { height = 0.95, width = 0.8 },
		catalog = {},
	}
	for k, v in over or {} do
		s[k] = v
	end
	return s
end

local function item(slot, id, kind, rigs)
	return { slot = slot, id = id, type = kind, name = slot .. " " .. id, rigs = rigs or { "R15", "R6" } }
end

-- kit/costume.py's starter creature: a body, a head and two feet, standing 1.6 studs up
local BEAST = {
	role = "npc1", character = "Beast", kind = "creature", stand = 1.6, root = { 2, 2, 2 },
	parts = {
		Body = { shape = "sphere", size = { 2, 2, 3 }, color = "#7a6a58" },
		Head = { shape = "sphere", size = { 1.5, 1.5, 1.5 }, color = "#7a6a58" },
		FootL = { size = { 0.6, 0.6, 0.8 }, color = "#4a3f35" },
		FootR = { size = { 0.6, 0.6, 0.8 }, color = "#4a3f35" },
	},
	joints = {
		{ "Root", "HumanoidRootPart", "Body", { 0, 0, 0 }, { 0, 0, 0 } },
		{ "Neck", "Body", "Head", { 0, 0.8, -1.6 }, { 0, 0, 0.5 } },
		{ "HipL", "Body", "FootL", { -0.6, -1, 0 }, { 0, 0.3, 0 } },
		{ "HipR", "Body", "FootR", { 0.6, -1, 0 }, { 0, 0.3, 0 } },
	},
	feet = { "FootL", "FootR" },
}

-- props (spec 14.3: never worn as a character's costume; a prop the catalog doesn't have)
local GLOW = { name = "Glow", at = "HatAttachment", parts = {
	{ shape = "sphere", size = { 0.5, 0.5, 0.5 }, offset = { 0, 0.2, 0 }, color = "#e070ff", material = "Neon",
		light = { color = "#e070ff", range = 10, brightness = 2 } } } }
local SWORD = { name = "Sword", at = "RightGripAttachment", parts = {
	{ size = { 0.2, 0.7, 0.2 }, offset = { 0, 0, 0 }, color = "#3a2a1e", material = "Wood" },
	{ size = { 0.1, 2.4, 0.3 }, offset = { 0, 1.7, 0 }, color = "#c9ced6", material = "Metal" } } }

local function gone(t, inst)
	t.defer(function()
		inst:Destroy()
	end)
	return inst
end

-- A stub MarketplaceService in place of the catalog, and no real waits between retries; both are put back afterwards.
-- answers[id] = an AssetTypeId, an error text, or a list of those answered one call after another (the last repeats);
-- an id with no answer is not found (what GetProductInfo says for a missing asset, measured: "... failed because HTTP 404").
local function catalog(t, K, answers)
	local C = K.Costume
	local real = { marketplace = C.marketplace, sleep = C.sleep }
	t.defer(function()
		C.marketplace, C.sleep = real.marketplace, real.sleep
	end)
	local asked, slept = {}, {}
	C.sleep = function(seconds)
		table.insert(slept, seconds)
	end
	C.marketplace = {
		GetProductInfo = function(_, id, infoType)
			assert(infoType == Enum.InfoType.Asset, "asks for an asset")
			table.insert(asked, id)
			local a = answers[id]
			if type(a) == "table" then
				a = #a > 1 and table.remove(a, 1) or a[1]
			end
			if a == nil then
				error("MarketplaceService:getProductInfo() failed because HTTP 404")
			elseif type(a) == "string" then
				error(a)
			end
			return { AssetTypeId = a, Name = "fake" }
		end,
	}
	return asked, slept
end

local function count(list, value)
	local n = 0
	for _, v in list do
		if v == value then
			n += 1
		end
	end
	return n
end

-- is this part held to `body` by a joint anywhere in the model (a weld, or the constraint Roblox swaps an
-- AccessoryWeld for on R15)?
local function heldBy(model, part, body)
	for _, j in model:GetDescendants() do
		local a, b
		if j:IsA("JointInstance") or j:IsA("WeldConstraint") then
			a, b = j.Part0, j.Part1
		elseif j:IsA("Constraint") and j.Attachment0 and j.Attachment1 then
			a, b = j.Attachment0.Parent, j.Attachment1.Parent
		end
		if (a == part and b == body) or (a == body and b == part) then
			return true
		end
	end
	return false
end

-- the head's face that would show: a Decal on the Head that isn't fully transparent, or nil
local function visibleFace(m)
	local head = m:FindFirstChild("Head")
	for _, d in head and head:GetChildren() or {} do
		if d:IsA("Decal") and d.Transparency < 1 then
			return d
		end
	end
	return nil
end

-- Measured (2026-11-08): an R6 head from a description carries the classic face as a Decal named face
-- (rbxasset://textures/face.png); an R15 one is a dynamic head (FaceControls, the face in its mesh) with no Decal, so
-- there is nothing to hide or keep there. kept: the R6 face shows, and no R15 decal was made transparent.
local function keptFace(t, m, rig, what)
	local d = m.Head:FindFirstChildOfClass("Decal")
	if rig == "R6" then
		t.ok(d ~= nil and d.Transparency < 1, rig .. " " .. what)
	else
		t.ok(d == nil or d.Transparency < 1, rig .. " " .. what)
		t.eq(m.Head:GetAttribute("CostumeHeadTexture"), nil, rig .. " " .. what .. " (the head texture stays)")
	end
end

-- a real catalog face accessory (AyanokojiFight's "Kiyotaka Ayanokoji"): the default face is hidden only when one
-- arrived on the built model (ruling, ledger 2b), so these cases load it over the network
local MASK = item("face_acc", 122704149503593, "FaceAccessory")

-- the face accessory the description attached (typed Face, or a handle on a face attachment point), or nil
local function faceAccessory(m)
	for _, c in m:GetChildren() do
		local h = c:IsA("Accessory") and c:FindFirstChild("Handle")
		if h and (c.AccessoryType == Enum.AccessoryType.Face or h:FindFirstChild("FaceFrontAttachment")
			or h:FindFirstChild("FaceCenterAttachment")) then
			return c
		end
	end
	return nil
end

return {
	["a face accessory with no classic face hides the default face on R15 and R6"] = function(t, K)
		-- found in AyanokojiFight: the R6 heads kept the classic smile, opaque, under a see-through face accessory
		for _, rig in { "R15", "R6" } do
			local m, notes = K.Costume.humanoid(hero({ catalog = { MASK } }), rig)
			gone(t, m)
			t.ok(faceAccessory(m) ~= nil, rig .. " the face accessory arrived: " .. table.concat(notes, "; "))
			if rig == "R6" then
				t.ok(m.Head:FindFirstChildOfClass("Decal") ~= nil, rig .. " the face decal is kept (made transparent)")
			elseif m.Head:FindFirstChildOfClass("FaceControls") then
				-- RS-1: the dynamic head's painted eyes showed through on the forehead; its texture goes, kept to undo
				t.eq(m.Head.TextureID, "", rig .. " the dynamic head's own face texture is cleared")
				t.ok(m.Head:GetAttribute("CostumeHeadTexture") ~= nil, rig .. " the old head texture is kept")
			end
			t.eq(visibleFace(m), nil, rig .. " no visible default face")
		end
	end,
	["a classic face, or no face accessory, keeps the face"] = function(t, K)
		for _, rig in { "R15", "R6" } do
			local faced = gone(t, K.Costume.humanoid(hero({ catalog = { MASK, item("face", 2, "Face") } }), rig))
			keptFace(t, faced, rig, "a classic face is kept")
			keptFace(t, gone(t, K.Costume.humanoid(hero(), rig)), rig, "no face accessory: the face stays")
		end
	end,
	["a face accessory that is left off keeps the default face"] = function(t, K)
		-- a definite answer leaves it off (the catalog says 5 is a Hat): the head keeps its face, the note names the item
		catalog(t, K, { [5] = 8 })
		local models, notes = K.Costume.build("player", hero({ catalog = { item("face_acc", 5, "FaceAccessory") } }))
		for rig, m in models do
			gone(t, m)
			keptFace(t, m, rig, "the default face stays")
		end
		t.ok(string.find(table.concat(notes, "; "), "Hero: face_acc 5 (face_acc 5) left off", 1, true) ~= nil,
			table.concat(notes, "; "))
		-- listed but never attached (asset 1 is no face accessory): the face stays too, and the count says so
		for _, rig in { "R15", "R6" } do
			local m, more = K.Costume.humanoid(hero({ catalog = { item("face_acc", 1, "FaceAccessory") } }), rig)
			gone(t, m)
			keptFace(t, m, rig, "listed, never attached: the default face stays")
			t.ok(string.find(table.concat(more, "; "), "0 of 1 catalog accessories arrived", 1, true) ~= nil,
				table.concat(more, "; "))
		end
	end,
	["a re-dress doesn't bring the default face back"] = function(t, K)
		for _, rig in { "R15", "R6" } do
			local m = gone(t, K.Costume.humanoid(hero({ catalog = { MASK } }), rig))
			t.ok(faceAccessory(m) ~= nil, rig .. " the face accessory arrived")
			m.Parent = t.sandbox
			-- a HumanoidDescription applied again (its Face is 0: the default face) ...
			local hum = m:FindFirstChildOfClass("Humanoid")
			t.ok(hum ~= nil, rig .. " a Humanoid")
			hum:ApplyDescription(K.Costume.description(hero(), false, rig))
			t.eq(visibleFace(m), nil, rig .. " no visible default face after ApplyDescription")
			-- ... and the copy Director.dress plays (a clone of the built model)
			local copy = gone(t, m:Clone())
			t.eq(visibleFace(copy), nil, rig .. " no visible default face on the cutscene's copy")
		end
	end,
	["description maps colours, scales and catalog slots"] = function(t, K)
		local spec = hero({ catalog = {
			item("hair", 11, "HairAccessory"), item("hair", 12, "HairAccessory"), item("shirt", 13, "Shirt"),
			item("face", 14, "Face"), item("layered_jacket", 15, "JacketAccessory", { "R15" }) } })
		local d = K.Costume.description(spec, true, "R15")
		t.eq(string.lower(d.HeadColor:ToHex()), "f1c9a5")
		t.near(d.HeightScale, 0.95)
		t.near(d.WidthScale, 0.8)
		-- SetAccessories rebuilds the slot strings in no fixed order (measured: "12,11" 10 times in 200): compare the ids
		local hair = string.split(d.HairAccessory, ",")
		table.sort(hair)
		t.eq(table.concat(hair, ","), "11,12", "the layered list must not wipe the slot strings (spike S16c)")
		t.eq(d.Shirt, 13)
		t.eq(d.Face, 14)
		local layered = d:GetAccessories(false)
		t.eq(#layered, 1, "one layered item")
		t.eq(layered[1].AssetId, 15)
		t.eq(layered[1].AccessoryType, Enum.AccessoryType.Jacket)
		t.eq(layered[1].IsLayered, true)
		t.eq(#K.Costume.description(spec, true, "R6"):GetAccessories(false), 0, "R6 never wears layered clothing")
		t.eq(K.Costume.description(spec, true, "R6").Shirt, 13, "R6 wears the classic shirt")
		t.eq(K.Costume.description(spec, false, "R15").HairAccessory, "", "without the catalog")
	end,
	["a humanoid wears its body on R15 and R6, with no scripts"] = function(t, K)
		for _, rig in { "R15", "R6" } do
			local m, notes = K.Costume.humanoid(hero(), rig)
			gone(t, m)
			t.eq(#notes, 0, rig .. " " .. table.concat(notes, "; "))
			local hum = m:FindFirstChildOfClass("Humanoid")
			t.eq(hum.RigType, Enum.HumanoidRigType[rig], rig)
			local colors = m:FindFirstChildOfClass("BodyColors")
			t.eq(string.lower((colors and colors.HeadColor3 or m.Head.Color):ToHex()), "f1c9a5", rig .. " head colour")
			for _, d in m:GetDescendants() do
				t.ok(not d:IsA("BaseScript"), rig .. " keeps a script: " .. d:GetFullName())
			end
		end
	end,
	["a catalog item is checked before it is worn"] = function(t, K)
		local asked = catalog(t, K, { [11] = 41, [13] = 8 }) -- 41 HairAccessory, 8 Hat; 14 is not found
		local spec = hero({ catalog = { item("hair", 11, "HairAccessory"), item("shirt", 13, "Shirt"),
			item("pants", 14, "Pants") } })
		local kept, notes = K.Costume.verify(spec)
		t.eq(#asked, 3, "every id is asked about")
		t.eq(#kept.catalog, 1)
		t.eq(kept.catalog[1].id, 11)
		t.eq(#spec.catalog, 3, "the spec itself is left as it was")
		local all = table.concat(notes, "; ")
		t.eq(#notes, 2, all)
		t.ok(string.find(all, "Hero", 1, true) and string.find(all, "13", 1, true) and string.find(all, "Hat", 1, true), all)
		t.ok(string.find(all, "14", 1, true) and string.find(all, "404", 1, true), all)
	end,
	["a definite answer is not asked again: a wrong type or a missing asset is left off at once"] = function(t, K)
		local asked, slept = catalog(t, K, { [13] = 8, [-5] = "MarketplaceService:GetProductInfo() -5 is not a valid assetId" })
		local kept, notes = K.Costume.verify(hero({ catalog = { item("shirt", 13, "Shirt"), item("pants", 14, "Pants"),
			item("hat", -5, "Hat") } }))
		t.eq(#kept.catalog, 0)
		t.eq(#notes, 3, table.concat(notes, "; "))
		t.eq(#asked, 3, "each asked once")
		t.eq(#slept, 0, "no retry for an answer")
		t.ok(string.find(notes[2], "no such asset", 1, true) ~= nil, notes[2])
	end,
	["a transient catalog error is retried, then the item is worn"] = function(t, K)
		local asked, slept = catalog(t, K, { [11] = { "HTTP 429 (Too Many Requests)", "HttpError: Timedout", 41 } })
		local kept, notes = K.Costume.verify(hero({ catalog = { item("hair", 11, "HairAccessory") } }))
		t.eq(#notes, 0, table.concat(notes, "; "))
		t.eq(#kept.catalog, 1)
		t.eq(#asked, 3, "asked until it answered")
		t.eq(#slept, 2, "a short wait before each retry")
		t.ok(slept[2] > slept[1], "the wait grows")
	end,
	["a catalog that can't be reached refuses the costume and says to retry the install"] = function(t, K)
		local asked = catalog(t, K, { [11] = "HTTP 503 (Service Unavailable)" })
		t.errors(function()
			K.Costume.verify(hero({ catalog = { item("hair", 11, "HairAccessory") } }))
		end, "retry the install")
		t.eq(#asked, K.Costume.TRIES, "every try was spent")
		local ok, why = pcall(K.Costume.build, "player", hero({ catalog = { item("hair", 11, "HairAccessory") } }))
		t.ok(not ok and string.find(tostring(why), "Hero: hair 11 (hair 11)", 1, true) ~= nil, tostring(why))
		-- never a half-dressed costume in the place: the install is refused and nothing is installed
		t.defer(function()
			K.SceneInstall.remove({ name = "_SIUnreachable" })
		end)
		t.errors(function()
			K.SceneInstall.install({
				name = "_SIUnreachable",
				data = 'return { Name = "_SIUnreachable", Kind = "story", Length = 6, Anims = { Stage = "X" }, Costumes = { "npc1" }, Markers = { { 6, "End", "" } } }',
				cast = {},
				costumes = { npc1 = hero({ role = "npc1", catalog = { item("hair", 11, "HairAccessory") } }) },
				trigger = { type = "zone" },
				anchor = { 0, 740, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1 },
			}, function(name)
				return K[name]
			end)
		end, "retry the install")
		local cs = game:GetService("ReplicatedStorage"):FindFirstChild("Cutscenes")
		t.eq(cs and cs:FindFirstChild("_SIUnreachable"), nil, "nothing installed")
	end,
	["each id is asked once per install and per lineup, across roles"] = function(t, K)
		t.defer(function()
			K.Costume.lineupOff()
		end)
		local asked = catalog(t, K, { [5] = 8 })
		local costumes = { player = hero({ catalog = { item("hat", 5, "Hat") } }),
			npc1 = hero({ role = "npc1", catalog = { item("hat", 5, "Hat") } }) }
		local folder = K.Costume.buildAll(costumes)
		folder:Destroy()
		t.eq(count(asked, 5), 1, "buildAll")
		K.Costume.lineup({ costumes = costumes, at = { 600, 0, 600, 0 } })
		t.eq(count(asked, 5), 2, "lineup asks once more, for its own run")
	end,
	["a catalog item that doesn't arrive is named and the costume still builds"] = function(t, K)
		-- the real catalog: asset 1 is no hair, so it is left off and named
		local models, notes = K.Costume.build("player", hero({ catalog = { item("hair", 1, "HairAccessory") } }))
		for _, m in models do
			gone(t, m)
		end
		t.ok(models.R15 ~= nil and models.R6 ~= nil, "both rigs built")
		t.eq(#notes, 1, table.concat(notes, "; "))
		t.ok(string.find(notes[1], "Hero: hair 1 (hair 1) left off: the catalog has no such asset", 1, true) ~= nil, notes[1])
	end,
	["remove takes away a costume lineup left in the place, never an untagged folder"] = function(t, K)
		local lineup = HttpService:JSONDecode(K.Costume.lineup({ costumes = { npc1 = BEAST }, at = { 600, 0, 600, 0 } }))
		t.eq(lineup.lineup, 1)
		local f = workspace:FindFirstChild("_CostumeLineup")
		t.eq(f and f:GetAttribute("CutsceneKitDev"), true, "tagged as a dev artefact")
		local gone = K.SceneInstall.remove({ name = "_SINoSuchScene" })
		t.ok(string.find(gone, "costume lineup", 1, true) ~= nil, gone)
		t.eq(workspace:FindFirstChild("_CostumeLineup"), nil)
		local own = Instance.new("Folder")
		own.Name = "_CostumeLineup" -- not made by the kit: left alone
		own.Parent = workspace
		t.defer(function()
			own:Destroy()
		end)
		t.ok(string.find(K.SceneInstall.remove({ name = "_SINoSuchScene" }), "costume lineup", 1, true) == nil, "untagged")
		t.eq(K.Costume.lineupOff(), "no costume lineup")
		t.eq(own.Parent, workspace)
	end,
	["an item the catalog vouches for but that never arrives is counted as missing"] = function(t, K)
		catalog(t, K, { [1] = 41 }) -- told it is a hair: the build itself skips it (spike S16, BAD_ID = skipped)
		local models, notes = K.Costume.build("player", hero({ catalog = { item("hair", 1, "HairAccessory") } }))
		for _, m in models do
			gone(t, m)
		end
		local all = table.concat(notes, "; ")
		t.eq(#notes, 2, all)
		t.ok(string.find(all, "Hero R15: 0 of 1 catalog accessories arrived", 1, true) ~= nil, all)
		t.ok(string.find(all, "Hero R6: 0 of 1 catalog accessories arrived", 1, true) ~= nil, all)
	end,
	["a prop sits on its attachment and stays held there on R15 and R6"] = function(t, K)
		for _, rig in { "R15", "R6" } do
			local m = gone(t, K.Costume.humanoid(hero(), rig))
			m.Parent = t.sandbox -- in the place, where the Humanoid would re-weld a Handle it can't place
			t.eq(K.Costume.attach(m, GLOW), nil, rig .. " glow")
			t.eq(K.Costume.attach(m, SWORD), nil, rig .. " sword")
			local glow = m:FindFirstChild("Glow")
			t.ok(glow and glow:IsA("Accessory"), rig .. " Glow accessory")
			local att = m.Head:FindFirstChild("HatAttachment")
			t.near((glow.Handle.Position - (att.WorldPosition + att.WorldCFrame.UpVector * 0.2)).Magnitude, 0, 1e-3, rig .. " on the hat point")
			-- spike S17 (WELD_FOLLOWS = no): a Handle without an Attachment of the body's name is re-welded to the Head
			t.ok(glow.Handle:FindFirstChild("HatAttachment") ~= nil, rig .. " the handle names its attachment")
			t.ok(heldBy(m, glow.Handle, m.Head), rig .. " glow held by the head")
			t.ok(glow.Handle:FindFirstChildOfClass("PointLight") ~= nil, rig .. " light")
			local hand = rig == "R15" and m.RightHand or m["Right Arm"]
			local grip = hand:FindFirstChild("RightGripAttachment")
			t.near((m.Sword.Handle.Position - grip.WorldPosition).Magnitude, 0, 1e-3, rig .. " sword in the hand")
			t.ok(heldBy(m, m.Sword.Handle, hand), rig .. " sword held by the hand")
			t.ok(not heldBy(m, m.Sword.Handle, m.Head), rig .. " sword not re-welded to the head")
			t.eq(#m.Sword:GetChildren(), 2, rig .. " a two-part sword")
		end
	end,
	["a humanoid holds its prop in the hand on R15 and R6, the same way on both"] = function(t, K)
		-- a held prop (kit/costume.py props): built after the description is applied, on both rigs, by build()
		local models, notes = K.Costume.build("player", hero({ props = { SWORD } }))
		t.eq(#notes, 0, table.concat(notes, "; "))
		for _, rig in { "R15", "R6" } do
			local m = gone(t, models[rig])
			m.Parent = t.sandbox -- in the place, where the Humanoid would re-weld a Handle it can't place
			local hand = rig == "R15" and m.RightHand or m["Right Arm"]
			local grip = hand:FindFirstChild("RightGripAttachment")
			local sword = m:FindFirstChild("Sword")
			t.ok(sword ~= nil and sword:IsA("Accessory"), rig .. " the prop is built")
			t.near((sword.Handle.Position - grip.WorldPosition).Magnitude, 0, 0.05, rig .. " the handle is on the grip")
			t.ok(heldBy(m, sword.Handle, hand), rig .. " held by the hand")
			t.ok(sword.Handle:FindFirstChild("RightGripAttachment") ~= nil, rig .. " the handle names its attachment")
			-- held like a Roblox Tool on both rigs (R6's grip attachment is not turned, spike S16): the blade runs
			-- forward out of the fist, -Z of the hand
			local rel = hand.CFrame:VectorToObjectSpace(sword.Sword2.Position - sword.Handle.Position)
			t.near((rel - Vector3.new(0, 0, -1.7)).Magnitude, 0, 1e-3, rig .. (" blade forward: %s"):format(tostring(rel)))
		end
	end,
	["a prop that can't be held is named in the notes, not thrown"] = function(t, K)
		local white = { size = { 1, 1, 1 }, color = "#ffffff" }
		local bad = {
			{ name = "Hat", at = "HatAttachment", parts = { white } }, -- a real attachment, but nothing is worn
			{ name = "Odd", at = "NoSuchGrip", parts = { white } },
			{ name = "Broken", at = "LeftGripAttachment", parts = { { size = { 1, 1, 1 }, color = "#ffffff",
				material = "NoSuchMaterial" } } },
		}
		for _, prop in bad do
			for _, rig in { "R15", "R6" } do
				local ok, m, notes = pcall(K.Costume.humanoid, hero({ props = { prop, SWORD } }), rig)
				t.ok(ok, ("%s %s throws: %s"):format(rig, prop.name, tostring(m)))
				gone(t, m)
				local all = table.concat(notes, "; ")
				t.eq(#notes, 1, all)
				t.ok(string.find(all, ("Hero %s: prop %s left off"):format(rig, prop.name), 1, true) ~= nil, all)
				t.eq(m:FindFirstChild(prop.name), nil, rig .. " nothing of it is added")
				t.ok(m:FindFirstChild("Sword") ~= nil, rig .. " the good prop is still held")
			end
		end
		local m, notes = K.Costume.humanoid(hero({ props = { bad[1] } }), "R15")
		gone(t, m)
		t.ok(string.find(notes[1] or "", "RightGripAttachment or LeftGripAttachment", 1, true) ~= nil, notes[1])
	end,
	["a missing attachment is named and nothing is added"] = function(t, K)
		local m = gone(t, K.Costume.humanoid(hero(), "R15"))
		local why = K.Costume.attach(m, { name = "Odd", at = "NoSuchAttachment", parts = { { size = { 1, 1, 1 }, color = "#ffffff" } } })
		t.eq(why, "Odd: this rig has no NoSuchAttachment")
		t.eq(m:FindFirstChild("Odd"), nil)
	end,
	["a creature stands on its feet and keeps its joints"] = function(t, K)
		local m = gone(t, K.Costume.creature(BEAST))
		local hum = m:FindFirstChildOfClass("Humanoid")
		t.near(m.HumanoidRootPart.Position.Y, 1.6)
		t.near(m.FootL.Position.Y - m.FootL.Size.Y / 2, 0, 1e-3, "soles on y = 0")
		t.near(hum.HipHeight + m.HumanoidRootPart.Size.Y / 2, 1.6, 1e-3, "Director.place stands it the same")
		t.eq(hum.RequiresNeck, false)
		local motors = 0
		for _, d in m:GetDescendants() do
			if d:IsA("Motor6D") then
				motors += 1
			end
		end
		t.eq(motors, 4)
		t.near((m.Head.Position - Vector3.new(0, 2.4, -2.1)).Magnitude, 0, 1e-3, "head where kit/costume.py puts it")
	end,
	["build names one model per rig; buildAll gathers them"] = function(t, K)
		local models = K.Costume.build("npc2", hero({ role = "npc2" }))
		t.eq(models.R15.Name, "npc2_R15")
		t.eq(models.R6:GetAttribute("Costume"), "Hero")
		t.eq(models.R6:GetAttribute("CostumeRig"), "R6")
		for _, m in models do
			m:Destroy()
		end
		local folder, n, notes = K.Costume.buildAll({ player = hero(), npc1 = BEAST })
		gone(t, folder)
		t.eq(folder.Name, "Costumes")
		t.eq(n, 3, "a humanoid in two rigs and a creature in one")
		t.eq(#notes, 0, table.concat(notes, "; "))
		t.ok(folder:FindFirstChild("npc1_R15") and not folder:FindFirstChild("npc1_R6"), "a creature has one rig")
		local module = gone(t, Instance.new("Folder")) -- stands in for the scene module the folder goes in
		folder.Parent = module
		t.eq(K.Director.costume(module, "player", "R6"), folder.player_R6, "the shape the Director reads")
		t.eq(K.Director.costume(module, "npc1", "R6"), folder.npc1_R15, "an R6 player's creature")
	end,
	["captureRig captures the costume's own proportions"] = function(t, K)
		local json = K.Costume.captureRig({ role = "player", spec = hero() }, function(name)
			return K[name]
		end)
		local r = HttpService:JSONDecode(json)
		t.eq(r.rigType, "R15")
		t.eq(r.source, "costume")
		t.eq(r.role, "player")
		t.ok(r.parts.UpperTorso ~= nil and r.parts.Handle == nil, "body parts only, not accessories")
		t.ok(r.parts.UpperTorso[1] < 1.8, ("width 0.8 narrows the torso (a default one is 1.94): %.3f"):format(r.parts.UpperTorso[1]))
	end,
	["lineup stands every costume side by side and says where to look"] = function(t, K)
		t.defer(function()
			K.Costume.lineupOff()
		end)
		-- a real catalog hat (the fixture's Red Cap): a freshly built model's accessory handles sit far from the body
		-- until it is in the place, so spacing by the model's extents scattered the lineup over thousands of studs
		local capped = hero({ catalog = { item("hat", 13724930536, "Hat") } })
		local r = HttpService:JSONDecode(K.Costume.lineup({ costumes = { player = capped, npc1 = BEAST }, at = { 600, 0, 600, 0 } }))
		t.eq(r.lineup, 3)
		t.eq(#r.notes, 0, table.concat(r.notes, "; "))
		t.eq(#r.camera_position, 3)
		t.eq(#r.look_at_position, 3)
		local eye, look = Vector3.new(table.unpack(r.camera_position)), Vector3.new(table.unpack(r.look_at_position))
		t.ok((eye - look).Magnitude < 30, ("the camera is near the lineup: %.1f studs"):format((eye - look).Magnitude))
		local f = workspace:FindFirstChild("_CostumeLineup")
		t.ok(f ~= nil)
		local xs = {}
		for _, m in f:GetChildren() do
			if m:IsA("Model") then
				table.insert(xs, m.HumanoidRootPart.Position.X)
			end
		end
		table.sort(xs)
		for i = 2, #xs do
			t.ok(xs[i] - xs[i - 1] > 2 and xs[i] - xs[i - 1] < 8, ("side by side: %.1f studs apart"):format(xs[i] - xs[i - 1]))
		end
		for _, m in f:GetChildren() do
			if m:IsA("Model") then
				local low = math.huge
				for _, p in m:GetDescendants() do
					if p:IsA("BasePart") and p.Name ~= "HumanoidRootPart" and not p:FindFirstAncestorOfClass("Accessory") then
						low = math.min(low, p.Position.Y - p.Size.Y / 2)
					end
				end
				t.near(low, 0, 0.15, m.Name .. " stands on the floor")
			end
		end
		t.eq(K.Costume.lineupOff(), "costume lineup removed")
		t.eq(K.Costume.lineupOff(), "no costume lineup")
	end,
	["install builds the scene's Costumes folder and says so"] = function(t, K)
		t.defer(function()
			K.SceneInstall.remove({ name = "_SICostume" })
		end)
		local data = 'return { Name = "_SICostume", Kind = "story", Length = 6, Anims = { Stage = "Fixture_Walkin_Stage" }, Costumes = { "player", "npc1" }, Config = { Costume = true }, Markers = { { 6, "End", "" } } }'
		local function args(costumes)
			return {
				name = "_SICostume",
				data = data,
				clips = { Fixture_Walkin_Stage = HttpService:JSONEncode(K.clip("Fixture_Walkin_Stage")) },
				cast = {},
				costumes = costumes,
				trigger = { type = "zone", size = { 16, 8, 16 } },
				anchor = { 0, 620, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1 },
			}
		end
		local function need(name)
			return K[name]
		end
		local out = K.SceneInstall.install(args({ player = hero(), npc1 = BEAST }), need)
		t.ok(string.find(out, "cast 0, costumes 3, trigger zone", 1, true) ~= nil, out)
		t.ok(string.find(out, "data valid", 1, true) ~= nil, out)
		t.ok(string.find(out, "COSTUME:", 1, true) == nil, out)
		local m = game:GetService("ReplicatedStorage").Cutscenes._SICostume
		t.ok(m.Costumes:FindFirstChild("player_R15") and m.Costumes:FindFirstChild("player_R6") and m.Costumes:FindFirstChild("npc1_R15"), "every model")
		-- a costume that can't be built refuses the install and leaves the one before it in place
		local broken = table.clone(BEAST)
		broken.joints = { { "Root", "NoSuchPart", "Body", { 0, 0, 0 }, { 0, 0, 0 } } }
		t.errors(function()
			K.SceneInstall.install(args({ npc1 = broken }), need)
		end)
		local still = game:GetService("ReplicatedStorage").Cutscenes:FindFirstChild("_SICostume")
		t.ok(still == m and still.Costumes:FindFirstChild("player_R15") ~= nil, "the old install stays")
	end,
	["install names a costume note on its line"] = function(t, K)
		t.defer(function()
			K.SceneInstall.remove({ name = "_SICostume" })
		end)
		catalog(t, K, {}) -- nothing is found: the hair is left off and named
		local out = K.SceneInstall.install({
			name = "_SICostume",
			data = 'return { Name = "_SICostume", Kind = "story", Length = 6, Anims = { Stage = "Fixture_Walkin_Stage" }, Costumes = { "npc1" }, Markers = { { 6, "End", "" } } }',
			clips = { Fixture_Walkin_Stage = HttpService:JSONEncode(K.clip("Fixture_Walkin_Stage")) },
			cast = {},
			costumes = { npc1 = hero({ role = "npc1", catalog = { item("hair", 77, "HairAccessory") } }) },
			trigger = { type = "zone", size = { 16, 8, 16 } },
			anchor = { 0, 620, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1 },
		}, function(name)
			return K[name]
		end)
		t.ok(string.find(out, "costumes 2", 1, true) ~= nil, out)
		t.ok(string.find(out, " | COSTUME: Hero: hair 77", 1, true) ~= nil, out)
	end,
	["PlayTest: cast with no scene says so; setRig makes an R15 cast too"] = function(t, K)
		local said = K.PlayTest.cast()
		t.ok(string.find(said, "cast: no scene running", 1, true) == 1, said)
		t.ok(string.find(said, "character accessories=0", 1, true) ~= nil, said)
		local keep = { isStudio = K.PlayTest.isStudio, studioUserId = K.PlayTest.studioUserId, player = K.PlayTest.player }
		t.defer(function()
			K.PlayTest.isStudio, K.PlayTest.studioUserId, K.PlayTest.player = keep.isStudio, keep.studioUserId, keep.player
		end)
		K.PlayTest.isStudio = function()
			return false
		end
		t.errors(function()
			K.PlayTest.cast()
		end, "dev-only")
		K.PlayTest.isStudio = keep.isStudio
		local before = StarterPlayer:FindFirstChild("StarterCharacter")
		if before and not before:GetAttribute("CutsceneKitPlayTest") then
			return -- the place has its own StarterCharacter: PlayTest leaves it alone (PlayTest.test covers that)
		end
		K.PlayTest.studioUserId = function() -- no web call: the stand-in takes a blank look
			return nil
		end
		K.PlayTest.player = function()
			return nil
		end
		t.defer(function()
			K.PlayTest.setRig("avatar")
		end)
		said = K.PlayTest.setRig("R15")
		t.ok(string.find(said, "players spawn as R15 at the next Play", 1, true) == 1, said)
		local m = StarterPlayer:FindFirstChild("StarterCharacter")
		local hum = m and m:FindFirstChildOfClass("Humanoid")
		t.ok(hum ~= nil and hum.RigType == Enum.HumanoidRigType.R15, "an R15 StarterCharacter")
		t.eq(m:GetAttribute("CutsceneKitPlayTest"), true, "tagged, so playtest-off takes it away")
	end,
}
