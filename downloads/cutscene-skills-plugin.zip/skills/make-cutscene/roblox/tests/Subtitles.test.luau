-- Tests for CutsceneKit.Subtitles. Method by fwjelaa (FWJ STUDIOS).
return {
	["show colours the speaker and escapes rich text"] = function(t, K)
		local gui = K.Subtitles.create(t.sandbox)
		K.Subtitles.show(gui, { speaker = "Guard", text = "a <b> & c" })
		t.ok(string.find(gui.Line.Text, "Guard", 1, true) ~= nil, "speaker")
		t.ok(string.find(gui.Line.Text, "a &lt;b&gt; &amp; c", 1, true) ~= nil, "escaped text")
		t.eq(gui.Line.RichText, true)
	end,
	["letterbox on: label sits centred inside the bottom bar and fits"] = function(t, K)
		local lb = K.Letterbox.create(t.sandbox, 0.11)
		K.Letterbox.set(lb, true, true)
		local gui = K.Subtitles.create(t.sandbox)
		K.Subtitles.layout(gui, 1080)
		local l = gui.Line
		t.eq(gui:GetAttribute("Mode"), "bar")
		local centre = l.Position.Y.Scale
		local top = centre - l.Size.Y.Scale * l.AnchorPoint.Y
		local bottom = top + l.Size.Y.Scale
		t.ok(centre > 1 - 0.11 and centre < 1, "vertical centre inside the bar")
		t.ok(top >= 1 - 0.11 - 1e-6 and bottom <= 1 + 1e-6, "label fits within the bar")
		t.near(centre, 1 - 0.055)
		t.eq(gui.IgnoreGuiInset, true)
		t.eq(gui.Plate.Visible, false)
		K.Subtitles.show(gui, { text = "hello" })
		t.eq(gui.Plate.Visible, false)
	end,
	["letterbox off: a backing plate exists and shows with text"] = function(t, K)
		local gui = K.Subtitles.create(t.sandbox)
		K.Subtitles.layout(gui, 1080)
		t.eq(gui:GetAttribute("Mode"), "plate")
		t.ok(gui.Plate ~= nil and gui.Plate:IsA("Frame"), "plate")
		t.ok(gui.Plate.BackgroundTransparency >= 0.35 and gui.Plate.BackgroundTransparency <= 0.45, "plate transparency")
		t.ok(gui.Plate:FindFirstChildOfClass("UICorner") ~= nil, "rounded")
		t.eq(gui.Plate.Visible, false)
		K.Subtitles.show(gui, { text = "hello" })
		t.eq(gui.Plate.Visible, true)
		t.ok(gui.Line.Position.Y.Scale < 1 and gui.Line.Position.Y.Scale > 0.5, "lower part of the picture")
		K.Subtitles.clear(gui)
		t.eq(gui.Plate.Visible, false)
	end,
	["bars too thin for the text fall back to the plate"] = function(t, K)
		local lb = K.Letterbox.create(t.sandbox, 0.11)
		K.Letterbox.set(lb, true, true)
		local gui = K.Subtitles.create(t.sandbox)
		K.Subtitles.layout(gui, 300)
		t.eq(gui:GetAttribute("Mode"), "plate")
		K.Subtitles.show(gui, { text = "hi" })
		t.eq(gui.Plate.Visible, true)
	end,
	["plate follows the letterbox closing"] = function(t, K)
		local lb = K.Letterbox.create(t.sandbox, 0.11)
		K.Letterbox.set(lb, true, true)
		local gui = K.Subtitles.create(t.sandbox)
		K.Subtitles.layout(gui, 1080)
		t.eq(gui:GetAttribute("Mode"), "bar")
		K.Letterbox.set(lb, false, true)
		K.Subtitles.layout(gui, 1080)
		t.eq(gui:GetAttribute("Mode"), "plate")
	end,
	["text size is big enough for phones and capped"] = function(t, K)
		t.ok(K.Subtitles.MIN_TEXT >= 18, "minimum readable size")
		t.ok(K.Subtitles.MAX_TEXT >= 34 * 1.4 - 1, "about 1.4x the old maximum")
		local gui = K.Subtitles.create(t.sandbox)
		local c = gui.Line:FindFirstChildOfClass("UITextSizeConstraint")
		t.eq(c.MinTextSize, K.Subtitles.MIN_TEXT)
		t.eq(c.MaxTextSize, K.Subtitles.MAX_TEXT)
		t.eq(gui.Line.TextScaled, true)
	end,
	["the text has a solid outline"] = function(t, K)
		local gui = K.Subtitles.create(t.sandbox)
		local s = gui.Line:FindFirstChildOfClass("UIStroke")
		t.ok(s ~= nil, "UIStroke present")
		t.ok(s.Thickness >= 1.5 and s.Thickness <= 2, "thickness 1.5-2")
		t.near(s.Transparency, 0)
	end,
	["text stays in the centre 84% width and may wrap to two lines"] = function(t, K)
		local gui = K.Subtitles.create(t.sandbox)
		t.near(gui.Line.Size.X.Scale, 0.84)
		t.eq(gui.Line.TextWrapped, true)
		t.eq(K.Subtitles.MAX_LINES, 2)
	end,
	["bar mode centres above the bottom inset, plate when too short"] = function(t, K)
		local lb = K.Letterbox.create(t.sandbox, 0.11)
		K.Letterbox.set(lb, true, true)
		local gui = K.Subtitles.create(t.sandbox)
		K.Subtitles.layout(gui, 1080, 40)
		t.eq(gui:GetAttribute("Mode"), "bar")
		local l = gui.Line
		local centre = l.Position.Y.Scale
		local bottom = centre + l.Size.Y.Scale / 2
		t.ok(bottom <= 1 - 40 / 1080 + 1e-6, "label ends above the inset")
		t.ok(centre - l.Size.Y.Scale / 2 >= 1 - 0.11 - 1e-6, "label inside the bar")
		t.near(centre, 1 - 0.11 + (0.11 - 40 / 1080) / 2)
		K.Subtitles.layout(gui, 1080, 80)
		t.eq(gui:GetAttribute("Mode"), "plate")
	end,
	["the bottom inset is measured with ScreenInsets, never with the RobloxScript-only GetSafeZoneOffsets"] = function(t, K)
		-- game code may not call GuiService:GetSafeZoneOffsets (lacking capability RobloxScript), so it would always be 0
		local src = game:GetService("ReplicatedStorage").CutsceneKit.Subtitles.Source
		t.eq(string.find(src, "GetSafeZoneOffsets", 1, true), nil, "no restricted API")
		t.eq(type(K.Subtitles.measureBottomInset), "function")
		local before = #t.sandbox:GetChildren()
		t.eq(K.Subtitles.measureBottomInset(t.sandbox), 0, "outside a PlayerGui nothing is laid out: 0")
		t.eq(#t.sandbox:GetChildren(), before, "the probes are gone again")
		t.eq(K.Subtitles.measureBottomInset(nil), 0)
	end,
	["layout reads the measured inset when none is given"] = function(t, K)
		local real = K.Subtitles.measureBottomInset
		t.defer(function()
			K.Subtitles.measureBottomInset = real
		end)
		local measured = 40
		K.Subtitles.measureBottomInset = function()
			return measured
		end
		local lb = K.Letterbox.create(t.sandbox, 0.11)
		K.Letterbox.set(lb, true, true)
		local gui = K.Subtitles.create(t.sandbox)
		K.Subtitles.layout(gui, 1080)
		t.eq(gui:GetAttribute("Mode"), "bar")
		t.near(gui.Line.Position.Y.Scale, 1 - 0.11 + (0.11 - 40 / 1080) / 2)
		measured = 80
		K.Subtitles.layout(gui, 1080)
		t.eq(gui:GetAttribute("Mode"), "plate", "a tall home bar leaves no room in the bar")
	end,
	["clear empties the line"] = function(t, K)
		local gui = K.Subtitles.create(t.sandbox)
		K.Subtitles.show(gui, { text = "x" })
		K.Subtitles.clear(gui)
		t.eq(gui.Line.Text, "")
	end,
	["hold grows with the text and is capped"] = function(t, K)
		t.near(K.Subtitles.hold(""), 1.6)
		t.ok(K.Subtitles.hold(string.rep("a", 40)) > 3, "longer line holds longer")
		t.near(K.Subtitles.hold(string.rep("a", 1000)), 6)
	end,
}
