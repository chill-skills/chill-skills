-- Tests for CutsceneKit.Screen (Edit mode, stepped by hand on a made-up timeline). Method by fwjelaa (FWJ STUDIOS).
local function screen(t, K, opts)
	opts = opts or {}
	local made = {}
	local gui = Instance.new("Folder") -- stands in for PlayerGui
	gui.Parent = t.sandbox
	local sc = K.Screen.new({
		camera = workspace.CurrentCamera,
		playerGui = gui,
		reduced = opts.reduced,
		base = opts.base,
		cast = opts.cast,
		world = t.sandbox,
		follow = opts.follow,
		palette = K.Vfx.palette("azure"),
		track = function(inst)
			table.insert(made, inst)
			return inst
		end,
	})
	t.defer(function()
		K.Screen.clear(sc)
		for _, inst in ipairs(made) do
			pcall(inst.Destroy, inst)
		end
	end)
	return sc, made
end

local function subject(t)
	local m = Instance.new("Model")
	local p = Instance.new("Part")
	p.Anchored = true
	p.Parent = m
	local own = Instance.new("Highlight")
	own.Name = "CutsceneAura"
	own.Parent = m
	m.Parent = t.sandbox
	return m, own
end

return {
	["envelope rises, holds and falls"] = function(t, K)
		t.eq(K.Screen.envelope(-1, 0.1, 0.2, 0.3), 0)
		t.near(K.Screen.envelope(0.05, 0.1, 0.2, 0.3), 0.75)
		t.eq(K.Screen.envelope(0.2, 0.1, 0.2, 0.3), 1)
		t.near(K.Screen.envelope(0.45, 0.1, 0.2, 0.3), 0.75)
		t.eq(K.Screen.envelope(1, 0.1, 0.2, 0.3), 0)
	end,
	["impact frames are two frames"] = function(t, K)
		t.eq(K.Screen.impactPhase(1, 0.99), nil)
		t.eq(K.Screen.impactPhase(1, 1.02), "A")
		t.eq(K.Screen.impactPhase(1, 1.07), "B")
		t.eq(K.Screen.impactPhase(1, 1.2), "done")
	end,
	["at most two flashes in any second"] = function(t, K)
		local sc = screen(t, K)
		local m = subject(t)
		t.eq(K.Screen.impact(sc, 1.0, { m }), true)
		t.eq(K.Screen.flash(sc, 1.3), true)
		t.eq(K.Screen.flash(sc, 1.6), false, "a third within the second is dropped")
		t.eq(K.Screen.flash(sc, 2.05), true, "a new second, a new flash")
		t.ok(string.find(table.concat(sc.log, ","), "flash@1.60 gated", 1, true) ~= nil, table.concat(sc.log, ","))
	end,
	["flashes registered out of time order still keep two per second"] = function(t, K)
		local sc = screen(t, K)
		t.eq(K.Screen.flash(sc, 1.5), true, "a future flash first")
		t.eq(K.Screen.flash(sc, 1.2), true, "one now")
		t.eq(K.Screen.flash(sc, 1.0), false, "the third inside one second is refused, even though two lie after it")
		t.eq(K.Screen.flash(sc, 2.6), true, "outside every window holding two")
	end,
	["impact frames silhouette the subject, then put everything back"] = function(t, K)
		local sc = screen(t, K)
		local m, own = subject(t)
		K.Screen.impact(sc, 1, { m })
		K.Screen.step(sc, 1.01)
		t.eq(sc.impactCC.Enabled, true)
		t.eq(sc.impactCC.Brightness, -1, "frame A: a black world")
		t.eq(#sc.highlights, 1)
		t.eq(sc.highlights[1].FillColor, Color3.new(1, 1, 1), "white subject")
		t.eq(own.Enabled, false, "the subject's own Highlight steps aside")
		K.Screen.step(sc, 1.07)
		t.eq(sc.impactCC.Brightness, 1, "frame B: inverted")
		t.eq(sc.highlights[1].FillColor, Color3.new(0, 0, 0))
		K.Screen.step(sc, 1.2)
		t.eq(sc.impactCC.Enabled, false)
		t.eq(#sc.highlights, 0)
		t.eq(own.Enabled, true, "the subject's own Highlight is back")
		K.Screen.step(sc, 1.21)
		t.ok(sc.flashFrame.BackgroundTransparency < 1, "a white flash follows the two frames")
	end,
	["reduced motion turns impact frames and speed lines off"] = function(t, K)
		local sc = screen(t, K, { reduced = true })
		local m = subject(t)
		t.eq(K.Screen.impact(sc, 1, { m }), false)
		t.eq(K.Screen.speedLines(sc, 1, { life = 0.4 }), false)
		K.Screen.step(sc, 1.01)
		t.eq(sc.impactCC.Enabled, false)
		t.ok(string.find(table.concat(sc.log, ","), "impact@1.00 reduced", 1, true) ~= nil)
	end,
	["a grade pulse goes back to the scene's own grade"] = function(t, K)
		local sc = screen(t, K, { base = { Saturation = -0.2, Tint = "ffd9a0" } })
		t.near(sc.grade.Saturation, -0.2)
		t.eq(sc.grade.TintColor, Color3.fromRGB(255, 217, 160))
		K.Screen.grade(sc, 0, { sat = 0.4, attack = 0.1, hold = 0.1, release = 0.1 })
		K.Screen.step(sc, 0.15)
		t.near(sc.grade.Saturation, 0.2)
		K.Screen.step(sc, 0.5)
		t.near(sc.grade.Saturation, -0.2)
		t.eq(#sc.events, 0, "a finished pulse is dropped")
	end,
	["a preset's screen entries become pulses at the marker time"] = function(t, K)
		local sc = screen(t, K)
		K.Screen.apply(sc, 2, K.VfxPresets.Presets.Burst.screen)
		K.Screen.step(sc, 2.05)
		t.eq(sc.bloom.Enabled, true)
		t.ok(sc.grade.Saturation > 0.3, "the burst's saturation spike")
		K.Screen.step(sc, 4)
		t.eq(sc.bloom.Enabled, false)
	end,
	["a word is a comic-font TextLabel with a capped stroke, punched in by a UIScale, then gone"] = function(t, K)
		local sc = screen(t, K)
		t.eq(K.Screen.word(sc, 1, { text = "POW!!", at = { 0.3, 0.2 }, size = 0.2, rot = -12, life = 1, fill = "black",
			stroke = 0.2 }), true)
		K.Screen.step(sc, 1.0)
		local l = sc.manga:FindFirstChild("Word")
		t.ok(l ~= nil and l:IsA("TextLabel"), "a TextLabel, not an image (moderation)")
		t.eq(l.Text, "POW!!")
		t.eq(l.FontFace.Family, Font.fromEnum(Enum.Font.Bangers).Family)
		t.eq(l.TextColor3, Color3.new(0, 0, 0))
		local stroke, scale = l:FindFirstChildOfClass("UIStroke"), l:FindFirstChildOfClass("UIScale")
		t.near(stroke.Thickness, 7, 1e-3, "capped at 7 % of the 100 px text")
		t.eq(stroke.Color, Color3.new(1, 1, 1), "a dark word gets a light edge")
		local vpY = workspace.CurrentCamera.ViewportSize.Y
		t.near(scale.Scale, 0.2 * vpY / 100 * 1.6, 1e-3, "punched in at 1.6x")
		K.Screen.step(sc, 1.3)
		t.near(scale.Scale, 0.2 * vpY / 100, 1e-3, "settled at its size")
		t.eq(l.TextTransparency, 0)
		K.Screen.step(sc, 2.1)
		t.eq(l.Parent, nil, "gone after its life")
	end,
	["a burst shows its sheet cell at its point, scales in, flickers on twos and fades"] = function(t, K)
		local sc = screen(t, K)
		K.Screen.burst(sc, 0, { image = "burst2", at = { 0.5, 0.5 }, size = 0.4, life = 0.5, rot = 20 })
		K.Screen.step(sc, 0)
		local l = sc.manga:FindFirstChild("Burst")
		local vpY = workspace.CurrentCamera.ViewportSize.Y
		t.eq(l.Image, K.Screen.MANGA.burst2.id)
		t.eq(l.ImageRectOffset, Vector2.new(0, 512), "burst2 is the sheet's bottom row")
		t.ok(l.Size.X.Offset < 0.4 * vpY * 0.5, "starts small")
		t.eq(l.Rotation, 20)
		K.Screen.step(sc, 0.1)
		t.near(l.Size.X.Offset, 0.4 * vpY, 1, "full size (whole pixels)")
		t.eq(l.ImageRectOffset, Vector2.new(512, 512), "the next jitter frame")
		t.eq(l.ImageTransparency, 0)
		K.Screen.step(sc, 0.45)
		t.ok(l.ImageTransparency > 0, "fading")
		K.Screen.step(sc, 0.6)
		t.eq(l.Parent, nil)
	end,
	["focus lines are four rotated quadrant cells round the focus, doubled by density"] = function(t, K)
		local sc = screen(t, K)
		K.Screen.speedLines(sc, 0, { focus = { 0.4, 0.5 }, life = 0.5, alpha = 1, density = 0.8, color = "black" })
		K.Screen.step(sc, 0.01)
		local labels = {}
		for _, c in ipairs(sc.manga:GetChildren()) do
			if c.Name == "FocusLines" then
				table.insert(labels, c)
			end
		end
		t.eq(#labels, 8, "density 0.8: two sets of four")
		local rots = {}
		for _, l in ipairs(labels) do
			rots[l.Rotation] = true
			t.eq(l.Image, K.Screen.MANGA.lines.id)
			t.eq(l.ImageColor3, Color3.new(0, 0, 0))
			t.eq(l.ImageTransparency, 0)
		end
		t.ok(rots[0] and rots[90] and rots[180] and rots[270], "all four quadrants")
		local before = labels[1].ImageRectOffset
		local changed = false
		for k = 1, 4 do
			K.Screen.step(sc, 0.01 + k / 12)
			changed = changed or labels[1].ImageRectOffset ~= before
		end
		t.ok(changed, "the cells jitter on twos")
		K.Screen.step(sc, 0.6)
		t.eq(labels[1].Parent, nil)
	end,
	["the backdrop card sits behind the farthest cast member and fills the view, unlit"] = function(t, K)
		local cam = workspace.CurrentCamera
		local m = Instance.new("Model")
		local p = Instance.new("Part")
		p.Anchored = true
		p.Size = Vector3.new(2, 5, 2)
		p.CFrame = cam.CFrame * CFrame.new(0, 0, -12)
		p.Parent = m
		m.Parent = t.sandbox
		local sc = screen(t, K, { cast = { npc1 = m } })
		K.Screen.backdrop(sc, 0, { image = "plum", dist = 5, life = 1 })
		K.Screen.step(sc, 0.1)
		local card = sc.card
		t.eq(card.gui.Enabled, true)
		t.eq(card.gui.LightInfluence, 0)
		t.eq(card.img.Image, K.Screen.MANGA.plum.id)
		local depth = (card.part.Position - cam.CFrame.Position):Dot(cam.CFrame.LookVector)
		t.ok(depth >= 12 + 1 + K.Screen.CARD_GAP - 0.01, ("behind the cast: depth %.2f"):format(depth))
		local h = 2 * depth * math.tan(math.rad(cam.FieldOfView) / 2)
		t.ok(card.part.Size.Y >= h, "fills the view's height")
		K.Screen.backdrop(sc, 0.5, { color = "#ffffff", life = 1 })
		K.Screen.step(sc, 0.6)
		t.eq(card.img.BackgroundTransparency, 0, "the newer card shows: a flat colour")
		K.Screen.step(sc, 1.6)
		t.eq(card.gui.Enabled, false, "no backdrop after their lives")
	end,
	["the cast light sits between each cast member's head and the camera"] = function(t, K)
		local cam = workspace.CurrentCamera
		local m = Instance.new("Model")
		local root = Instance.new("Part")
		root.Name = "HumanoidRootPart"
		root.Anchored = true
		root.CFrame = cam.CFrame * CFrame.new(0, 0, -20)
		root.Parent = m
		m.Parent = t.sandbox
		local sc = screen(t, K, { cast = { player = m } })
		t.eq(K.Screen.castLight(sc, { Color = "ffffff", Brightness = 2, Range = 12 }), 1)
		K.Screen.step(sc, 0)
		local att = root:FindFirstChild("CutsceneCastLight")
		local light = att:FindFirstChildOfClass("PointLight")
		t.eq(light.Range, 12)
		t.eq(light.Shadows, false)
		local toCam = (att.WorldPosition - root.Position):Dot((cam.CFrame.Position - root.Position).Unit)
		t.near(toCam, K.Screen.CASTLIGHT_AHEAD, 1.1, "toward the camera (and 1 stud up)")
		K.Screen.clear(sc)
		t.eq(att.Parent, nil, "clear takes it off")
	end,
	["more manga layers than the cap are dropped, and a big burst is a gated flash"] = function(t, K)
		local sc = screen(t, K)
		for i = 1, K.Screen.MAX_LAYERS do
			t.eq(K.Screen.word(sc, 1, { text = "BZZT" .. i }), true)
		end
		t.eq(K.Screen.word(sc, 1, { text = "ONE MORE" }), false)
		t.ok(string.find(table.concat(sc.log, ","), "word@1.00 dropped", 1, true) ~= nil)
		local sc2 = screen(t, K)
		t.eq(K.Screen.impact(sc2, 2.0, {}), true)
		t.eq(K.Screen.flash(sc2, 2.2), true)
		t.eq(K.Screen.burst(sc2, 2.4, { size = 0.8 }), false, "a third flash in the second")
		t.eq(K.Screen.burst(sc2, 2.4, { size = 0.4 }), true, "a small burst is no flash")
		local sc3 = screen(t, K, { reduced = true })
		t.eq(K.Screen.burst(sc3, 1, { size = 0.8 }), false, "reduced motion: no big burst")
		t.eq(K.Screen.word(sc3, 1, { text = "?!" }), true, "words stay, without their punch")
		K.Screen.step(sc3, 1)
		local word = sc3.manga:FindFirstChild("Word")
		t.ok(word ~= nil, "the word is up")
		local scale = word and word:FindFirstChildOfClass("UIScale")
		t.near(scale and scale.Scale, K.Screen.WORD_SIZE * workspace.CurrentCamera.ViewportSize.Y / 100, 1e-3, "no punch")
	end,
	["clear takes every manga layer down"] = function(t, K)
		local sc = screen(t, K)
		K.Screen.word(sc, 0, { text = "BZZT" })
		K.Screen.burst(sc, 0, {})
		K.Screen.backdrop(sc, 0, { image = "inksmoke" })
		K.Screen.step(sc, 0.02)
		t.ok(#sc.manga:GetChildren() >= 2)
		K.Screen.clear(sc)
		t.eq(#sc.manga:GetChildren(), 0)
		t.eq(sc.card.gui.Enabled, false)
	end,
	["clear mid-impact gives the subject its Highlight back"] = function(t, K)
		local sc = screen(t, K)
		local m, own = subject(t)
		K.Screen.impact(sc, 1, { m })
		K.Screen.step(sc, 1.01)
		K.Screen.clear(sc)
		t.eq(own.Enabled, true)
		t.eq(sc.impactCC.Enabled, false)
	end,
	["Snapshot: a plain restore after a camera-less one gives the camera back"] = function(t, K)
		local cam = workspace.CurrentCamera
		local before = cam.CameraType
		local subject = cam.CameraSubject
		local root = Instance.new("Part")
		root.Anchored = true
		root.Parent = t.sandbox
		local s = K.Snapshot.capture({ camera = cam, root = root })
		cam.CameraType = Enum.CameraType.Scriptable
		t.defer(function()
			cam.CameraType = before
		end)
		K.Snapshot.restore(s, { camera = false })
		t.eq(cam.CameraType, Enum.CameraType.Scriptable)
		K.Snapshot.restore(s, { camera = false })
		t.eq(cam.CameraType, Enum.CameraType.Scriptable, "camera = false again leaves it")
		K.Snapshot.restore(s)
		t.eq(cam.CameraType, before)
		t.eq(cam.CameraSubject, subject)
	end,
	["Snapshot: the camera can be given back after the rest"] = function(t, K)
		local cam = workspace.CurrentCamera
		local before = cam.CameraType
		local root = Instance.new("Part")
		root.Anchored = true
		root.CFrame = CFrame.new(5, -300, 0)
		root.Parent = t.sandbox
		local s = K.Snapshot.capture({ camera = cam, root = root })
		t.ok(s.camera.Rel ~= nil, "the camera's place relative to the character")
		cam.CameraType = Enum.CameraType.Scriptable
		t.defer(function()
			cam.CameraType = before
		end)
		K.Snapshot.restore(s, { camera = false })
		t.eq(cam.CameraType, Enum.CameraType.Scriptable, "left for the blend")
		K.Snapshot.restoreCamera(s)
		t.eq(cam.CameraType, before)
	end,
}
