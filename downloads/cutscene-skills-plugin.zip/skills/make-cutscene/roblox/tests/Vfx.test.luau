-- Tests for CutsceneKit.Vfx (Edit mode; the timeline is stepped by hand, so nothing waits). Method by fwjelaa (FWJ STUDIOS).
local HERE = CFrame.new(0, -300, 0) -- under the map, near nothing

local function player(t, K, opts)
	local folder = Instance.new("Folder")
	folder.Name = "Fx"
	folder.Parent = t.sandbox
	opts = opts or {}
	opts.parent = folder
	opts.manual = true
	if opts.important == nil then
		opts.important = true
	end
	opts.quality = opts.quality or 1
	return K.Vfx.new(opts)
end

local function run(K, p, seconds, dt)
	dt = dt or 1 / 30
	for _ = 1, math.ceil(seconds / dt) do
		K.Vfx.step(p, dt)
	end
end

-- For one case the workspace camera looks at HERE from about 32 studs, inside Vfx.LOW_DETAIL, so effects there play at
-- full detail (far away, decor is off and counts are halved at every quality). The camera goes back after the case.
local function nearCamera(t)
	local cam = workspace.CurrentCamera
	local keep = cam.CFrame
	t.defer(function()
		cam.CFrame = keep
	end)
	cam.CFrame = CFrame.lookAt(HERE.Position + Vector3.new(0, 10, 30), HERE.Position)
end

return {
	["curve reads numbers, pairs and keys"] = function(t, K)
		t.eq(K.Vfx.curve(3, 0.5, 1), 3)
		t.near(K.Vfx.curve({ 0, 10 }, 0.5, 1, "linear"), 5)
		t.near(K.Vfx.curve({ { 0, 0 }, { 1, 10 }, { 2, 0, "in" } }, 1.5), 7.5)
		t.near(K.Vfx.curve({ { 0, 0 }, { 1, 10 } }, 5), 10, 1e-6, "holds the last key")
		t.near(K.Vfx.curve({ { 0.5, 2 }, { 1, 4 } }, 0), 2, 1e-6, "holds the first key")
	end,
	["palette roles, accents and hex colours"] = function(t, K)
		local pal = K.Vfx.palette("azure")
		t.eq(pal.accent, Color3.fromRGB(255, 200, 74))
		-- every element in the library has its own accent, so the fallback is checked on a stand-in element
		local elements = K.VfxPresets.Elements
		local plain = table.clone(elements.teal)
		plain.accent = nil
		elements._NoAccent = plain
		t.defer(function()
			elements._NoAccent = nil
		end)
		t.eq(K.Vfx.palette("_NoAccent").accent, K.Vfx.palette("_NoAccent").hot, "an element without an accent uses hot")
		t.eq(K.Vfx.palette("teal").accent, K.Vfx.hex(elements.teal.accent), "an element's own accent wins")
		t.eq(K.Vfx.color(pal, "#ff0000"), Color3.fromRGB(255, 0, 0))
		t.eq(K.Vfx.palette("nope").main, K.Vfx.palette("teal").main, "an unknown element falls back to teal")
	end,
	["budget is the same rule as kit/vfxlib.py"] = function(t, K)
		local b = K.Vfx.budget("Burst")
		t.eq(b.particles, 92)
		t.eq(b.lights, 1)
		t.eq(b.parts, 14)
		t.eq(K.Vfx.budget("Crater").parts, 97)
		t.eq(K.Vfx.budget("Lightning").parts, 56)
	end,
	["every preset builds, plays to its end and cleans up"] = function(t, K)
		nearCamera(t) -- full detail, so every decor layer's update code runs too
		local p = player(t, K)
		local live = K.Vfx.live
		for name in pairs(K.VfxPresets.Presets) do
			local e = K.Vfx.play(p, name, HERE, { element = "azure" })
			t.ok(e ~= nil, name .. " played")
			run(K, p, e.life + 0.2, 0.1)
			t.ok(e.done, name .. " finished")
			t.eq(e.model.Parent, nil, name .. " model destroyed")
		end
		t.eq(#p.effects, 0)
		t.eq(K.Vfx.live, live, "the live-particle count comes back")
	end,
	["bursts emit and nothing is left enabled"] = function(t, K)
		local p = player(t, K)
		local e = K.Vfx.play(p, "Burst", HERE)
		run(K, p, 0.3)
		local emitters = 0
		for _, d in ipairs(e.model:GetDescendants()) do
			if d:IsA("ParticleEmitter") then
				emitters += 1
				t.eq(d.Enabled, false, "an emitter was left on")
			end
		end
		t.ok(emitters >= 4, "Burst has its emitters")
		t.ok(e.particles > 0, "particles were emitted")
		K.Vfx.clear(p)
	end,
	["a ring expands, stays a ring, then fades"] = function(t, K)
		local p = player(t, K)
		local e = K.Vfx.play(p, "Burst", HERE)
		local ring
		for _, d in ipairs(e.model:GetDescendants()) do
			if d:IsA("CylinderHandleAdornment") then
				ring = d
				break
			end
		end
		K.Vfx.step(p, 0.08)
		local r1 = ring.Radius
		K.Vfx.step(p, 0.12)
		t.ok(ring.Radius > r1, "the ring grows")
		t.ok(ring.InnerRadius > 0, "a ring, not a disc")
		K.Vfx.step(p, 0.5)
		t.eq(ring.Transparency, 1, "gone after its life")
		K.Vfx.clear(p)
	end,
	["slowmo slows the timeline and the particles already in the air"] = function(t, K)
		local p = player(t, K)
		local e = K.Vfx.play(p, "Embers", HERE)
		K.Vfx.setTimeScale(p, 0.25)
		K.Vfx.step(p, 0.4)
		t.near(e.age, 0.1, 1e-6)
		for _, em in ipairs(e.emitters) do
			t.near(em.TimeScale, 0.25, 1e-6)
		end
		K.Vfx.setTimeScale(p, 5)
		t.eq(p.timeScale, 1, "clamped to normal speed")
		K.Vfx.clear(p)
	end,
	["an effect rides on the part it follows"] = function(t, K)
		local p = player(t, K)
		local head = Instance.new("Part")
		head.Anchored = true
		head.CFrame = CFrame.new(0, -300, 0)
		head.Parent = t.sandbox
		local e = K.Vfx.play(p, "EyeFlare", nil, { follow = head, offset = CFrame.new(0, 1, 0) })
		head.CFrame = CFrame.new(10, -300, 0)
		K.Vfx.step(p, 0.05)
		t.ok((e.frame.Position - Vector3.new(10, -299, 0)).Magnitude < 1e-3, "the frame follows the part")
		K.Vfx.clear(p)
	end,
	["far effects are culled unless important"] = function(t, K)
		local far = workspace.CurrentCamera.CFrame * CFrame.new(0, 0, -(K.Vfx.CULL + 100))
		local p = player(t, K, { important = false })
		t.eq(K.Vfx.play(p, "Dust", far), nil, "culled")
		t.eq(#p.effects, 0)
		local q = player(t, K)
		t.ok(K.Vfx.play(q, "Dust", far) ~= nil, "the cinematic viewer's own effects always play")
		K.Vfx.clear(q)
	end,
	["decor layers are skipped at low quality"] = function(t, K)
		nearCamera(t)
		-- PC (1) and phones (0.6) keep decor; graphics level 1-3 (0.5) and anything lower drop it
		for _, case in ipairs({ { 1, 0 }, { 0.6, 0 }, { 0.5, 1 }, { 0.4, 1 } }) do
			local q, want = case[1], case[2]
			local p = player(t, K, { quality = q })
			local e = K.Vfx.play(p, "Burst", HERE)
			t.eq(e.detail, q, ("quality %s: near the camera, so counts are not halved"):format(tostring(q)))
			local skipped = 0
			for _, layer in ipairs(e.layers) do
				if layer.skip then
					skipped += 1
				end
			end
			t.eq(skipped, want, ("quality %s: Burst's dark ink specks are its one decor layer"):format(tostring(q)))
			K.Vfx.clear(p)
		end
		local p = player(t, K)
		local e = K.Vfx.play(p, "Burst", HERE)
		K.Vfx.step(p, 0.1)
		t.eq(e.particles, K.Vfx.budget("Burst").particles, "at quality 1 every layer emitted, the decor specks too")
		K.Vfx.clear(p)
	end,
	["rocks take the ground's material and colour"] = function(t, K)
		local floor = Instance.new("Part")
		floor.Anchored = true
		floor.Size = Vector3.new(40, 1, 40)
		floor.CFrame = CFrame.new(0, -300.5, 0)
		floor.Material = Enum.Material.Grass -- not Slate: a rock is built as Slate, so Slate would prove nothing
		floor.Color = Color3.fromRGB(120, 60, 30)
		floor.Parent = t.sandbox
		local p = player(t, K)
		local e = K.Vfx.play(p, "Crater", HERE)
		K.Vfx.step(p, 0.05)
		local rock
		for _, d in ipairs(e.model:GetChildren()) do
			if d.Name == "Rock" then
				rock = d
				break
			end
		end
		t.eq(rock.Material, Enum.Material.Grass)
		t.eq(rock.Color, floor.Color)
		K.Vfx.clear(p)
	end,
	["a broken effect is removed and the others play on"] = function(t, K)
		local p = player(t, K)
		local good = K.Vfx.play(p, "Embers", HERE)
		local bad = K.Vfx.play(p, "Dust", HERE)
		bad.layers[1].update = function()
			error("a broken layer (on purpose)")
		end
		K.Vfx.step(p, 0.1)
		t.ok(bad.done, "the broken effect is gone")
		t.eq(bad.model.Parent, nil)
		t.ok(not good.done and good.model.Parent ~= nil, "the other effect plays on")
		t.eq(#p.effects, 1)
		local early = K.Vfx.prepare(p, "Dust", {})
		early.layers[1].start = function()
			error("a broken first frame (on purpose)")
		end
		t.eq(K.Vfx.fire(early, HERE), false, "an effect that breaks on its first frame doesn't start")
		t.eq(early.model.Parent, nil)
		t.eq(#p.effects, 1)
		K.Vfx.clear(p)
	end,
	["an unknown preset plays nothing"] = function(t, K)
		local p = player(t, K)
		t.eq(K.Vfx.play(p, "NoSuchPreset", HERE), nil)
	end,
	["clear destroys prepared effects that never fired"] = function(t, K)
		local p = player(t, K)
		local e = K.Vfx.prepare(p, "Pillar", {})
		t.ok(e.model.Parent ~= nil, "built and parked")
		K.Vfx.clear(p)
		t.eq(e.model.Parent, nil)
		t.eq(#p.prepared, 0)
	end,
}
