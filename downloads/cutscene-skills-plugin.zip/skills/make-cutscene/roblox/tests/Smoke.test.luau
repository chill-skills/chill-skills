-- Smoke tests: the installers and the fixture. Method by fwjelaa (FWJ STUDIOS).
return {
	["the installed kit carries its version"] = function(t, K)
		local root = game:GetService("ReplicatedStorage"):FindFirstChild("CutsceneKit")
		t.ok(root ~= nil, "ReplicatedStorage.CutsceneKit exists")
		t.eq(root:GetAttribute("Version"), "0.4.0")
		local index = { "Schedule", "Fov", "Markers", "Zones", "VfxPresets", "Data", "Shake", "Snapshot", "Letterbox",
			"Subtitles", "Vfx", "Screen", "Director", "Aura", "Preload", "Onlooker", "Server", "Client" }
		for _, name in ipairs(index) do
			t.ok(root:FindFirstChild(name) ~= nil, "module " .. name)
		end
		t.ok(game:GetService("ServerScriptService"):FindFirstChild("CutsceneServer") ~= nil, "server script")
		t.ok(game:GetService("StarterPlayer").StarterPlayerScripts:FindFirstChild("CutsceneClient") ~= nil, "client script")
	end,
	["ClipBuilder builds the stage clip with the camera under StageRoot"] = function(t, K)
		local data = K.clip("Fixture_Walkin_Stage")
		local kfs = K.ClipBuilder.build(data)
		t.defer(function() kfs:Destroy() end)
		t.eq(kfs.Priority, Enum.AnimationPriority.Action4)
		t.eq(#kfs:GetKeyframes(), #data.keyframes)
		local first = kfs:GetKeyframes()[1]
		t.eq(first.Time, 0)
		t.ok(first:FindFirstChild("StageRoot") and first.StageRoot:FindFirstChild("CutsceneCamera"), "pose path StageRoot/CutsceneCamera")
		t.eq(first:FindFirstChildOfClass("KeyframeMarker").Name, "Letterbox")
	end,
	["the fixture is installed with its clips (or asset ids), cast and zone"] = function(t, K)
		local m = game:GetService("ReplicatedStorage").Cutscenes:FindFirstChild("Fixture_Walkin")
		t.ok(m and m:FindFirstChild("Cast") and m.Cast:FindFirstChild("npc1"), "module + Cast.npc1")
		local data = require(m)
		local clips = m:FindFirstChild("Clips")
		if clips then
			t.eq(#clips:GetChildren(), 5)
		else -- out/fixture_assets.luau: the data module names uploaded assets instead
			t.ok(string.match(data.Anims.Stage, "^rbxassetid://") ~= nil, "no Clips folder, so Anims.Stage must be an asset id, got " .. tostring(data.Anims.Stage))
		end
		t.eq(data.Kind, "story")
		local zone = workspace.CutsceneZones:FindFirstChild("Fixture_Walkin")
		t.ok(zone and zone:GetAttribute("Cutscene") == "Fixture_Walkin" and zone:FindFirstChild("Anchor"), "zone + anchor")
	end,
}
