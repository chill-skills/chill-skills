-- Tests for CutsceneKit.Shake. Method by fwjelaa (FWJ STUDIOS).
return {
	["no trauma, no shake"] = function(t, K)
		local s = K.Shake.new()
		t.eq(K.Shake.step(s, 1 / 60, 1, 1), CFrame.identity)
	end,
	["trauma moves the camera but never turns where it looks"] = function(t, K)
		local s = K.Shake.new()
		K.Shake.add(s, 0.8)
		local cf = K.Shake.step(s, 1 / 60, 0.37, 1)
		t.ok(cf.Position.Magnitude > 0 or math.abs(select(3, cf:ToEulerAnglesXYZ())) > 0, "something moved")
		t.near(cf.LookVector.Z, -1, 1e-6, "no pitch or yaw")
	end,
	["trauma decays to zero"] = function(t, K)
		local s = K.Shake.new()
		K.Shake.add(s, 0.5)
		K.Shake.step(s, 1, 0, 1)
		t.eq(s.trauma, 0)
	end,
	["scale 0 (reduced motion) means no shake"] = function(t, K)
		local s = K.Shake.new()
		K.Shake.add(s, 1)
		t.eq(K.Shake.step(s, 1 / 60, 0.5, 0), CFrame.identity)
	end,
}
