-- Tests for CutsceneKit.Data, the data-module format contract (kit/schema.py checks the same rules). Method by fwjelaa (FWJ STUDIOS).
local function valid()
	return {
		Name = "A",
		Kind = "story",
		Length = 6,
		Anims = { Stage = "A_Stage", R15 = { player = "p" } },
		Places = { player = { 0, 0, 0, 0, 0, 0 } },
		Fov = { { 0, 50 }, { 2.5, 40 }, { 2.5, 55 } },
		Markers = { { 0, "Letterbox", "in" }, { 1, "Line", "1" }, { 6, "End", "" } },
		Lines = { ["1"] = { speaker = "G", text = "hi" } },
		Config = { Replay = "session", Skip = 2, Letterbox = 0.11, Style = "anime" },
	}
end
local function fails(t, K, d, mention)
	local ok, problems = K.Data.validate(d)
	t.ok(not ok, "should be invalid")
	t.ok(string.find(table.concat(problems, "; "), mention, 1, true) ~= nil, "mentions " .. mention .. ", got: " .. table.concat(problems, "; "))
end
return {
	["a good scene passes"] = function(t, K)
		local ok, problems = K.Data.validate(valid())
		t.ok(ok, table.concat(problems or {}, "; "))
	end,
	["the fixture's data passes"] = function(t, K)
		local folder = game:GetService("ReplicatedStorage"):FindFirstChild("Cutscenes")
		local m = folder and folder:FindFirstChild("Fixture_Walkin")
		t.ok(m ~= nil, "install out/fixture.luau first")
		local ok, problems = K.Data.validate(require(m))
		t.ok(ok, table.concat(problems or {}, "; "))
	end,
	["Name may be left out, but must be a string"] = function(t, K)
		local d = valid()
		d.Name = nil
		t.ok((K.Data.validate(d)), "no Name is fine")
		d.Name = 5
		fails(t, K, d, "Name must be a string")
	end,
	["the camera clip is required"] = function(t, K)
		local d = valid()
		d.Anims.Stage = nil
		fails(t, K, d, "Anims.Stage")
	end,
	["anim refs must be strings"] = function(t, K)
		local d = valid()
		d.Anims.R6 = { npc1 = 123 }
		fails(t, K, d, "Anims.R6 must map roles to clip refs")
	end,
	["markers must be sorted"] = function(t, K)
		local d = valid()
		d.Markers = { { 1, "Line", "1" }, { 0, "Letterbox", "in" } }
		fails(t, K, d, "not sorted")
	end,
	["markers must sit inside the scene"] = function(t, K)
		local d = valid()
		table.insert(d.Markers, { 7, "End", "" })
		fails(t, K, d, "after the end")
	end,
	["a marker before 0 s is refused"] = function(t, K)
		local d = valid()
		d.Markers[1] = { -0.1, "Letterbox", "in" }
		fails(t, K, d, "marker 1 is before 0 s")
	end,
	["markers must be a list with no gaps"] = function(t, K)
		local d = valid()
		d.Markers = { [1] = { 0, "Letterbox", "in" }, [3] = { 1, "Line", "1" } }
		fails(t, K, d, "Markers must be a list with no gaps")
	end,
	["a Letterbox marker is in or out"] = function(t, K)
		local d = valid()
		d.Markers[1] = { 0, "Letterbox", "on" }
		fails(t, K, d, "Letterbox marker 1 must be in or out")
	end,
	["a Line marker needs its line"] = function(t, K)
		local d = valid()
		d.Lines = {}
		fails(t, K, d, "no Lines entry")
	end,
	["a line needs its text"] = function(t, K)
		local d = valid()
		d.Lines["1"] = { speaker = "G" }
		fails(t, K, d, "Lines[1] needs a text")
	end,
	["Fov entries are {time, fov} pairs"] = function(t, K)
		local d = valid()
		d.Fov = { { 0, 50 }, { 1, "wide" } }
		fails(t, K, d, "Fov entry 2 must be {time, fov}")
	end,
	["Fov times never go back"] = function(t, K)
		local d = valid()
		d.Fov = { { 0, 50 }, { 2, 40 }, { 1, 55 } }
		fails(t, K, d, "Fov times go backwards at 3")
	end,
	["Fov stays within 1-120"] = function(t, K)
		local d = valid()
		d.Fov = { { 0, 0.5 } }
		fails(t, K, d, "Fov entry 1 must be 1-120 degrees")
	end,
	["a place is 6 numbers"] = function(t, K)
		local d = valid()
		d.Places.npc1 = { 0, 0, -8 }
		fails(t, K, d, "Places.npc1 must be 6 numbers")
	end,
	["replay must be a known rule"] = function(t, K)
		local d = valid()
		d.Config.Replay = "once"
		fails(t, K, d, "Config.Replay")
	end,
	["Skip is false or a number of seconds"] = function(t, K)
		local d = valid()
		d.Config.Skip = true
		fails(t, K, d, "Config.Skip must be false or a number of seconds >= 0")
		d.Config.Skip = false
		t.ok((K.Data.validate(d)), "Skip = false is fine")
	end,
	["the letterbox covers at most 0.2 of the screen"] = function(t, K)
		local d = valid()
		d.Config.Letterbox = 0.3
		fails(t, K, d, "Config.Letterbox must be a number from 0 to 0.2")
	end,
	["Style is a string"] = function(t, K)
		local d = valid()
		d.Config.Style = 1
		fails(t, K, d, "Config.Style must be a string")
	end,
	["Config must be a table"] = function(t, K)
		local d = valid()
		d.Config = "x"
		fails(t, K, d, "Config must be a table")
	end,
	["scenes are at most MAX_LENGTH (30 s)"] = function(t, K)
		t.eq(K.Data.MAX_LENGTH, 30)
		local d = valid()
		d.Length = 30.5
		d.Markers = { { 0, "Letterbox", "in" } }
		fails(t, K, d, "Length must be more than 0 and at most 30 s")
	end,
	["config fills defaults by kind"] = function(t, K)
		local c = K.Data.config({ Kind = "story" })
		t.eq(c.Skip, 2)
		t.eq(c.Replay, "saved")
		t.near(c.Letterbox, 0.11)
		t.eq(c.Style, "anime")
		t.eq(K.Data.config({ Kind = "awakening" }).Skip, false)
	end,
	["Fov times stay inside the scene"] = function(t, K)
		local d = valid()
		d.Fov = { { 0, 50 }, { 7, 50 } }
		fails(t, K, d, "Fov entry 2 is outside the scene")
	end,
	["a line's hold and voice are checked"] = function(t, K)
		local d = valid()
		d.Lines["1"].hold = 0
		fails(t, K, d, "Lines[1].hold must be a number of seconds > 0")
		d = valid()
		d.Lines["1"].voice = 5
		fails(t, K, d, "Lines[1].voice must be a string")
	end,
	["Config.Hide is a list of paths"] = function(t, K)
		local d = valid()
		d.Config.Hide = { "Gate/Guard" }
		t.ok((K.Data.validate(d)), "a list of paths is fine")
		d.Config.Hide = "Gate/Guard"
		fails(t, K, d, "Config.Hide must be a list of paths like Gate/Guard")
	end,
	["a line's hold edge values are refused"] = function(t, K)
		for _, bad in { -1, true, "2" } do
			local d = valid()
			d.Lines["1"].hold = bad
			fails(t, K, d, "Lines[1].hold must be a number of seconds > 0")
		end
	end,
	["a Config.Hide entry must be a string"] = function(t, K)
		local d = valid()
		d.Config.Hide = { 5 }
		fails(t, K, d, "Config.Hide must be a list of paths like Gate/Guard")
	end,
	["Config.Hide paths follow the path rule"] = function(t, K)
		for _, bad in { "", "/Gate", "Workspace/Gate", "Workspace" } do
			local d = valid()
			d.Config.Hide = { bad }
			fails(t, K, d, ("Config.Hide path '%s' is not valid"):format(bad))
		end
		local d = valid()
		d.Config.Hide = { "Gate/Guard", "WorkspaceGate" }
		t.ok((K.Data.validate(d)), "ordinary paths are fine")
	end,
}
