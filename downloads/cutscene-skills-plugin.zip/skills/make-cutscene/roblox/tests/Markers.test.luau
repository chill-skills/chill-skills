-- Tests for CutsceneKit.Markers. Method by fwjelaa (FWJ STUDIOS).
local list = { { 0, "Letterbox", "in" }, { 0.6, "Line", "1" }, { 2.5, "Cut", "" }, { 5.4, "Letterbox", "out" } }
local function names(ms)
	local out = {}
	for _, m in ms do
		table.insert(out, m[2])
	end
	return table.concat(out, ",")
end
return {
	["the first frame fires a marker at 0"] = function(t, K)
		t.eq(names(K.Markers.due(list, -1, 0.016)), "Letterbox")
	end,
	["due covers (tPrev, tNow]"] = function(t, K)
		t.eq(names(K.Markers.due(list, 0.6, 2.5)), "Cut")
	end,
	["a big step fires everything in order"] = function(t, K)
		t.eq(names(K.Markers.due(list, -1, 6)), "Letterbox,Line,Cut,Letterbox")
	end,
	["stateAt gives the latest stateful value only"] = function(t, K)
		t.eq(K.Markers.stateAt(list, 3).Letterbox, "in")
		t.eq(K.Markers.stateAt(list, 5.5).Letterbox, "out")
		t.eq(K.Markers.stateAt(list, 3).Line, nil)
	end,
}
