-- Tests for CutsceneKit.Server (Edit mode, with stand-in players). Method by fwjelaa (FWJ STUDIOS).
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local function scene(t, kind, replay)
	local m = Instance.new("ModuleScript")
	m.Name = "_TestScene" .. math.random(1, 1e6)
	m.Source = ('return { Name = "x", Kind = "%s", Length = 2, Anims = { Stage = "S" }, Markers = { { 0, "Letterbox", "in" } }, Config = { Replay = "%s" } }')
		:format(kind, replay)
	m.Parent = ReplicatedStorage:WaitForChild("Cutscenes")
	t.defer(function()
		m:Destroy()
	end)
	return m.Name
end
local function fakePlayer(t, uid)
	local p = Instance.new("Folder")
	p.Name = "FakePlayer"
	p:SetAttribute("UserId", uid)
	p.Parent = t.sandbox
	return p
end
-- a prompt trigger part in Workspace.CutsceneZones, the scene it starts, and a stand-in player with a live character
-- standing at the prompt; returns name, prompt, player, root part, humanoid
local function promptRig(t, replay, uid)
	local name = scene(t, "story", replay)
	local zones = workspace:FindFirstChild("CutsceneZones")
	local madeZones = zones == nil
	if madeZones then
		zones = Instance.new("Folder")
		zones.Name = "CutsceneZones"
		zones.Parent = workspace
	end
	local z = Instance.new("Part")
	z.Name = name
	z.Anchored = true
	z.Size = Vector3.new(2, 2, 2)
	z.CFrame = CFrame.new(0, 501, 0)
	z:SetAttribute("Cutscene", name)
	z:SetAttribute("Trigger", "prompt")
	z.Parent = zones
	t.defer(function()
		z:Destroy()
		if madeZones then
			zones:Destroy()
		end
	end)
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "CutscenePrompt_" .. name
	prompt:SetAttribute("Cutscene", name)
	prompt.Parent = z
	local p = fakePlayer(t, uid)
	local char = Instance.new("Model")
	char.Name = "Character"
	local root = Instance.new("Part")
	root.Name = "HumanoidRootPart"
	root.Anchored = true
	root.Position = z.Position
	root.Parent = char
	local hum = Instance.new("Humanoid")
	hum.Parent = char
	char.Parent = p
	return name, prompt, p, root, hum
end
-- a server clock the case moves by hand (c.t += seconds)
local function fakeClock(t, K)
	local c = { t = 1e6 }
	local keep = K.Server.now
	K.Server.now = function()
		return c.t
	end
	t.defer(function()
		K.Server.now = keep
	end)
	return c
end
-- what the server logs during the case
local function said(t, K)
	local lines = {}
	local keep = K.Server.say
	K.Server.say = function(msg)
		table.insert(lines, msg)
	end
	t.defer(function()
		K.Server.say = keep
	end)
	return lines
end
-- a DataStore stand-in that counts reads and writes
local function fakeStore(t, K)
	local s = { data = {}, reads = 0, writes = 0 }
	function s.GetAsync(self, key)
		self.reads += 1
		return self.data[key]
	end
	function s.UpdateAsync(self, key, fn)
		self.writes += 1
		self.data[key] = fn(self.data[key])
		return self.data[key]
	end
	K.Server.useStore(s)
	t.defer(function()
		K.Server.useStore(nil)
	end)
	return s
end
-- a live server (rate limits on): Edit-mode tests run in Studio, where the kit's play tests are exempt
local function live(t, K)
	local keep = K.Server.isStudio
	K.Server.isStudio = function()
		return false
	end
	t.defer(function()
		K.Server.isStudio = keep
	end)
end
local function withCharacter(p)
	local char = Instance.new("Model")
	char.Name = "Character"
	char.Parent = p
	return char
end
return {
	["shouldPlay follows the replay rule"] = function(t, K)
		t.eq(K.Server.shouldPlay("always", true, true), true)
		t.eq(K.Server.shouldPlay("session", false, true), true)
		t.eq(K.Server.shouldPlay("session", true, false), false)
		t.eq(K.Server.shouldPlay("saved", false, false), true)
		t.eq(K.Server.shouldPlay("saved", false, true), false)
		t.eq(K.Server.shouldPlay("saved", true, false), false)
	end,
	["an unknown cutscene is refused by name"] = function(t, K)
		local ok, why = K.Server.play(fakePlayer(t, -1), "_Nope")
		t.eq(ok, false)
		t.ok(string.find(why, "_Nope", 1, true) ~= nil, why)
	end,
	["a module that errors is refused, not raised"] = function(t, K)
		local m = Instance.new("ModuleScript")
		m.Name = "_TestBroken" .. math.random(1, 1e6)
		m.Source = "error('boom')"
		m.Parent = ReplicatedStorage.Cutscenes
		t.defer(function()
			m:Destroy()
		end)
		local ok, why = K.Server.play(fakePlayer(t, -2), m.Name, CFrame.new())
		t.eq(ok, false)
		t.ok(string.find(why, "errored", 1, true) ~= nil, why)
	end,
	["a playing player is busy"] = function(t, K)
		local name = scene(t, "story", "always")
		local p = fakePlayer(t, -3)
		t.eq(K.Server.play(p, name, CFrame.new()), true)
		local ok, why = K.Server.play(p, name, CFrame.new())
		t.eq(ok, false)
		t.eq(why, "busy")
		K.Server.release(p)
		t.eq(p:GetAttribute("CutsceneLock"), nil)
	end,
	["session scenes play once per visit and Forget resets them"] = function(t, K)
		local name = scene(t, "story", "session")
		local p = fakePlayer(t, -4)
		t.eq(K.Server.play(p, name, CFrame.new()), true)
		K.Server.release(p)
		local ok, why = K.Server.play(p, name, CFrame.new())
		t.eq(ok, false)
		t.eq(why, "seen")
		K.Server.forget(p, name)
		t.eq(K.Server.play(p, name, CFrame.new()), true)
		K.Server.release(p)
	end,
	["play schedules attributes, start last and LEAD ahead"] = function(t, K)
		local name = scene(t, "story", "always")
		local p = fakePlayer(t, -5)
		local anchor = CFrame.new(1, 2, 3)
		K.Server.play(p, name, anchor)
		t.near(p:GetAttribute("CutsceneStartAt") - K.Server.now(), 0.75, 0.1)
		t.eq(p:GetAttribute("CutsceneAnchor"), anchor)
		t.eq(p:GetAttribute("CutsceneName"), name)
		t.near(p:GetAttribute("CutsceneDuration"), 2)
		K.Server.release(p)
	end,
	["awakenings do not start through Play"] = function(t, K)
		local name = scene(t, "awakening", "always")
		local ok, why = K.Server.play(fakePlayer(t, -6), name, CFrame.new())
		t.eq(ok, false)
		t.ok(string.find(why, "Awaken", 1, true) ~= nil, why)
	end,
	["no zone and no anchor is refused"] = function(t, K)
		local name = scene(t, "story", "always")
		local ok, why = K.Server.play(fakePlayer(t, -7), name)
		t.eq(ok, false)
		t.ok(string.find(why, "no anchor", 1, true) ~= nil, why)
	end,
	["a name with spaces or punctuation is refused"] = function(t, K)
		local ok, why = K.Server.play(fakePlayer(t, -8), "Bad Name!", CFrame.new())
		t.eq(ok, false)
		t.ok(string.find(why, "letters, digits", 1, true) ~= nil, why)
	end,
	["saved scenes wait until the player's history is loaded"] = function(t, K)
		local name = scene(t, "story", "saved")
		local p = fakePlayer(t, -9)
		local ok, why = K.Server.play(p, name, CFrame.new())
		t.eq(ok, false)
		t.eq(why, "loading")
		p:SetAttribute("CutsceneKitTestLoaded", true)
		t.eq(K.Server.play(p, name, CFrame.new()), true)
		K.Server.release(p)
	end,
	["Ended releases the player's own scene and un-marks a failed one"] = function(t, K)
		local name = scene(t, "story", "session")
		local p = fakePlayer(t, -10)
		t.eq(K.Server.play(p, name, CFrame.new()), true)
		local startAt = p:GetAttribute("CutsceneStartAt")
		K.Server.onRemote(p, "Ended", name, startAt, "load-failed")
		t.eq(p:GetAttribute("CutsceneLock"), nil, "lock released at once")
		t.eq(p:GetAttribute("CutsceneStartAt"), nil, "schedule cleared")
		t.eq(p:GetAttribute("CutsceneSeen_" .. name), nil, "a scene that never played is not seen")
		t.eq(K.Server.play(p, name, CFrame.new()), true, "so it can play again")
		K.Server.release(p)
	end,
	["Ended with another name or another startAt is ignored"] = function(t, K)
		local name = scene(t, "story", "session")
		local p = fakePlayer(t, -11)
		t.eq(K.Server.play(p, name, CFrame.new()), true)
		local startAt = p:GetAttribute("CutsceneStartAt")
		K.Server.onRemote(p, "Ended", name .. "x", startAt, "error")
		K.Server.onRemote(p, "Ended", name, startAt + 1, "error")
		K.Server.onRemote(p, "Ended", name, tostring(startAt), "error")
		K.Server.onRemote(p, "Ended", name, startAt, 5)
		K.Server.onRemote(p, "Ended", 5, startAt, "error")
		t.eq(p:GetAttribute("CutsceneLock"), name, "still locked")
		t.eq(p:GetAttribute("CutsceneSeen_" .. name), true, "still seen")
		K.Server.release(p)
	end,
	["Ended after a normal end keeps the scene marked seen"] = function(t, K)
		local name = scene(t, "story", "session")
		local p = fakePlayer(t, -12)
		t.eq(K.Server.play(p, name, CFrame.new()), true)
		K.Server.onRemote(p, "Ended", name, p:GetAttribute("CutsceneStartAt"), "end")
		t.eq(p:GetAttribute("CutsceneLock"), nil, "lock released at once")
		t.eq(p:GetAttribute("CutsceneSeen_" .. name), true, "still seen")
		local ok, why = K.Server.play(p, name, CFrame.new())
		t.eq(ok, false)
		t.eq(why, "seen")
	end,
	["zone parts for prompt and api triggers only hold the anchor"] = function(t, K)
		local z = Instance.new("Part")
		t.eq(K.Server.zoneTriggers(z), true)
		z:SetAttribute("Trigger", "zone")
		t.eq(K.Server.zoneTriggers(z), true)
		z:SetAttribute("Trigger", "prompt")
		t.eq(K.Server.zoneTriggers(z), false)
		z:SetAttribute("Trigger", "api")
		t.eq(K.Server.zoneTriggers(z), false)
		z:Destroy()
	end,
	["a cutscene prompt starts its scene at the trigger's anchor"] = function(t, K)
		local _, prompt, p = promptRig(t, "always", -21)
		t.eq(K.Server.onPrompt(prompt, p), true)
		t.ok((p:GetAttribute("CutsceneAnchor").Position - Vector3.new(0, 500, 0)).Magnitude < 1e-3, "anchored at the trigger's floor point")
		K.Server.release(p)
	end,
	["a second press while the scene plays is busy"] = function(t, K)
		local _, prompt, p = promptRig(t, "always", -23)
		t.eq(K.Server.onPrompt(prompt, p), true)
		local ok, why = K.Server.onPrompt(prompt, p)
		t.eq(ok, false)
		t.eq(why, "busy")
		K.Server.release(p)
	end,
	["a session scene seen once is refused on the next press"] = function(t, K)
		local _, prompt, p = promptRig(t, "session", -24)
		t.eq(K.Server.onPrompt(prompt, p), true)
		K.Server.release(p)
		local ok, why = K.Server.onPrompt(prompt, p)
		t.eq(ok, false)
		t.eq(why, "seen")
	end,
	["a saved scene seen once is refused on the next press"] = function(t, K)
		local _, prompt, p = promptRig(t, "saved", -25)
		p:SetAttribute("CutsceneKitTestLoaded", true)
		t.eq(K.Server.onPrompt(prompt, p), true)
		K.Server.release(p)
		local ok, why = K.Server.onPrompt(prompt, p)
		t.eq(ok, false)
		t.eq(why, "seen")
	end,
	["a prompt that is not the scene's own is refused"] = function(t, K)
		local _, prompt, p = promptRig(t, "always", -26)
		prompt.Name = "SomeOtherPrompt"
		local ok, why = K.Server.onPrompt(prompt, p)
		t.eq(ok, false)
		t.eq(why, "not this scene's prompt")
		t.eq(p:GetAttribute("CutsceneLock"), nil)
	end,
	["a disabled prompt is refused"] = function(t, K)
		local _, prompt, p = promptRig(t, "always", -27)
		prompt.Enabled = false
		local ok, why = K.Server.onPrompt(prompt, p)
		t.eq(ok, false)
		t.eq(why, "prompt is disabled")
		t.eq(p:GetAttribute("CutsceneLock"), nil)
	end,
	["a press from out of range is refused"] = function(t, K)
		local _, prompt, p, root = promptRig(t, "always", -28)
		root.Position += Vector3.new(prompt.MaxActivationDistance + K.Server.PROMPT_SLACK + 5, 0, 0)
		local ok, why = K.Server.onPrompt(prompt, p)
		t.eq(ok, false)
		t.eq(why, "too far from the prompt")
		t.eq(p:GetAttribute("CutsceneLock"), nil)
	end,
	["a press from a dead player is refused"] = function(t, K)
		local _, prompt, p, _, hum = promptRig(t, "always", -29)
		hum.Health = 0
		local ok, why = K.Server.onPrompt(prompt, p)
		t.eq(ok, false)
		t.eq(why, "no live character")
		t.eq(p:GetAttribute("CutsceneLock"), nil)
	end,
	["a press from a player with no character is refused"] = function(t, K)
		local _, prompt, p = promptRig(t, "always", -30)
		p.Character:Destroy()
		local ok, why = K.Server.onPrompt(prompt, p)
		t.eq(ok, false)
		t.eq(why, "no live character")
	end,
	["a prompt outside the workspace is refused"] = function(t, K)
		local _, prompt, p = promptRig(t, "always", -31)
		prompt.Parent = nil
		local ok, why = K.Server.onPrompt(prompt, p)
		t.eq(ok, false)
		t.eq(why, "prompt is not in the world")
	end,
	["a prompt without the Cutscene attribute is ignored"] = function(t, K)
		local prompt = Instance.new("ProximityPrompt")
		local ok, why = K.Server.onPrompt(prompt, fakePlayer(t, -22))
		t.eq(ok, false)
		t.eq(why, "not a cutscene prompt")
		prompt:Destroy()
	end,
	-- C1: a client that loops Play -> Ended can't keep the shield or drain the DataStore
	["the shield carries the scene's end and is gone after it, whatever the client says"] = function(t, K)
		local c = fakeClock(t, K)
		local name = scene(t, "story", "always")
		local p = fakePlayer(t, -40)
		local char = withCharacter(p)
		t.eq(K.Server.play(p, name, CFrame.new()), true)
		local startAt = p:GetAttribute("CutsceneStartAt")
		local ff = char:FindFirstChild("CutsceneShield")
		t.ok(ff ~= nil, "shielded while it plays")
		t.near(ff:GetAttribute("CutsceneShieldUntil"), startAt + 2, 1e-6, "until the scheduled end (Length 2)")
		c.t = startAt + 1.9
		K.Server.expire(p)
		t.eq(ff.Parent, char, "still shielded inside the scene")
		p:SetAttribute("CutsceneStartAt", startAt + 100) -- whatever the schedule attributes say now
		c.t = startAt + 2.01
		K.Server.expire(p)
		t.eq(ff.Parent, nil, "gone at the scheduled end")
		K.Server.release(p)
	end,
	["a new scene's shield replaces an old one instead of inheriting its end"] = function(t, K)
		local c = fakeClock(t, K)
		local name = scene(t, "story", "always")
		local p = fakePlayer(t, -41)
		local char = withCharacter(p)
		local old = Instance.new("ForceField")
		old.Name = "CutsceneShield"
		old:SetAttribute("CutsceneShieldUntil", c.t + 600)
		old.Parent = char
		t.eq(K.Server.play(p, name, CFrame.new()), true)
		t.eq(old.Parent, nil, "the leftover shield is replaced")
		local ff = char:FindFirstChild("CutsceneShield")
		t.near(ff:GetAttribute("CutsceneShieldUntil"), p:GetAttribute("CutsceneStartAt") + 2, 1e-6)
		K.Server.release(p)
	end,
	["a shield with no end of its own is removed"] = function(t, K)
		local p = fakePlayer(t, -42)
		local char = withCharacter(p)
		local ff = Instance.new("ForceField")
		ff.Name = "CutsceneShield"
		ff.Parent = char
		K.Server.expire(p)
		t.eq(ff.Parent, nil)
	end,
	["a zone or prompt start of the same scene waits out the gap, an early Ended doesn't shorten it"] = function(t, K)
		live(t, K)
		local c = fakeClock(t, K)
		local name = scene(t, "story", "always")
		local p = fakePlayer(t, -43)
		t.eq(K.Server.request(p, name, CFrame.new()), true)
		K.Server.onRemote(p, "Ended", name, p:GetAttribute("CutsceneStartAt"), "end")
		t.eq(p:GetAttribute("CutsceneLock"), nil, "an early end still frees the player at once")
		local ok, why = K.Server.request(p, name, CFrame.new())
		t.eq(ok, false)
		t.eq(why, "too soon")
		c.t += K.Server.SCENE_GAP - 0.1
		t.eq(K.Server.request(p, name, CFrame.new()), false, "still inside the gap")
		c.t += 0.2
		t.eq(K.Server.request(p, name, CFrame.new()), true, "after the gap")
		K.Server.release(p)
	end,
	["a prompt press goes through the same rate limit"] = function(t, K)
		live(t, K)
		fakeClock(t, K)
		local name, prompt, p = promptRig(t, "always", -44)
		t.eq(K.Server.onPrompt(prompt, p), true)
		K.Server.onRemote(p, "Ended", name, p:GetAttribute("CutsceneStartAt"), "end")
		local ok, why = K.Server.onPrompt(prompt, p)
		t.eq(ok, false)
		t.eq(why, "too soon")
	end,
	["at most STARTS_PER_MINUTE zone or prompt starts per player a minute"] = function(t, K)
		live(t, K)
		local c = fakeClock(t, K)
		local p = fakePlayer(t, -45)
		local names = {}
		for i = 1, K.Server.STARTS_PER_MINUTE + 1 do
			names[i] = scene(t, "story", "always")
		end
		for i = 1, K.Server.STARTS_PER_MINUTE do
			t.eq(K.Server.request(p, names[i], CFrame.new()), true, "start " .. i)
			K.Server.release(p)
			c.t += 1
		end
		local last = names[K.Server.STARTS_PER_MINUTE + 1]
		local ok, why = K.Server.request(p, last, CFrame.new())
		t.eq(ok, false)
		t.eq(why, "too often")
		c.t += 60
		t.eq(K.Server.request(p, last, CFrame.new()), true, "a minute later")
		K.Server.release(p)
	end,
	["rate-limit refusals are logged once per player"] = function(t, K)
		live(t, K)
		fakeClock(t, K)
		local lines = said(t, K)
		local name = scene(t, "story", "always")
		local p = fakePlayer(t, -46)
		t.eq(K.Server.request(p, name, CFrame.new()), true)
		K.Server.release(p)
		for _ = 1, 3 do
			t.eq(K.Server.request(p, name, CFrame.new()), false)
		end
		t.eq(#lines, 1, "one line for three refusals")
		t.ok(string.find(lines[1], "too soon", 1, true) ~= nil, lines[1])
	end,
	["the server API is not rate limited"] = function(t, K)
		live(t, K)
		fakeClock(t, K)
		local name = scene(t, "story", "always")
		local p = fakePlayer(t, -47)
		for i = 1, K.Server.STARTS_PER_MINUTE + 2 do
			t.eq(K.Server.play(p, name, CFrame.new()), true, "Play " .. i)
			K.Server.release(p)
		end
	end,
	["a Studio play test is not rate limited (PlayTest.start walks into the zone again and again)"] = function(t, K)
		fakeClock(t, K)
		local keep = K.Server.isStudio
		K.Server.isStudio = function()
			return true
		end
		t.defer(function()
			K.Server.isStudio = keep
		end)
		local name = scene(t, "story", "always")
		local p = fakePlayer(t, -53)
		for i = 1, K.Server.STARTS_PER_MINUTE + 2 do
			t.eq(K.Server.request(p, name, CFrame.new()), true, "start " .. i)
			K.Server.onRemote(p, "Ended", name, p:GetAttribute("CutsceneStartAt"), "skip")
		end
	end,
	["the game's Forget clears the gap and gives the scene its retries back"] = function(t, K)
		live(t, K)
		fakeClock(t, K)
		local name = scene(t, "story", "session")
		local p = fakePlayer(t, -54)
		for _ = 1, K.Server.MAX_UNMARKS + 1 do
			t.eq(K.Server.request(p, name, CFrame.new()), true)
			K.Server.onRemote(p, "Ended", name, p:GetAttribute("CutsceneStartAt"), "error")
		end
		t.eq(p:GetAttribute("CutsceneSeen_" .. name), true, "retries used up")
		K.Server.forget(p, name)
		t.eq(K.Server.request(p, name, CFrame.new()), true, "the game asked for it again: no gap, not seen")
		K.Server.onRemote(p, "Ended", name, p:GetAttribute("CutsceneStartAt"), "error")
		t.eq(p:GetAttribute("CutsceneSeen_" .. name), nil, "and a failure un-marks it again")
	end,
	["a failed scene can be retried at once, but Ended un-marks it only MAX_UNMARKS times a visit"] = function(t, K)
		fakeClock(t, K)
		local name = scene(t, "story", "session")
		local p = fakePlayer(t, -48)
		for i = 1, K.Server.MAX_UNMARKS do
			t.eq(K.Server.request(p, name, CFrame.new()), true, "try " .. i)
			K.Server.onRemote(p, "Ended", name, p:GetAttribute("CutsceneStartAt"), "error")
			t.eq(p:GetAttribute("CutsceneSeen_" .. name), nil, "un-marked " .. i)
		end
		t.eq(K.Server.request(p, name, CFrame.new()), true, "one more try")
		K.Server.onRemote(p, "Ended", name, p:GetAttribute("CutsceneStartAt"), "error")
		t.eq(p:GetAttribute("CutsceneLock"), nil, "an Ended still frees the player")
		t.eq(p:GetAttribute("CutsceneSeen_" .. name), true, "but no longer un-marks the scene")
		local ok, why = K.Server.request(p, name, CFrame.new())
		t.eq(ok, false)
		t.eq(why, "seen")
	end,
	["an always scene that keeps failing falls back to the gap"] = function(t, K)
		live(t, K)
		fakeClock(t, K)
		local name = scene(t, "story", "always")
		local p = fakePlayer(t, -49)
		for _ = 1, K.Server.MAX_UNMARKS + 1 do
			t.eq(K.Server.request(p, name, CFrame.new()), true)
			K.Server.onRemote(p, "Ended", name, p:GetAttribute("CutsceneStartAt"), "error")
		end
		local ok, why = K.Server.request(p, name, CFrame.new())
		t.eq(ok, false)
		t.eq(why, "too soon")
	end,
	["session and always scenes never write the DataStore"] = function(t, K)
		fakeClock(t, K)
		local store = fakeStore(t, K)
		local p = fakePlayer(t, -50)
		K.Server.join(p)
		for _, replay in ipairs({ "session", "always" }) do
			local name = scene(t, "story", replay)
			t.eq(K.Server.request(p, name, CFrame.new()), true)
			K.Server.onRemote(p, "Ended", name, p:GetAttribute("CutsceneStartAt"), "error")
			K.Server.forget(p, name)
		end
		K.Server.leave(p)
		t.eq(store.writes, 0)
	end,
	["saved scenes write only real changes, one write per player for the batch"] = function(t, K)
		fakeClock(t, K)
		local store = fakeStore(t, K)
		local p = fakePlayer(t, -51)
		local key = tostring(K.Server.userId(p))
		K.Server.join(p)
		local a, b, never = scene(t, "story", "saved"), scene(t, "story", "saved"), scene(t, "story", "saved")
		t.eq(K.Server.play(p, a, CFrame.new()), true)
		K.Server.release(p)
		t.eq(K.Server.play(p, b, CFrame.new()), true)
		K.Server.release(p)
		K.Server.forget(p, never) -- never seen: nothing to change
		t.eq(store.writes, 0, "nothing written yet: changes wait for one batch")
		K.Server.flush(K.Server.userId(p))
		t.eq(store.writes, 1, "two marks, one write")
		t.eq(store.data[key][a], true)
		t.eq(store.data[key][b], true)
		t.eq(store.data[key][never], nil)
		K.Server.flush(K.Server.userId(p))
		t.eq(store.writes, 1, "nothing pending, nothing written")
		K.Server.forget(p, a)
		K.Server.forget(p, a) -- already forgotten: no second change
		K.Server.leave(p)
		t.eq(store.writes, 2, "leaving writes what is pending")
		t.eq(store.data[key][a], nil)
		t.eq(store.data[key][b], true)
	end,
	["a saved scene marked and then un-marked by a failed Ended costs no write"] = function(t, K)
		fakeClock(t, K)
		local store = fakeStore(t, K)
		local p = fakePlayer(t, -52)
		K.Server.join(p)
		local name = scene(t, "story", "saved")
		t.eq(K.Server.request(p, name, CFrame.new()), true)
		K.Server.onRemote(p, "Ended", name, p:GetAttribute("CutsceneStartAt"), "load-failed")
		t.eq(p:GetAttribute("CutsceneSeen_" .. name), nil)
		K.Server.leave(p)
		t.eq(store.writes, 0, "back where the store already was")
	end,
	-- I3: the play-test StarterCharacter never reaches a live game
	["a play-test StarterCharacter is removed in a live game"] = function(t, K)
		local lines = said(t, K)
		local keep = K.Server.isStudio
		K.Server.isStudio = function()
			return false
		end
		t.defer(function()
			K.Server.isStudio = keep
		end)
		local box = Instance.new("Folder")
		box.Parent = t.sandbox
		local m = Instance.new("Model")
		m.Name = "StarterCharacter"
		m:SetAttribute("CutsceneKitPlayTest", true)
		m.Parent = box
		t.eq(K.Server.dropPlayTestCharacter(box), "removed")
		t.eq(m.Parent, nil)
		t.eq(#lines, 1)
		t.ok(string.find(lines[1], "StarterCharacter", 1, true) ~= nil, lines[1])
		t.eq(K.Server.dropPlayTestCharacter(box), nil, "nothing left")
		t.eq(#lines, 1)
	end,
	["a play-test StarterCharacter is kept in Studio, with one warning"] = function(t, K)
		local lines = said(t, K)
		local keep = K.Server.isStudio
		K.Server.isStudio = function()
			return true
		end
		t.defer(function()
			K.Server.isStudio = keep
		end)
		local box = Instance.new("Folder")
		box.Parent = t.sandbox
		local m = Instance.new("Model")
		m.Name = "StarterCharacter"
		m:SetAttribute("CutsceneKitPlayTest", true)
		m.Parent = box
		t.eq(K.Server.dropPlayTestCharacter(box), "kept")
		t.eq(m.Parent, box, "Studio play tests still use it")
		t.eq(K.Server.dropPlayTestCharacter(box), "kept")
		t.eq(#lines, 1, "warned once")
		t.ok(string.find(lines[1], "playtest-off", 1, true) ~= nil, lines[1])
	end,
	["a place's own StarterCharacter is never touched"] = function(t, K)
		local lines = said(t, K)
		local keep = K.Server.isStudio
		K.Server.isStudio = function()
			return false
		end
		t.defer(function()
			K.Server.isStudio = keep
		end)
		local box = Instance.new("Folder")
		box.Parent = t.sandbox
		local m = Instance.new("Model")
		m.Name = "StarterCharacter"
		m.Parent = box
		t.eq(K.Server.dropPlayTestCharacter(box), nil)
		t.eq(m.Parent, box)
		t.eq(#lines, 0)
	end,
}
