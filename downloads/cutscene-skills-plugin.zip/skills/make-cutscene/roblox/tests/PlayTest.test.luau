-- Tests for the dev module PlayTest (Edit mode: the parts that work without Play). Method by fwjelaa (FWJ STUDIOS).
local StarterPlayer = game:GetService("StarterPlayer")

-- A zone part far from the map and a stand-in player, with the module's seams replaced (and put back afterwards)
local function setup(t, K, opts)
	local PT = K.PlayTest
	local keep = { player = PT.player, sleep = PT.sleep, isStudio = PT.isStudio }
	t.defer(function()
		PT.player, PT.sleep, PT.isStudio = keep.player, keep.sleep, keep.isStudio
	end)
	local zones = workspace:FindFirstChild("CutsceneZones")
	if not zones then
		zones = Instance.new("Folder")
		zones.Name = "CutsceneZones"
		zones.Parent = workspace
		t.defer(function()
			zones:Destroy()
		end)
	end
	local zone = Instance.new("Part")
	zone.Name = "_PTZone"
	zone.Anchored = true
	zone.Size = Vector3.new(16, 8, 16)
	zone.Position = Vector3.new(5000, 4, 5000)
	zone:SetAttribute("Trigger", "zone")
	zone.Parent = zones
	local model = Instance.new("Model")
	local hrp = Instance.new("Part")
	hrp.Name = "HumanoidRootPart"
	hrp.Anchored = true
	hrp.Position = opts.inside and zone.Position or zone.Position + Vector3.new(100, 0, 0)
	hrp.Parent = model
	model.PrimaryPart = hrp
	model.Parent = workspace
	t.defer(function()
		zone:Destroy()
		model:Destroy()
	end)
	local attrs = {}
	local fake = {
		Character = model,
		GetAttribute = function(_, key)
			return attrs[key]
		end,
	}
	local sleeps = {}
	PT.player = function()
		return fake
	end
	PT.sleep = function(seconds)
		table.insert(sleeps, seconds)
		if opts.lockOnEntry and PT.inside(zone, hrp.Position) then
			attrs.CutsceneLock = "_PTZone" -- what the server does when the character enters
		end
	end
	return zone, hrp, sleeps
end

-- The look seams setRig reads (PlayTest.player, studioUserId, descriptionFromUserId) replaced by fakes and put back
-- afterwards. opts: player (a fake player or nil), studioId (a number or nil), byId = { [id] = desc } or "error".
-- Returns the list of user ids the web call was asked for. The real seams are saved once per module: a second look()
-- in the same case would otherwise save the first fake as "real", and every later R6 stand-in would come out blank.
local real = {}
local function look(t, K, opts)
	local PT = K.PlayTest
	real[PT] = real[PT] or { player = PT.player, studioUserId = PT.studioUserId, fromId = PT.descriptionFromUserId }
	local keep = real[PT]
	t.defer(function()
		PT.player, PT.studioUserId, PT.descriptionFromUserId = keep.player, keep.studioUserId, keep.fromId
	end)
	local asked = {}
	PT.player = function()
		return opts.player
	end
	PT.studioUserId = function()
		return opts.studioId
	end
	PT.descriptionFromUserId = function(userId)
		table.insert(asked, userId)
		if opts.byId == "error" then
			error("HTTP 500 (fake)")
		end
		return (opts.byId or {})[userId]
	end
	return asked
end

local function described(color)
	local d = Instance.new("HumanoidDescription")
	d.HeadColor = color
	d.TorsoColor = color
	return d
end

-- a fake player whose character's Humanoid answers GetAppliedDescription with `applied` (or has no character)
local function fakePlayer(userId, applied)
	local hum = applied and {
		GetAppliedDescription = function()
			return applied
		end,
	}
	local char = hum and {
		FindFirstChildOfClass = function(_, class)
			return class == "Humanoid" and hum or nil
		end,
	}
	return { UserId = userId, Character = char }
end

return {
	["avatarLook takes the live character's own look first"] = function(t, K)
		local applied = described(Color3.fromRGB(200, 10, 10))
		local asked = look(t, K, { player = fakePlayer(42, applied), studioId = 7, byId = { [42] = described(Color3.new()) } })
		local desc, source = K.PlayTest.avatarLook()
		t.eq(desc, applied)
		t.ok(string.find(source, "character", 1, true) ~= nil, source)
		t.eq(#asked, 0, "no web call when the character's look is there")
	end,
	["avatarLook asks for the player's avatar by user id when the character gives no look"] = function(t, K)
		local web = described(Color3.fromRGB(10, 200, 10))
		local asked = look(t, K, { player = fakePlayer(42, nil), studioId = 7, byId = { [42] = web } })
		local desc, source = K.PlayTest.avatarLook()
		t.eq(desc, web)
		t.eq(asked[1], 42, "the player's own id, not the Studio user's")
		t.ok(string.find(source, "42", 1, true) ~= nil, source)
	end,
	["avatarLook in Edit uses the signed-in Studio user's avatar (Studio-only)"] = function(t, K)
		local web = described(Color3.fromRGB(10, 10, 200))
		local asked = look(t, K, { player = nil, studioId = 7, byId = { [7] = web } })
		local desc, source = K.PlayTest.avatarLook()
		t.eq(desc, web)
		t.eq(asked[1], 7)
		t.ok(string.find(source, "7", 1, true) ~= nil, source)
	end,
	["avatarLook falls back to a blank description when no user id can be read, and says so"] = function(t, K)
		local asked = look(t, K, { player = nil, studioId = nil })
		local desc, source = K.PlayTest.avatarLook()
		t.ok(typeof(desc) == "Instance" and desc:IsA("HumanoidDescription"), "a description")
		t.ok(string.find(source, "blank", 1, true) ~= nil, source)
		t.eq(#asked, 0, "no web call without an id")
	end,
	["avatarLook falls back to a blank description when the web call fails, and says so"] = function(t, K)
		local asked = look(t, K, { player = nil, studioId = 7, byId = "error" })
		local desc, source = K.PlayTest.avatarLook()
		t.eq(asked[1], 7)
		t.ok(desc:IsA("HumanoidDescription"), "a failed web call still gives a description")
		t.ok(string.find(source, "blank", 1, true) ~= nil, source)
	end,
	["setRig R6 dresses the stand-in in the avatar's look and says whose"] = function(t, K)
		local before = StarterPlayer:FindFirstChild("StarterCharacter")
		if before and not before:GetAttribute("CutsceneKitPlayTest") then
			return -- a place's own StarterCharacter is never replaced (the first setRig test covers it)
		end
		local red = Color3.fromRGB(200, 10, 10)
		look(t, K, { player = nil, studioId = 7, byId = { [7] = described(red) } })
		t.defer(function()
			K.PlayTest.setRig("avatar")
		end)
		local said = K.PlayTest.setRig("R6")
		t.ok(string.find(said, "R6", 1, true) ~= nil and string.find(said, "7", 1, true) ~= nil, said)
		local m = StarterPlayer:FindFirstChild("StarterCharacter")
		t.ok(m ~= nil and m:GetAttribute("CutsceneKitPlayTest") == true, "tagged")
		local hum = m:FindFirstChildOfClass("Humanoid")
		t.ok(hum ~= nil and hum.RigType == Enum.HumanoidRigType.R6, "R6")
		local colors = m:FindFirstChildOfClass("BodyColors")
		t.ok(colors ~= nil and colors.HeadColor3 == red and colors.TorsoColor3 == red, "wears the avatar's body colours")
	end,
	["setRig makes an R6 StarterCharacter and takes it away again"] = function(t, K)
		local before = StarterPlayer:FindFirstChild("StarterCharacter")
		if before and not before:GetAttribute("CutsceneKitPlayTest") then
			t.eq(K.PlayTest.setRig("R6"), "StarterPlayer already has its own StarterCharacter: left alone")
			return
		end
		t.defer(function()
			K.PlayTest.setRig("avatar")
		end)
		K.PlayTest.setRig("R6")
		local m = StarterPlayer:FindFirstChild("StarterCharacter")
		local hum = m and m:FindFirstChildOfClass("Humanoid")
		t.ok(hum ~= nil and hum.RigType == Enum.HumanoidRigType.R6, "R6 StarterCharacter")
		K.PlayTest.setRig("avatar")
		t.eq(StarterPlayer:FindFirstChild("StarterCharacter"), nil)
	end,
	["start needs a player in Play"] = function(t, K)
		t.errors(function()
			K.PlayTest.start("Fixture_Scene")
		end, "no player character yet")
	end,
	["skip with no scene running says so"] = function(t, K)
		t.eq(K.PlayTest.skip(), "no scene running")
	end,
	["inside tells a point in the zone box from one outside"] = function(t, K)
		local zone = setup(t, K, { inside = true })
		t.ok(K.PlayTest.inside(zone, zone.Position))
		t.ok(not K.PlayTest.inside(zone, zone.Position + Vector3.new(9, 0, 0)))
		t.ok(not K.PlayTest.inside(zone, zone.Position + Vector3.new(0, 5, 0)))
	end,
	["start walks a character from outside into the zone and waits for the lock"] = function(t, K)
		local zone, hrp, sleeps = setup(t, K, { inside = false, lockOnEntry = true })
		t.eq(K.PlayTest.start("_PTZone"), "walked into the zone")
		t.ok(K.PlayTest.inside(zone, hrp.Position))
		for _, s in sleeps do
			t.ok(s ~= K.PlayTest.REENTER_WAIT, "no step-out wait when the character was outside")
		end
	end,
	["start with the character already inside walks out, waits, and walks back in"] = function(t, K)
		local zone, hrp, sleeps = setup(t, K, { inside = true, lockOnEntry = true })
		local seenOutside
		local sleep = K.PlayTest.sleep
		K.PlayTest.sleep = function(seconds)
			if seconds == K.PlayTest.REENTER_WAIT then
				seenOutside = not K.PlayTest.inside(zone, hrp.Position)
			end
			return sleep(seconds)
		end
		t.eq(K.PlayTest.start("_PTZone"), "walked out of the zone and back in")
		t.eq(sleeps[1], K.PlayTest.REENTER_WAIT)
		t.ok(seenOutside, "the character was outside the zone during the wait")
		t.ok(K.PlayTest.inside(zone, hrp.Position))
	end,
	["start reports a failure when the scene never starts"] = function(t, K)
		local zone, hrp = setup(t, K, { inside = false, lockOnEntry = false })
		local result = K.PlayTest.start("_PTZone")
		t.ok(string.find(result, "FAILED", 1, true) == 1, result)
		t.ok(string.find(result, "_PTZone did not start", 1, true) ~= nil, result)
		t.ok(K.PlayTest.inside(zone, hrp.Position))
	end,
	["every function refuses to run outside Studio"] = function(t, K)
		local keep = K.PlayTest.isStudio
		t.defer(function()
			K.PlayTest.isStudio = keep
		end)
		K.PlayTest.isStudio = function()
			return false
		end
		local calls = {
			start = function() return K.PlayTest.start("x") end,
			approach = function() return K.PlayTest.approach("x") end,
			press = function() return K.PlayTest.press("x") end,
			arm = function() return K.PlayTest.arm(1) end,
			read = function() return K.PlayTest.read() end,
			skip = function() return K.PlayTest.skip() end,
			kill = function() return K.PlayTest.kill() end,
			lock = function() return K.PlayTest.lock() end,
			setRig = function() return K.PlayTest.setRig("R6") end,
		}
		for name, call in calls do
			local ok, err = pcall(call)
			t.ok(not ok and string.find(tostring(err), "dev-only", 1, true) ~= nil, name .. ": " .. tostring(err))
		end
	end,
	["lock and approach say what is missing without a player"] = function(t, K)
		local keep = K.PlayTest.player
		t.defer(function()
			K.PlayTest.player = keep
		end)
		K.PlayTest.player = function()
			return nil
		end
		t.errors(function()
			K.PlayTest.lock()
		end, "no player yet")
		t.errors(function()
			K.PlayTest.approach("x")
		end, "no prompt for x")
		t.eq(K.PlayTest.kill(), "no character")
	end,
	["setRig tags the temporary R6 StarterCharacter and leaves an untagged one alone"] = function(t, K)
		local before = StarterPlayer:FindFirstChild("StarterCharacter")
		if before then
			return -- the place's own StarterCharacter: the brief's first test covers that case
		end
		t.defer(function()
			K.PlayTest.setRig("avatar")
		end)
		K.PlayTest.setRig("R6")
		local m = StarterPlayer:FindFirstChild("StarterCharacter")
		t.ok(m ~= nil and m:GetAttribute("CutsceneKitPlayTest") == true, "tagged")
		m:SetAttribute("CutsceneKitPlayTest", nil) -- now it looks like a viewer's own
		t.eq(K.PlayTest.setRig("avatar"), "StarterPlayer already has its own StarterCharacter: left alone")
		t.eq(StarterPlayer:FindFirstChild("StarterCharacter"), m)
		m:Destroy()
	end,
}
