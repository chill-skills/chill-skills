-- Tests for the authoring module SceneInstall (Edit mode). Method by fwjelaa (FWJ STUDIOS).
local HttpService = game:GetService("HttpService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local function kitInstalled()
	local kit = ReplicatedStorage:FindFirstChild("CutsceneKit")
	return kit ~= nil and kit:FindFirstChild("Data") ~= nil
end

local function need(K)
	return function(name)
		return K[name]
	end
end

return {
	["castModel makes a plain dummy of the asked rig"] = function(t, K)
		local m = K.SceneInstall.castModel("npc1", { model = "default", rig = "R6" }, K.Capture.resolve)
		t.defer(function()
			m:Destroy()
		end)
		t.eq(m.Name, "npc1")
		t.eq(m:FindFirstChildOfClass("Humanoid").RigType, Enum.HumanoidRigType.R6)
	end,
	["castModel copies a map model without its scripts"] = function(t, K)
		local src = game:GetService("Players"):CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType.R15)
		src.Name = "Guard"
		src.Archivable = false
		Instance.new("Script").Parent = src
		src.Parent = t.sandbox
		local m = K.SceneInstall.castModel("npc1", { model = "_CutsceneKitTest/Guard" }, K.Capture.resolve)
		t.defer(function()
			m:Destroy()
		end)
		t.eq(m.Name, "npc1")
		t.eq(#m:GetDescendants() > 10, true)
		local scripts = 0
		for _, d in m:GetDescendants() do
			if d:IsA("BaseScript") then
				scripts += 1
			end
		end
		t.eq(scripts, 0, "scripts stripped")
		t.eq(src.Archivable, false, "the original is left as it was")
	end,
	["install puts module, clips, cast and trigger in; remove takes them out"] = function(t, K)
		t.defer(function()
			K.SceneInstall.remove({ name = "_SITest" })
		end)
		local data = 'return { Name = "_SITest", Kind = "story", Length = 6, Anims = { Stage = "Fixture_Walkin_Stage" }, Markers = { { 6, "End", "" } } }'
		local out = K.SceneInstall.install({
			name = "_SITest",
			data = data,
			clips = { Fixture_Walkin_Stage = HttpService:JSONEncode(K.clip("Fixture_Walkin_Stage")) },
			cast = { npc1 = { model = "default", rig = "R15" } },
			trigger = { type = "zone", size = { 16, 8, 16 } },
			anchor = { 0, 600, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1 },
		}, need(K))
		t.ok(string.find(out, "installed _SITest: 1 Studio-only clips", 1, true) ~= nil, out)
		t.ok(string.find(out, "data valid", 1, true) ~= nil, out)
		local m = ReplicatedStorage.Cutscenes._SITest
		t.eq(#m.Clips:GetChildren(), 1)
		t.ok(m.Cast:FindFirstChild("npc1") ~= nil, "cast")
		t.ok(workspace.CutsceneZones:FindFirstChild("_SITest") ~= nil, "trigger")
		local gone = K.SceneInstall.remove({ name = "_SITest" })
		t.ok(string.find(gone, "removed _SITest: module, trigger", 1, true) == 1, gone)
		local cs = ReplicatedStorage:FindFirstChild("Cutscenes")
		t.eq(cs and cs:FindFirstChild("_SITest"), nil)
	end,
	["dev scripts and modules go in and come out"] = function(t, K)
		t.ok(string.find(K.SceneInstall.devModule({ name = "_SITestModule", source = "return 1" }), "installed", 1, true) ~= nil)
		t.ok(ReplicatedStorage:FindFirstChild("_SITestModule") ~= nil, "module there")
		K.SceneInstall.devModule({ name = "_SITestModule", remove = true })
		t.eq(ReplicatedStorage:FindFirstChild("_SITestModule"), nil)
		K.SceneInstall.devScript({ name = "_SITestScript", source = "print(1)" })
		local sps = game:GetService("StarterPlayer").StarterPlayerScripts
		t.ok(sps:FindFirstChild("_SITestScript") ~= nil, "script there")
		K.SceneInstall.devScript({ name = "_SITestScript", remove = true })
		t.eq(sps:FindFirstChild("_SITestScript"), nil)
	end,
	["castModel copies descendants with Archivable off and puts the flag back"] = function(t, K)
		local src = Instance.new("Model")
		src.Name = "Guard2"
		local hidden = Instance.new("Part")
		hidden.Name = "Hidden"
		hidden.Archivable = false
		hidden.Parent = src
		src.Parent = t.sandbox
		local m = K.SceneInstall.castModel("npc1", { model = "_CutsceneKitTest/Guard2" }, K.Capture.resolve)
		t.defer(function()
			m:Destroy()
		end)
		t.ok(m:FindFirstChild("Hidden") ~= nil, "the non-archivable part is in the copy")
		t.eq(hidden.Archivable, false, "flag restored on the original")
	end,
	["installing twice leaves one module and one trigger, and a prompt replaces a zone"] = function(t, K)
		t.defer(function()
			K.SceneInstall.remove({ name = "_SITwice" })
		end)
		local data = 'return { Name = "_SITwice", Kind = "story", Length = 6, Anims = { Stage = "Fixture_Walkin_Stage" }, Markers = { { 6, "End", "" } } }'
		local function go(kind)
			return K.SceneInstall.install({
				name = "_SITwice",
				data = data,
				cast = {},
				trigger = { type = kind, size = { 16, 8, 16 } },
				anchor = { 0, 620, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1 },
			}, need(K))
		end
		go("zone")
		go("prompt")
		local n = 0
		for _, z in workspace.CutsceneZones:GetChildren() do
			if z.Name == "_SITwice" then
				n += 1
			end
		end
		t.eq(n, 1, "one trigger")
		local mods = 0
		for _, c in ReplicatedStorage.Cutscenes:GetChildren() do
			if c.Name == "_SITwice" then
				mods += 1
			end
		end
		t.eq(mods, 1, "one module")
		local prompts = 0
		for _, d in workspace:GetDescendants() do
			if d.Name == "CutscenePrompt__SITwice" then
				prompts += 1
			end
		end
		t.eq(prompts, 1, "exactly the new prompt")
		go("zone")
		prompts = 0
		for _, d in workspace:GetDescendants() do
			if d.Name == "CutscenePrompt__SITwice" then
				prompts += 1
			end
		end
		t.eq(prompts, 0, "the zone install took the prompt away")
	end,
	["invalid data is refused loudly and the old install stays"] = function(t, K)
		if not kitInstalled() then
			return -- Data.validate lives in the installed kit: without out/install.luau this case cannot run
		end
		t.defer(function()
			K.SceneInstall.remove({ name = "_SIBad" })
		end)
		local good = 'return { Name = "_SIBad", Kind = "story", Length = 6, Anims = { Stage = "X" }, Markers = { { 6, "End", "" } } }'
		local args = { name = "_SIBad", data = good, cast = {}, trigger = { type = "zone" },
			anchor = { 0, 640, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1 } }
		K.SceneInstall.install(args, need(K))
		local old = ReplicatedStorage.Cutscenes._SIBad
		args.data = 'return { Kind = "nope" }'
		t.errors(function()
			K.SceneInstall.install(args, need(K))
		end, "install refused")
		t.eq(ReplicatedStorage.Cutscenes._SIBad, old, "the old module is still the one installed")
	end,
	["a missing prompt part leaves the old scene intact"] = function(t, K)
		t.defer(function()
			K.SceneInstall.remove({ name = "_SIPart" })
		end)
		local data = 'return { Name = "_SIPart", Kind = "story", Length = 6, Anims = { Stage = "X" }, Markers = { { 6, "End", "" } } }'
		local args = { name = "_SIPart", data = data, cast = {}, trigger = { type = "zone" },
			anchor = { 0, 660, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1 } }
		K.SceneInstall.install(args, need(K))
		local old = ReplicatedStorage.Cutscenes._SIPart
		local zone = workspace.CutsceneZones._SIPart
		args.trigger = { type = "prompt", on = "_CutsceneKitTest/NoSuchPart" }
		t.errors(function()
			K.SceneInstall.install(args, need(K))
		end, "trigger.on")
		t.eq(ReplicatedStorage.Cutscenes._SIPart, old, "old module kept")
		t.eq(workspace.CutsceneZones._SIPart, zone, "old trigger kept")
	end,
	["parts: a part refuses to run before the one ahead of it, and only the last part installs"] = function(t, K)
		t.defer(function()
			K.SceneInstall.remove({ name = "_SIParts" })
		end)
		local data = 'return { Name = "_SIParts", Kind = "story", Length = 6, Anims = { Stage = "Fixture_Walkin_Stage" }, Markers = { { 6, "End", "" } } }'
		local function clipFor(k) -- each part carries a clip with its own name, like a real scene
			local d = K.clip("Fixture_Walkin_Stage")
			d.name = "Clip" .. k
			return HttpService:JSONEncode(d)
		end
		local function part(k, withData)
			local args = { name = "_SIParts", part = k, parts = 2, clips = { ["Clip" .. k] = clipFor(k) } }
			if withData then
				args.data, args.cast, args.trigger = data, {}, { type = "zone" }
				args.anchor = { 0, 680, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1 }
			end
			-- like the studio template's `need`: a part before the last embeds no Capture, and asking for it errors
			local allowed = withData and { SceneInstall = true, Capture = true, ClipBuilder = true }
				or { SceneInstall = true, ClipBuilder = true }
			return K.SceneInstall.install(args, function(name)
				assert(allowed[name], "this step was rendered without the module " .. tostring(name))
				return K[name]
			end)
		end
		t.errors(function()
			part(2, true)
		end, "did not run yet")
		local cs = ReplicatedStorage:FindFirstChild("Cutscenes")
		t.eq(cs and cs:FindFirstChild("_SIParts"), nil, "nothing installed by a lone last part")
		t.ok(string.find(part(1, false), "staged", 1, true) ~= nil, "part 1 stages")
		t.eq(ReplicatedStorage.Cutscenes:FindFirstChild("_SIParts"), nil, "still nothing installed")
		t.ok(ServerStorage:FindFirstChild("CutsceneInstall__SIParts") ~= nil, "progress marker")
		local out = part(2, true)
		t.ok(string.find(out, "2 Studio-only clips", 1, true) ~= nil, out)
		t.eq(#ReplicatedStorage.Cutscenes._SIParts.Clips:GetChildren(), 2)
		t.eq(ServerStorage:FindFirstChild("CutsceneInstall__SIParts"), nil, "staging is gone")
	end,
	["a failed last part keeps the staged clips, a repeated part says so, and a retried part replaces its clips"] = function(t, K)
		if not kitInstalled() then
			return -- needs Data.validate from the installed kit to make the last part fail
		end
		t.defer(function()
			K.SceneInstall.remove({ name = "_SIRetry" })
		end)
		local good = 'return { Name = "_SIRetry", Kind = "story", Length = 6, Anims = { Stage = "X" }, Markers = { { 6, "End", "" } } }'
		local function clipFor(k) -- each part carries a clip with its own name, like a real scene
			local d = K.clip("Fixture_Walkin_Stage")
			d.name = "Clip" .. k
			return HttpService:JSONEncode(d)
		end
		local function part(k, extra)
			local args = { name = "_SIRetry", part = k, parts = 2, clips = { ["Clip" .. k] = clipFor(k) } }
			for key, v in extra or {} do
				args[key] = v
			end
			return K.SceneInstall.install(args, need(K))
		end
		local last = { cast = {}, trigger = { type = "zone" }, anchor = { 0, 720, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1 } }
		part(1)
		last.data = 'return { Kind = "nope" }'
		t.errors(function()
			part(2, last)
		end, "install refused")
		local staging = ServerStorage:FindFirstChild("CutsceneInstall__SIRetry")
		t.ok(staging ~= nil, "a failed last part keeps the staging folder")
		t.eq(#staging.Clips:GetChildren(), 2, "part 1's clip and the failed part's clip are staged")
		t.errors(function()
			part(2, last)
		end, "install refused") -- the retry fails the same way and must not pile up a second copy of the clip
		t.eq(#staging.Clips:GetChildren(), 2, "a retried part replaces its clip by name")
		last.data = good
		local out = part(2, last)
		t.ok(string.find(out, "2 Studio-only clips", 1, true) ~= nil, out)
		t.eq(ServerStorage:FindFirstChild("CutsceneInstall__SIRetry"), nil, "staging is gone after success")
		-- a middle part sent twice
		local function three(k)
			return K.SceneInstall.install({ name = "_SIRetry", part = k, parts = 3, clips = { ["Clip" .. k] = clipFor(k) } }, need(K))
		end
		three(1)
		three(2)
		t.errors(function()
			three(2)
		end, "was already installed")
	end,
	["remove also takes away a leftover record overlay"] = function(t, K)
		local sps = game:GetService("StarterPlayer").StarterPlayerScripts
		if sps:FindFirstChild("CutsceneRecordOverlay") then
			return -- never delete a real overlay another task has put there
		end
		local o = Instance.new("LocalScript")
		o.Name = "CutsceneRecordOverlay"
		o.Parent = sps
		t.defer(function()
			if o.Parent then
				o:Destroy()
			end
		end)
		local gone = K.SceneInstall.remove({ name = "_SINoSuchScene" })
		t.ok(string.find(gone, "overlay", 1, true) ~= nil, gone)
		t.eq(sps:FindFirstChild("CutsceneRecordOverlay"), nil)
	end,
	["remove takes away the folders install made once they are empty"] = function(t, K)
		local held = {}
		local function hold(parent, name)
			local f = parent:FindFirstChild(name)
			if f then
				f.Name = "_Held" .. name
				table.insert(held, f)
			end
		end
		hold(ReplicatedStorage, "Cutscenes")
		hold(workspace, "CutsceneZones")
		t.defer(function()
			K.SceneInstall.remove({ name = "_SIFolders" })
			for _, f in held do
				f.Name = string.sub(f.Name, #"_Held" + 1)
			end
		end)
		local data = 'return { Name = "_SIFolders", Kind = "story", Length = 6, Anims = { Stage = "X" }, Markers = { { 6, "End", "" } } }'
		K.SceneInstall.install({ name = "_SIFolders", data = data, cast = {}, trigger = { type = "zone" },
			anchor = { 0, 700, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1 } }, need(K))
		local gone = K.SceneInstall.remove({ name = "_SIFolders" })
		t.ok(string.find(gone, "Cutscenes folder", 1, true) ~= nil, gone)
		t.ok(string.find(gone, "CutsceneZones folder", 1, true) ~= nil, gone)
		t.eq(ReplicatedStorage:FindFirstChild("Cutscenes"), nil)
		t.eq(workspace:FindFirstChild("CutsceneZones"), nil)
	end,
	["remove takes away the play-test module and its tagged StarterCharacter"] = function(t, K)
		local StarterPlayer = game:GetService("StarterPlayer")
		if ReplicatedStorage:FindFirstChild("CutsceneKitPlayTest") or StarterPlayer:FindFirstChild("StarterCharacter") then
			return -- never delete a real play-test module or a viewer's own character
		end
		local m = Instance.new("ModuleScript")
		m.Name = "CutsceneKitPlayTest"
		m.Parent = ReplicatedStorage
		local c = Instance.new("Model")
		c.Name = "StarterCharacter"
		c:SetAttribute("CutsceneKitPlayTest", true)
		c.Parent = StarterPlayer
		t.defer(function()
			m:Destroy()
			c:Destroy()
		end)
		local gone = K.SceneInstall.remove({ name = "_SINoSuchScene" })
		t.ok(string.find(gone, "playtest", 1, true) ~= nil, gone)
		t.ok(string.find(gone, "temporary StarterCharacter", 1, true) ~= nil, gone)
		t.eq(ReplicatedStorage:FindFirstChild("CutsceneKitPlayTest"), nil)
		t.eq(StarterPlayer:FindFirstChild("StarterCharacter"), nil)
	end,
	["remove leaves a viewer's own untagged StarterCharacter alone"] = function(t, K)
		local StarterPlayer = game:GetService("StarterPlayer")
		if StarterPlayer:FindFirstChild("StarterCharacter") then
			return
		end
		local c = Instance.new("Model")
		c.Name = "StarterCharacter"
		c.Parent = StarterPlayer
		t.defer(function()
			c:Destroy()
		end)
		local gone = K.SceneInstall.remove({ name = "_SINoSuchScene" })
		t.ok(string.find(gone, "StarterCharacter", 1, true) == nil, gone)
		t.eq(StarterPlayer:FindFirstChild("StarterCharacter"), c)
	end,
	["devModule remove of the play-test module also takes away a tagged StarterCharacter, never an untagged one"] = function(t, K)
		local StarterPlayer = game:GetService("StarterPlayer")
		if ReplicatedStorage:FindFirstChild("CutsceneKitPlayTest") or StarterPlayer:FindFirstChild("StarterCharacter") then
			return
		end
		local c = Instance.new("Model")
		c.Name = "StarterCharacter"
		c:SetAttribute("CutsceneKitPlayTest", true)
		c.Parent = StarterPlayer
		t.defer(function()
			c:Destroy()
		end)
		local msg = K.SceneInstall.devModule({ name = "CutsceneKitPlayTest", remove = true })
		t.eq(msg, "removed CutsceneKitPlayTest and the temporary StarterCharacter")
		t.eq(StarterPlayer:FindFirstChild("StarterCharacter"), nil)
		local own = Instance.new("Model")
		own.Name = "StarterCharacter"
		own.Parent = StarterPlayer
		t.defer(function()
			own:Destroy()
		end)
		t.eq(K.SceneInstall.devModule({ name = "CutsceneKitPlayTest", remove = true }), "removed CutsceneKitPlayTest")
		t.eq(StarterPlayer:FindFirstChild("StarterCharacter"), own)
	end,
}
