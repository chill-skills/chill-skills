-- Tests for CutsceneKit.Letterbox. Method by fwjelaa (FWJ STUDIOS).
return {
	["bars ignore safe areas and insets"] = function(t, K)
		local gui = K.Letterbox.create(t.sandbox, 0.11)
		t.eq(gui.ScreenInsets, Enum.ScreenInsets.None)
		t.eq(gui.SafeAreaCompatibility, Enum.SafeAreaCompatibility.None)
		t.eq(gui.ClipToDeviceSafeArea, false)
		t.eq(gui.IgnoreGuiInset, true)
		t.eq(gui.ResetOnSpawn, false)
	end,
	["set opens and closes both bars"] = function(t, K)
		local gui = K.Letterbox.create(t.sandbox, 0.11)
		t.near(gui.Top.Size.Y.Scale, 0)
		K.Letterbox.set(gui, true, true)
		t.near(gui.Top.Size.Y.Scale, 0.11)
		t.near(gui.Bottom.Size.Y.Scale, 0.11)
		t.eq(gui.Bottom.AnchorPoint, Vector2.new(0, 1))
		K.Letterbox.set(gui, false, true)
		t.near(gui.Bottom.Size.Y.Scale, 0)
	end,
}
