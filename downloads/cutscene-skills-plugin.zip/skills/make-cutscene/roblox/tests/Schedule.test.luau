-- Tests for CutsceneKit.Schedule. Method by fwjelaa (FWJ STUDIOS).
return {
	["startAt is LEAD seconds ahead"] = function(t, K)
		t.near(K.Schedule.startAt(100), 100.75)
	end,
	["decide waits before the start"] = function(t, K)
		t.eq(K.Schedule.decide(100, 6, 99.5), "wait")
	end,
	["decide plays on time and a little late"] = function(t, K)
		t.eq(K.Schedule.decide(100, 6, 100), "play")
		t.eq(K.Schedule.decide(100, 6, 103), "play")
	end,
	["decide skips when under 1.5 s are left"] = function(t, K)
		t.eq(K.Schedule.decide(100, 6, 104.8), "skip")
	end,
	["a short scene started on time is not skipped"] = function(t, K)
		t.eq(K.Schedule.decide(100, 1, 100.1), "play")
	end,
	["decide is over after the end"] = function(t, K)
		t.eq(K.Schedule.decide(100, 6, 106), "over")
	end,
}
