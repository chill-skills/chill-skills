-- Tests for CutsceneKit.Zones. Method by fwjelaa (FWJ STUDIOS).
return {
	["inside a turned box"] = function(t, K)
		local cf = CFrame.new(10, 0, 0) * CFrame.Angles(0, math.rad(45), 0)
		local size = Vector3.new(4, 4, 20)
		t.ok(K.Zones.inside(cf, size, cf * Vector3.new(0, 0, 9)), "along the long side")
		t.ok(not K.Zones.inside(cf, size, cf * Vector3.new(3, 0, 0)), "past the short side")
	end,
	["step enters once and leaves only past the margin"] = function(t, K)
		local cf, size = CFrame.new(), Vector3.new(10, 10, 10)
		local inside, entered = K.Zones.step(cf, size, Vector3.zero, false)
		t.ok(inside and entered, "enters")
		inside, entered = K.Zones.step(cf, size, Vector3.zero, true)
		t.ok(inside and not entered, "stays without entering again")
		inside = K.Zones.step(cf, size, Vector3.new(7, 0, 0), true)
		t.ok(inside, "2 studs outside still counts (hysteresis)")
		inside = K.Zones.step(cf, size, Vector3.new(10, 0, 0), true)
		t.ok(not inside, "5 studs outside has left")
	end,
	["anchor is the Anchor attachment, else the floor centre"] = function(t, K)
		local zone = Instance.new("Part")
		zone.Size = Vector3.new(16, 8, 16)
		zone.CFrame = CFrame.new(0, 4, -40)
		zone.Anchored = true
		zone.Parent = t.sandbox
		t.ok((K.Zones.anchor(zone).Position - Vector3.new(0, 0, -40)).Magnitude < 1e-4, "floor centre")
		local a = Instance.new("Attachment")
		a.Name = "Anchor"
		a.Position = Vector3.new(2, -4, 0)
		a.Parent = zone
		t.ok((K.Zones.anchor(zone).Position - Vector3.new(2, 0, -40)).Magnitude < 1e-4, "attachment")
	end,
}
