-- Tests for CutsceneKit.Server's awakenings, cooldowns and the awakened state, and Onlooker's pure parts (Edit mode,
-- stand-in players). Method by fwjelaa (FWJ STUDIOS).
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local FLOOR_Y = -499.5 -- the top of the test floor

local function module(t, source)
	local m = Instance.new("ModuleScript")
	m.Name = "_AwakenTest" .. math.random(1, 1e6)
	m.Source = source
	m.Parent = ReplicatedStorage:WaitForChild("Cutscenes")
	t.defer(function()
		m:Destroy()
	end)
	return m.Name
end

local function awakening(t, cooldown)
	return module(t, ('return { Kind = "awakening", Length = 4, Anims = { Stage = "S", R15 = { player = "P" } }, Markers = { { 1.5, "Impact", "" }, { 4, "End", "" } }, Config = { Cooldown = %d, Awakened = { Duration = 20 } } }'):format(cooldown or 0))
end

local function floor(t)
	local f = Instance.new("Part")
	f.Anchored = true
	f.Size = Vector3.new(60, 1, 60)
	f.CFrame = CFrame.new(0, FLOOR_Y - 0.5, 0)
	f.Parent = t.sandbox
	return f
end

local function body(t, name)
	local c = Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType.R15)
	c.Name = name
	c:PivotTo(CFrame.new(3, FLOOR_Y + 3.2, 4) * CFrame.Angles(0, math.rad(90), 0))
	return c
end

-- a stand-in player: a Folder with its character as a child named Character (Server.characterOf)
local function caster(t, uid)
	local p = Instance.new("Folder")
	p.Name = "FakeCaster"
	p:SetAttribute("UserId", uid)
	body(t, "Character").Parent = p
	p.Parent = t.sandbox
	t.defer(function()
		pcall(function()
			require(ReplicatedStorage.CutsceneKit.Server).release(p)
		end)
	end)
	return p
end

return {
	["only awakening scenes start with Awaken"] = function(t, K)
		local story = module(t, 'return { Kind = "story", Length = 2, Anims = { Stage = "S" }, Markers = { { 2, "End", "" } } }')
		local ok, why = K.Server.awaken(caster(t, -31), story)
		t.eq(ok, false)
		t.ok(string.find(why, "Play", 1, true) ~= nil, why)
		ok, why = K.Server.awaken(caster(t, -32), "_NoSuchScene")
		t.eq(ok, false)
		t.ok(string.find(why, "_NoSuchScene", 1, true) ~= nil, why)
	end,
	["awaken pins the caster on the floor under it and sets the awakened state"] = function(t, K)
		floor(t)
		local name = awakening(t, 0)
		local p = caster(t, -33)
		local root = p.Character.HumanoidRootPart
		local facing = root.CFrame.LookVector -- before the pin turns the root to the anchor
		t.eq(K.Server.awaken(p, name), true)
		local anchor = p:GetAttribute("CutsceneAnchor")
		t.near(anchor.Position.Y, FLOOR_Y, 1e-3, "the anchor is on the floor")
		t.ok((anchor.LookVector - facing).Magnitude < 1e-3, "the anchor faces the way the caster faced")
		t.ok((root.CFrame.LookVector - facing).Magnitude < 1e-3, "the pinned caster still faces its way")
		t.ok(root.Anchored, "pinned for the scene")
		t.near(root.Position.Y - FLOOR_Y, K.Server.standHeight(p.Character), 1e-3, "stood on its spot")
		local startAt = p:GetAttribute("CutsceneStartAt")
		t.near(p:GetAttribute("AwakenedAt") - startAt, 1.5, 1e-6, "the aura comes with the first Impact")
		t.near(p:GetAttribute("AwakenedEndsAt") - startAt, 4 + 20, 1e-6, "the scene, then Duration")
		t.eq(p:GetAttribute("Awakened"), name)
		t.eq(p:GetAttribute("AwakenedEnd"), "expire")
		local again, why = K.Server.awaken(p, name)
		t.eq(again, false)
		t.eq(why, "busy")
		K.Server.release(p)
		t.eq(root.Anchored, false, "release unpins")
		t.eq(select(2, K.Server.awaken(p, name)), "awakened", "one awakened state at a time")
	end,
	["the cooldown counts from the start"] = function(t, K)
		floor(t)
		local name = awakening(t, 30)
		local p = caster(t, -34)
		t.eq(K.Server.awaken(p, name), true)
		K.Server.release(p)
		p:SetAttribute("Awakened", nil)
		local ok, why, wait = K.Server.awaken(p, name)
		t.eq(ok, false)
		t.eq(why, "cooldown")
		t.near(wait, 30.75, 0.2)
		t.ok(type(p:GetAttribute("CutsceneReady_" .. name)) == "number", "a UI can read when it is ready")
	end,
	["Play keeps Config.Cooldown too"] = function(t, K)
		local name = module(t, 'return { Kind = "story", Length = 2, Anims = { Stage = "S" }, Markers = { { 2, "End", "" } }, Config = { Replay = "always", Cooldown = 10 } }')
		local p = caster(t, -35)
		t.eq(K.Server.play(p, name, CFrame.new(0, FLOOR_Y, 0)), true)
		K.Server.release(p)
		local ok, why = K.Server.play(p, name, CFrame.new(0, FLOOR_Y, 0))
		t.eq(ok, false)
		t.eq(why, "cooldown")
	end,
	["EndAwakening waits for the cinematic, a death doesn't"] = function(t, K)
		floor(t)
		local name = awakening(t, 0)
		local p = caster(t, -36)
		K.Server.awaken(p, name)
		local startAt = p:GetAttribute("CutsceneStartAt")
		t.eq(K.Server.endAwakening(p), true)
		t.eq(p:GetAttribute("AwakenedEnd"), "ended")
		t.near(p:GetAttribute("AwakenedEndsAt"), startAt + 4, 1e-3, "the power-down comes after the scene")
		K.Server.onDied(p)
		t.eq(p:GetAttribute("AwakenedEnd"), "died")
		t.eq(p:GetAttribute("Awakened"), nil)
		t.eq(p:GetAttribute("CutsceneLock"), nil, "the scene is released too")
		t.eq(select(2, K.Server.endAwakening(p)), "not awakened")
	end,
	["an NPC awakens for everyone and is tagged"] = function(t, K)
		floor(t)
		local name = awakening(t, 0)
		local npc = body(t, "Boss")
		npc.Parent = t.sandbox
		t.eq(K.Server.awaken(npc, name), true)
		t.ok(CollectionService:HasTag(npc, "CutsceneCaster"), "clients watch tagged casters")
		t.eq(npc:GetAttribute("Awakened"), name)
		t.ok(npc.HumanoidRootPart.Anchored, "pinned")
		K.Server.release(npc)
		CollectionService:RemoveTag(npc, "CutsceneCaster")
	end,
	["an unskippable scene's early Ended keeps the caster pinned; a skippable one's frees it"] = function(t, K)
		floor(t)
		local name = awakening(t, 0)
		local p = caster(t, -37)
		local root = p.Character.HumanoidRootPart
		t.eq(K.Server.awaken(p, name), true)
		K.Server.ended(p, name, p:GetAttribute("CutsceneStartAt"), "late")
		t.ok(root.Anchored, "still pinned: a client can't cancel its own wind-up")
		t.eq(p:GetAttribute("CutsceneLock"), name, "the scene goes on on the server")
		local over = K.Server.now() - 10 -- the same report at the scene's end frees the caster
		p:SetAttribute("CutsceneStartAt", over)
		K.Server.ended(p, name, over, "end")
		t.eq(p:GetAttribute("CutsceneLock"), nil, "an Ended at the end frees it")
		t.eq(root.Anchored, false, "and unpins it")
		local story = module(t, 'return { Kind = "story", Length = 2, Anims = { Stage = "S" }, Markers = { { 2, "End", "" } }, Config = { Replay = "always" } }')
		local q = caster(t, -38)
		t.eq(K.Server.play(q, story, CFrame.new(0, FLOOR_Y, 0)), true)
		K.Server.ended(q, story, q:GetAttribute("CutsceneStartAt"), "error")
		t.eq(q:GetAttribute("CutsceneLock"), nil, "a skippable scene's Ended frees the player at once, as before")
	end,
	["a player's character passed as the subject awakens the player, not an NPC"] = function(t, K)
		floor(t)
		local name = awakening(t, 0)
		local p = caster(t, -39)
		local char = p.Character
		local ownerOf = K.Server.ownerOf
		K.Server.ownerOf = function(m)
			return m == char and p or nil -- a stub player whose character is this Model
		end
		t.defer(function()
			K.Server.ownerOf = ownerOf
		end)
		t.eq(K.Server.awaken(char, name), true)
		t.eq(p:GetAttribute("Awakened"), name, "the state is on the player")
		t.eq(char:GetAttribute("Awakened"), nil, "not on the body")
		t.ok(not CollectionService:HasTag(char, "CutsceneCaster"), "a player's body is never tagged as an NPC caster")
		t.eq(K.Server.endAwakening(char), true)
		t.eq(p:GetAttribute("AwakenedEnd"), "ended")
	end,
	["only the subject's current body ends its awakened state"] = function(t, K)
		floor(t)
		local name = awakening(t, 0)
		local p = caster(t, -40)
		t.eq(K.Server.awaken(p, name), true)
		local old = p.Character
		old.Name = "OldBody" -- the game swapped bodies and kept the old one alive
		local new = body(t, "Character")
		new.Parent = p
		K.Server.bodyGone(p, old)
		t.eq(p:GetAttribute("Awakened"), name, "the old body's death or removal leaves the new body awake")
		K.Server.bodyGone(p, new)
		t.eq(p:GetAttribute("AwakenedEnd"), "died", "the current body's death or removal ends it at once")
		t.eq(p:GetAttribute("Awakened"), nil)
	end,
	["a Replay saved NPC never touches the DataStore"] = function(t, K)
		local name = module(t, 'return { Kind = "story", Length = 2, Anims = { Stage = "S" }, Markers = { { 2, "End", "" } }, Config = { Replay = "saved" } }')
		local writes = 0
		K.Server.useStore({
			GetAsync = function()
				return nil
			end,
			UpdateAsync = function(_, _, fn)
				writes += 1
				return fn(nil)
			end,
		})
		t.defer(function()
			K.Server.useStore(nil)
		end)
		K.Server.flush(0)
		writes = 0
		local npc = body(t, "Villager")
		npc:SetAttribute("CutsceneKitTestLoaded", true)
		npc.Parent = t.sandbox
		t.eq(K.Server.play(npc, name, CFrame.new(0, FLOOR_Y, 0)), true)
		K.Server.release(npc)
		K.Server.forget(npc, name)
		K.Server.flush(0)
		t.eq(writes, 0, "no seen-list write under key 0 for an NPC")
	end,
	["awaken and endAwakening answer a bad subject instead of throwing"] = function(t, K)
		local name = awakening(t, 0)
		for _, bad in ipairs({ "Bob", 42, true }) do
			local ok, why = K.Server.awaken(bad, name)
			t.eq(ok, false, "awaken " .. tostring(bad))
			t.ok(type(why) == "string", "awaken says why")
			ok, why = K.Server.endAwakening(bad)
			t.eq(ok, false, "endAwakening " .. tostring(bad))
			t.ok(type(why) == "string", "endAwakening says why")
		end
		t.eq(K.Server.awaken(nil, name), false, "awaken nil")
		t.eq(K.Server.endAwakening(nil), false, "endAwakening nil")
	end,
	["an onlooker fades only on the scene's normal end"] = function(t, K)
		t.eq(K.Onlooker.early(100, 4, 101, nil), true, "a death or early release mid-scene stops at once")
		t.eq(K.Onlooker.early(100, 4, 103.9, nil), false, "a release at the end fades")
		t.eq(K.Onlooker.early(100, 4, 103.9, 105), true, "a new scene replaces it at once")
	end,
	["an onlooker's broken cue warns once, never fires again, and the scene still ends"] = function(t, K)
		local name = module(t, 'return { Kind = "awakening", Length = 0.3, Anims = { Stage = "S", R15 = { player = "P" } }, Markers = { { 0.05, "VFX", "Boom" }, { 0.3, "End", "" } } }')
		local fire, calls = K.Director.fireVfx, 0
		K.Director.fireVfx = function()
			calls += 1
			error("a broken cue on purpose")
		end
		t.defer(function()
			K.Director.fireVfx = fire
		end)
		K.Onlooker.warned["cue:VFX:Boom"] = nil
		local s = Instance.new("Folder")
		s.Parent = t.sandbox
		s:SetAttribute("CutsceneAnchor", CFrame.new(0, FLOOR_Y, 0))
		s:SetAttribute("CutsceneName", name)
		s:SetAttribute("CutsceneStartAt", os.clock())
		local h = K.Onlooker.play(s, { now = os.clock })
		t.ok(h ~= nil, "it plays")
		t.defer(function()
			h.stop(true)
			h.folder:Destroy()
		end)
		task.wait(0.6)
		t.eq(calls, 1, "the broken cue fired once, not every frame")
		t.eq(K.Onlooker.warned["cue:VFX:Boom"], true, "and warned")
		t.ok(h.done, "the handle still reached its stop")
	end,
	["an onlooker that fails to set up leaves no folder behind"] = function(t, K)
		local name = awakening(t, 0)
		local prepare = K.Director.prepareVfx
		K.Director.prepareVfx = function()
			error("setup broken on purpose")
		end
		t.defer(function()
			K.Director.prepareVfx = prepare
		end)
		local function folders()
			local n = 0
			for _, c in ipairs(workspace:GetChildren()) do
				n += c.Name == "CutsceneOnlook" and 1 or 0
			end
			return n
		end
		local s = Instance.new("Folder")
		s.Parent = t.sandbox
		s:SetAttribute("CutsceneAnchor", CFrame.new(0, FLOOR_Y, 0))
		s:SetAttribute("CutsceneName", name)
		s:SetAttribute("CutsceneStartAt", os.clock())
		local before = folders()
		t.eq(pcall(K.Onlooker.play, s, { now = os.clock }), false, "the error still reaches watch's warning")
		t.eq(folders(), before, "its folder is gone")
	end,
	["one caster tag for the server, the aura and the onlooker"] = function(t, K)
		t.eq(K.Server.TAG, "CutsceneCaster")
		t.eq(K.Aura.TAG, K.Server.TAG, "Aura.TAG")
		t.eq(K.Onlooker.TAG, K.Server.TAG, "Onlooker.TAG")
	end,
	["groundAnchor falls back below the root when there is no floor"] = function(t, K)
		local c = body(t, "Floating")
		c:PivotTo(CFrame.new(0, 4000, 0))
		c.Parent = t.sandbox
		local a = K.Server.groundAnchor(c.HumanoidRootPart, c)
		t.near(a.Position.Y, 3997, 1e-3)
	end,
	["an onlooker's shake fades with distance"] = function(t, K)
		t.eq(K.Shake.falloff(10, 30, 150), 1)
		t.eq(K.Shake.falloff(30, 30, 150), 1)
		t.near(K.Shake.falloff(90, 30, 150), 0.5)
		t.eq(K.Shake.falloff(150, 30, 150), 0)
		t.eq(K.Shake.falloff(400, 30, 150), 0)
	end,
	["an onlooker sees awakenings, not story scenes, and skips what is nearly over"] = function(t, K)
		local wake = awakening(t, 0)
		local story = module(t, 'return { Kind = "story", Length = 2, Anims = { Stage = "S" }, Markers = { { 2, "End", "" } } }')
		local s = Instance.new("Folder")
		s.Parent = t.sandbox
		s:SetAttribute("CutsceneAnchor", CFrame.new())
		s:SetAttribute("CutsceneName", wake)
		s:SetAttribute("CutsceneStartAt", 100)
		t.ok(K.Onlooker.sceneOf(s, 100.5) ~= nil, "an awakening in progress")
		t.eq(K.Onlooker.sceneOf(s, 103.2), nil, "under 1.5 s left: skipped (spec 6)")
		s:SetAttribute("CutsceneName", story)
		t.eq(K.Onlooker.sceneOf(s, 100.5), nil, "story scenes are private")
	end,
}
