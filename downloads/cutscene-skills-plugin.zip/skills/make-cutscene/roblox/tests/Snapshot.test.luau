-- Tests for CutsceneKit.Snapshot. Method by fwjelaa (FWJ STUDIOS).
local function env(t)
	local cam = Instance.new("Camera")
	cam.CameraType = Enum.CameraType.Custom
	cam.FieldOfView = 70
	cam.Parent = t.sandbox
	local gui = Instance.new("Folder")
	gui.Parent = t.sandbox
	local on = Instance.new("ScreenGui")
	on.Name = "On"
	on.Enabled = true
	on.Parent = gui
	local off = Instance.new("ScreenGui")
	off.Name = "Off"
	off.Enabled = false
	off.Parent = gui
	local controls = { enabled = true }
	function controls:Disable()
		self.enabled = false
	end
	function controls:Enable()
		self.enabled = true
	end
	return { camera = cam, playerGui = gui, controls = controls }, on, off
end
return {
	["capture turns off only enabled guis and the controls"] = function(t, K)
		local e, on, off = env(t)
		K.Snapshot.capture(e)
		t.eq(on.Enabled, false)
		t.eq(off.Enabled, false)
		t.eq(e.controls.enabled, false)
	end,
	["restore brings back exactly what was on"] = function(t, K)
		local e, on, off = env(t)
		local s = K.Snapshot.capture(e)
		e.camera.CameraType = Enum.CameraType.Scriptable
		e.camera.FieldOfView = 40
		K.Snapshot.restore(s)
		t.eq(e.camera.CameraType, Enum.CameraType.Custom)
		t.near(e.camera.FieldOfView, 70)
		t.eq(on.Enabled, true)
		t.eq(off.Enabled, false, "a gui the player had closed stays closed")
		t.eq(e.controls.enabled, true)
	end,
	["restore destroys tracked instances and unhides and unanchors parts"] = function(t, K)
		local e = env(t)
		local s = K.Snapshot.capture(e)
		local made = K.Snapshot.track(s, Instance.new("Folder"))
		made.Parent = t.sandbox
		local model = Instance.new("Model")
		local part = Instance.new("Part")
		part.Anchored = false
		part.Parent = model
		model.Parent = t.sandbox
		K.Snapshot.hide(s, model)
		K.Snapshot.anchor(s, part)
		t.eq(part.LocalTransparencyModifier, 1)
		t.eq(part.Anchored, true)
		K.Snapshot.restore(s)
		t.eq(made.Parent, nil)
		t.eq(part.LocalTransparencyModifier, 0)
		t.eq(part.Anchored, false)
	end,
	["restore twice is harmless"] = function(t, K)
		local e = env(t)
		local s = K.Snapshot.capture(e)
		K.Snapshot.restore(s)
		K.Snapshot.restore(s)
		t.eq(e.controls.enabled, true)
	end,
	["restore still re-enables guis when controls:Enable throws"] = function(t, K)
		local e, on = env(t)
		function e.controls:Enable()
			error("boom")
		end
		local s = K.Snapshot.capture(e)
		e.camera.CameraType = Enum.CameraType.Scriptable
		K.Snapshot.restore(s)
		t.eq(on.Enabled, true)
		t.eq(e.camera.CameraType, Enum.CameraType.Custom)
	end,
	["capture survives controls:Disable throwing"] = function(t, K)
		local e, on = env(t)
		function e.controls:Disable()
			error("boom")
		end
		local s = K.Snapshot.capture(e)
		t.ok(s ~= nil, "capture returned a snapshot")
		K.Snapshot.restore(s)
		t.eq(on.Enabled, true)
	end,
	["restore reports each step that failed, once"] = function(t, K)
		local e = env(t)
		function e.controls:Enable()
			error("boom")
		end
		local s = K.Snapshot.capture(e)
		local failed = K.Snapshot.restore(s)
		t.eq(type(failed), "table")
		t.eq(#failed, 1)
		t.ok(string.find(failed[1], "controls", 1, true) and string.find(failed[1], "boom", 1, true), failed[1])
		t.eq(#K.Snapshot.restore(s), 0, "a second restore does nothing")
		t.eq(#K.Snapshot.restore(K.Snapshot.capture(env(t))), 0, "a clean restore reports nothing")
	end,
	["capture frees a locked mouse for the Skip button and restore locks it again"] = function(t, K)
		local e = env(t)
		e.userInput = { MouseBehavior = Enum.MouseBehavior.LockCenter, MouseIconEnabled = false }
		local s = K.Snapshot.capture(e)
		t.eq(e.userInput.MouseBehavior, Enum.MouseBehavior.Default)
		t.eq(e.userInput.MouseIconEnabled, true)
		K.Snapshot.restore(s)
		t.eq(e.userInput.MouseBehavior, Enum.MouseBehavior.LockCenter)
		t.eq(e.userInput.MouseIconEnabled, false)
	end,
	["a mouse setting that throws on restore does not stop the other"] = function(t, K)
		local e = env(t)
		local store = { MouseBehavior = Enum.MouseBehavior.LockCurrentPosition, MouseIconEnabled = false }
		local locked = false
		e.userInput = setmetatable({}, {
			__index = store,
			__newindex = function(_, k, v)
				if locked and k == "MouseIconEnabled" then
					error("icon locked")
				end
				store[k] = v
			end,
		})
		local s = K.Snapshot.capture(e)
		t.eq(store.MouseBehavior, Enum.MouseBehavior.Default)
		t.eq(store.MouseIconEnabled, true)
		locked = true
		local failed = K.Snapshot.restore(s)
		t.eq(store.MouseBehavior, Enum.MouseBehavior.LockCurrentPosition)
		t.eq(#failed, 1)
		t.ok(string.find(failed[1], "mouse icon", 1, true) ~= nil, failed[1])
	end,
	["a mouse setting capture could not change is not put back"] = function(t, K)
		local e = env(t)
		local store = { MouseBehavior = Enum.MouseBehavior.LockCenter, MouseIconEnabled = false }
		e.userInput = setmetatable({}, {
			__index = store,
			__newindex = function(_, k, v)
				if k == "MouseIconEnabled" then
					error("icon locked")
				end
				store[k] = v
			end,
		})
		local s = K.Snapshot.capture(e)
		t.eq(store.MouseBehavior, Enum.MouseBehavior.Default, "the other setting still changed")
		t.eq(#K.Snapshot.restore(s), 0, "nothing to put back for the icon, so nothing failed")
		t.eq(store.MouseBehavior, Enum.MouseBehavior.LockCenter)
	end,
}
