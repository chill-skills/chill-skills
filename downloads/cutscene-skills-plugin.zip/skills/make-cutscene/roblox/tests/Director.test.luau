-- Tests for CutsceneKit.Director (Edit-mode parts; playback is tested in Play in Task 10). Method by fwjelaa (FWJ STUDIOS).
local function rig(t, rigType)
	local m = Instance.new("Model")
	local root = Instance.new("Part")
	root.Name = "HumanoidRootPart"
	root.Size = Vector3.new(2, 2, 1)
	root.Parent = m
	local hum = Instance.new("Humanoid")
	hum.RigType = Enum.HumanoidRigType[rigType]
	hum.HipHeight = 2
	hum.Parent = m
	m.Parent = t.sandbox
	return m
end
-- a stand-in Player for Director.play in Edit mode: no character, no PlayerGui, no PlayerScripts
local function fakePlayer(t)
	local attrs = {}
	local removing = Instance.new("BindableEvent")
	removing.Parent = t.sandbox
	return {
		Character = nil,
		CharacterRemoving = removing.Event,
		FindFirstChild = function()
			return nil
		end,
		FindFirstChildOfClass = function()
			return nil
		end,
		SetAttribute = function(_, k, v)
			attrs[k] = v
		end,
		GetAttribute = function(_, k)
			return attrs[k]
		end,
	}
end
local function sceneModule(t, source)
	local m = Instance.new("ModuleScript")
	m.Name = "_DirectorScene"
	m.Source = source
	m.Parent = t.sandbox
	t.defer(function()
		local left = workspace:FindFirstChild("CutsceneLocal")
		if left then
			left:Destroy()
		end
	end)
	return m
end
return {
	["play reports a clip that cannot load once, after restoring"] = function(t, K)
		t.eq(workspace:FindFirstChild("CutsceneLocal"), nil, "no scene running before the test")
		local module = sceneModule(t, 'return { Kind = "story", Length = 2, Anims = { Stage = "NoSuchClip" }, Markers = { { 0, "Letterbox", "in" } } }')
		local player = fakePlayer(t)
		local ends, folderAtEnd = {}, nil
		local handle = K.Director.play({
			module = module,
			player = player,
			anchor = CFrame.new(0, -500, 0),
			startAt = os.clock() + 0.75,
			now = os.clock,
			onEnd = function(reason)
				table.insert(ends, reason)
				folderAtEnd = workspace:FindFirstChild("CutsceneLocal")
			end,
		})
		t.eq(handle.reason, "load-failed")
		t.eq(player:GetAttribute("CutsceneLastResult"), "load-failed")
		handle.finish("skip")
		t.eq(table.concat(ends, ","), "load-failed", "reported once")
		t.eq(folderAtEnd, nil, "restored before it was reported")
	end,
	["play reports an invalid scene"] = function(t, K)
		local module = sceneModule(t, 'return { Kind = "nope" }')
		local ends = {}
		local handle = K.Director.play({
			module = module,
			player = fakePlayer(t),
			anchor = CFrame.new(),
			startAt = os.clock(),
			now = os.clock,
			onEnd = function(reason)
				table.insert(ends, reason)
			end,
		})
		t.eq(handle.reason, "invalid")
		t.eq(table.concat(ends, ","), "invalid")
		t.eq(workspace:FindFirstChild("CutsceneLocal"), nil, "nothing was set up")
	end,
	["every end is reported except skip and replaced"] = function(t, K)
		for _, r in { "end", "died", "respawn", "load-failed", "late", "overtime", "invalid", "error" } do
			t.eq(K.Director.reportsEnd(r), true, r)
		end
		t.eq(K.Director.reportsEnd("skip"), false, "skip has its own remote")
		t.eq(K.Director.reportsEnd("replaced"), false, "the server already scheduled the next scene")
	end,
	["guard runs the frame step and passes its arguments"] = function(t, K)
		local got
		local step = K.Director.guard("test step", function(dt)
			got = dt
		end, function() end)
		step(0.016)
		t.near(got, 0.016)
	end,
	["guard stops a failing frame step after one warning and hands on the traceback"] = function(t, K)
		local calls, errs = 0, {}
		local step = K.Director.guard("test step", function(x)
			calls += 1
			error("boom " .. tostring(x))
		end, function(err)
			table.insert(errs, err)
		end)
		step(1)
		step(2)
		t.eq(calls, 1, "the body is not run again after its error")
		t.eq(#errs, 1)
		t.ok(string.find(errs[1], "boom 1", 1, true) ~= nil, errs[1])
		t.ok(string.find(errs[1], "\n", 1, true) ~= nil, "carries a traceback")
	end,
	["clonePlayer shows every part of the copy, even ones the camera hid"] = function(t, K)
		local m = rig(t, "R15")
		local head = Instance.new("Part")
		head.Name = "Head"
		head.Parent = m
		local face = Instance.new("Decal")
		face.Name = "face"
		face.Parent = head
		head.LocalTransparencyModifier = 1 -- first person: the camera scripts hide your own head
		face.LocalTransparencyModifier = 1
		m.HumanoidRootPart.LocalTransparencyModifier = 1
		local copy = K.Director.clonePlayer(m)
		copy.Parent = t.sandbox
		t.eq(copy.Head.LocalTransparencyModifier, 0, "head")
		t.eq(copy.Head.face.LocalTransparencyModifier, 0, "face")
		t.eq(copy.HumanoidRootPart.LocalTransparencyModifier, 0, "root")
		t.eq(head.LocalTransparencyModifier, 1, "the real character is left alone")
	end,
	["stage puts the camera joint under StageRoot at the anchor"] = function(t, K)
		local model, motor = K.Director.stage(CFrame.new(5, 0, 5), t.sandbox)
		t.eq(motor.Name, "CutsceneCamera")
		t.eq(motor.Part0.Name, "StageRoot")
		t.eq(motor.Part1.Name, "CutsceneCamera")
		t.ok(model.StageRoot.Anchored, "root anchored")
		t.ok(model.AnimationController:FindFirstChildOfClass("Animator") ~= nil, "animator")
		t.ok((model.StageRoot.Position - Vector3.new(5, 0, 5)).Magnitude < 1e-4, "at the anchor")
	end,
	["place stands an R15 rig on its spot, turned"] = function(t, K)
		local m = rig(t, "R15")
		local animator, rigName = K.Director.place(m, CFrame.new(0, 10, 0), { 0, 0, -8, 0, 180, 0 })
		t.eq(rigName, "R15")
		t.ok(animator:IsA("Animator"), "animator")
		t.ok((m.HumanoidRootPart.Position - Vector3.new(0, 13, -8)).Magnitude < 1e-3, "root at hip height + half root")
		t.ok((m.HumanoidRootPart.CFrame.LookVector - Vector3.new(0, 0, 1)).Magnitude < 1e-3, "faces +Z")
		t.ok(m.HumanoidRootPart.Anchored, "anchored")
	end,
	["place uses 3 studs for R6"] = function(t, K)
		local m = rig(t, "R6")
		local _, rigName = K.Director.place(m, CFrame.new(), nil)
		t.eq(rigName, "R6")
		t.near(m.HumanoidRootPart.Position.Y, 3)
	end,
	["strip removes scripts and force fields and hides the name"] = function(t, K)
		local m = rig(t, "R15")
		Instance.new("LocalScript").Parent = m
		Instance.new("ForceField").Parent = m
		K.Director.strip(m)
		t.eq(m:FindFirstChildOfClass("LocalScript"), nil)
		t.eq(m:FindFirstChildOfClass("ForceField"), nil)
		t.eq(m.Humanoid.DisplayDistanceType, Enum.HumanoidDisplayDistanceType.None)
	end,
	["animation passes asset ids through and returns nil for a missing clip"] = function(t, K)
		local module = Instance.new("ModuleScript")
		module.Parent = t.sandbox
		t.eq(K.Director.animation(module, "rbxassetid://123").AnimationId, "rbxassetid://123")
		t.eq(K.Director.animation(module, "Nope"), nil)
	end,
	["firstPrev fires markers at 0 for an on-time start"] = function(t, K)
		t.eq(K.Director.firstPrev(0.004), -1)
		t.eq(K.Director.firstPrev(0), -1)
	end,
	["firstPrev keeps a late start's time"] = function(t, K)
		t.eq(K.Director.firstPrev(1.2), 1.2)
	end,
	["place returns nil for a model without a root part"] = function(t, K)
		local m = Instance.new("Model")
		m.Name = "Broken"
		Instance.new("Humanoid").Parent = m
		m.Parent = t.sandbox
		t.eq(K.Director.place(m, CFrame.new(), nil), nil)
	end,
	["findControls returns nil at once when the place has no PlayerModule"] = function(t, K)
		local player = Instance.new("Folder")
		local scripts = Instance.new("Folder")
		scripts.Name = "PlayerScripts"
		scripts.Parent = player
		player.Parent = t.sandbox
		local t0 = os.clock()
		t.eq(K.Director.findControls(player), nil)
		t.ok(os.clock() - t0 < 0.5, "must not wait for a PlayerModule that is not there")
		t.eq(K.Director.findControls(t.sandbox), nil, "no PlayerScripts at all")
	end,
	["cue Line shows the text and schedules the clear"] = function(t, K)
		local ctx = { data = { Lines = { ["1"] = { speaker = "G", text = "Stop." } } }, shake = K.Shake.new(), cues = {} }
		ctx.subtitles = K.Subtitles.create(t.sandbox)
		K.Director.cue(ctx, { 0.6, "Line", "1" })
		t.ok(string.find(ctx.subtitles.Line.Text, "Stop.", 1, true) ~= nil, "text shown")
		t.near(ctx.lineClearAt, 0.6 + K.Subtitles.hold("Stop."))
		t.eq(ctx.cues[1], "Line")
	end,
	["cue Shake adds trauma; unknown markers are only recorded"] = function(t, K)
		local ctx = { data = {}, shake = K.Shake.new(), cues = {} }
		K.Director.cue(ctx, { 2.6, "Shake", "0.35" })
		K.Director.cue(ctx, { 3, "VFX", "Burst" })
		t.near(ctx.shake.trauma, 0.35)
		t.eq(table.concat(ctx.cues, ","), "Shake,VFX")
	end,
	["resolve walks a slash path under Workspace"] = function(t, K)
		local a = Instance.new("Folder")
		a.Name = "A"
		a.Parent = t.sandbox
		local b = Instance.new("Part")
		b.Name = "B"
		b.Parent = a
		t.eq(K.Director.resolve("_CutsceneKitTest/A/B"), b)
		t.eq(K.Director.resolve("_CutsceneKitTest/Nope/B"), nil)
		t.eq(K.Director.resolve(""), nil)
	end,
	["Config.Hide hides parts and names, and restore puts back the saved values"] = function(t, K)
		local part = Instance.new("Part")
		part.Name = "H"
		part.LocalTransparencyModifier = 0.25
		part.Parent = t.sandbox
		local model = Instance.new("Model")
		model.Name = "M"
		model.Parent = t.sandbox
		local inner = Instance.new("Part")
		inner.Name = "P"
		inner.Parent = model
		local hum = Instance.new("Humanoid")
		hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.Viewer
		hum.Parent = model
		local cam = Instance.new("Camera")
		cam.Parent = t.sandbox
		local s = K.Snapshot.capture({ camera = cam })
		K.Director.hideConfigured(s, { "_CutsceneKitTest/H", "_CutsceneKitTest/M", "_CutsceneKitTest/Missing" }, "scene")
		t.eq(part.LocalTransparencyModifier, 1, "part hidden")
		t.eq(inner.LocalTransparencyModifier, 1, "model part hidden")
		t.eq(hum.DisplayDistanceType, Enum.HumanoidDisplayDistanceType.None, "name hidden")
		part.LocalTransparencyModifier = 0 -- the camera scripts rewrite it; keepHidden re-applies
		K.Snapshot.keepHidden(s)
		t.eq(part.LocalTransparencyModifier, 1, "kept hidden")
		K.Snapshot.restore(s)
		t.near(part.LocalTransparencyModifier, 0.25)
		t.eq(inner.LocalTransparencyModifier, 0)
		t.eq(hum.DisplayDistanceType, Enum.HumanoidDisplayDistanceType.Viewer, "name back")
		K.Snapshot.restore(s) -- a second end (skip after end) changes nothing
		t.near(part.LocalTransparencyModifier, 0.25)
	end,
	["overlapping Hide paths still bring the name back"] = function(t, K)
		local model = Instance.new("Model")
		model.Name = "Gate"
		model.Parent = t.sandbox
		local guard = Instance.new("Model")
		guard.Name = "Guard"
		guard.Parent = model
		local hum = Instance.new("Humanoid")
		hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.Viewer
		hum.Parent = guard
		local cam = Instance.new("Camera")
		cam.Parent = t.sandbox
		local s = K.Snapshot.capture({ camera = cam })
		K.Director.hideConfigured(s, { "_CutsceneKitTest/Gate", "_CutsceneKitTest/Gate/Guard", "_CutsceneKitTest/Gate" }, "scene")
		t.eq(hum.DisplayDistanceType, Enum.HumanoidDisplayDistanceType.None, "name hidden")
		K.Snapshot.restore(s)
		t.eq(hum.DisplayDistanceType, Enum.HumanoidDisplayDistanceType.Viewer, "name back")
	end,
	["play with Config.Hide hides the named part and restores it when the scene ends"] = function(t, K)
		local part = Instance.new("Part")
		part.Name = "H"
		part.LocalTransparencyModifier = 0.25
		part.Parent = t.sandbox
		local hidden = {}
		local realHidePart = K.Snapshot.hidePart
		K.Snapshot.hidePart = function(s, d)
			table.insert(hidden, d)
			return realHidePart(s, d)
		end
		t.defer(function()
			K.Snapshot.hidePart = realHidePart
		end)
		local module = sceneModule(t, 'return { Kind = "story", Length = 2, Anims = { Stage = "NoSuchClip" }, Markers = { { 0, "Letterbox", "in" } }, Config = { Hide = { "_CutsceneKitTest/H" } } }')
		local handle = K.Director.play({
			module = module,
			player = fakePlayer(t),
			anchor = CFrame.new(0, -500, 0),
			startAt = os.clock() + 0.75,
			now = os.clock,
		})
		t.eq(handle.reason, "load-failed")
		handle.finish("skip") -- already over: must not change anything
		t.eq(hidden[1], part, "hidden at setup")
		t.near(part.LocalTransparencyModifier, 0.25)
	end,
}
