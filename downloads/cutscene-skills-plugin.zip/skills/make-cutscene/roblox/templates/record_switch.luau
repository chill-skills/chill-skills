-- RecordSwitch: the record-on / record-off steps. record-on installs the record overlay and sets the attribute that
-- opens its gate; record-off deletes the overlay and clears the attribute. Method by fwjelaa (FWJ STUDIOS).
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local StarterPlayer = game:GetService("StarterPlayer")

local OVERLAY = "CutsceneRecordOverlay"
local ATTRIBUTE = "CutsceneKitRecord"

local RecordSwitch = {}

-- args = {source = the overlay script text}
function RecordSwitch.on(args, need)
	local message = need("SceneInstall").devScript({ name = OVERLAY, source = args.source })
	ReplicatedStorage:SetAttribute(ATTRIBUTE, true)
	return ("%s; ReplicatedStorage.%s = true"):format(message, ATTRIBUTE)
end

function RecordSwitch.off(_, need)
	local scripts = StarterPlayer:WaitForChild("StarterPlayerScripts")
	local had = scripts:FindFirstChild(OVERLAY) ~= nil
	need("SceneInstall").devScript({ name = OVERLAY, remove = true })
	ReplicatedStorage:SetAttribute(ATTRIBUTE, nil)
	local what = had and ("removed StarterPlayerScripts." .. OVERLAY) or ("nothing to remove: no " .. OVERLAY)
	return ("%s; ReplicatedStorage.%s cleared"):format(what, ATTRIBUTE)
end

return RecordSwitch
