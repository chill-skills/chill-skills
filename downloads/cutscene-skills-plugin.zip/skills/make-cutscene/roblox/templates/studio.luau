-- One /make-cutscene Studio step for one cutscene (`py kit/run.py studio <id> <step>`). Method by fwjelaa (FWJ STUDIOS).
-- Send the rendered cutscenes/<id>/studio/<step>.luau with execute_luau (Edit mode), never this template. It builds
-- fresh ModuleScripts from the embedded authoring sources (require() caches by instance), calls one function and
-- removes them again.
local EMBED = nil -- filled in by kit/bundle.py
assert(EMBED, "run `py kit/run.py studio <id> <step>` and send the file it writes, not this template")
local ServerStorage = game:GetService("ServerStorage")

local leftover = ServerStorage:FindFirstChild("_CutsceneAuthoring") -- a cancelled earlier step leaves it behind
if leftover then
	leftover:Destroy()
end
local holder = Instance.new("Folder")
holder.Name = "_CutsceneAuthoring"
local modules = {}
for name, source in EMBED.modules do
	local m = Instance.new("ModuleScript")
	m.Name = name
	m.Source = source
	m.Parent = holder
	modules[name] = m
end
holder.Parent = ServerStorage
local function need(name)
	assert(modules[name], "this step was rendered without the module " .. tostring(name))
	return require(modules[name])
end
local ok, result = pcall(function()
	local main = need(EMBED.main)
	return main[EMBED.call](EMBED.args, need)
end)
holder:Destroy()
if not ok then
	error(result, 0)
end
return result
