-- CutsceneRecordOverlay (dev only, never part of a viewer's game). Method by fwjelaa (FWJ STUDIOS).
-- Flashes the whole game view magenta twice (two pulses) just after each cutscene ends, so kit/takes.py can find the
-- scene's end and the game view in a screen recording. `py kit/run.py studio <id> record-on` puts it in
-- StarterPlayerScripts and sets ReplicatedStorage attribute CutsceneKitRecord; record-off clears both.
-- Gate: it does nothing unless this is Studio AND that attribute is true, so a copy left in a published place stays dark.
-- No start flash: Snapshot.capture disables every enabled ScreenGui at scene start, so a flash there is hidden or comes
-- back at the restore. This ScreenGui is Enabled = false whenever a scene starts and ends, and only shows once the
-- scene has finished (LEAD after its last frame), so Snapshot neither hides nor re-enables it.
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
if not RunService:IsStudio() or ReplicatedStorage:GetAttribute("CutsceneKitRecord") ~= true then
	return
end

local Players = game:GetService("Players")
local player = Players.LocalPlayer
local LEAD, PULSE, GAP = 0.25, 0.3, 0.2 -- the same numbers as kit/takes.py

local gui = Instance.new("ScreenGui")
gui.Name = "CutsceneRecordOverlay"
gui.IgnoreGuiInset = true
gui.ScreenInsets = Enum.ScreenInsets.None
gui.DisplayOrder = 1000
gui.ResetOnSpawn = false
gui.Enabled = false
local frame = Instance.new("Frame")
frame.Size = UDim2.fromScale(1, 1)
frame.BackgroundColor3 = Color3.fromRGB(255, 0, 255)
frame.BorderSizePixel = 0
frame.Parent = gui
gui.Parent = player:WaitForChild("PlayerGui")

local pending = false

local function flashAt(serverTime)
	if pending then
		warn("CutsceneRecordOverlay: another scene's end flash is still pending, so this scene gets none (record one scene per take)")
		return
	end
	pending = true
	task.delay(math.max(0, serverTime - workspace:GetServerTimeNow()), function()
		for pulse = 1, 2 do
			gui.Enabled = true
			task.wait(PULSE)
			gui.Enabled = false
			if pulse == 1 then
				task.wait(GAP)
			end
		end
		pending = false
	end)
end

player:GetAttributeChangedSignal("CutsceneStartAt"):Connect(function()
	local startAt, duration = player:GetAttribute("CutsceneStartAt"), player:GetAttribute("CutsceneDuration")
	if type(startAt) == "number" and type(duration) == "number" then
		flashAt(startAt + duration + LEAD) -- takes.py: end = (first pulse start) - LEAD, start = end - Length
	end
end)
