-- Costume: dresses a cast member as an adapted character (spec 14) in Edit, from cast/<role>.json (kit/costume.py).
-- Method by fwjelaa (FWJ STUDIOS).
-- A character is a HumanoidDescription (colours, R15 scales, catalog items by id, spec 14.3) built as R15 and R6, plus
-- held props in a hand; a creature is shaped parts on Motor6Ds. SceneInstall puts the models in the module's Costumes
-- folder (<role>_R15, <role>_R6) for Director.costume.
local HttpService = game:GetService("HttpService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")

local Costume = {}
-- slot -> the HumanoidDescription property it fills
Costume.SLOTS = { hair = "HairAccessory", hat = "HatAccessory", face_acc = "FaceAccessory", neck = "NeckAccessory",
	shoulders = "ShouldersAccessory", front = "FrontAccessory", back = "BackAccessory", waist = "WaistAccessory",
	shirt = "Shirt", pants = "Pants", tshirt = "GraphicTShirt", face = "Face" }
-- layered slot -> {AccessoryType when the item names no type, Order (inner to outer)}; R15 only
Costume.LAYERED = { left_shoe = { "LeftShoe", 1 }, right_shoe = { "RightShoe", 1 }, layered_pants = { "Pants", 2 },
	layered_skirt = { "DressSkirt", 3 }, layered_shirt = { "Shirt", 4 }, layered_jacket = { "Jacket", 5 } }
Costume.BODY = { head = "HeadColor", torso = "TorsoColor", left_arm = "LeftArmColor", right_arm = "RightArmColor",
	left_leg = "LeftLegColor", right_leg = "RightLegColor" }
Costume.SCALES = { height = "HeightScale", width = "WidthScale", depth = "DepthScale", head = "HeadScale" }
Costume.ROOT = "HumanoidRootPart"
Costume.LINEUP = "_CostumeLineup"
Costume.DEV_TAG = "CutsceneKitDev" -- the lineup is a dev artefact: SceneInstall.remove takes away what carries it
Costume.TRIES = 3 -- catalog calls per id before an unanswered one refuses the costume
Costume.BACKOFF = 0.5 -- seconds before the first retry; it doubles each time
Costume.GRIPS = { RightGripAttachment = true, LeftGripAttachment = true } -- a held prop's only places
-- held like a Tool on both rigs (kit/costume.py HOLD): R15 grips are turned so, R6 grips are not (spike S16)
Costume.HOLD = CFrame.Angles(math.rad(-90), 0, 0)

-- test seams: the catalog (a stub answers in tests) and the wait between tries
Costume.marketplace = MarketplaceService
Costume.sleep = function(seconds)
	task.wait(seconds)
end

local assetTypes
local function assetTypeName(id)
	if not assetTypes then
		assetTypes = {}
		for _, e in Enum.AssetType:GetEnumItems() do
			assetTypes[e.Value] = e.Name
		end
	end
	return assetTypes[id] or tostring(id)
end

-- {x, y, z(, rx, ry, rz)} (studs, degrees) -> CFrame.new(x, y, z) * CFrame.Angles(rx, ry, rz), like kit/costume.py
function Costume.offset(o)
	o = o or {}
	return CFrame.new(o[1] or 0, o[2] or 0, o[3] or 0)
		* CFrame.Angles(math.rad(o[4] or 0), math.rad(o[5] or 0), math.rad(o[6] or 0))
end

-- One shaped part (not parented): block, sphere and cylinder (SpecialMesh, so any size works) or a WedgePart
function Costume.part(name, p)
	local inst = Instance.new(p.shape == "wedge" and "WedgePart" or "Part")
	inst.Name = name
	inst.Size = Vector3.new(p.size[1], p.size[2], p.size[3])
	inst.Color = Color3.fromHex(p.color)
	inst.Material = Enum.Material[p.material or "SmoothPlastic"]
	inst.Transparency = p.transparency or 0
	inst.CanCollide, inst.CanQuery, inst.CanTouch, inst.Massless = false, false, false, true
	inst.TopSurface, inst.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	if p.shape == "sphere" or p.shape == "cylinder" then
		local mesh = Instance.new("SpecialMesh")
		mesh.MeshType = p.shape == "sphere" and Enum.MeshType.Sphere or Enum.MeshType.Cylinder -- a cylinder runs along X
		mesh.Parent = inst
	end
	if p.light then
		local light = Instance.new("PointLight")
		light.Color = Color3.fromHex(p.light.color)
		light.Range = p.light.range or 8
		light.Brightness = p.light.brightness or 1
		light.Parent = inst
	end
	return inst
end

-- The catalog items a rig wears: the item's own rigs (kit/costume.py install_specs), else R15 only for layered slots
function Costume.items(spec, rig)
	local out = {}
	for _, item in ipairs(spec.catalog or {}) do
		local rigs = item.rigs or (Costume.LAYERED[item.slot] and { "R15" } or { "R15", "R6" })
		if rig == nil or table.find(rigs, rig) then
			table.insert(out, item)
		end
	end
	return out
end

local function isAccessory(slot)
	return Costume.LAYERED[slot] ~= nil or string.find(Costume.SLOTS[slot] or "", "Accessory", 1, true) ~= nil
end

-- The look for one rig: "id,id" slot strings, then layered pieces by SetAccessories(list, false) (true wipes the
-- strings: spike S16c)
function Costume.description(spec, withCatalog, rig)
	local d = Instance.new("HumanoidDescription")
	for region, prop in Costume.BODY do
		if spec.body and spec.body[region] then
			d[prop] = Color3.fromHex(spec.body[region])
		end
	end
	for key, prop in Costume.SCALES do
		if spec.scale and spec.scale[key] then
			d[prop] = spec.scale[key]
		end
	end
	if not withCatalog then
		return d
	end
	local lists, layered = {}, {}
	for _, item in Costume.items(spec, rig) do
		local prop, wrap = Costume.SLOTS[item.slot], Costume.LAYERED[item.slot]
		if wrap then
			local kind = item.type and (string.gsub(item.type, "Accessory$", "")) or wrap[1]
			table.insert(layered, { AssetId = item.id, AccessoryType = Enum.AccessoryType[kind], IsLayered = true,
				Order = wrap[2] })
		elseif string.find(prop, "Accessory", 1, true) then
			lists[prop] = lists[prop] or {}
			table.insert(lists[prop], tostring(item.id))
		else
			d[prop] = item.id
		end
	end
	for prop, ids in lists do
		d[prop] = table.concat(ids, ",")
	end
	if #layered > 0 then
		d:SetAccessories(layered, false)
	end
	return d
end

-- Answers (measured): "HTTP 404" (missing), "not a valid assetId". Anything else may pass, so it is asked again.
local function definite(err)
	local e = tostring(err)
	return string.find(e, "HTTP 404", 1, true) ~= nil or string.find(e, "HTTP 400", 1, true) ~= nil
		or string.find(e, "not a valid assetId", 1, true) ~= nil
end

-- One id's answer: {type = asset type name} or {why = ...}; raises when no try got an answer
local function lookup(id)
	local last
	for try = 1, Costume.TRIES do
		local ok, info = pcall(function()
			return Costume.marketplace:GetProductInfo(id, Enum.InfoType.Asset)
		end)
		if ok then
			return type(info) == "table" and info.AssetTypeId and { type = assetTypeName(info.AssetTypeId) }
				or { why = "the catalog gave it no asset type" }
		elseif definite(info) then
			return { why = ("the catalog has no such asset (%s)"):format(tostring(info)) }
		end
		last = info
		if try < Costume.TRIES then
			Costume.sleep(Costume.BACKOFF * 2 ^ (try - 1))
		end
	end
	error(last, 0)
end

-- A bad id never throws (spike S16, BAD_ID = skipped), so each id is asked first, once per run (`cache`). A wrong or
-- missing one is left off and noted; one never answered refuses the costume (never half-dressed). -> (spec copy, notes)
function Costume.verify(spec, cache)
	cache = cache or {}
	local keep, notes = {}, {}
	for _, item in ipairs(spec.catalog or {}) do
		local label = ("%s: %s %s (%s)"):format(spec.character, tostring(item.slot), tostring(item.id), tostring(item.name))
		if not item.type then -- kit/costume.py refuses this; say so rather than blame the catalog
			table.insert(notes, label .. " left off: its spec names no catalog type")
			continue
		end
		local answer = cache[item.id]
		if not answer then
			local ok, got = pcall(lookup, item.id)
			if not ok then
				error(("%s could not be checked with the catalog in %d tries (%s): nothing was built, retry the install")
					:format(label, Costume.TRIES, tostring(got)), 0)
			end
			answer = got
			cache[item.id] = answer
		end
		if answer.type == item.type then
			table.insert(keep, item)
		else
			table.insert(notes, ("%s left off: %s"):format(label, answer.type
				and ("the catalog says it is a %s, not a %s"):format(answer.type, item.type) or answer.why))
		end
	end
	local out = table.clone(spec)
	out.catalog = keep
	return out, notes
end

-- The body's own attachment of that name (on a body part, not inside an accessory)
local function attachment(model, name)
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("Attachment") and d.Name == name and d.Parent and d.Parent.Parent == model then
			return d
		end
	end
	return nil
end

-- A prop of parts on a body attachment, `turn` from it; returns a problem or nil. Spike S17: a Handle with no Attachment
-- is re-welded to the Head, so it gets one named like the body's, and Roblox's AccessoryWeld (C0 its, C1 the body's).
function Costume.attach(model, item, turn)
	local att = attachment(model, item.at)
	if not att then
		return ("%s: this rig has no %s"):format(item.name, item.at)
	end
	turn = turn or CFrame.identity
	local acc = Instance.new("Accessory")
	acc.Name = item.name
	local handle
	for i, p in ipairs(item.parts) do
		local inst = Costume.part(i == 1 and "Handle" or (item.name .. i), p)
		inst.CFrame = att.WorldCFrame * turn * Costume.offset(p.offset)
		inst.Parent = acc
		if i == 1 then
			handle = inst
		else -- a Weld: R15 re-lays its body on entering the place (the hand moves) and a WeldConstraint lags behind
			local w = Instance.new("Weld")
			w.Part0, w.Part1, w.C0 = handle, inst, handle.CFrame:ToObjectSpace(inst.CFrame)
			w.Parent = inst
		end
	end
	local own = Instance.new("Attachment")
	own.Name = item.at
	own.CFrame = (turn * Costume.offset(item.parts[1].offset)):Inverse()
	own.Parent = handle
	local weld = Instance.new("Weld")
	weld.Name = "AccessoryWeld"
	weld.Part0, weld.Part1 = handle, att.Parent
	weld.C0, weld.C1 = own.CFrame, att.CFrame
	weld.Parent = handle
	acc.Parent = model
	return nil
end

-- A held prop in its hand, turned to HOLD from the body's grip; returns a problem or nil
function Costume.hold(model, prop)
	if not Costume.GRIPS[prop.at] then
		return ("a prop is held at RightGripAttachment or LeftGripAttachment, not %s"):format(tostring(prop.at))
	end
	local att = attachment(model, prop.at)
	return Costume.attach(model, prop, att and att.CFrame.Rotation:Inverse() * Costume.HOLD)
end

local function countAccessories(model)
	local n = 0
	for _, c in ipairs(model:GetChildren()) do
		if c:IsA("Accessory") then
			n += 1
		end
	end
	return n
end

-- a face accessory the description really attached (typed Face, or a handle on a face attachment point)
local function faceArrived(model)
	for _, c in ipairs(model:GetChildren()) do
		local h = c:IsA("Accessory") and c:FindFirstChild("Handle")
		if h and (c.AccessoryType == Enum.AccessoryType.Face or h:FindFirstChild("FaceFrontAttachment")
			or h:FindFirstChild("FaceCenterAttachment")) then
			return true
		end
	end
	return false
end

-- A humanoid costume on one rig -> (model, notes); build checks the catalog. A missing item or prop is noted, never fatal.
function Costume.humanoid(spec, rig)
	local notes = {}
	local wanted, clothes, slots = 0, {}, {}
	for _, item in Costume.items(spec, rig) do
		slots[item.slot] = true
		if isAccessory(item.slot) then
			wanted += 1
		elseif item.slot == "shirt" or item.slot == "pants" then
			table.insert(clothes, item.slot == "shirt" and "Shirt" or "Pants")
		end
	end
	local ok, model = pcall(Players.CreateHumanoidModelFromDescription, Players, Costume.description(spec, true, rig),
		Enum.HumanoidRigType[rig])
	if not ok then
		table.insert(notes, ("%s %s: the catalog items didn't load (%s), built without them"):format(spec.character, rig,
			tostring(model)))
		model = Players:CreateHumanoidModelFromDescription(Costume.description(spec, false, rig), Enum.HumanoidRigType[rig])
	else
		if countAccessories(model) < wanted then
			table.insert(notes, ("%s %s: %d of %d catalog accessories arrived"):format(spec.character, rig,
				countAccessories(model), wanted))
		end
		for _, class in clothes do
			if not model:FindFirstChildOfClass(class) then
				table.insert(notes, ("%s %s: its %s didn't arrive"):format(spec.character, rig, class))
			end
		end
		-- a face accessory that arrived and no classic face: the default smile showed through see-through ones on R6, so
		-- it goes: Transparency 1, which a description re-apply keeps (measured) and which can be undone (kit/costume.py)
		local head = slots.face_acc and not slots.face and faceArrived(model) and model:FindFirstChild("Head")
		for _, d in head and head:GetChildren() or {} do
			if d:IsA("Decal") then
				d.Transparency = 1
			end
		end
		-- an R15 dynamic head paints its own eyes in its TextureID (no Decal): DanielUI's showed through the face
		-- accessory as two dark marks on the forehead in close-ups (RS-1). The plain mesh in the body colour stays; the
		-- old texture is kept as an attribute so it can be put back.
		if head and head:IsA("MeshPart") and head:FindFirstChildOfClass("FaceControls") and head.TextureID ~= "" then
			head:SetAttribute("CostumeHeadTexture", head.TextureID)
			head.TextureID = ""
		end
	end
	for _, d in ipairs(model:GetDescendants()) do -- a costume waits in ReplicatedStorage: no scripts ride along
		if d:IsA("BaseScript") then
			d:Destroy()
		end
	end
	for _, prop in spec.props or {} do -- on the dressed body
		local ok, why = pcall(Costume.hold, model, prop)
		if not ok or why then
			table.insert(notes, ("%s %s: prop %s left off: %s"):format(spec.character, rig, tostring(prop.name), tostring(why)))
		end
	end
	return model, notes
end

-- A creature: parts joined child = parent * C0 * C1:Inverse(), root `stand` above y = 0; an R15 Humanoid with no neck
-- rule (spike S18: NECK_KILLS = no, kept anyway) that never dies on its own
function Costume.creature(spec)
	local model = Instance.new("Model")
	local root = Costume.part(Costume.ROOT, { size = spec.root, color = "#808080" })
	root.Transparency = 1
	root.Anchored = true
	root.CFrame = CFrame.new(0, spec.stand, 0)
	root.Parent = model
	local parts = { [Costume.ROOT] = root }
	for _, j in ipairs(spec.joints) do
		local p = Costume.part(j[3], spec.parts[j[3]])
		local c0, c1 = Costume.offset(j[4]), Costume.offset(j[5])
		p.CFrame = parts[j[2]].CFrame * c0 * c1:Inverse()
		p.Parent = model
		local m = Instance.new("Motor6D")
		m.Name = j[1]
		m.Part0, m.Part1, m.C0, m.C1 = parts[j[2]], p, c0, c1
		m.Parent = p
		parts[j[3]] = p
	end
	local hum = Instance.new("Humanoid")
	hum.RigType = Enum.HumanoidRigType.R15
	hum.HipHeight = spec.stand - spec.root[2] / 2
	hum.RequiresNeck = false
	hum.BreakJointsOnDeath = false
	hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
	hum.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
	Instance.new("Animator").Parent = hum
	hum.Parent = model
	model.PrimaryPart = root
	return model, {}
end

-- {R15 = model, R6 = model} (a creature: R15 only), named <role>_<rig>, attributes Costume and CostumeRig; the catalog
-- is checked once for both rigs (verify)
function Costume.build(role, spec, cache)
	local out, notes = {}, {}
	if spec.kind ~= "creature" then
		spec, notes = Costume.verify(spec, cache)
	end
	for _, rig in ipairs(spec.kind == "creature" and { "R15" } or { "R15", "R6" }) do
		local model, n
		if spec.kind == "creature" then
			model, n = Costume.creature(spec)
		else
			model, n = Costume.humanoid(spec, rig)
		end
		model.Name = role .. "_" .. rig
		model:SetAttribute("Costume", spec.character)
		model:SetAttribute("CostumeRig", rig)
		out[rig] = model
		table.move(n, 1, #n, #notes + 1, notes)
	end
	return out, notes
end

local function sorted(t)
	local keys = {}
	for k in t do
		table.insert(keys, k)
	end
	table.sort(keys)
	return keys
end

-- {role = spec} -> (Costumes folder, model count, notes) for SceneInstall; all or nothing (a failure raises)
function Costume.buildAll(costumes)
	local folder = Instance.new("Folder")
	folder.Name = "Costumes"
	local n, notes, cache = 0, {}, {}
	local ok, err = pcall(function()
		for _, role in sorted(costumes) do
			local models, more = Costume.build(role, costumes[role], cache)
			for _, m in models do
				m.Parent = folder
				n += 1
			end
			table.move(more, 1, #more, #notes + 1, notes)
		end
	end)
	if not ok then
		folder:Destroy()
		error(err, 0)
	end
	return folder, n, notes
end

-- `studio <id> rig --role <role>`: the costume's R15 body (scales; no catalog items: they don't change it)
function Costume.captureRig(args, need)
	local model = Players:CreateHumanoidModelFromDescription(Costume.description(args.spec, false, "R15"),
		Enum.HumanoidRigType.R15)
	local ok, out = pcall(need("Capture").rigOf, model)
	model:Destroy()
	if not ok then
		error(out, 0)
	end
	out.role = args.role
	out.source = "costume"
	return HttpService:JSONEncode(out)
end

-- `studio <id> costume-look`: every costume, R15 then R6, on a floor at args.at (x, y, z, yaw) in _CostumeLineup;
-- returns the camera. Spaced by body parts: a fresh model's accessory handles sit far off until it is in the place.
local function bodyWidth(m)
	local lo, hi = math.huge, -math.huge
	for _, p in m:GetChildren() do
		if p:IsA("BasePart") then
			lo, hi = math.min(lo, p.Position.X - p.Size.X / 2), math.max(hi, p.Position.X + p.Size.X / 2)
		end
	end
	return hi - lo
end

function Costume.lineup(args)
	Costume.lineupOff()
	local folder = Instance.new("Folder")
	folder.Name = Costume.LINEUP
	folder:SetAttribute(Costume.DEV_TAG, true) -- dev only: `studio <id> remove` takes it away too
	local at = args.at
	local base = CFrame.new(at[1], at[2], at[3]) * CFrame.Angles(0, math.rad(at[4] or 0), 0)
	local x, notes, cache = 0, {}, {}
	for _, role in sorted(args.costumes) do
		local models, more = Costume.build(role, args.costumes[role], cache)
		table.move(more, 1, #more, #notes + 1, notes)
		for _, rig in { "R15", "R6" } do
			local m = models[rig]
			if m then
				local hum = m:FindFirstChildOfClass("Humanoid")
				local root = m:FindFirstChild(Costume.ROOT)
				local stand = hum.RigType == Enum.HumanoidRigType.R15 and (hum.HipHeight + root.Size.Y / 2) or 3
				local width = bodyWidth(m)
				x += width / 2 + 1.5
				root.Anchored = true
				m.PrimaryPart = root
				m:PivotTo(base * CFrame.new(x, stand, 0))
				x += width / 2 + 1.5
				m.Parent = folder
			end
		end
	end
	local floor = Instance.new("Part")
	floor.Name = "Floor"
	floor.Anchored = true
	floor.Size = Vector3.new(x + 8, 1, 16)
	floor.CFrame = base * CFrame.new(x / 2, -0.5, 0)
	floor.Color = Color3.fromRGB(90, 92, 98)
	floor.Parent = folder
	folder.Parent = workspace
	local look = base * Vector3.new(x / 2, 3, 0)
	local eye = base * Vector3.new(x / 2, 4.5, -math.max(12, x * 0.9))
	return HttpService:JSONEncode({ lineup = #folder:GetChildren() - 1, notes = notes,
		camera_position = { eye.X, eye.Y, eye.Z }, look_at_position = { look.X, look.Y, look.Z } })
end

-- Only the kit's own (tagged) lineup: a folder of that name the kit didn't make is left alone
function Costume.lineupOff()
	for _, old in workspace:GetChildren() do
		if old.Name == Costume.LINEUP and old:GetAttribute(Costume.DEV_TAG) then
			old:Destroy()
			return "costume lineup removed"
		end
	end
	return "no costume lineup"
end

return Costume
