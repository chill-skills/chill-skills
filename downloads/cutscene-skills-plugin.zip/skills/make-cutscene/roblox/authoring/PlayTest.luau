-- PlayTest (dev only): short probes for the Studio play test of a cutscene. Method by fwjelaa (FWJ STUDIOS).
-- One small execute_luau call each (spec 8 gate 2). `py kit/run.py studio <id> playtest-on` puts it in
-- ReplicatedStorage before Play; playtest-off (and `studio <id> remove`) take it away again. Every function refuses to run
-- outside Studio, so a copy that ships by mistake does nothing. Read results in a LATER call than the one that started a
-- scene: an execute_luau call that spans a scene can see the camera type reset by the MCP wrapper (Plan 1, e2e-1.md finding 2).
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local StarterPlayer = game:GetService("StarterPlayer")
local UserInputService = game:GetService("UserInputService")

local PlayTest = {}
PlayTest.PROBE = "CutsceneKitProbe"
PlayTest.REENTER_WAIT = 1.5 -- seconds spent outside the zone before walking back in
PlayTest.START_TIMEOUT = 3 -- seconds to wait for the scene's lock before start reports a failure
PlayTest.POLL = 0.1

-- test seams: the tests replace these, a play test never needs to
PlayTest.isStudio = function()
	return RunService:IsStudio()
end
PlayTest.player = function()
	return Players:GetPlayers()[1]
end
PlayTest.sleep = function(seconds)
	return task.wait(seconds)
end
-- Studio-only: the signed-in Studio user, whose avatar Play spawns (StudioService does not exist in a live game)
PlayTest.studioUserId = function()
	local ok, id = pcall(function()
		return game:GetService("StudioService"):GetUserId()
	end)
	return ok and type(id) == "number" and id > 0 and id or nil
end
-- a web call (it yields); setRig catches its errors
PlayTest.descriptionFromUserId = function(userId)
	return Players:GetHumanoidDescriptionFromUserId(userId)
end

local function guard()
	if not PlayTest.isStudio() then
		error("PlayTest is dev-only: it runs in Studio and does nothing in a published game (remove it: py kit/run.py studio <id> playtest-off)", 0)
	end
end

local function hasPrefix(name, prefix)
	return string.sub(name, 1, #prefix) == prefix
end

local function first()
	return Players.LocalPlayer or PlayTest.player()
end

local function serverPlayer()
	local p = PlayTest.player()
	assert(p, "no player yet (start Play first)")
	return p
end

local function promptOf(name)
	for _, d in ipairs(workspace:GetDescendants()) do
		if d:IsA("ProximityPrompt") and d:GetAttribute("Cutscene") == name then
			return d
		end
	end
	return nil
end

local function hiddenOf(path)
	if not path then
		return ""
	end
	local inst = require(ReplicatedStorage.CutsceneKit.Director).resolve(path)
	local part = inst and (inst:IsA("BasePart") and inst or inst:FindFirstChildWhichIsA("BasePart", true))
	return (" hiddenLTM=%s"):format(part and tostring(part.LocalTransparencyModifier) or "?")
end

-- Is a world position inside the zone part's box?
function PlayTest.inside(zone, position)
	local o = zone.CFrame:PointToObjectSpace(position)
	local h = zone.Size / 2
	return math.abs(o.X) <= h.X and math.abs(o.Y) <= h.Y and math.abs(o.Z) <= h.Z
end

-- Server: start the scene the way its trigger does: walk into the zone, or Api Play for prompt and api triggers. A zone only
-- fires on entry, so a character already inside is walked out, left outside for REENTER_WAIT and walked back in. The result
-- starts with "FAILED" when the scene did not start (no lock on the player within START_TIMEOUT).
function PlayTest.start(name)
	guard()
	local p = PlayTest.player()
	local char = p and p.Character
	local hrp = char and char:FindFirstChild("HumanoidRootPart")
	assert(hrp, "no player character yet (start Play first)")
	local zones = workspace:FindFirstChild("CutsceneZones")
	local zone = zones and zones:FindFirstChild(name)
	assert(zone, "no trigger for " .. name .. " (install the scene first)")
	if (zone:GetAttribute("Trigger") or "zone") ~= "zone" then
		local ok, why = ReplicatedStorage.CutsceneKit.Api:Invoke("Play", p, name)
		return ("Api Play: %s %s"):format(tostring(ok), tostring(why))
	end
	local steppedOut = false
	if PlayTest.inside(zone, hrp.Position) then
		char:PivotTo(CFrame.new(zone.Position + Vector3.new(zone.Size.X / 2 + zone.Size.Z / 2 + 10, 0, 0)))
		PlayTest.sleep(PlayTest.REENTER_WAIT)
		steppedOut = true
	end
	char:PivotTo(zone.CFrame)
	local waited = 0
	while p:GetAttribute("CutsceneLock") == nil do
		if waited >= PlayTest.START_TIMEOUT then
			return ("FAILED: %s did not start within %s s (the player never got CutsceneLock): is the kit installed and Play running?")
				:format(name, tostring(PlayTest.START_TIMEOUT))
		end
		PlayTest.sleep(PlayTest.POLL)
		waited += PlayTest.POLL
	end
	return steppedOut and "walked out of the zone and back in" or "walked into the zone"
end

-- Server: stand next to the scene's prompt, in reach
function PlayTest.approach(name)
	guard()
	-- the scene's prompt first: without it no Play can help, so that is the thing to report
	local prompt = promptOf(name)
	assert(prompt, "no prompt for " .. name)
	local p = serverPlayer()
	assert(p.Character, "no player character yet (start Play first)")
	local at = prompt.Parent:IsA("Attachment") and prompt.Parent.WorldPosition or prompt.Parent:GetPivot().Position
	p.Character:PivotTo(CFrame.new(at + Vector3.new(0, 1, math.max(2, prompt.MaxActivationDistance - 3))))
	return "standing next to the prompt"
end

-- Client: press the scene's prompt like a player would
function PlayTest.press(name)
	guard()
	local prompt = promptOf(name)
	if not prompt then
		return "no prompt for " .. name
	end
	prompt:InputHoldBegin()
	task.wait(math.max(0.05, prompt.HoldDuration + 0.05))
	prompt:InputHoldEnd()
	return "pressed"
end

-- Client: remember what the camera does once the running scene reaches time t (read it later with PlayTest.read)
function PlayTest.arm(t, hidePath)
	guard()
	local player = first()
	local cam = workspace.CurrentCamera
	player:SetAttribute(PlayTest.PROBE, "armed for T >= " .. t)
	pcall(RunService.UnbindFromRenderStep, RunService, PlayTest.PROBE)
	RunService:BindToRenderStep(PlayTest.PROBE, Enum.RenderPriority.Camera.Value + 2, function()
		local f = workspace:FindFirstChild("CutsceneLocal")
		local now = f and f:GetAttribute("T")
		if type(now) == "number" and now >= t then
			RunService:UnbindFromRenderStep(PlayTest.PROBE) -- first, so a failure below cannot repeat every frame
			local anchor = player:GetAttribute("CutsceneAnchor")
			local rel = typeof(anchor) == "CFrame" and anchor:PointToObjectSpace(cam.CFrame.Position) or cam.CFrame.Position
			local okHidden, hidden = pcall(hiddenOf, hidePath)
			player:SetAttribute(PlayTest.PROBE, ("T=%.3f type=%s rel=(%.2f, %.2f, %.2f) fov=%.1f cues=%s%s"):format(now,
				cam.CameraType.Name, rel.X, rel.Y, rel.Z, cam.FieldOfView, tostring(f:GetAttribute("Cues")),
				okHidden and hidden or " hiddenLTM=error"))
		end
	end)
	return "armed"
end

-- Client: the probe's line and how things stand now (after an end, skip or death: everything restored?)
function PlayTest.read(hidePath)
	guard()
	local player = first()
	local char = player.Character
	local hrp = char and char:FindFirstChild("HumanoidRootPart")
	local head = char and char:FindFirstChild("Head")
	return ("probe: %s | last=%s camera=%s local=%s hrpAnchored=%s headLTM=%s mouse=%s%s"):format(
		tostring(player:GetAttribute(PlayTest.PROBE)), tostring(player:GetAttribute("CutsceneLastResult")),
		workspace.CurrentCamera.CameraType.Name, tostring(workspace:FindFirstChild("CutsceneLocal") ~= nil),
		tostring(hrp and hrp.Anchored), tostring(head and head.LocalTransparencyModifier),
		UserInputService.MouseBehavior.Name, hiddenOf(hidePath))
end

-- Client: press Skip (it works once the scene's Config.Skip seconds have passed)
function PlayTest.skip()
	guard()
	local f = workspace:FindFirstChild("CutsceneLocal")
	if not f or not f:FindFirstChild("Skip") then
		return "no scene running"
	end
	f.Skip:Fire()
	return "skip fired"
end

-- Server: kill the character mid-scene (the restore after death)
function PlayTest.kill()
	guard()
	local p = PlayTest.player()
	local hum = p and p.Character and p.Character:FindFirstChildOfClass("Humanoid")
	if not hum then
		return "no character"
	end
	hum.Health = 0
	return "killed"
end

-- Server: the scene lock and protection
function PlayTest.lock()
	guard()
	local p = serverPlayer()
	local shield = p.Character and p.Character:FindFirstChild("CutsceneShield")
	return ("lock=%s name=%s shield=%s"):format(tostring(p:GetAttribute("CutsceneLock")),
		tostring(p:GetAttribute("CutsceneName")), tostring(shield ~= nil))
end

-- The look the R6 stand-in wears, so an R6 take shows the player's own avatar: in Play the live character's applied
-- description, else the player's avatar by user id; in Edit (Studio-only) the signed-in Studio user's avatar. When none
-- can be read (signed out, offline, a web error) a blank description is the fallback, and the second result says so.
function PlayTest.avatarLook()
	local p = PlayTest.player()
	local char = p and p.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	if hum then
		local ok, desc = pcall(function()
			return hum:GetAppliedDescription()
		end)
		if ok and desc then
			return desc, "the live character's own look"
		end
	end
	local userId = p and p.UserId or PlayTest.studioUserId()
	if type(userId) == "number" and userId > 0 then
		local ok, desc = pcall(PlayTest.descriptionFromUserId, userId)
		if ok and desc then
			return desc, ("user %d's avatar"):format(userId)
		end
	end
	return Instance.new("HumanoidDescription"), "a blank description (no avatar could be read)"
end

-- Edit: play as R6 or R15 (a StarterCharacter of that rig in the player's own look, tagged with the attribute
-- CutsceneKitPlayTest) or with the avatar again ("avatar"); a place's own StarterCharacter is never touched.
-- playtest-off and remove take a tagged one away as well.
function PlayTest.setRig(rig)
	guard()
	local old = StarterPlayer:FindFirstChild("StarterCharacter")
	if old and not old:GetAttribute("CutsceneKitPlayTest") then
		return "StarterPlayer already has its own StarterCharacter: left alone"
	end
	if old then
		old:Destroy()
	end
	if rig == "R6" or rig == "R15" then -- spec 14: each scene is shown with an R15 cast and an R6 cast
		local desc, source = PlayTest.avatarLook()
		local m = Players:CreateHumanoidModelFromDescription(desc, Enum.HumanoidRigType[rig])
		m.Name = "StarterCharacter"
		m:SetAttribute("CutsceneKitPlayTest", true)
		m.Parent = StarterPlayer
		return ("players spawn as %s at the next Play, wearing %s"):format(rig, source)
	end
	return "players spawn with their own avatar at the next Play"
end

-- Client: who acts in the running scene (spec 14): each cast model as name=costume/rig ("own" = not in costume; the
-- player's copy is CutscenePlayer), and how many accessories the player's own character wears (the same before,
-- during and after a costumed scene: the costume is only ever on a local copy)
function PlayTest.cast()
	guard()
	local player = first()
	local f = workspace:FindFirstChild("CutsceneLocal")
	local cast = {}
	for _, m in ipairs(f and f:GetChildren() or {}) do
		local hum = m:IsA("Model") and m:FindFirstChildOfClass("Humanoid")
		if hum then
			table.insert(cast, ("%s=%s/%s"):format(m.Name, tostring(m:GetAttribute("Costume") or "own"), hum.RigType.Name))
		end
	end
	table.sort(cast)
	local accessories = 0
	local char = player and player.Character -- nil in Edit mode, or before the character spawns
	for _, c in ipairs(char and char:GetChildren() or {}) do
		if c:IsA("Accessory") then
			accessories += 1
		end
	end
	return ("cast: %s | character accessories=%d"):format(#cast > 0 and table.concat(cast, " ") or "no scene running",
		accessories)
end

-- Server: awaken the player on the scene's spot (its api trigger's anchor), the way a key bind would
function PlayTest.awaken(name)
	guard()
	local p = serverPlayer()
	assert(p.Character and p.Character:FindFirstChild("HumanoidRootPart"), "no player character yet (start Play first)")
	local zones = workspace:FindFirstChild("CutsceneZones")
	local zone = zones and zones:FindFirstChild(name)
	if zone then
		local anchor = require(ReplicatedStorage.CutsceneKit.Zones).anchor(zone)
		p.Character:PivotTo(anchor * CFrame.new(0, 3.2, 0))
		PlayTest.sleep(0.3) -- let it settle on the floor
	end
	local ok, why, wait = ReplicatedStorage.CutsceneKit.Api:Invoke("Awaken", p, name)
	return ("Api Awaken: %s %s %s"):format(tostring(ok), tostring(why), tostring(wait))
end

-- Server: a plain R15 dummy awakens `offset` studs in front of the player (spec 8 gate 2's NPC stand-in: this client
-- is its onlooker, so its camera must stay the player's)
function PlayTest.awakenNpc(name, offset)
	guard()
	local p = serverPlayer()
	assert(p.Character and p.Character:FindFirstChild("HumanoidRootPart"), "no player character yet (start Play first)")
	local root = p.Character.HumanoidRootPart
	local old = workspace:FindFirstChild("PlayTestCaster")
	if old then
		old:Destroy()
	end
	local npc = Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType.R15)
	npc.Name = "PlayTestCaster"
	npc:PivotTo(root.CFrame * CFrame.new(0, 0, -(offset or 24)) * CFrame.Angles(0, math.pi, 0))
	npc.Parent = workspace
	PlayTest.sleep(0.3)
	local ok, why = ReplicatedStorage.CutsceneKit.Api:Invoke("Awaken", npc, name)
	return ("NPC Awaken: %s %s"):format(tostring(ok), tostring(why))
end

-- Client: what this client sees of someone else's awakening
function PlayTest.onlook()
	guard()
	local f = workspace:FindFirstChild("CutsceneOnlook")
	return ("camera=%s onlook=%s T=%s cues=%s effects=%d"):format(workspace.CurrentCamera.CameraType.Name,
		tostring(f ~= nil), tostring(f and f:GetAttribute("T")), tostring(f and f:GetAttribute("Cues")),
		f and #f:GetChildren() or 0)
end

-- Client or Server: the awakened state of the player (or of the NPC caster: who = "npc") and its aura on this client
function PlayTest.aura(who)
	guard()
	local subject = who == "npc" and workspace:FindFirstChild("PlayTestCaster") or first()
	if not subject then
		return "no subject"
	end
	local char = subject:IsA("Player") and subject.Character or subject
	local emitters, rate, outline = 0, 0, "none"
	for _, d in ipairs(char and char:GetDescendants() or {}) do
		if d:IsA("ParticleEmitter") and hasPrefix(d.Name, "CutsceneAura") then
			emitters += 1
			rate += d.Rate
		elseif d:IsA("Highlight") and hasPrefix(d.Name, "CutsceneAura") then
			outline = ("%.2f"):format(d.OutlineTransparency)
		end
	end
	local now = workspace:GetServerTimeNow()
	local function left(attr)
		local v = subject:GetAttribute(attr)
		return type(v) == "number" and ("%+.2f s"):format(v - now) or tostring(v)
	end
	return ("Awakened=%s At=%s EndsAt=%s End=%s emitters=%d rate=%.1f outline=%s"):format(
		tostring(subject:GetAttribute("Awakened")), left("AwakenedAt"), left("AwakenedEndsAt"),
		tostring(subject:GetAttribute("AwakenedEnd")), emitters, rate, outline)
end

-- Server: the power-down now (who = "npc" for the NPC caster)
function PlayTest.endAwaken(who)
	guard()
	local subject = who == "npc" and workspace:FindFirstChild("PlayTestCaster") or serverPlayer()
	local ok, why = ReplicatedStorage.CutsceneKit.Api:Invoke("EndAwakening", subject)
	return ("EndAwakening: %s %s"):format(tostring(ok), tostring(why))
end

-- Client: the running scene's screen log and VFX, what is left under the camera, and the game's Lighting
function PlayTest.fx()
	guard()
	local cam = workspace.CurrentCamera
	local left = {}
	for _, d in ipairs(cam:GetChildren()) do
		if hasPrefix(d.Name, "Cutscene") then
			table.insert(left, d.Name)
		end
	end
	local L = game:GetService("Lighting")
	local f = workspace:FindFirstChild("CutsceneLocal")
	local v = workspace:FindFirstChild("CutsceneVfx")
	return ("screen=%s vfx=%d underCamera=%s lighting=%.2f/%.2f/%s/%d"):format(tostring(f and f:GetAttribute("Screen")),
		v and #v:GetChildren() or 0, table.concat(left, "|"), L.Brightness, L.ClockTime, tostring(L.Ambient), #L:GetChildren())
end

return PlayTest
