-- Capture: what /make-cutscene reads from the open place (Edit mode); it never edits the map. Method by fwjelaa (FWJ STUDIOS).
-- It adds a scene's trigger in Workspace.CutsceneZones and the text chunks it stores in ServerStorage.CutsceneCapture_<id>
-- for Claude to fetch. One exception: a prompt trigger with trigger.on parents its ProximityPrompt onto that existing
-- map part (outside CutsceneZones), so the prompt shows on the part the viewer chose.
--   placeTrigger(args)  trigger part + Anchor attachment (+ prompt) at the scene anchor -> JSON {anchor, trigger}
--   storeMap(args)      parts and sampled terrain around the anchor as box stand-ins, chunked for kit/mapcap.py
--   captureRig(args)    a rig's parts and joints as JSON for kit/rigcap.py (Task 9)
local HttpService = game:GetService("HttpService")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")
local StarterPlayer = game:GetService("StarterPlayer")

local Capture = {}
Capture.VERSION = 1
Capture.RADIUS = 150 -- studs around the anchor (spec 5.2)
Capture.MAX_BOXES = 900 -- spike S8: the nearest, biggest parts are kept first
Capture.CHUNK = 12000 -- spike S7: characters per returned chunk
Capture.MIN_SIZE = 0.6 -- parts smaller than this on every side are left out
Capture.TERRAIN_STEP = 6
Capture.TERRAIN_RADIUS = 72
Capture.YIELD_EVERY = 2000 -- execute_luau freezes Studio until the script yields
Capture.ZONE_SIZE = { 16, 8, 16 }

-- Mirror of Director.resolve (roblox/CutsceneKit/Director.luau): keep the two in sync.
function Capture.resolve(path)
	local inst = workspace
	for name in string.gmatch(path or "", "[^/]+") do
		inst = inst:FindFirstChild(name)
		if not inst then
			return nil
		end
	end
	return inst ~= workspace and inst or nil
end

function Capture.cframeList(cf)
	local out = {}
	for i, v in { cf:GetComponents() } do
		out[i] = math.floor(v * 1e5 + 0.5) / 1e5
	end
	return out
end

-- the same checksum as Python's zlib.adler32, so kit/mapcap.py can tell a chunk was copied exactly
function Capture.adler(s)
	local a, b = 1, 0
	for i = 1, #s do
		a = (a + string.byte(s, i)) % 65521
		b = (b + a) % 65521
	end
	return string.format("%08x", b * 65536 + a)
end

function Capture.yawOf(look)
	return math.atan2(-look.X, -look.Z)
end

function Capture.floorBelow(position, ignore)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = ignore or {}
	local hit = workspace:Raycast(position + Vector3.new(0, 3, 0), Vector3.new(0, -500, 0), params)
	return hit and hit.Position.Y or nil
end

function Capture.zoneOf(name)
	local zones = workspace:FindFirstChild("CutsceneZones")
	return zones and zones:FindFirstChild(name)
end

function Capture.anchorOf(zone)
	local a = zone:FindFirstChild("Anchor")
	if a and a:IsA("Attachment") then
		return a.WorldCFrame
	end
	return zone.CFrame * CFrame.new(0, -zone.Size.Y / 2, 0)
end

-- Where the scene happens. args.at = {x, y, z, yaw}, or args.from = "camera" (the ground point the Studio camera looks
-- at, facing away from the camera), "selection" (the selected part or model, facing its front) or "keep" (the existing
-- trigger). The height always snaps to the floor below.
function Capture.anchorFrom(args)
	local zones = workspace:FindFirstChild("CutsceneZones")
	local ignore = zones and { zones } or {}
	local pos, yaw
	if args.at then
		pos, yaw = Vector3.new(args.at[1], args.at[2], args.at[3]), math.rad(args.at[4] or 0)
	elseif args.from == "keep" then
		local zone = Capture.zoneOf(args.name)
		assert(zone, ("no trigger for %s yet: run the anchor step with --from camera, --from selection or --at"):format(tostring(args.name)))
		return Capture.anchorOf(zone)
	elseif args.from == "selection" then
		local sel = game:GetService("Selection"):Get()[1]
		assert(sel and (sel:IsA("BasePart") or sel:IsA("Model")), "select the part or model the scene happens at, then run this again")
		local cf = sel:IsA("Model") and sel:GetPivot() or sel.CFrame
		pos, yaw = cf.Position, Capture.yawOf(cf.LookVector)
		table.insert(ignore, sel)
	else
		local cam = workspace.CurrentCamera
		local params = RaycastParams.new()
		params.FilterType = Enum.RaycastFilterType.Exclude
		params.FilterDescendantsInstances = ignore
		local hit = workspace:Raycast(cam.CFrame.Position, cam.CFrame.LookVector * 1000, params)
		assert(hit, "point the Studio camera at the ground where the scene should happen, then run this again")
		pos, yaw = hit.Position, Capture.yawOf(cam.CFrame.LookVector)
	end
	local y = Capture.floorBelow(pos, ignore) or pos.Y
	return CFrame.new(pos.X, y, pos.Z) * CFrame.Angles(0, yaw, 0)
end

-- The scene's trigger: a part in Workspace.CutsceneZones named after the scene, with attributes Cutscene and Trigger
-- (zone | prompt | api) and an Anchor attachment at the anchor. A zone is the box the server watches; for a prompt or
-- api trigger the part only holds the anchor. args = {name, trigger = {type, size, text, distance, hold, on},
-- anchor = {12 numbers} | at | from}
function Capture.placeTrigger(args)
	local anchor = args.anchor and CFrame.new(table.unpack(args.anchor)) or Capture.anchorFrom(args)
	local zones = workspace:FindFirstChild("CutsceneZones")
	if not zones then
		zones = Instance.new("Folder")
		zones.Name = "CutsceneZones"
		zones.Parent = workspace
	end
	local old = zones:FindFirstChild(args.name)
	if old then
		old:Destroy()
	end
	for _, d in ipairs(workspace:GetDescendants()) do
		if d:IsA("ProximityPrompt") and d.Name == "CutscenePrompt_" .. args.name then
			d:Destroy()
		end
	end
	local trig = args.trigger or { type = "zone" }
	local kind = trig.type or "zone"
	local zone = Instance.new("Part")
	zone.Name = args.name
	zone.Size = kind == "zone" and Vector3.new(table.unpack(trig.size or Capture.ZONE_SIZE)) or Vector3.new(2, 2, 2)
	zone.CFrame = anchor * CFrame.new(0, zone.Size.Y / 2, 0)
	-- invisible in every kind: a live game must never show the trigger (the server tests the root's position against it)
	zone.Anchored, zone.CanCollide, zone.CanQuery, zone.CanTouch, zone.CastShadow = true, false, false, true, false
	zone.Transparency = 1
	zone.Color = Color3.fromRGB(255, 170, 0)
	zone:SetAttribute("Cutscene", args.name)
	zone:SetAttribute("Trigger", kind)
	local a = Instance.new("Attachment")
	a.Name = "Anchor"
	a.Position = Vector3.new(0, -zone.Size.Y / 2, 0)
	a.Parent = zone
	zone.Parent = zones
	local where = "zone"
	if kind == "prompt" then
		local parent = trig.on and Capture.resolve(trig.on)
		assert(not trig.on or parent, ("trigger.on: nothing at Workspace/%s"):format(tostring(trig.on)))
		if not parent then
			parent = Instance.new("Attachment")
			parent.Name = "Prompt"
			parent.Position = Vector3.new(0, 2.5 - zone.Size.Y / 2, 0) -- 2.5 studs above the floor
			parent.Parent = zone
		end
		local prompt = Instance.new("ProximityPrompt")
		prompt.Name = "CutscenePrompt_" .. args.name
		prompt.ActionText = trig.text or "Talk"
		prompt.ObjectText = trig.object or ""
		prompt.MaxActivationDistance = trig.distance or 10
		prompt.HoldDuration = trig.hold or 0
		prompt.RequiresLineOfSight = false
		prompt:SetAttribute("Cutscene", args.name)
		prompt.Parent = parent
		where = "prompt on " .. parent:GetFullName()
	elseif kind == "api" then
		where = "api (call CutsceneKit.Play)"
	end
	return HttpService:JSONEncode({ anchor = Capture.cframeList(anchor), trigger = where })
end

-- Not set: characters and NPCs (they are cast), invisible non-colliding helpers, the cutscene zones themselves.
function Capture.ignored(part)
	if not part:IsA("BasePart") or part:IsA("Terrain") then
		return true
	end
	local zones = workspace:FindFirstChild("CutsceneZones")
	if zones and part:IsDescendantOf(zones) then
		return true
	end
	if part.Transparency >= 0.98 and not part.CanCollide then
		return true
	end
	local m = part:FindFirstAncestorWhichIsA("Model")
	while m do
		if m:FindFirstChildOfClass("Humanoid") then
			return true
		end
		m = m:FindFirstAncestorWhichIsA("Model")
	end
	return false
end

local function i10(v)
	return tostring(math.floor(v * 10 + 0.5))
end

-- 12 fields; the last is the part's Transparency in percent (kit/mapcap.py reads 11 or 12, kit/gates.py skips >= 98)
function Capture.encodeBox(rel, size, color, transparency)
	local rx, ry, rz = rel:ToOrientation()
	local p = rel.Position
	return table.concat({ "b", i10(p.X), i10(p.Y), i10(p.Z), i10(size.X), i10(size.Y), i10(size.Z),
		i10(math.deg(rx)), i10(math.deg(ry)), i10(math.deg(rz)),
		string.format("%x%x%x", math.floor(color.R * 15 + 0.5), math.floor(color.G * 15 + 0.5), math.floor(color.B * 15 + 0.5)),
		tostring(math.floor((transparency or 0) * 100 + 0.5)) }, ",")
end

-- Parts within opts.radius of the anchor, nearest and biggest first, at most opts.maxBoxes.
function Capture.collect(anchor, opts)
	opts = opts or {}
	local radius = opts.radius or Capture.RADIUS
	local maxBoxes = opts.maxBoxes or Capture.MAX_BOXES
	local found, skipped = {}, 0
	for i, d in ipairs((opts.root or workspace):GetDescendants()) do
		if i % Capture.YIELD_EVERY == 0 then
			task.wait()
		end
		if d:IsA("BasePart") and not Capture.ignored(d) then
			local size = d.Size
			if math.max(size.X, size.Y, size.Z) < Capture.MIN_SIZE then
				skipped += 1
			else
				local reach = size.Magnitude / 2
				local dist = (d.Position - anchor.Position).Magnitude - reach
				if dist <= radius then
					table.insert(found, { part = d, score = math.max(0, dist) - reach })
				end
			end
		end
	end
	table.sort(found, function(a, b)
		return a.score < b.score
	end)
	local boxes = {}
	for i, f in ipairs(found) do
		if i > maxBoxes then
			skipped += 1
		else
			table.insert(boxes, Capture.encodeBox(anchor:ToObjectSpace(f.part.CFrame), f.part.Size, f.part.Color, f.part.Transparency))
		end
	end
	return boxes, skipped, #found
end

-- Terrain heights on a grid around the anchor (tenths of studs above the anchor), where there is terrain.
function Capture.terrain(anchor, opts)
	opts = opts or {}
	local step = opts.terrainStep or Capture.TERRAIN_STEP
	local n = math.floor((opts.terrainRadius or Capture.TERRAIN_RADIUS) / step)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Include
	params.FilterDescendantsInstances = { workspace.Terrain }
	local cells = {}
	for i = -n, n do
		for j = -n, n do
			local p = anchor * Vector3.new(i * step, 0, j * step)
			local hit = workspace:Raycast(p + Vector3.new(0, 200, 0), Vector3.new(0, -400, 0), params)
			if hit then
				table.insert(cells, ("t,%d,%d,%d"):format(i, j, math.floor((hit.Position.Y - anchor.Position.Y) * 10 + 0.5)))
			end
		end
		task.wait()
	end
	return cells, step, n
end

function Capture.chunks(records, size)
	local out, cur, len = {}, {}, 0
	for _, r in ipairs(records) do
		local add = (#cur > 0 and 1 or 0) + #r
		if #cur > 0 and len + add > size then
			table.insert(out, table.concat(cur, ";"))
			cur, len, add = {}, 0, #r
		end
		table.insert(cur, r)
		len += add
	end
	if #cur > 0 then
		table.insert(out, table.concat(cur, ";"))
	end
	return out
end

-- args = {name, radius, maxBoxes, chunk, root ("A/B" under Workspace, for tests), terrain (false = skip)}
function Capture.storeMap(args)
	local zone = Capture.zoneOf(args.name)
	assert(zone, ("no trigger for %s yet: send studio/anchor.luau first"):format(tostring(args.name)))
	local anchor = Capture.anchorOf(zone)
	local root = workspace
	if args.root then
		root = Capture.resolve(args.root)
		assert(root, "args.root: nothing at Workspace/" .. tostring(args.root))
	end
	local boxes, skipped, found = Capture.collect(anchor, { radius = args.radius, maxBoxes = args.maxBoxes, root = root })
	local cells, step, n = {}, Capture.TERRAIN_STEP, 0
	if args.terrain ~= false then
		cells, step, n = Capture.terrain(anchor, args)
	end
	local records = table.clone(boxes)
	table.move(cells, 1, #cells, #records + 1, records)
	local header = HttpService:JSONEncode({ v = Capture.VERSION, name = args.name, anchor = Capture.cframeList(anchor),
		radius = args.radius or Capture.RADIUS, boxes = #boxes, cells = #cells, skipped = skipped, found = found,
		terrain = { step = step, n = n } })
	local nonce = string.sub(string.gsub(HttpService:GenerateGUID(false), "-", ""), 1, 8):lower() -- ties every chunk to this capture
	local all = { header }
	for _, body in Capture.chunks(records, args.chunk or Capture.CHUNK) do
		table.insert(all, body)
	end
	local folder = Instance.new("Folder")
	folder.Name = "CutsceneCapture_" .. args.name
	for i, payload in all do
		local v = Instance.new("StringValue")
		v.Name = tostring(i - 1)
		v.Value = ("MAPCAP %s %d/%d %s %s %d\n%s"):format(args.name, i - 1, #all, nonce, Capture.adler(payload), #payload, payload)
		v.Parent = folder
	end
	local old = ServerStorage:FindFirstChild(folder.Name)
	if old then
		old:Destroy()
	end
	folder.Parent = ServerStorage
	return ("stored %d boxes (%d left out), %d terrain samples in %d chunks. Fetch each chunk n = 0..%d with "
		.. '`return game:GetService("ServerStorage")["%s"]["<n>"].Value` (py kit/run.py studio %s chunk --n <n>) and save '
		.. "it, exactly as returned, to cutscenes/%s/studio/map_<n>.txt"):format(#boxes, skipped, #cells, #all, #all - 1,
		folder.Name, args.name, args.name)
end

-- A rig's parts (direct children) and joints: Motor6D C0/C1, or for AnimationConstraint rigs (default for R15 since
-- May 2026) the two attachments' CFrames, which is what C0/C1 are on them. Parents come before children.
function Capture.rigOf(model)
	local hum = model:FindFirstChildOfClass("Humanoid")
	local root = model:FindFirstChild("HumanoidRootPart")
	assert(hum and root, model:GetFullName() .. " needs a Humanoid and a HumanoidRootPart")
	local out = { v = 1, rigType = hum.RigType == Enum.HumanoidRigType.R6 and "R6" or "R15", hipHeight = hum.HipHeight,
		root = "HumanoidRootPart", parts = {}, colors = {}, joints = {} }
	for _, p in ipairs(model:GetChildren()) do
		if p:IsA("BasePart") then
			out.parts[p.Name] = { p.Size.X, p.Size.Y, p.Size.Z }
			out.colors[p.Name] = p.Color:ToHex()
		end
	end
	local byChild = {}
	for _, d in ipairs(model:GetDescendants()) do
		local p0, p1, c0, c1
		if d:IsA("Motor6D") and d.Part0 and d.Part1 then
			p0, p1, c0, c1 = d.Part0, d.Part1, d.C0, d.C1
		elseif d:IsA("AnimationConstraint") and d.Attachment0 and d.Attachment1 then
			p0, p1, c0, c1 = d.Attachment0.Parent, d.Attachment1.Parent, d.Attachment0.CFrame, d.Attachment1.CFrame
		end
		if p0 and p1 and p0.Parent == model and p1.Parent == model then
			if not byChild[p1.Name] or d:IsA("Motor6D") then -- a Motor6D wins over a constraint on the same part
				byChild[p1.Name] = { d.Name, p0.Name, p1.Name, Capture.cframeList(c0), Capture.cframeList(c1) }
			end
		end
	end
	local placed, progress = { [out.root] = true }, true
	while progress do
		progress = false
		local names = {}
		for child in byChild do
			table.insert(names, child)
		end
		table.sort(names)
		for _, child in names do
			local j = byChild[child]
			if not placed[child] and placed[j[2]] then
				table.insert(out.joints, j)
				placed[child] = true
				progress = true
			end
		end
	end
	return out
end

-- args = {role, source = "default" (a plain HumanoidDescription dummy of args.rig) | "starter" (StarterPlayer's
-- StarterCharacter, else the default) | "path" (Workspace/<args.path>), rig = "R15" | "R6"}
function Capture.captureRig(args)
	local model, made
	if args.source == "path" then
		model = Capture.resolve(args.path)
		assert(model and model:IsA("Model"), "no model at Workspace/" .. tostring(args.path))
	elseif args.source == "starter" and StarterPlayer:FindFirstChild("StarterCharacter")
		and not StarterPlayer.StarterCharacter:GetAttribute("CutsceneKitPlayTest") then -- a play-test R6 stand-in is not the game's avatar
		model = StarterPlayer.StarterCharacter
	else
		model = Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType[args.rig or "R15"])
		made = true
	end
	local ok, out = pcall(Capture.rigOf, model)
	if made then
		model:Destroy()
	end
	if not ok then
		error(out, 0)
	end
	out.role = args.role
	out.source = made and "default" or args.source
	return HttpService:JSONEncode(out)
end

return Capture
