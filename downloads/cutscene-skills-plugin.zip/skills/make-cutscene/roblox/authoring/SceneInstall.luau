-- SceneInstall: puts one authored cutscene into the open place (Edit mode). Method by fwjelaa (FWJ STUDIOS).
-- The data module goes in ReplicatedStorage.Cutscenes, with its Studio-only clips (no Open Cloud key yet) or nothing when
-- the module names asset ids, the NPC cast, and the trigger (Capture.placeTrigger). Rendered by
-- `py kit/run.py studio <id> install`; a big Studio-only install arrives in ordered parts that only the last one completes.
-- devScript / devModule put the dev-only play-test and record helpers in place for Play.
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local StarterPlayer = game:GetService("StarterPlayer")

local SceneInstall = {}

function SceneInstall.castModel(role, entry, resolve)
	local model
	if entry.model == nil or entry.model == "default" then
		model = Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType[entry.rig or "R15"])
	else
		local src = resolve(entry.model)
		assert(src and src:IsA("Model"), ("cast %s: no model at Workspace/%s"):format(role, tostring(entry.model)))
		-- Clone skips anything with Archivable = false: switch it on for the whole subtree, copy, switch back
		local flagged = {}
		for _, d in ipairs(src:GetDescendants()) do
			if not d.Archivable then
				table.insert(flagged, d)
				d.Archivable = true
			end
		end
		local was = src.Archivable
		src.Archivable = true
		model = src:Clone()
		src.Archivable = was
		for _, d in ipairs(flagged) do
			d.Archivable = false
		end
		assert(model, ("cast %s: Workspace/%s could not be copied"):format(role, entry.model))
		-- a copy waits in ReplicatedStorage: scripts with a RunContext would run there, so none are kept
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BaseScript") then
				d:Destroy()
			end
		end
	end
	model.Name = role
	return model
end

local function stagingName(name)
	return "CutsceneInstall_" .. name
end

local function folderIn(parent, name)
	local f = parent:FindFirstChild(name)
	if not f then
		f = Instance.new("Folder")
		f.Name = name
		f:SetAttribute("CutsceneKitMade", true) -- remove takes it away again once it is empty
		f.Parent = parent
	end
	return f
end

-- Part k of n: the clips it carries go into a staging folder in ServerStorage (never into the place's scene folders).
-- A part refuses to run unless the part before it did (its Progress marker), so a half-sent install never plays.
-- Returns the staging folder, and a message while parts are still missing.
local function stage(args, need)
	local key = stagingName(args.name)
	local staging = ServerStorage:FindFirstChild(key)
	if args.part == 1 then
		if staging then
			staging:Destroy()
		end
		staging = Instance.new("Folder")
		staging.Name = key
		local clips = Instance.new("Folder")
		clips.Name = "Clips"
		clips.Parent = staging
		local start = Instance.new("StringValue")
		start.Name = "Progress"
		start.Value = "0"
		start.Parent = staging
		staging.Parent = ServerStorage
	end
	local mark = staging and staging:FindFirstChild("Progress")
	assert(not (mark and mark.Value == tostring(args.part)),
		("part %d of %d for %s was already installed: send part %d next"):format(args.part, args.parts, args.name, args.part + 1))
	assert(mark and mark.Value == tostring(args.part - 1),
		("part %d of %d for %s did not run yet (or the install already finished or was removed): send the parts in order, starting with install.1.luau"):format(args.part - 1, args.parts, args.name))
	-- built apart first: a clip that fails to build must not leave half of this part in the staging folder
	local ClipBuilder = need("ClipBuilder")
	local built = {}
	for _, json in args.clips or {} do
		table.insert(built, ClipBuilder.build(HttpService:JSONDecode(json)))
	end
	for _, kfs in built do
		local same = staging.Clips:FindFirstChild(kfs.Name) -- a retried part replaces its own clips
		if same then
			same:Destroy()
		end
		kfs.Parent = staging.Clips
	end
	local n = #built
	if args.part == args.parts then
		return staging, nil -- the marker stays at part - 1 until the install succeeds, so a failed last part can be resent alone
	end
	mark.Value = tostring(args.part)
	if args.part < args.parts then
		return staging, ("part %d of %d for %s: %d clips staged; send install.%d.luau next"):format(args.part, args.parts, args.name, n, args.part + 1)
	end
	return staging, nil
end

-- args = {name, data (the module's source), clips = {clip name = clip JSON} or nil (asset ids), cast = {role = entry}
-- (NPCs), costumes = {role = costume spec} or nil (spec 14: Costume builds them into the module's Costumes folder),
-- trigger = {type, size, text, distance, hold, on}, anchor = {12 numbers} or nil (keep the trigger's anchor),
-- part/parts = this is part k of n of a Studio-only install (see stage)}. Nothing in the place changes until the data is
-- valid and the trigger can be placed: invalid data raises an error and the old install stays.
function SceneInstall.install(args, need)
	local staging
	if args.part then
		local msg
		staging, msg = stage(args, need)
		if msg then
			return msg -- a part before the last one embeds no Capture: nothing past here may need it
		end
	end
	local Capture = need("Capture")
	local made = Instance.new("Folder") -- holds what is built until it is known to be good
	made.Name = "_CutsceneInstallCheck"
	made.Parent = ServerStorage
	local ok, result = pcall(function()
		local module = Instance.new("ModuleScript")
		module.Name = args.name
		module.Source = args.data
		module.Parent = made
		local nClips = 0
		local clips
		if staging then
			clips = staging.Clips
			nClips = #clips:GetChildren()
		elseif args.clips then
			local ClipBuilder = need("ClipBuilder")
			clips = Instance.new("Folder")
			clips.Name = "Clips"
			for _, json in args.clips do
				ClipBuilder.build(HttpService:JSONDecode(json)).Parent = clips
				nClips += 1
			end
		end
		local cast = Instance.new("Folder")
		cast.Name = "Cast"
		local nCast = 0
		for role, entry in args.cast or {} do
			SceneInstall.castModel(role, entry, Capture.resolve).Parent = cast
			nCast += 1
		end
		-- spec 14: the roles dressed as an adapted character, built from their specs (R15 and R6; a creature: one model)
		local costumes, nCostumes, costumeNotes = nil, 0, {}
		if args.costumes and next(args.costumes) then
			costumes, nCostumes, costumeNotes = need("Costume").buildAll(args.costumes)
			costumes.Parent = made -- held with the module until the install is known to be good; made:Destroy() takes it
		end
		local valid = "kit not installed (send out/install.luau)"
		local kit = ReplicatedStorage:FindFirstChild("CutsceneKit")
		if kit and kit:FindFirstChild("Data") then
			local okData, problems = require(kit.Data).validate(require(module))
			assert(okData, "DATA INVALID, install refused: " .. table.concat(problems or {}, "; "))
			valid = "data valid"
		end
		local trig = args.trigger or {}
		if args.anchor == nil then
			assert(Capture.zoneOf(args.name), ("no trigger for %s yet: install needs an anchor"):format(args.name))
		end
		if trig.type == "prompt" and trig.on then
			assert(Capture.resolve(trig.on), ("trigger.on: nothing at Workspace/%s"):format(tostring(trig.on)))
		end
		-- from here on nothing is expected to fail
		if clips then
			clips.Parent = module
		end
		cast.Parent = module
		if costumes then
			costumes.Parent = module
		end
		local folder = folderIn(ReplicatedStorage, "Cutscenes")
		local old = folder:FindFirstChild(args.name)
		if old then
			old:Destroy()
		end
		module.Parent = folder
		local hadZones = workspace:FindFirstChild("CutsceneZones") ~= nil
		local placed = HttpService:JSONDecode(Capture.placeTrigger({ name = args.name, anchor = args.anchor,
			from = args.anchor == nil and "keep" or nil, trigger = args.trigger }))
		if not hadZones then
			local zones = workspace:FindFirstChild("CutsceneZones")
			if zones then
				zones:SetAttribute("CutsceneKitMade", true)
			end
		end
		local clipText = clips and ("%d Studio-only clips (they won't play in a published game until uploaded)"):format(nClips)
			or "clips by asset id"
		local dressed = costumes and (", costumes %d"):format(nCostumes) or ""
		local notes = #costumeNotes > 0 and (" | COSTUME: " .. table.concat(costumeNotes, "; ")) or ""
		return ("installed %s: %s, cast %d%s, trigger %s, %s%s"):format(args.name, clipText, nCast, dressed,
			placed.trigger, valid, notes)
	end)
	made:Destroy()
	if not ok then
		error(result, 0) -- the staged clips stay, so only the last part has to be sent again
	end
	if staging then
		staging:Destroy()
	end
	return result
end

local PLAYTEST = "CutsceneKitPlayTest" -- the dev module's name, and the attribute on the temporary R6 StarterCharacter it makes

-- a viewer's own StarterCharacter has no such attribute and is never touched
local function dropTempCharacter()
	local sc = StarterPlayer:FindFirstChild("StarterCharacter")
	if sc and sc:GetAttribute(PLAYTEST) then
		sc:Destroy()
		return true
	end
	return false
end

-- the dev-only play-test module and its temporary R6 character must never ship with the place
function SceneInstall.dropPlayTest(removed)
	local m = ReplicatedStorage:FindFirstChild(PLAYTEST)
	if m then
		m:Destroy()
		table.insert(removed, "playtest")
	end
	if dropTempCharacter() then
		table.insert(removed, "temporary StarterCharacter")
	end
end

local function dropIfEmpty(inst)
	if inst and inst:GetAttribute("CutsceneKitMade") and #inst:GetChildren() == 0 then
		inst:Destroy()
		return true
	end
	return false
end

function SceneInstall.remove(args)
	local removed = {}
	local folder = ReplicatedStorage:FindFirstChild("Cutscenes")
	local m = folder and folder:FindFirstChild(args.name)
	if m then
		m:Destroy()
		table.insert(removed, "module")
	end
	local zones = workspace:FindFirstChild("CutsceneZones")
	local z = zones and zones:FindFirstChild(args.name)
	if z then
		z:Destroy()
		table.insert(removed, "trigger")
	end
	for _, d in ipairs(workspace:GetDescendants()) do
		if d:IsA("ProximityPrompt") and d.Name == "CutscenePrompt_" .. args.name then
			d:Destroy()
			table.insert(removed, "prompt")
		end
	end
	local leftover = ServerStorage:FindFirstChild(stagingName(args.name))
	if leftover then
		leftover:Destroy()
		table.insert(removed, "unfinished parts")
	end
	-- the dev-only record overlay must never ship with the place
	local overlays = {}
	local sps = StarterPlayer:FindFirstChild("StarterPlayerScripts")
	table.insert(overlays, sps and sps:FindFirstChild("CutsceneRecordOverlay"))
	for _, p in ipairs(Players:GetPlayers()) do
		local ps = p:FindFirstChild("PlayerScripts")
		table.insert(overlays, ps and ps:FindFirstChild("CutsceneRecordOverlay"))
	end
	local hadOverlay = false
	for _, o in overlays do
		o:Destroy()
		hadOverlay = true
	end
	if hadOverlay then
		table.insert(removed, "overlay")
	end
	-- nor may `studio <id> costume-look`'s lineup (Costume.lineup tags it; an untagged folder of that name is not ours)
	for _, c in workspace:GetChildren() do
		if c.Name == "_CostumeLineup" and c:GetAttribute("CutsceneKitDev") then
			c:Destroy()
			table.insert(removed, "costume lineup")
		end
	end
	SceneInstall.dropPlayTest(removed)
	if dropIfEmpty(folder) then
		table.insert(removed, "Cutscenes folder")
	end
	if dropIfEmpty(zones) then
		table.insert(removed, "CutsceneZones folder")
	end
	return ("removed %s: %s"):format(args.name, #removed > 0 and table.concat(removed, ", ") or "nothing was installed")
end

local function replace(parent, className, args)
	local old = parent:FindFirstChild(args.name)
	if old then
		old:Destroy()
	end
	if args.remove then
		return "removed " .. args.name
	end
	local s = Instance.new(className)
	s.Name = args.name
	s.Source = args.source
	s.Parent = parent
	return ("installed %s.%s (it takes effect at the next Play)"):format(parent.Name, args.name)
end

-- dev only: a LocalScript in StarterPlayerScripts (the record overlay)
function SceneInstall.devScript(args)
	return replace(StarterPlayer:WaitForChild("StarterPlayerScripts"), "LocalScript", args)
end

-- dev only: a ModuleScript in ReplicatedStorage (the play-test probes)
function SceneInstall.devModule(args)
	local result = replace(ReplicatedStorage, "ModuleScript", args)
	if args.remove and args.name == PLAYTEST and dropTempCharacter() then
		result ..= " and the temporary StarterCharacter"
	end
	return result
end

-- The example key bind for an awakening (the viewer's to keep or change, so not dev-only): a Script in
-- ServerScriptService and a LocalScript in StarterPlayerScripts, both named args.name; args.remove takes them out.
function SceneInstall.keyBind(args)
	assert(type(args.name) == "string" and args.name ~= "", "keyBind needs a name")
	assert(args.remove or (type(args.server) == "string" and type(args.client) == "string"),
		"keyBind needs the server and client sources (or remove = true)")
	local ServerScriptService = game:GetService("ServerScriptService")
	local playerScripts = StarterPlayer:WaitForChild("StarterPlayerScripts")
	for _, parent in { ServerScriptService, playerScripts } do
		local old = parent:FindFirstChild(args.name)
		while old do
			old:Destroy()
			old = parent:FindFirstChild(args.name)
		end
	end
	if args.remove then
		return "removed the key bind " .. args.name
	end
	local server = Instance.new("Script")
	server.Name = args.name
	server.Source = args.server
	server.Parent = ServerScriptService
	local client = Instance.new("LocalScript")
	client.Name = args.name
	client.Source = args.client
	client.Parent = playerScripts
	return ("installed the key bind %s (a Script and a LocalScript; it works from the next Play)"):format(args.name)
end

return SceneInstall
