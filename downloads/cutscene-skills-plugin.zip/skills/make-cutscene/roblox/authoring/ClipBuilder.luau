-- KeyframeSequence from clip JSON (kit/clip.py format): Studio-only playback while developing, and the Studio-only
-- preview for viewers without an Open Cloud key. Same steps as make-anim's command-bar builder. Method by fwjelaa (FWJ STUDIOS).
local ClipBuilder = {}

function ClipBuilder.build(data)
	local kfs = Instance.new("KeyframeSequence")
	kfs.Name = data.name
	kfs.Loop = data.loop
	kfs.Priority = Enum.AnimationPriority[data.priority]
	for _, k in ipairs(data.keyframes) do
		local kf = Instance.new("Keyframe")
		kf.Time = k.time
		local made = {}
		local function poseFor(part)
			if made[part] then
				return made[part]
			end
			local p = Instance.new("Pose")
			p.Name = part
			p.Weight = 0
			p.CFrame = CFrame.identity
			local parent = data.parents[part]
			p.Parent = parent and poseFor(parent) or kf
			made[part] = p
			return p
		end
		for part, pose in pairs(k.poses) do
			local p = poseFor(part)
			p.CFrame = CFrame.new(table.unpack(pose.cf))
			p.EasingStyle = Enum.PoseEasingStyle[pose.style]
			p.EasingDirection = Enum.PoseEasingDirection[pose.dir]
			p.Weight = 1
		end
		for _, m in ipairs(k.markers) do
			local marker = Instance.new("KeyframeMarker")
			marker.Name = m[1]
			marker.Value = m[2]
			marker.Parent = kf
		end
		kf.Parent = kfs
	end
	return kfs
end

return ClipBuilder
