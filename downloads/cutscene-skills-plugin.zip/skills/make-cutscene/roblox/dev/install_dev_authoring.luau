-- Adds the authoring modules (Capture, ...) and their tests to ServerStorage.CutsceneKitDev, after out/dev.luau.
-- Dev only: never ship this. Method by fwjelaa (FWJ STUDIOS).
-- Split from dev.luau so every execute_luau payload stays under 60,000 bytes. Template: `py kit/run.py bundle` embeds
-- the files and writes out/dev_authoring.luau.
local EMBED = nil -- filled in by kit/bundle.py
assert(EMBED, "run `py kit/run.py bundle` and send out/dev_authoring.luau, not this template")
local ServerStorage = game:GetService("ServerStorage")
local dev = ServerStorage:FindFirstChild("CutsceneKitDev")
assert(dev, "send out/dev.luau first")
local authoring = dev:FindFirstChild("Authoring")
local tests = dev:FindFirstChild("Tests")
assert(authoring and tests, "CutsceneKitDev is incomplete: send out/dev.luau again")

local function put(folder, name, source)
	local old = folder:FindFirstChild(name)
	if old then
		old:Destroy() -- require() caches by instance, so a re-send must be a new ModuleScript
	end
	local m = Instance.new("ModuleScript")
	m.Name = name
	m.Source = source
	m.Parent = folder
end

local count = 0
for name, source in EMBED.authoring do
	put(authoring, name, source)
end
for name, source in EMBED.tests do
	put(tests, name, source)
	count += 1
end
return ("CutsceneKitDev authoring installed (%d tests)"):format(count)
