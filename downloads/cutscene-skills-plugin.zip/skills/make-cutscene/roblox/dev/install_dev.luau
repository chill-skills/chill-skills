-- Installs the dev helpers into ServerStorage.CutsceneKitDev (Test, ClipBuilder, Tests, FixtureClips). Dev only: never ship
-- this. Template: `py kit/run.py bundle` embeds the files and writes out/dev.luau. Method by fwjelaa (FWJ STUDIOS).
local EMBED = nil -- filled in by kit/bundle.py
assert(EMBED, "run `py kit/run.py bundle` and send out/dev.luau, not this template")
local ServerStorage = game:GetService("ServerStorage")

local folder = Instance.new("Folder")
folder.Name = "CutsceneKitDev"
for name, source in EMBED.files do
	local m = Instance.new("ModuleScript")
	m.Name = name
	m.Source = source
	m.Parent = folder
end
local tests = Instance.new("Folder")
tests.Name = "Tests"
local count = 0
for name, source in EMBED.tests do
	local m = Instance.new("ModuleScript")
	m.Name = name
	m.Source = source
	m.Parent = tests
	count += 1
end
tests.Parent = folder
local authoring = Instance.new("Folder")
authoring.Name = "Authoring"
for name, source in EMBED.authoring do
	local m = Instance.new("ModuleScript")
	m.Name = name
	m.Source = source
	m.Parent = authoring
end
authoring.Parent = folder
local clips = Instance.new("Folder")
clips.Name = "FixtureClips"
for name, json in EMBED.clips do
	local v = Instance.new("StringValue")
	v.Name = name
	v.Value = json
	v.Parent = clips
end
clips.Parent = folder
local old = ServerStorage:FindFirstChild("CutsceneKitDev")
if old then
	old:Destroy()
end
folder.Parent = ServerStorage
return ("CutsceneKitDev installed (%d tests)"):format(count)
