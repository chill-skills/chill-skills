-- Delta install (dev only; `py kit/run.py delta <Module> ... [--tests A,B]` writes out/delta.luau): one payload that
-- carries only what changed. Method by fwjelaa (FWJ STUDIOS).
-- It rebuilds the kit with the named modules' new sources and every other module's source copied from the kit installed
-- now, and replaces the named test modules. require() caches by instance, so every ModuleScript of the kit is made
-- anew, never edited in place.
local EMBED = nil -- filled in by kit/bundle.py
assert(EMBED, "run `py kit/run.py delta <Module> ...` and send out/delta.luau, not this template")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local old = ReplicatedStorage:FindFirstChild("CutsceneKit")
assert(old, "no CutsceneKit is installed: send out/install.luau (and its parts) first")
local function source(name)
	local given = EMBED.files["CutsceneKit/" .. name .. ".luau"]
	if given then
		return given
	end
	local m = name == "CutsceneKit" and old or old:FindFirstChild(name)
	assert(m and m:IsA("ModuleScript"), ("the installed kit has no module %s: send out/install.luau first"):format(name))
	return m.Source
end
local root = Instance.new("ModuleScript")
root.Name = "CutsceneKit"
root.Source = source("CutsceneKit")
root:SetAttribute("Version", EMBED.version)
for _, name in EMBED.modules do
	local m = Instance.new("ModuleScript")
	m.Name = name
	m.Source = source(name)
	m.Parent = root
end
local changed = 0
for _ in EMBED.files do
	changed += 1
end
local dev = ServerStorage:FindFirstChild("CutsceneKitDev")
local tests = dev and dev:FindFirstChild("Tests")
local replaced = 0
for name, src in EMBED.tests do
	assert(tests, "no CutsceneKitDev is installed: send out/dev.luau first")
	local t = tests:FindFirstChild(name)
	if t then
		t:Destroy()
	end
	local m = Instance.new("ModuleScript")
	m.Name = name
	m.Source = src
	m.Parent = tests
	replaced += 1
end
old:Destroy()
root.Parent = ReplicatedStorage
return ("delta: CutsceneKit %s rebuilt (%d modules, %d changed), %d tests replaced"):format(EMBED.version, #EMBED.modules, changed, replaced)
