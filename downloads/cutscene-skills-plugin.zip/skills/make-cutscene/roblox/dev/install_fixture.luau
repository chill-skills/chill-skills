-- Installs the test cutscene Fixture_Walkin (and Fixture_Broken) into the open place, Edit mode. Never shipped.
-- Needs out/install.luau and out/dev.luau first. Method by fwjelaa (FWJ STUDIOS).
-- Template: `py kit/run.py bundle` embeds the fixture and writes out/fixture.luau (R15), out/fixture_r6.luau (R6 clips)
-- and out/fixture_assets.luau (asset ids instead of clips).
local EMBED = nil -- filled in by kit/bundle.py
assert(EMBED, "run `py kit/run.py bundle` and send out/fixture.luau, not this template")
local USE_CLIPS = EMBED.useClips
local NPC_RIG = EMBED.npcRig
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local StarterGui = game:GetService("StarterGui")
assert(ServerStorage:FindFirstChild("CutsceneKitDev"), "run out/dev.luau first (the fixture uses its ClipBuilder)")
local ClipBuilder = require(ServerStorage:WaitForChild("CutsceneKitDev").Authoring.ClipBuilder)

local manifest = EMBED.manifest
local source = EMBED.data

local function folder(parent, name)
	local f = parent:FindFirstChild(name)
	if not f then
		f = Instance.new("Folder")
		f.Name = name
		f.Parent = parent
	end
	return f
end
local cutscenes = folder(ReplicatedStorage, "Cutscenes")
local zones = folder(workspace, "CutsceneZones")

local function install(name, src, withZone)
	local old = cutscenes:FindFirstChild(name)
	if old then
		old:Destroy()
	end
	local module = Instance.new("ModuleScript")
	module.Name = name
	module.Source = src
	if USE_CLIPS then
		local clips = Instance.new("Folder")
		clips.Name = "Clips"
		for _, clipName in manifest.clips do
			ClipBuilder.build(HttpService:JSONDecode(EMBED.clips[clipName])).Parent = clips
		end
		clips.Parent = module
	end
	local cast = Instance.new("Folder")
	cast.Name = "Cast"
	local npc = Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType[NPC_RIG])
	npc.Name = "npc1"
	npc.Parent = cast
	cast.Parent = module
	module.Parent = cutscenes
	if withZone then
		local oldZone = zones:FindFirstChild(name)
		if oldZone then
			oldZone:Destroy()
		end
		local zone = Instance.new("Part")
		zone.Name = name
		zone.Size = Vector3.new(table.unpack(manifest.zone.size))
		zone.CFrame = CFrame.new(table.unpack(manifest.zone.position))
		zone.Anchored, zone.CanCollide, zone.CanQuery, zone.CanTouch, zone.CastShadow = true, false, false, false, false
		zone.Transparency = 0.85
		zone.Color = Color3.fromRGB(255, 170, 0)
		zone:SetAttribute("Cutscene", name)
		local anchor = Instance.new("Attachment")
		anchor.Name = "Anchor"
		anchor.Position = Vector3.new(0, -zone.Size.Y / 2, 0)
		anchor.Parent = zone
		zone.Parent = zones
	end
end

install(manifest.name, source, true)
-- the same scene with a camera clip that can't load: for the load-failure test (no zone; started through the Api)
local broken = string.gsub(source, 'Stage = "[^"]*"', 'Stage = "rbxassetid://1"')
broken = string.gsub(broken, 'Name = "' .. manifest.name .. '"', 'Name = "Fixture_Broken"')
install("Fixture_Broken", broken, false)

for _, spec in { { "CutsceneHUDProbe", true }, { "CutsceneHUDProbeOff", false } } do
	local g = StarterGui:FindFirstChild(spec[1]) or Instance.new("ScreenGui")
	g.Name = spec[1]
	g.Enabled = spec[2]
	g.ResetOnSpawn = false
	g.Parent = StarterGui
end
return ("installed %s + Fixture_Broken, npc %s, clips %s"):format(manifest.name, NPC_RIG, USE_CLIPS and "in Clips" or "by asset id")
