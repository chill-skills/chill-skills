-- Tiny test runner for CutsceneKit (dev only, never shipped), after make-map's MapKit.Test.
-- Tests live in roblox/tests/<Name>.test.luau. Method by fwjelaa (FWJ STUDIOS).
-- Each returns { ["case name"] = function(t, K) ... end }; `py kit/run.py bundle` + out/dev.luau put them in
-- CutsceneKitDev.Tests. K.<Module> is require(ReplicatedStorage.CutsceneKit.<Module>); K.ClipBuilder is the dev helper
-- and K.clip(name) decodes a fixture clip's JSON.
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HttpService = game:GetService("HttpService")
local ClipBuilder = require(script.Parent.Authoring.ClipBuilder)

local Test = {}

local function checker(sandbox, deferred)
	local t = { sandbox = sandbox }
	function t.ok(cond, msg)
		if not cond then
			error(msg or "expected true", 2)
		end
	end
	function t.eq(got, want, msg)
		if got ~= want then
			error(("%s: want %s, got %s"):format(msg or "eq", tostring(want), tostring(got)), 2)
		end
	end
	function t.near(got, want, eps, msg)
		if type(got) ~= "number" or math.abs(got - want) > (eps or 1e-3) then
			error(("%s: want %.4f, got %s"):format(msg or "near", want, tostring(got)), 2)
		end
	end
	function t.errors(fn, mustMention, msg)
		local ok, err = pcall(fn)
		if ok then
			error(msg or "expected an error", 2)
		end
		if mustMention and not string.find(tostring(err), mustMention, 1, true) then
			error(("%s: error %q does not mention %q"):format(msg or "errors", tostring(err), mustMention), 2)
		end
	end
	function t.defer(fn) -- runs after the case, pass or fail (cleanup outside the sandbox)
		table.insert(deferred, fn)
	end
	return t
end

local function kit()
	local helpers = { ClipBuilder = ClipBuilder }
	function helpers.clip(name)
		return HttpService:JSONDecode(script.Parent.FixtureClips[name].Value)
	end
	return setmetatable(helpers, {
		__index = function(_, name)
			local root = ReplicatedStorage:FindFirstChild("CutsceneKit")
			local m = root and root:FindFirstChild(name)
			if not m then -- authoring modules (Capture, SceneInstall, PlayTest ...) live in CutsceneKitDev.Authoring
				local authoring = script.Parent:FindFirstChild("Authoring")
				m = authoring and authoring:FindFirstChild(name)
			end
			assert(m, ("%s is missing: run `py kit/run.py bundle`, then send out/install.luau and out/dev.luau"):format(name))
			return require(m)
		end,
	})
end

function Test.run(names)
	local K = kit()
	local lines, passed, total = {}, 0, 0
	for _, name in names do
		local suite = script.Parent.Tests:FindFirstChild(name)
		if not suite then
			total += 1
			table.insert(lines, ("FAIL %s (load): not installed — run py kit/run.py bundle, then out/dev.luau (out/dev_authoring.luau and its parts, for Authoring suites)"):format(name))
			continue
		end
		local ok, cases = pcall(require, suite)
		if not ok then
			total += 1
			table.insert(lines, ("FAIL %s (load): %s"):format(name, tostring(cases)))
			continue
		end
		local order = {}
		for caseName in cases do
			table.insert(order, caseName)
		end
		table.sort(order)
		for _, caseName in order do
			total += 1
			local sandbox = Instance.new("Folder")
			sandbox.Name = "_CutsceneKitTest"
			sandbox.Parent = workspace
			local deferred = {}
			local okCase, err = pcall(cases[caseName], checker(sandbox, deferred), K)
			for _, fn in deferred do
				pcall(fn)
			end
			sandbox:Destroy()
			if okCase then
				passed += 1
			else
				table.insert(lines, ("FAIL %s / %s: %s"):format(name, caseName, tostring(err)))
			end
		end
	end
	table.insert(lines, 1, ("%d/%d passed"):format(passed, total))
	return table.concat(lines, "\n")
end

return Test
