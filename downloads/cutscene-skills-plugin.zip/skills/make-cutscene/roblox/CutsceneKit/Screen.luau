-- Screen: the screen layer of the player whose camera the scene takes (spec 7). Onlookers never get it.
-- Impact frames (two frames: a black world with white subjects, then the inverse, then a white flash), white flashes,
-- colour-grade and bloom pulses, focus pulls, and the flat 2D manga effects: focus lines, impact bursts, sound words
-- and per-shot backdrop cards (plus a neutral key light on the cast), all timed on the scene's timeline. Everything is
-- made under the camera, in PlayerGui or in the scene's folder and tracked by the Snapshot, so restore puts the game's
-- look back exactly; Lighting itself is never changed. Comfort (spec 6): Reduced Motion turns impact frames, focus
-- lines and big bursts off and stills the words' punch and shake, and at most FLASH_PER_S flashes (Impact and Flash
-- markers and big bursts together) play in any second. Method by fwjelaa (FWJ STUDIOS).
local Vfx = require(script.Parent.Vfx)
local Lib = require(script.Parent.VfxPresets)

local Screen = {}
Screen.FLASH_PER_S = 2
Screen.IMPACT_FRAME = 0.05 -- s per impact frame: two of them, about 0.1 s in all (spec 7)
Screen.MAX_HIGHLIGHTS = 8 -- research/03 section 5: at most 8 Highlights during an impact frame
Screen.FLASH_LIFE = 0.18
Screen.AFTER_IMPACT = 0.9 -- the white flash that follows the impact frames
Screen.SKY_DOME = true -- default until spike S12 measures: the sky ignores ColorCorrection, so a dome hides it during the impact frames
Screen.DOME_RADIUS = 1000
Screen.IMPACT_A = { Brightness = -1, Contrast = 0, Saturation = -1, fill = Color3.new(1, 1, 1) } -- default until spike S12 measures
Screen.IMPACT_B = { Brightness = 1, Contrast = 0, Saturation = -1, fill = Color3.new(0, 0, 0) } -- default until spike S12 measures
-- the manga effects (vfx/manga: textures.json, made in Blender by make_manga.py)
Screen.MANGA = Lib.Manga or {} -- name -> { id = "rbxassetid://n", grid = 1|2, cells = { ... } }
Screen.SHEET = 1024 -- px: every manga texture is a 1024 image (a grid 2 sheet has 512 px cells)
Screen.JITTER = 1 / 12 -- s: manga effects jitter on twos
Screen.MAX_LAYERS = 6 -- focus-line sets, bursts and words alive at once; more are dropped (kit/cues.py SCREEN_LAYERS)
Screen.LIFE = { speedlines = 0.4, burst = 0.5, word = 1.0, backdrop = 2.0 } -- default lives (kit/cues.py SCREEN_LIFE)
Screen.LINES_FADE = 0.3 -- the last share of a focus-line set's life fades out
Screen.LINES_OVER = 1.04 -- the quadrants reach a little past the farthest screen corner
Screen.BURST_SIZE = 0.45 -- screen heights (kit/cues.py BURST_SIZE)
Screen.BURST_FLASH = 0.6 -- a burst this big counts as a flash (kit/cues.py BURST_FLASH)
Screen.BURST_IN, Screen.BURST_FROM = 0.035, 0.3 -- scales in from 30 % over about 2 frames
Screen.BURST_FADE = 0.35 -- the last share of its life fades out
Screen.WORD_BASE = 100 -- px: a word's TextSize (Roblox's cap); its UIScale makes it the asked size
Screen.WORD_SIZE = 0.16 -- screen heights
Screen.WORD_STROKE = 0.06 -- share of the text size
Screen.WORD_STROKE_MAX = 0.07 -- vault rule: thicker fills the letters' counters in (kit/vfxlib.py STROKE_MAX)
Screen.WORD_PUNCH, Screen.PUNCH_TIME = 1.6, 0.05 -- UIScale 1.6 -> 1.0 in about 3 frames
Screen.WORD_OUT = 0.15 -- s of fade at the end
Screen.WORD_SHAKE = 0.004 -- screen heights of jitter on twos while it holds
Screen.FONT = "Bangers"
Screen.FONTS = { Bangers = true, LuckiestGuy = true, FredokaOne = true, PermanentMarker = true, Creepster = true,
	DenkOne = true }
Screen.CARD_DIST = 30 -- studs: a backdrop card's distance with no cast in view
Screen.CARD_GAP = 3 -- studs behind the farthest cast member, at least
Screen.CARD_OVERSCAN = 1.15 -- the card is this much bigger than the view (shake, rounding)
Screen.CASTLIGHT = { Color = "ffffff", Brightness = 1.5, Range = 10 } -- Config.CastLight defaults
Screen.CASTLIGHT_AHEAD = 3 -- studs from the head toward the camera, 1 up

-- 0..1: rises over attack (ease out), holds, falls over release (ease in)
function Screen.envelope(lt, attack, hold, release)
	attack, hold, release = attack or 0, hold or 0, release or 0
	if lt < 0 then
		return 0
	end
	if lt < attack then
		return Vfx.EASE.out(lt / attack)
	end
	lt -= attack
	if lt <= hold then
		return 1
	end
	lt -= hold
	if lt < release then
		return 1 - Vfx.EASE["in"](lt / release)
	end
	return 0
end

local function over(lt, s)
	return lt > (s.attack or 0) + (s.hold or 0) + (s.release or 0)
end

-- "A" (black world, white subjects), "B" (white world, black subjects), "done", or nil before it starts
function Screen.impactPhase(t0, t)
	local d = t - t0
	if d < 0 then
		return nil
	end
	if d < Screen.IMPACT_FRAME then
		return "A"
	end
	if d < 2 * Screen.IMPACT_FRAME then
		return "B"
	end
	return "done"
end

-- flashes can be registered out of time order (a preset's flash lies in the future), so check every 1 s window that
-- contains t, counting flashes before and after it
function Screen.flashAllowed(sc, t)
	local all = { t }
	for _, f in ipairs(sc.flashes) do
		table.insert(all, f)
	end
	for _, start in ipairs(all) do
		if start <= t and t < start + 1 then
			local n = 0
			for _, f in ipairs(all) do
				if f >= start and f < start + 1 then
					n += 1
				end
			end
			if n > Screen.FLASH_PER_S then
				return false
			end
		end
	end
	return true
end

-- ---------------------------------------------------------------- the manga effects' maths (no engine calls)

-- the jitter frame (on twos) at lt seconds into an effect
function Screen.tick(lt)
	return math.floor(lt / Screen.JITTER + 1e-6)
end

-- a cell 0..n-1 for this jitter frame and slot, never the one the frame before had (n > 1)
function Screen.pick(tick, slot, n)
	if n <= 1 then
		return 0
	end
	local function raw(k)
		local h = (k * 73856093 + slot * 19349663) % 1000003
		return h % n
	end
	local prev = tick > 0 and Screen.pick(tick - 1, slot, n) or -1
	local c = raw(tick)
	if c == prev then
		c = (c + 1 + (tick % (n - 1))) % n
	end
	return c
end

-- a flipbook cell's x, y and size in image pixels (ImageRectOffset / ImageRectSize)
function Screen.cell(tex, k)
	local grid = (tex and tex.grid) or 1
	local size = Screen.SHEET / grid
	return (k % grid) * size, math.floor(k / grid) * size, size
end

-- the focus lines are four rotated copies of a quadrant cell whose top-left corner is the focus: the side of each
-- (px) and their centres and rotations, so that together they cover the whole w x h screen around (fx, fy)
function Screen.quadrants(fx, fy, w, h)
	local far = 0
	for _, x in ipairs({ 0, w }) do
		for _, y in ipairs({ 0, h }) do
			far = math.max(far, math.sqrt((x - fx) ^ 2 + (y - fy) ^ 2))
		end
	end
	local side = far * Screen.LINES_OVER
	local half = side / 2
	-- rotation r (clockwise on screen) turns the corner-to-centre vector (half, half)
	return side, {
		{ fx + half, fy + half, 0 },
		{ fx - half, fy + half, 90 },
		{ fx - half, fy - half, 180 },
		{ fx + half, fy - half, 270 },
	}
end

-- focus lines: on at once, held, faded over the last LINES_FADE of their life; alpha is the opacity
function Screen.linesAlpha(lt, life, alpha)
	if lt < 0 or lt > life then
		return 0
	end
	local fade = life * Screen.LINES_FADE
	local k = lt < life - fade and 1 or (life - lt) / fade
	return (alpha or 1) * k
end

-- a word's UIScale punch: WORD_PUNCH -> 1 over PUNCH_TIME (ease out); none under reduced motion
function Screen.punch(lt, reduced)
	if reduced or lt >= Screen.PUNCH_TIME then
		return 1
	end
	local x = math.max(lt, 0) / Screen.PUNCH_TIME
	return Screen.WORD_PUNCH + (1 - Screen.WORD_PUNCH) * Vfx.EASE.out(x)
end

-- transparency 0 until the last `out` seconds of life, then up to 1
function Screen.fadeOut(lt, life, out)
	if lt >= life then
		return 1
	end
	if lt <= life - out then
		return 0
	end
	return 1 - (life - lt) / out
end

-- a word's stroke in px at WORD_BASE text size, capped at WORD_STROKE_MAX of it
function Screen.strokePx(stroke)
	return math.clamp(stroke or Screen.WORD_STROKE, 0, Screen.WORD_STROKE_MAX) * Screen.WORD_BASE
end

function Screen.burstScale(lt)
	if lt >= Screen.BURST_IN then
		return 1
	end
	return Screen.BURST_FROM + (1 - Screen.BURST_FROM) * Vfx.EASE.out(math.max(lt, 0) / Screen.BURST_IN)
end

-- a backdrop card's distance from the camera: `dist` (or CARD_DIST with no cast in view), but always CARD_GAP behind
-- the farthest cast member, so it never shows in front of one; depths = each cast member's farthest point
function Screen.cardDepth(dist, depths)
	local far = nil
	for _, d in ipairs(depths) do
		far = math.max(far or d, d)
	end
	if not far then
		return dist or Screen.CARD_DIST
	end
	return math.max(dist or 0, far + Screen.CARD_GAP)
end

-- the card's width and height in studs at that depth: the whole view (vertical fov, aspect w/h) plus the overscan
function Screen.cardSize(depth, fov, aspect)
	local h = 2 * depth * math.tan(math.rad(fov) / 2) * Screen.CARD_OVERSCAN
	return h * aspect, h
end

-- Config.Grade = { Tint = "rrggbb", Brightness, Contrast, Saturation } (each -1..1): the scene's own look
function Screen.baseGrade(g)
	g = g or {}
	return { tint = g.Tint and Vfx.hex(g.Tint) or Color3.new(1, 1, 1), bright = g.Brightness or 0,
		contrast = g.Contrast or 0, sat = g.Saturation or 0 }
end

-- env = { camera, playerGui = Instance?, track = function(inst) -> inst (Snapshot.track), reduced = bool,
--         palette = Vfx.palette(...), base = Config.Grade? }
function Screen.new(env)
	local sc = { env = env, flashes = {}, events = {}, log = {}, highlights = {}, suppressed = {},
		pal = env.palette or Vfx.palette(nil) }
	local function make(class, name, parent)
		local inst = Instance.new(class)
		inst.Name = name
		if env.track then
			env.track(inst)
		end
		inst.Parent = parent
		return inst
	end
	sc.make = make
	local cam = env.camera
	sc.grade = make("ColorCorrectionEffect", "CutsceneGrade", cam)
	sc.impactCC = make("ColorCorrectionEffect", "CutsceneImpact", cam)
	sc.impactCC.Enabled = false
	sc.bloom = make("BloomEffect", "CutsceneBloom", cam)
	sc.bloom.Enabled = false
	sc.bloom.Intensity, sc.bloom.Size, sc.bloom.Threshold = 0, 24, 2
	sc.hlFolder = make("Folder", "CutsceneImpactHighlights", cam)
	sc.base = Screen.baseGrade(env.base)
	if env.playerGui then
		local gui = make("ScreenGui", "CutsceneFlash", nil)
		gui.IgnoreGuiInset = true
		gui.ScreenInsets = Enum.ScreenInsets.None
		gui.ResetOnSpawn = false
		gui.DisplayOrder = 49 -- under the letterbox (50) and subtitles (51)
		local f = Instance.new("Frame")
		f.Name = "White"
		f.BackgroundColor3 = Color3.new(1, 1, 1)
		f.BackgroundTransparency = 1
		f.BorderSizePixel = 0
		f.Size = UDim2.fromScale(1, 1)
		f.Parent = gui
		gui.Parent = env.playerGui
		sc.flashGui, sc.flashFrame = gui, f
	end
	Screen.step(sc, 0)
	return sc
end

function Screen.grade(sc, t, spec)
	table.insert(sc.events, { kind = "grade", t = t, spec = spec })
end

function Screen.bloom(sc, t, spec)
	table.insert(sc.events, { kind = "bloom", t = t, spec = spec })
end

function Screen.focus(sc, t, spec)
	table.insert(sc.events, { kind = "focus", t = t, spec = spec })
end

local MANGA_KINDS = { speedlines = true, burst = true, word = true }

-- a manga layer (focus lines, a burst or a word), unless MAX_LAYERS are already due
local function addManga(sc, kind, t, spec)
	local n = 0
	for _, ev in ipairs(sc.events) do
		if MANGA_KINDS[ev.kind] then
			n += 1
		end
	end
	if n >= Screen.MAX_LAYERS then
		table.insert(sc.log, ("%s@%.2f dropped"):format(kind, t))
		return false
	end
	table.insert(sc.events, { kind = kind, t = t, spec = spec, life = spec.life or Screen.LIFE[kind] })
	table.insert(sc.log, ("%s@%.2f"):format(kind, t))
	return true
end

-- manga focus lines converging on spec.focus / spec.at (screen 0-1, studs from the anchor, or follow a cast part):
-- { focus, at, follow, life, alpha (opacity), density (0.5 and up doubles the lines), color }
function Screen.speedLines(sc, t, spec)
	if sc.env.reduced then
		table.insert(sc.log, ("speedlines@%.2f reduced"):format(t))
		return false
	end
	return addManga(sc, "speedlines", t, spec)
end

-- the white spiky impact burst at a point: { image, at, follow, size (screen heights), life, rot, color }; a big one
-- (BURST_FLASH and up) counts as a flash
function Screen.burst(sc, t, spec)
	local big = (spec.size or Screen.BURST_SIZE) >= Screen.BURST_FLASH
	if big and sc.env.reduced then
		table.insert(sc.log, ("burst@%.2f reduced"):format(t))
		return false
	end
	if big and not Screen.flashAllowed(sc, t) then
		table.insert(sc.log, ("burst@%.2f gated"):format(t))
		return false
	end
	if not addManga(sc, "burst", t, spec) then
		return false
	end
	if big then
		table.insert(sc.flashes, t)
	end
	return true
end

-- a sound word: { text, at, follow, size (screen heights), rot, life, fill, stroke (share of the text size), font }
function Screen.word(sc, t, spec)
	return addManga(sc, "word", t, spec)
end

-- a backdrop card behind the cast, filling the view: { image, color, dist, life }; the latest one started shows
function Screen.backdrop(sc, t, spec)
	table.insert(sc.events, { kind = "backdrop", t = t, spec = spec, life = spec.life or Screen.LIFE.backdrop })
	table.insert(sc.log, ("backdrop@%.2f"):format(t))
	return true
end

-- Config.CastLight (true or { Color, Brightness, Range }): a neutral key light on each cast member, kept between its
-- head and the camera, so a white tee stays white in a red set. Returns how many lights it made.
function Screen.castLight(sc, spec)
	if not spec then
		return 0
	end
	local c = type(spec) == "table" and spec or {}
	sc.lights = sc.lights or {}
	for _, model in pairs(sc.env.cast or {}) do
		if typeof(model) == "Instance" and model:IsA("Model") then
			local root = model:FindFirstChild("HumanoidRootPart") or model.PrimaryPart
				or model:FindFirstChildWhichIsA("BasePart")
			if root and root:IsA("BasePart") then
				local att = sc.make("Attachment", "CutsceneCastLight", nil)
				local light = Instance.new("PointLight")
				light.Color = Vfx.hex(c.Color or Screen.CASTLIGHT.Color)
				light.Brightness = c.Brightness or Screen.CASTLIGHT.Brightness
				light.Range = c.Range or Screen.CASTLIGHT.Range
				light.Shadows = false
				light.Parent = att
				att.Parent = root
				table.insert(sc.lights, { att = att, light = light, model = model, root = root })
			end
		end
	end
	return #sc.lights
end

function Screen.flash(sc, t, power)
	if not Screen.flashAllowed(sc, t) then
		table.insert(sc.log, ("flash@%.2f gated"):format(t))
		return false
	end
	table.insert(sc.flashes, t)
	table.insert(sc.events, { kind = "flash", t = t, power = power or 0.85 })
	table.insert(sc.log, ("flash@%.2f"):format(t))
	return true
end

-- subjects: the models to keep visible as silhouettes (the cast and the key VFX), at most MAX_HIGHLIGHTS
function Screen.impact(sc, t, subjects)
	if sc.env.reduced then
		table.insert(sc.log, ("impact@%.2f reduced"):format(t))
		return false
	end
	if not Screen.flashAllowed(sc, t) then
		table.insert(sc.log, ("impact@%.2f gated"):format(t))
		return false
	end
	table.insert(sc.flashes, t)
	local list = {}
	for _, s in ipairs(subjects or {}) do
		if #list < Screen.MAX_HIGHLIGHTS and typeof(s) == "Instance" and s.Parent then
			table.insert(list, s)
		end
	end
	table.insert(sc.events, { kind = "impact", t = t, subjects = list })
	table.insert(sc.log, ("impact@%.2f"):format(t))
	return true
end

-- a VFX preset's (or a screen cue's) entries: { effect = grade | bloom | flash | speedlines | focus | burst | word |
-- backdrop, t = offset, ... }
function Screen.apply(sc, t, entries)
	for _, s in ipairs(entries or {}) do
		local at = t + (s.t or 0)
		if s.effect == "grade" then
			Screen.grade(sc, at, s)
		elseif s.effect == "bloom" then
			Screen.bloom(sc, at, s)
		elseif s.effect == "flash" then
			Screen.flash(sc, at, s.power)
		elseif s.effect == "speedlines" then
			Screen.speedLines(sc, at, s)
		elseif s.effect == "focus" then
			Screen.focus(sc, at, s)
		elseif s.effect == "burst" then
			Screen.burst(sc, at, s)
		elseif s.effect == "word" then
			Screen.word(sc, at, s)
		elseif s.effect == "backdrop" then
			Screen.backdrop(sc, at, s)
		end
	end
end

local function dome(sc)
	if sc.dome then
		return sc.dome
	end
	local p = sc.make("Part", "CutsceneSkyDome", nil)
	p.Anchored = true
	p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = false, false, false, false
	p.Size = Vector3.one
	p.Material = Enum.Material.SmoothPlastic
	p.Transparency = 1
	local mesh = Instance.new("SpecialMesh")
	mesh.MeshType = Enum.MeshType.Sphere
	mesh.Scale = Vector3.one * (-2 * Screen.DOME_RADIUS) -- inside out: seen from the camera inside it
	mesh.Parent = p
	p.Parent = sc.env.camera
	sc.dome = p
	return p
end

local function showImpact(sc, ev, phase)
	if not ev.made then
		ev.made = true
		for _, subject in ipairs(ev.subjects) do
			if subject.Parent then
				-- one Highlight per object shows: switch the subject's own (the aura outline) off meanwhile
				for _, d in ipairs(subject:GetDescendants()) do
					if d:IsA("Highlight") and d.Enabled then
						d.Enabled = false
						table.insert(sc.suppressed, d)
					end
				end
				local h = Instance.new("Highlight")
				h.Name = "CutsceneImpact"
				h.Adornee = subject
				h.DepthMode = Enum.HighlightDepthMode.Occluded
				h.FillTransparency = 0
				h.OutlineTransparency = 1
				h.Parent = sc.hlFolder
				table.insert(sc.highlights, h)
			end
		end
	end
	local look = phase == "A" and Screen.IMPACT_A or Screen.IMPACT_B
	local cc = sc.impactCC
	cc.Brightness, cc.Contrast, cc.Saturation = look.Brightness, look.Contrast, look.Saturation
	cc.Enabled = true
	for _, h in ipairs(sc.highlights) do
		h.FillColor = look.fill
	end
	if Screen.SKY_DOME then
		local d = dome(sc)
		d.Color = phase == "A" and Color3.new(0, 0, 0) or Color3.new(1, 1, 1)
		d.CFrame = CFrame.new(sc.env.camera.CFrame.Position)
		d.Transparency = 0
	end
end

local function hideImpact(sc)
	sc.impactCC.Enabled = false
	if sc.dome then
		sc.dome.Transparency = 1
	end
	for _, h in ipairs(sc.highlights) do
		h:Destroy()
	end
	table.clear(sc.highlights)
	for _, d in ipairs(sc.suppressed) do
		if d.Parent then
			d.Enabled = true
		end
	end
	table.clear(sc.suppressed)
end

-- ---------------------------------------------------------------- the manga effects' instances

-- one ScreenGui for every manga layer: lines (ZIndex 1) under bursts (2) under words (3), all under the white flash
local function mangaGui(sc)
	if sc.manga then
		return sc.manga
	end
	if not sc.env.playerGui then
		return nil
	end
	local gui = sc.make("ScreenGui", "CutsceneManga", nil)
	gui.IgnoreGuiInset = true
	gui.ScreenInsets = Enum.ScreenInsets.None
	gui.ResetOnSpawn = false
	gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	gui.DisplayOrder = 48 -- under the flash (49), the letterbox (50) and subtitles (51)
	gui.Parent = sc.env.playerGui
	sc.manga = gui
	return gui
end

-- where an effect sits on the screen, in pixels: spec.at / spec.focus as screen 0-1 ({x, y}) or studs from the
-- anchor ({x, y, z}), or a cast part (spec.follow, at = an offset in its space) projected through the camera.
-- The third value is false when the point is behind the camera.
function Screen.point(sc, spec)
	local cam = sc.env.camera
	local vp = cam.ViewportSize
	local at = spec.at or spec.focus
	local part = spec.follow and sc.env.follow and sc.env.follow(spec.follow)
	local world
	if part then
		local off = (type(at) == "table" and #at == 3) and Vector3.new(at[1], at[2], at[3]) or Vector3.zero
		world = part.CFrame:PointToWorldSpace(off)
	elseif type(at) == "table" and #at == 3 then
		world = (sc.env.anchor or CFrame.identity):PointToWorldSpace(Vector3.new(at[1], at[2], at[3]))
	elseif type(at) == "table" and #at == 2 then
		return at[1] * vp.X, at[2] * vp.Y, true
	else
		return 0.5 * vp.X, 0.5 * vp.Y, true
	end
	local v = cam:WorldToViewportPoint(world)
	return v.X, v.Y, v.Z > 0
end

local function label(gui, name, z)
	local l = Instance.new("ImageLabel")
	l.Name = name
	l.BackgroundTransparency = 1
	l.BorderSizePixel = 0
	l.AnchorPoint = Vector2.new(0.5, 0.5)
	l.ImageTransparency = 1
	l.ZIndex = z
	l.Parent = gui
	return l
end

local function drawLines(sc, ev, lt)
	local s, tex, gui = ev.spec, Screen.MANGA.lines, mangaGui(sc)
	if not (tex and gui) then
		return
	end
	if not ev.ui then
		ev.ui = {}
		local sets = (s.density or 0.4) >= 0.5 and 2 or 1
		for i = 1, 4 * sets do
			local l = label(gui, "FocusLines", 1)
			l.Image = tex.id
			l.ImageColor3 = Vfx.color(sc.pal, s.color or "white")
			ev.ui[i] = l
		end
	end
	local vp = sc.env.camera.ViewportSize
	local fx, fy, front = Screen.point(sc, s)
	local a = front and Screen.linesAlpha(lt, ev.life, s.alpha or 0.9) or 0
	local side, quads = Screen.quadrants(fx, fy, vp.X, vp.Y)
	local tick = Screen.tick(lt)
	for i, l in ipairs(ev.ui) do
		local q = quads[(i - 1) % 4 + 1]
		local x, y, size = Screen.cell(tex, tex.cells[Screen.pick(tick, i, #tex.cells) + 1])
		l.ImageRectOffset, l.ImageRectSize = Vector2.new(x, y), Vector2.new(size, size)
		l.Size = UDim2.fromOffset(side, side)
		l.Position = UDim2.fromOffset(q[1], q[2])
		l.Rotation = q[3]
		l.ImageTransparency = 1 - a
	end
end

local function drawBurst(sc, ev, lt)
	local s, gui = ev.spec, mangaGui(sc)
	if not gui then
		return
	end
	local tex = Screen.MANGA[s.image or "burst"]
	if not ev.ui then
		local l = label(gui, "Burst", 2)
		l.Image = tex and tex.id or tostring(s.image)
		l.ImageColor3 = Vfx.color(sc.pal, s.color or "white")
		ev.ui = { l }
	end
	local l, reduced = ev.ui[1], sc.env.reduced
	local x, y, front = Screen.point(sc, s)
	local px = (s.size or Screen.BURST_SIZE) * sc.env.camera.ViewportSize.Y * (reduced and 1 or Screen.burstScale(lt))
	l.Size = UDim2.fromOffset(px, px)
	l.Position = UDim2.fromOffset(x, y)
	l.Rotation = s.rot or 0
	if tex and tex.grid > 1 then
		local k = tex.cells[(reduced and 0 or Screen.tick(lt) % #tex.cells) + 1]
		local cx, cy, size = Screen.cell(tex, k)
		l.ImageRectOffset, l.ImageRectSize = Vector2.new(cx, cy), Vector2.new(size, size)
	end
	l.ImageTransparency = front and Screen.fadeOut(lt, ev.life, ev.life * Screen.BURST_FADE) or 1
end

local function drawWord(sc, ev, lt)
	local s, gui = ev.spec, mangaGui(sc)
	if not gui then
		return
	end
	if not ev.ui then
		local l = Instance.new("TextLabel")
		l.Name = "Word"
		l.BackgroundTransparency = 1
		l.AnchorPoint = Vector2.new(0.5, 0.5)
		l.AutomaticSize = Enum.AutomaticSize.XY
		l.Size = UDim2.fromOffset(0, 0)
		l.Text = tostring(s.text or "")
		l.TextSize = Screen.WORD_BASE
		local font = Screen.FONTS[s.font or ""] and s.font or Screen.FONT
		l.FontFace = Font.fromEnum(Enum.Font[font])
		local fill = Vfx.color(sc.pal, s.fill or "white")
		l.TextColor3 = fill
		l.TextTransparency = 1
		l.ZIndex = 3
		local stroke = nil
		local px = Screen.strokePx(s.stroke)
		if px > 0 then
			stroke = Instance.new("UIStroke")
			stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
			stroke.LineJoinMode = Enum.LineJoinMode.Miter
			stroke.Thickness = px -- never tweened (vault: it re-renders the glyphs): the UIScale pulses instead
			local light = 0.299 * fill.R + 0.587 * fill.G + 0.114 * fill.B
			stroke.Color = light > 0.5 and Color3.new(0, 0, 0) or Color3.new(1, 1, 1)
			stroke.Parent = l
		end
		local scale = Instance.new("UIScale")
		scale.Parent = l
		l.Parent = gui
		ev.ui = { l, scale, stroke }
	end
	local l, scale, stroke = ev.ui[1], ev.ui[2], ev.ui[3]
	local vpY = sc.env.camera.ViewportSize.Y
	local reduced = sc.env.reduced
	local x, y, front = Screen.point(sc, s)
	scale.Scale = (s.size or Screen.WORD_SIZE) * vpY / Screen.WORD_BASE * Screen.punch(lt, reduced)
	local jx, jy, jr = 0, 0, 0
	if not reduced and lt >= Screen.PUNCH_TIME then -- a tiny shake on twos while it holds
		local k = Screen.tick(lt)
		local amp = Screen.WORD_SHAKE * vpY
		jx, jy, jr = ((k * 7) % 3 - 1) * amp, ((k * 5 + 1) % 3 - 1) * amp, ((k * 11 + 2) % 3 - 1) * 1.5
	end
	l.Position = UDim2.fromOffset(x + jx, y + jy)
	l.Rotation = (s.rot or 0) + jr
	local tr = front and Screen.fadeOut(lt, ev.life, math.min(Screen.WORD_OUT, ev.life / 2)) or 1
	l.TextTransparency = tr
	if stroke then
		stroke.Transparency = tr
	end
end

local function card(sc)
	if sc.card then
		return sc.card
	end
	local p = sc.make("Part", "CutsceneBackdrop", nil)
	p.Anchored = true
	p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = false, false, false, false
	p.Transparency = 1
	p.Size = Vector3.new(1, 1, 0.05)
	local g = Instance.new("SurfaceGui")
	g.Name = "Card"
	g.Face = Enum.NormalId.Back -- the camera looks down the card's -Z: its +Z face is toward the lens
	g.LightInfluence = 0 -- flat: the set's red light never tints the panel
	g.Brightness = 1
	g.SizingMode = Enum.SurfaceGuiSizingMode.FixedSize
	g.CanvasSize = Vector2.new(1820, 1024)
	g.ClipsDescendants = true
	g.Enabled = false
	local img = Instance.new("ImageLabel")
	img.Name = "Image"
	img.Size = UDim2.fromScale(1, 1)
	img.BorderSizePixel = 0
	img.ScaleType = Enum.ScaleType.Crop
	img.Parent = g
	g.Parent = p
	p.Parent = sc.env.world or sc.env.camera
	sc.card = { part = p, gui = g, img = img }
	return sc.card
end

-- each cast member's farthest point along the camera's view (only those reaching in front of it)
local function castDepths(sc, cf)
	local out, look = {}, cf.LookVector
	for _, model in pairs(sc.env.cast or {}) do
		if typeof(model) == "Instance" and model:IsA("Model") and model.Parent then
			local bcf, size = model:GetBoundingBox()
			local far = -math.huge
			for _, sx in ipairs({ -0.5, 0.5 }) do
				for _, sy in ipairs({ -0.5, 0.5 }) do
					for _, sz in ipairs({ -0.5, 0.5 }) do
						local p = bcf:PointToWorldSpace(Vector3.new(sx * size.X, sy * size.Y, sz * size.Z))
						far = math.max(far, (p - cf.Position):Dot(look))
					end
				end
			end
			if far > 0 then
				table.insert(out, far)
			end
		end
	end
	return out
end

local function drawBackdrop(sc, spec)
	local c = card(sc)
	if c.spec ~= spec then
		c.spec = spec
		local tex = Screen.MANGA[spec.image or ""]
		local image = tex and tex.id or spec.image
		c.img.Image = image or ""
		c.img.ImageTransparency = image and 0 or 1
		c.img.ImageColor3 = (image and spec.color) and Vfx.color(sc.pal, spec.color) or Color3.new(1, 1, 1)
		c.img.BackgroundColor3 = spec.color and Vfx.color(sc.pal, spec.color) or Color3.new(0, 0, 0)
		c.img.BackgroundTransparency = image and 1 or 0
	end
	local cam = sc.env.camera
	local cf = cam.CFrame
	local vp = cam.ViewportSize
	local aspect = vp.Y > 0 and vp.X / vp.Y or 16 / 9
	local depth = Screen.cardDepth(spec.dist, castDepths(sc, cf))
	local w, h = Screen.cardSize(depth, cam.FieldOfView, aspect)
	c.part.Size = Vector3.new(w, h, 0.05)
	c.part.CFrame = cf * CFrame.new(0, 0, -depth)
	c.gui.CanvasSize = Vector2.new(math.floor(1024 * aspect + 0.5), 1024)
	c.gui.Enabled = true
	c.depth = depth
end

local function stepLights(sc)
	local camPos = sc.env.camera.CFrame.Position
	for _, l in ipairs(sc.lights or {}) do
		if l.att.Parent and l.root.Parent then
			local head = l.model:FindFirstChild("Head")
			local pos = (head and head:IsA("BasePart")) and head.Position or l.root.Position
			local d = camPos - pos
			if d.Magnitude > 0.01 then
				local at = pos + d.Unit * Screen.CASTLIGHT_AHEAD + Vector3.new(0, 1, 0)
				l.att.Position = l.root.CFrame:PointToObjectSpace(at)
			end
		end
	end
end

local function dropUi(ev)
	for _, inst in pairs(ev.ui or {}) do
		inst:Destroy()
	end
	ev.ui = nil
end

local DRAW = { speedlines = drawLines, burst = drawBurst, word = drawWord }

-- applies everything due at timeline time t (the Director calls it every frame, after the camera)
function Screen.step(sc, t)
	local b = sc.base
	local bright, contrast, sat, tint = b.bright, b.contrast, b.sat, b.tint
	local bloom, bloomSize, bloomThreshold = 0, 24, 2
	local flash = 0
	local impact, focus, backdrop = nil, nil, nil
	for i = #sc.events, 1, -1 do
		local ev = sc.events[i]
		local lt = t - ev.t
		local s = ev.spec
		if ev.kind == "grade" then
			local k = Screen.envelope(lt, s.attack, s.hold, s.release)
			bright += (s.bright or 0) * k
			contrast += (s.contrast or 0) * k
			sat += (s.sat or 0) * k
			if s.tint then
				tint = tint:Lerp(Vfx.color(sc.pal, s.tint), (s.mix or 0.2) * k)
			end
			if over(lt, s) then
				table.remove(sc.events, i)
			end
		elseif ev.kind == "bloom" then
			local k = Screen.envelope(lt, s.attack, s.hold, s.release)
			if k * (s.intensity or 1) > bloom then
				bloom = k * (s.intensity or 1)
				bloomSize = s.size or 24
				bloomThreshold = 2 + ((s.threshold or 0.8) - 2) * k
			end
			if over(lt, s) then
				table.remove(sc.events, i)
			end
		elseif ev.kind == "flash" then
			if lt >= 0 then
				local x = lt / Screen.FLASH_LIFE
				if x >= 1 then
					table.remove(sc.events, i)
				else
					flash = math.max(flash, ev.power * (1 - x) ^ 2)
				end
			end
		elseif ev.kind == "impact" then
			local phase = Screen.impactPhase(ev.t, t)
			if phase == "done" then
				table.remove(sc.events, i)
				-- the flash after the silhouettes belongs to the same impact: it isn't counted again
				table.insert(sc.events, { kind = "flash", t = ev.t + 2 * Screen.IMPACT_FRAME, power = Screen.AFTER_IMPACT })
			elseif phase then
				impact = { ev = ev, phase = phase }
			end
		elseif ev.kind == "focus" then
			local k = Screen.envelope(lt, s.attack, s.hold, s.release)
			if k > 0 then
				focus = { spec = s, k = k }
			end
			if over(lt, s) then
				table.remove(sc.events, i)
			end
		elseif DRAW[ev.kind] then
			if lt > ev.life then
				table.remove(sc.events, i)
				dropUi(ev)
			elseif lt >= 0 then
				DRAW[ev.kind](sc, ev, lt)
			end
		elseif ev.kind == "backdrop" then
			if lt > ev.life then
				table.remove(sc.events, i)
			elseif lt >= 0 and (not backdrop or ev.t >= backdrop.t) then
				backdrop = ev -- the latest one started shows
			end
		end
	end
	local g = sc.grade
	g.Brightness, g.Contrast, g.Saturation = math.clamp(bright, -1, 1), math.clamp(contrast, -1, 1), math.clamp(sat, -1, 1)
	g.TintColor = tint
	if impact then
		showImpact(sc, impact.ev, impact.phase)
	elseif sc.impactCC.Enabled or #sc.highlights > 0 then
		hideImpact(sc)
	end
	sc.bloom.Enabled = bloom > 0.01
	sc.bloom.Intensity, sc.bloom.Size, sc.bloom.Threshold = bloom, bloomSize, bloomThreshold
	if sc.flashFrame then
		sc.flashFrame.BackgroundTransparency = 1 - math.clamp(flash, 0, 1)
	end
	if focus then
		if not sc.dof then
			sc.dof = sc.make("DepthOfFieldEffect", "CutsceneFocus", sc.env.camera)
		end
		local s = focus.spec
		sc.dof.Enabled = true
		sc.dof.FocusDistance = s.dist or 10
		sc.dof.InFocusRadius = s.radius or 6
		sc.dof.FarIntensity = (s.far or 0.6) * focus.k
		sc.dof.NearIntensity = (s.near or 0) * focus.k
	elseif sc.dof then
		sc.dof.Enabled = false
	end
	if backdrop then
		drawBackdrop(sc, backdrop.spec)
	elseif sc.card then
		sc.card.gui.Enabled = false
	end
	stepLights(sc)
end

-- puts back the Highlights an impact switched off and takes every manga layer down (the Snapshot destroys what
-- Screen made)
function Screen.clear(sc)
	hideImpact(sc)
	for _, ev in ipairs(sc.events) do
		dropUi(ev)
	end
	if sc.card then
		sc.card.gui.Enabled = false
	end
	for _, l in ipairs(sc.lights or {}) do
		l.att:Destroy()
	end
	sc.lights = {}
	table.clear(sc.events)
end

return Screen
