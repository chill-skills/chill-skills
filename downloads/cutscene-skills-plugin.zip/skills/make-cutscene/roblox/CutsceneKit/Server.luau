-- Server side of CutsceneKit: zones, prompts, scheduling, replay memory, cooldowns, awakenings and the awakened state,
-- protection while watching. The server only schedules (attributes on the Player, or on an NPC caster); clients play.
-- Method by fwjelaa (FWJ STUDIOS).
local CollectionService = game:GetService("CollectionService")
local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ProximityPromptService = game:GetService("ProximityPromptService")
local RunService = game:GetService("RunService")
local StarterPlayer = game:GetService("StarterPlayer")

local Data = require(script.Parent.Data)
local Schedule = require(script.Parent.Schedule)
local Zones = require(script.Parent.Zones)

local Server = {}
Server.ZONE_HZ = 4 -- zone checks per second (vault: 2-5 Hz on the server)
Server.STORE = "CutsceneKit_Seen_v1"
Server.MAX_PROTECT = 60
Server.END_GRACE = 0.5
Server.ATTRS = { "CutsceneLock", "CutsceneName", "CutsceneAnchor", "CutsceneDuration", "CutsceneStartAt" }
Server.AWAKENED = { "Awakened", "AwakenedAt", "AwakenedEndsAt", "AwakenedEnd" }
Server.TAG = "CutsceneCaster" -- NPC casters: every client plays their scenes as an onlooker and draws their aura
Server.MAX_AWAKENED = 600 -- s: the longest awakened state
Server.GROUND_PROBE = 50 -- studs below the root an awakening looks for the floor
-- client results ("Ended" remote) for a scene that never played: it is un-marked so it can play again
Server.NEVER_PLAYED = { ["load-failed"] = true, error = true, invalid = true, late = true }
-- Zone and prompt starts are client requests (the client moves the root and presses the prompt), so a live server rate
-- limits them; the server API (CutsceneKit.Play) is the game's own code and is not, and neither is a Studio play test.
Server.SCENE_GAP = 15 -- s between two zone/prompt starts of one scene by one player, counted from the earlier start (an
-- early Ended can't shorten it), and never shorter than that scene's own run
Server.STARTS_PER_MINUTE = 6 -- zone/prompt starts per player in any 60 s
Server.MAX_UNMARKS = 2 -- per player, scene and visit: how often an Ended (NEVER_PLAYED) may make a scene playable again
Server.SAVE_DELAY = 10 -- s: a player's seen-list changes are written together, one write per window (and one at leave)
Server.CLOSE_WAIT = 20 -- s the server waits at shutdown for those writes
Server.SHIELD_END = "CutsceneShieldUntil" -- on the shield: the server time it ends at (the scene's scheduled end)

local seenForever = {} -- [userId] = { [name] = true }: saved scenes this player has seen
local stored = {} -- [userId] = { [name] = true }: what the DataStore holds (join's read, then each write); nil = unknown
local pending = {} -- [userId] = { [name] = true | false }: changes the DataStore doesn't have yet
local saving = {} -- [userId] = true while a batched write is scheduled
local inflight = 0 -- writes running now
local loaded = {} -- [userId] = true once join's read finished (or failed)
local visits = setmetatable({}, { __mode = "k" }) -- [player] = this visit's zone/prompt starts and un-marks
local warned = {}
local store -- nil = not tried yet, false = unavailable
local cooldowns = setmetatable({}, { __mode = "k" }) -- [subject] = { [name] = server time it is ready again }
local pinned = setmetatable({}, { __mode = "k" }) -- [subject] = { root = BasePart, was = bool }
local npcTracks = setmetatable({}, { __mode = "k" }) -- [NPC caster] = AnimationTrack
local deathHooked = setmetatable({}, { __mode = "k" }) -- [Humanoid] = true

function Server.say(msg)
	warn("CutsceneKit: " .. msg)
end

local function warnOnce(key, msg)
	if not warned[key] then
		warned[key] = true
		Server.say(msg)
	end
end

function Server.isStudio()
	return RunService:IsStudio()
end

local function visit(player)
	local v = visits[player]
	if not v then
		v = { starts = {}, last = {}, unmarks = {} }
		visits[player] = v
	end
	return v
end

-- server clock; falls back to os.clock() where GetServerTimeNow isn't available (Edit-mode tests)
function Server.now()
	local ok, t = pcall(workspace.GetServerTimeNow, workspace)
	return ok and t or os.clock()
end

function Server.userId(player)
	if player:IsA("Player") then
		return player.UserId
	end
	return player:GetAttribute("UserId") or 0
end

-- a Player's character; an NPC caster (a Model with a Humanoid) is its own character; a stand-in player in Edit-mode
-- tests keeps its character as a child named Character
function Server.characterOf(subject)
	if subject:IsA("Player") then
		return subject.Character
	end
	if subject:IsA("Model") and subject:FindFirstChildOfClass("Humanoid") then
		return subject
	end
	return subject:FindFirstChild("Character")
end

local function character(player)
	return Server.characterOf(player)
end

-- the Player a character Model belongs to, or nil
function Server.ownerOf(model)
	return Players:GetPlayerFromCharacter(model)
end

-- who a call is about: a player's character Model resolves to its Player (never an NPC caster); nil for a non-Instance
function Server.subjectOf(subject)
	if typeof(subject) ~= "Instance" then
		return nil
	end
	if subject:IsA("Model") then
		return Server.ownerOf(subject) or subject
	end
	return subject
end

Server.BAD_SUBJECT = "the subject must be a Player or an NPC Model with a Humanoid"

-- an NPC caster is a Model with a Humanoid that is its own character and no player's character (not a Player, not a
-- test stand-in); it has no seen-list and no DataStore key
local function isNpc(subject)
	return not subject:IsA("Player") and Server.characterOf(subject) == subject and Server.ownerOf(subject) == nil
end

function Server.shouldPlay(replay, seenSession, seenSaved)
	if replay == "always" then
		return true
	end
	if replay == "session" then
		return not seenSession
	end
	return not (seenSession or seenSaved)
end

function Server.module(name)
	local folder = ReplicatedStorage:FindFirstChild("Cutscenes")
	return folder and folder:FindFirstChild(name)
end

function Server.zoneAnchor(name)
	local folder = workspace:FindFirstChild("CutsceneZones")
	for _, z in ipairs(folder and folder:GetChildren() or {}) do
		if z:IsA("BasePart") and z:GetAttribute("Cutscene") == name then
			return Zones.anchor(z)
		end
	end
	return nil
end

local function getStore()
	if store == nil then
		local ok, s = pcall(DataStoreService.GetDataStore, DataStoreService, Server.STORE)
		store = ok and s or false
	end
	return store or nil
end

-- Edit-mode tests: a stand-in DataStore (nil = the real one again, false = none)
function Server.useStore(s)
	store = s
end

-- Writes a player's pending seen-list changes in one UpdateAsync.
function Server.flush(uid)
	local changes = pending[uid]
	pending[uid] = nil
	local s = changes and getStore()
	if not s then
		return
	end
	inflight += 1
	local ok, err = pcall(s.UpdateAsync, s, tostring(uid), function(old)
		old = type(old) == "table" and old or {}
		for name, v in pairs(changes) do
			old[name] = v or nil
		end
		return old
	end)
	inflight -= 1
	if not ok then
		warnOnce("save", "could not save which scenes were seen (" .. tostring(err) .. ")")
		return
	end
	local base = stored[uid]
	if base then
		for name, v in pairs(changes) do
			base[name] = v or nil
		end
	end
end

-- Only a real change is queued: setting what the DataStore already holds cancels a pending change instead.
local function queue(uid, name, value)
	local base = stored[uid]
	local changes = pending[uid] or {}
	if base and (base[name] == true) == value then
		changes[name] = nil
	else
		changes[name] = value
	end
	pending[uid] = next(changes) ~= nil and changes or nil
	if pending[uid] and not saving[uid] then
		saving[uid] = true
		task.delay(Server.SAVE_DELAY, function()
			saving[uid] = nil
			Server.flush(uid)
		end)
	end
end

-- BindToClose: the writes still pending when the server shuts down
function Server.flushAll()
	for uid in pairs(pending) do
		task.spawn(Server.flush, uid)
	end
	local waited = 0
	while inflight > 0 and waited < Server.CLOSE_WAIT do
		waited += task.wait(0.1)
	end
end

function Server.join(player)
	local uid = Server.userId(player)
	seenForever[uid] = seenForever[uid] or {}
	local s = getStore()
	if not s then
		warnOnce("store", "DataStores unavailable: 'saved' scenes play once per server visit")
		loaded[uid] = true
		return
	end
	local ok, data = pcall(s.GetAsync, s, tostring(uid))
	local mine = seenForever[uid]
	if not mine then
		return -- the player left during the read
	end
	if ok then
		local base = {}
		for name, v in pairs(type(data) == "table" and data or {}) do
			if v then
				mine[name] = true
				base[name] = true
			end
		end
		stored[uid] = base
	else
		warnOnce("store", "could not read which scenes were seen (" .. tostring(data) .. "): 'saved' scenes play once per server visit")
	end
	loaded[uid] = true
end

function Server.leave(player)
	local uid = Server.userId(player)
	visits[player] = nil
	task.spawn(Server.flush, uid)
	seenForever[uid] = nil
	stored[uid] = nil
	loaded[uid] = nil
end

function Server.markSeen(player, name, replay)
	player:SetAttribute("CutsceneSeen_" .. name, true)
	if replay == "saved" and not isNpc(player) then -- an NPC has no DataStore key (userId would fall back to 0)
		local uid = Server.userId(player)
		local mine = seenForever[uid] or {}
		seenForever[uid] = mine
		if not mine[name] then
			mine[name] = true
			queue(uid, name, true)
		end
	end
end

-- trusted: the server API's Forget. When the DataStore's copy is unknown (join hasn't read it, or the read failed) it
-- writes anyway; a client's Ended only takes back what this visit marked.
local function unmark(player, name, trusted)
	player:SetAttribute("CutsceneSeen_" .. name, nil)
	if isNpc(player) then
		return -- an NPC has no DataStore key
	end
	local uid = Server.userId(player)
	local mine = seenForever[uid]
	if mine and mine[name] then
		mine[name] = nil
		queue(uid, name, false)
	elseif trusted and stored[uid] == nil then
		queue(uid, name, false)
	end
end

function Server.forget(player, name)
	player = Server.subjectOf(player)
	if not player then
		return false, Server.BAD_SUBJECT
	end
	unmark(player, name, true)
	local v = visits[player]
	if v then
		v.last[name] = nil -- the game asked for this scene again: no gap, and its retries back
		v.unmarks[name] = nil
	end
	return true
end

-- The shield ends at the scene's scheduled end: its own timer, and Server.expire on every zone tick as the backstop.
-- A shield left from an earlier scene is replaced, never inherited.
function Server.protect(player, untilAt)
	local char = character(player)
	if not char then
		return
	end
	local old = char:FindFirstChild("CutsceneShield")
	if old then
		old:Destroy()
	end
	local ff = Instance.new("ForceField")
	ff.Name = "CutsceneShield"
	ff.Visible = false
	ff:SetAttribute(Server.SHIELD_END, untilAt)
	ff.Parent = char
	task.delay(math.max(0, untilAt - Server.now()), function()
		if ff.Parent then
			ff:Destroy()
		end
	end)
end

function Server.expire(player)
	local char = character(player)
	local ff = char and char:FindFirstChild("CutsceneShield")
	if ff then
		local untilAt = ff:GetAttribute(Server.SHIELD_END)
		if type(untilAt) ~= "number" or Server.now() >= untilAt then
			ff:Destroy()
		end
	end
end

function Server.release(player)
	for _, a in ipairs(Server.ATTRS) do
		player:SetAttribute(a, nil)
	end
	local char = character(player)
	local ff = char and char:FindFirstChild("CutsceneShield")
	if ff then
		ff:Destroy()
	end
	Server.unpin(player)
	local tr = npcTracks[player]
	if tr then
		npcTracks[player] = nil
		pcall(tr.Stop, tr, 0.2)
	end
end

-- "too soon" (the same scene inside its gap), "too often" (STARTS_PER_MINUTE used up) or nil
local function tooFast(player, name, now)
	local v = visit(player)
	local last = v.last[name]
	if last and now < last.at + math.max(Server.SCENE_GAP, last.span) then
		return "too soon"
	end
	local recent = {}
	for _, at in ipairs(v.starts) do
		if now - at < 60 then
			table.insert(recent, at)
		end
	end
	v.starts = recent
	return #recent >= Server.STARTS_PER_MINUTE and "too often" or nil
end

local function refuse(player, why)
	local v = visit(player)
	if not v.logged then
		v.logged = true
		Server.say(("%s starts scenes faster than allowed (%s): refused, and not logged again for this player")
			:format(player.Name, why))
	end
	return false, why
end

-- s from the decision until the server frees the subject: the lead, the protected run, the grace
local function span(data)
	return Schedule.LEAD + math.min(data.Length, Server.MAX_PROTECT) + Server.END_GRACE
end

local function start(player, name, anchor, limited)
	local data, problem = Server.load(name)
	if not data then
		return false, problem
	end
	if data.Kind ~= "story" and data.Kind ~= "intro" then
		return false, data.Kind .. " scenes start with Awaken/Ultimate"
	end
	if player:GetAttribute("CutsceneLock") then
		return false, "busy"
	end
	local cfg = Data.config(data)
	local uid = Server.userId(player)
	-- CutsceneKitTestLoaded: Edit-mode tests' stand-in players never go through join
	if cfg.Replay == "saved" and not loaded[uid] and player:GetAttribute("CutsceneKitTestLoaded") ~= true then
		return false, "loading" -- join is still reading the saved history
	end
	local savedSeen = seenForever[uid] ~= nil and seenForever[uid][name] == true
	if not Server.shouldPlay(cfg.Replay, player:GetAttribute("CutsceneSeen_" .. name) == true, savedSeen) then
		return false, "seen"
	end
	local wait = Server.cooldownLeft(player, name)
	if wait > 0 then
		return false, "cooldown", wait
	end
	anchor = anchor or Server.zoneAnchor(name)
	if typeof(anchor) ~= "CFrame" then
		return false, "no anchor: add a zone for it in Workspace.CutsceneZones or pass a CFrame"
	end
	if limited and not Server.isStudio() then -- the kit's own play tests start scenes back to back in Studio
		local now = Server.now()
		local why = tooFast(player, name, now)
		if why then
			return refuse(player, why)
		end
		local v = visit(player)
		v.last[name] = { at = now, span = span(data) }
		table.insert(v.starts, now)
	end
	Server.schedule(player, name, data, cfg, anchor)
	return true
end

-- The server API (CutsceneKit.Play): the game's own code, not rate limited.
function Server.play(player, name, anchor)
	player = Server.subjectOf(player)
	if not player then
		return false, Server.BAD_SUBJECT
	end
	return start(player, name, anchor, false)
end

-- A zone entry or prompt press: the client's request, rate limited on a live server (SCENE_GAP, STARTS_PER_MINUTE).
function Server.request(player, name, anchor)
	return start(player, name, anchor, true)
end

-- seconds until this subject may start this scene again (0 = now)
function Server.cooldownLeft(subject, name)
	local mine = cooldowns[subject]
	local ready = mine and mine[name]
	return ready and math.max(0, ready - Server.now()) or 0
end

function Server.setCooldown(subject, name, readyAt)
	cooldowns[subject] = cooldowns[subject] or {}
	cooldowns[subject][name] = readyAt
	subject:SetAttribute("CutsceneReady_" .. name, readyAt) -- a game's UI can show the cooldown from this
end

function Server.standHeight(char)
	local hum = char:FindFirstChildOfClass("Humanoid")
	local root = char:FindFirstChild("HumanoidRootPart")
	if hum and root and hum.RigType == Enum.HumanoidRigType.R15 then
		return hum.HipHeight + root.Size.Y / 2
	end
	return 3
end

-- An awakening plays where the caster stands: the floor under the root, facing the root's way (yaw only).
function Server.groundAnchor(root, ignore)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { ignore }
	params.RespectCanCollide = true
	local hit = workspace:Raycast(root.Position, Vector3.new(0, -Server.GROUND_PROBE, 0), params)
	local y = hit and hit.Position.Y or (root.Position.Y - 3)
	local look = root.CFrame.LookVector
	local yaw = math.atan2(-look.X, -look.Z)
	return CFrame.new(root.Position.X, y, root.Position.Z) * CFrame.Angles(0, yaw, 0)
end

-- holds the caster at its place for the scene (spec 6: the character is anchored at the anchor)
function Server.pin(subject, char, anchor, place)
	local root = char:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end
	local p = place or { 0, 0, 0, 0, 0, 0 }
	if not pinned[subject] then
		pinned[subject] = { root = root, was = root.Anchored }
	end
	root.Anchored = true
	char.PrimaryPart = char.PrimaryPart or root
	char:PivotTo(anchor * CFrame.new(p[1], p[2] + Server.standHeight(char), p[3])
		* CFrame.Angles(math.rad(p[4] or 0), math.rad(p[5] or 0), math.rad(p[6] or 0)))
end

function Server.unpin(subject)
	local pin = pinned[subject]
	pinned[subject] = nil
	if pin and pin.root.Parent then
		pin.root.Anchored = pin.was
	end
end

-- the data module, checked: data, or nil and why (the same answers as Server.play)
function Server.load(name)
	if type(name) ~= "string" or not string.match(name, "^[%w_]+$") or #name > 60 then
		return nil, "cutscene names may only use letters, digits and _"
	end
	local module = Server.module(name)
	if not module then
		return nil, "no such cutscene: " .. tostring(name)
	end
	local okReq, data = pcall(require, module)
	if not okReq then
		return nil, "cutscene module errored: " .. tostring(data)
	end
	local ok, problems = Data.validate(data)
	if not ok then
		warn("CutsceneKit: " .. name .. " is invalid: " .. table.concat(problems, "; "))
		return nil, "invalid: " .. table.concat(problems, "; ")
	end
	return data
end

-- Sets the scene's attributes (clients start from them) and everything that goes with it; returns StartAt. Every scene
-- start goes through here (Server.play, Server.request, Server.awaken).
function Server.schedule(subject, name, data, cfg, anchor)
	if workspace.StreamingEnabled and subject:IsA("Player") then
		-- load the scene's surroundings before the first frame (no guarantee, so never wait on it)
		task.spawn(pcall, subject.RequestStreamAroundAsync, subject, anchor.Position, Schedule.LEAD)
	end
	local startAt = Schedule.startAt(Server.now())
	local protected = math.min(data.Length, Server.MAX_PROTECT)
	subject:SetAttribute("CutsceneLock", name)
	subject:SetAttribute("CutsceneName", name)
	subject:SetAttribute("CutsceneAnchor", anchor)
	subject:SetAttribute("CutsceneDuration", data.Length)
	subject:SetAttribute("CutsceneStartAt", startAt) -- last: clients start when this one changes
	task.delay(span(data), function()
		if subject.Parent and subject:GetAttribute("CutsceneStartAt") == startAt then
			Server.release(subject)
		end
	end)
	local okState, err = pcall(function()
		Server.markSeen(subject, name, cfg.Replay)
		Server.protect(subject, startAt + protected)
		if (cfg.Cooldown or 0) > 0 then
			Server.setCooldown(subject, name, startAt + cfg.Cooldown)
		end
	end)
	if not okState then
		warnOnce("state:" .. name, name .. ": could not record or protect the scene (" .. tostring(err) .. ")")
	end
	return startAt
end

-- the awakened state (spec 6): every client draws the aura from these attributes, then the power-down at EndsAt
function Server.startAwakened(subject, name, data, cfg, startAt)
	local a = cfg.Awakened
	local at = startAt + math.clamp(a.At, 0, data.Length)
	local endsAt = startAt + data.Length + math.min(a.Duration, Server.MAX_AWAKENED)
	subject:SetAttribute("AwakenedEnd", "expire")
	subject:SetAttribute("AwakenedAt", at)
	subject:SetAttribute("AwakenedEndsAt", endsAt)
	subject:SetAttribute("Awakened", name)
	task.delay(math.max(0, endsAt - Server.now()), function()
		if subject.Parent and subject:GetAttribute("AwakenedAt") == at and subject:GetAttribute("Awakened") == name then
			subject:SetAttribute("Awakened", nil) -- AwakenedEnd stays "expire": clients play the power-down
		end
	end)
end

-- an NPC caster's clip plays on the server, so it replicates to every client (a player's clip plays on its own client)
function Server.playNpc(model, data, startAt)
	local label = tostring(data.Name or model.Name)
	local hum = model:FindFirstChildOfClass("Humanoid")
	local rig = hum and (hum.RigType == Enum.HumanoidRigType.R6 and "R6" or "R15")
	local ref = rig and data.Anims[rig] and data.Anims[rig].player
	if type(ref) ~= "string" or not string.match(ref, "^rbxassetid://%d+$") then
		warnOnce("npcclip:" .. label, ("%s: an NPC caster plays only uploaded clips (rbxassetid): run upload"):format(label))
		return
	end
	local animator = hum:FindFirstChildOfClass("Animator")
	if not animator then
		animator = Instance.new("Animator")
		animator.Parent = hum
	end
	local anim = Instance.new("Animation")
	anim.AnimationId = ref
	local ok, track = pcall(animator.LoadAnimation, animator, anim)
	if not ok then
		warnOnce("npcload:" .. label, ("%s: the NPC clip did not load (%s)"):format(label, tostring(track)))
		return
	end
	track.Looped = false
	track.Priority = Enum.AnimationPriority.Action4
	npcTracks[model] = track
	task.delay(math.max(0, startAt - Server.now()), function()
		if npcTracks[model] == track then
			track:Play(0)
		end
	end)
end

function Server.onDied(subject)
	if subject:GetAttribute("Awakened") then
		subject:SetAttribute("AwakenedEnd", "died") -- clients drop the aura at once: no power-down on a body
		subject:SetAttribute("Awakened", nil)
	end
	if subject:GetAttribute("CutsceneLock") then
		Server.release(subject)
	end
end

-- char died or is being removed: only the subject's current body ends its state (a game that swaps Player.Character
-- and keeps the old body alive must not let that body's later death end the new body's awakening)
function Server.bodyGone(subject, char)
	if Server.characterOf(subject) == char then
		Server.onDied(subject)
	end
end

local function hookDeath(subject, char)
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	if hum and not deathHooked[hum] then
		deathHooked[hum] = true
		hum.Died:Connect(function()
			Server.bodyGone(subject, char)
		end)
	end
end
Server.hookDeath = hookDeath

-- CutsceneKit.Awaken (spec 6): the awakening cinematic for subject (a Player, or an NPC Model with a Humanoid) where
-- it stands, then the awakened state. Returns true, or false and why ("cooldown" also returns the seconds left).
-- A player's character Model counts as that player (Server.subjectOf); anything that isn't an Instance is refused.
function Server.awaken(subject, name, anchor)
	subject = Server.subjectOf(subject)
	if not subject then
		return false, Server.BAD_SUBJECT
	end
	local data, why = Server.load(name)
	if not data then
		return false, why
	end
	if data.Kind ~= "awakening" then
		return false, ("%s is a %s scene: start it with %s"):format(name, data.Kind, data.Kind == "ultimate" and "Ultimate" or "Play")
	end
	local char = Server.characterOf(subject)
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	local root = char and char:FindFirstChild("HumanoidRootPart")
	if not hum or not root or hum.Health <= 0 then
		return false, "no living character"
	end
	if subject:GetAttribute("CutsceneLock") then
		return false, "busy"
	end
	if subject:GetAttribute("Awakened") then
		return false, "awakened"
	end
	local cfg = Data.config(data)
	local wait = Server.cooldownLeft(subject, name)
	if wait > 0 then
		return false, "cooldown", wait
	end
	if subject:IsA("Player") and cfg.Replay ~= "always" then
		local uid = Server.userId(subject)
		if cfg.Replay == "saved" and not loaded[uid] then
			return false, "loading" -- join is still reading the saved history (as Server.play)
		end
		local savedSeen = seenForever[uid] ~= nil and seenForever[uid][name] == true
		if not Server.shouldPlay(cfg.Replay, subject:GetAttribute("CutsceneSeen_" .. name) == true, savedSeen) then
			return false, "seen"
		end
	end
	anchor = typeof(anchor) == "CFrame" and anchor or Server.groundAnchor(root, char)
	local startAt = Server.schedule(subject, name, data, cfg, anchor)
	Server.pin(subject, char, anchor, data.Places and data.Places.player)
	Server.startAwakened(subject, name, data, cfg, startAt)
	hookDeath(subject, char)
	if isNpc(subject) then
		CollectionService:AddTag(subject, Server.TAG)
		Server.playNpc(subject, data, startAt)
	end
	return true
end

-- CutsceneKit.EndAwakening: the power-down now (or right after the cinematic, if it is still playing)
function Server.endAwakening(subject)
	subject = Server.subjectOf(subject)
	if not subject then
		return false, Server.BAD_SUBJECT
	end
	if not subject:GetAttribute("Awakened") then
		return false, "not awakened"
	end
	local at = subject:GetAttribute("AwakenedAt")
	local sceneEnd = 0
	if subject:GetAttribute("CutsceneLock") == subject:GetAttribute("Awakened") then
		sceneEnd = (subject:GetAttribute("CutsceneStartAt") or 0) + (subject:GetAttribute("CutsceneDuration") or 0)
	end
	local endsAt = math.max(Server.now(), sceneEnd)
	subject:SetAttribute("AwakenedEnd", "ended")
	subject:SetAttribute("AwakenedEndsAt", endsAt)
	task.delay(math.max(0, endsAt - Server.now()), function()
		if subject.Parent and subject:GetAttribute("AwakenedAt") == at then
			subject:SetAttribute("Awakened", nil)
		end
	end)
	return true
end

-- An unskippable scene (Config.Skip false: awakenings, ultimates) runs to its end on the server. True while a client's
-- Ended must not free the subject yet: before StartAt + Length - Schedule.END_SLACK. Death, respawn and the server's own
-- timer still release it; a skippable scene, or one whose module can't be read, never holds.
function Server.holdsToEnd(name, startAt)
	local module = Server.module(name)
	local ok, data = pcall(require, module)
	if not ok or type(data) ~= "table" or type(data.Length) ~= "number" then
		return false
	end
	return Data.config(data).Skip == false and Server.now() < startAt + data.Length - Schedule.END_SLACK
end

-- The client's own scene ended early (or ended normally before the server's timer): free the player at once. That only
-- shortens the client's own protection, except for an unskippable scene, whose caster stays pinned and locked until its
-- end (Server.holdsToEnd: a client can't cancel its own wind-up). Making the scene playable again is bounded:
-- MAX_UNMARKS per scene and visit, and only those un-marks let a retry skip the gap; after that the report only frees the
-- player.
function Server.ended(player, name, startAt, reason)
	if type(name) ~= "string" or type(startAt) ~= "number" or type(reason) ~= "string" then
		return
	end
	if player:GetAttribute("CutsceneLock") ~= name or player:GetAttribute("CutsceneStartAt") ~= startAt then
		return -- an old scene, or another scene's report
	end
	if not Server.holdsToEnd(name, startAt) then
		Server.release(player)
	end
	if not Server.NEVER_PLAYED[reason] then
		return
	end
	local v = visit(player)
	local n = v.unmarks[name] or 0
	if n >= Server.MAX_UNMARKS then
		if not v.unmarkLogged then
			v.unmarkLogged = true
			Server.say(("%s: %s ended as %s again; it stays marked seen this visit (%d retries at most)")
				:format(player.Name, name, reason, Server.MAX_UNMARKS))
		end
		return
	end
	v.unmarks[name] = n + 1
	v.last[name] = nil -- it never played: the retry needn't wait out the gap
	unmark(player, name, false) -- marked seen when scheduled, but it never played: let it play again
end

function Server.onRemote(player, action, name, startAt, reason)
	if type(action) ~= "string" then
		return
	end
	if action == "Ended" then
		Server.ended(player, name, startAt, reason)
		return
	end
	if action ~= "Skip" or type(name) ~= "string" then
		return
	end
	if player:GetAttribute("CutsceneLock") ~= name then
		return
	end
	local scheduled = player:GetAttribute("CutsceneStartAt") -- the server's own time, never the client's
	local module = Server.module(name)
	if not module or type(scheduled) ~= "number" then
		return
	end
	local okReq, data = pcall(require, module)
	if not okReq then
		return
	end
	local cfg = Data.config(data)
	if cfg.Skip and Server.now() - scheduled >= cfg.Skip - 0.25 then
		Server.release(player)
	end
end

function Server.api(action, ...)
	if action == "Play" then
		return Server.play(...)
	elseif action == "Awaken" then
		return Server.awaken(...)
	elseif action == "EndAwakening" then
		return Server.endAwakening(...)
	elseif action == "Forget" then
		return Server.forget(...)
	elseif action == "Release" then
		Server.release(...)
		return true
	end
	return false, "unknown action " .. tostring(action)
end

-- A trigger part whose Trigger attribute is "prompt" or "api" only holds the scene's anchor; it is not a zone.
function Server.zoneTriggers(zone)
	local trigger = zone:GetAttribute("Trigger")
	return trigger == nil or trigger == "zone"
end

-- The optional ProximityPrompt trigger (spec 6): a prompt with a Cutscene attribute starts that scene at the scene's
-- zone anchor. The press is a client request, so onPrompt checks everything itself (as the zone path does with the
-- server-side root position) and only then goes through Server.request: same lock, replay and rate limits as a zone.
Server.PROMPT_SLACK = 4 -- studs added to MaxActivationDistance for lag between the client's check and the server's

function Server.promptName(prompt)
	local name = prompt:GetAttribute("Cutscene")
	return type(name) == "string" and name or nil
end

function Server.promptPosition(prompt)
	local parent = prompt.Parent
	if parent and parent:IsA("Attachment") then
		return parent.WorldPosition
	elseif parent and parent:IsA("BasePart") then
		return parent.Position
	end
	return nil
end

-- true, or false and the reason the press is refused
function Server.checkPrompt(prompt, player, name)
	if prompt.Name ~= "CutscenePrompt_" .. name then
		return false, "not this scene's prompt"
	end
	if not prompt:IsDescendantOf(workspace) then
		return false, "prompt is not in the world"
	end
	if not prompt.Enabled then
		return false, "prompt is disabled"
	end
	local char = character(player)
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	local root = char and char:FindFirstChild("HumanoidRootPart")
	if not (hum and root and hum.Health > 0) then
		return false, "no live character"
	end
	local position = Server.promptPosition(prompt)
	if not position then
		return false, "prompt has no position"
	end
	if (root.Position - position).Magnitude > prompt.MaxActivationDistance + Server.PROMPT_SLACK then
		return false, "too far from the prompt"
	end
	return true
end

function Server.onPrompt(prompt, player)
	local name = Server.promptName(prompt)
	if not name then
		return false, "not a cutscene prompt"
	end
	local allowed, reason = Server.checkPrompt(prompt, player, name)
	if not allowed then
		return false, reason
	end
	local ok, played, why = pcall(Server.request, player, name)
	if not ok then
		warnOnce("prompt:" .. name, "prompt for " .. name .. " failed (" .. tostring(played) .. ")")
		return false, tostring(played)
	end
	return played, why
end

-- One zone tick for one player: a zone entry is a request (Server.request), like a prompt press.
local function zoneStep(player, folder, inside)
	local char = player.Character
	local root = char and char:FindFirstChild("HumanoidRootPart")
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	if not (root and hum and hum.Health > 0) then
		inside[player] = nil
		return
	end
	local mine = inside[player] or {}
	inside[player] = mine
	for _, zone in ipairs(folder:GetChildren()) do
		local name = zone:IsA("BasePart") and zone:GetAttribute("Cutscene")
		if type(name) == "string" and Server.zoneTriggers(zone) then
			local now, entered = Zones.step(zone.CFrame, zone.Size, root.Position, mine[zone])
			mine[zone] = now
			if entered then
				local okPlay, played, why = pcall(function()
					return Server.request(player, name, Zones.anchor(zone))
				end)
				if not okPlay then
					warnOnce("zone:" .. name, "zone for " .. name .. " failed (" .. tostring(played) .. ")")
				elseif played == false and why == "loading" then
					mine[zone] = false -- retry the entry on the next tick
				end
			end
		end
	end
	for z in pairs(mine) do
		if z.Parent ~= folder then
			mine[z] = nil -- a removed or rebuilt trigger (the installer replaces it)
		end
	end
end

function Server.watchZones()
	local inside = {} -- [player] = { [zone] = boolean }
	Players.PlayerRemoving:Connect(function(p)
		inside[p] = nil
	end)
	while true do
		task.wait(1 / Server.ZONE_HZ)
		local folder = workspace:FindFirstChild("CutsceneZones")
		for _, player in ipairs(Players:GetPlayers()) do
			Server.expire(player) -- every tick, zones or not: no shield outlives its scene
			if folder then
				zoneStep(player, folder, inside)
			end
		end
	end
end

-- StarterPlayer.StarterCharacter with the CutsceneKitPlayTest attribute is the kit's play-test stand-in
-- (PlayTest.setRig). The engine would spawn every player of a live game as it, so a live server deletes it; a Studio
-- play test keeps it and says once how to take it away. A place's own StarterCharacter is never touched.
local playTestSaid = setmetatable({}, { __mode = "k" })

function Server.dropPlayTestCharacter(container)
	local m = (container or StarterPlayer):FindFirstChild("StarterCharacter")
	if not (m and m:GetAttribute("CutsceneKitPlayTest") == true) then
		return nil
	end
	if Server.isStudio() then
		if not playTestSaid[m] then
			playTestSaid[m] = true
			Server.say("StarterPlayer.StarterCharacter is the kit's play-test stand-in: remove it with "
				.. "`py kit/run.py studio <Id> playtest-off` before you save or publish (a live server deletes it)")
		end
		return "kept"
	end
	m:Destroy()
	Server.say("deleted the kit's play-test StarterCharacter left in StarterPlayer, so players spawn as themselves: run "
		.. "`py kit/run.py studio <Id> playtest-off` in Studio and publish again")
	return "removed"
end

function Server.start()
	local okDrop, dropErr = pcall(Server.dropPlayTestCharacter)
	if not okDrop then
		warnOnce("playtest", "could not check StarterPlayer for the play-test StarterCharacter (" .. tostring(dropErr) .. ")")
	end
	pcall(function()
		game:BindToClose(Server.flushAll)
	end)
	local kit = script.Parent
	local remote = kit:FindFirstChild("Remote") or Instance.new("RemoteEvent")
	remote.Name = "Remote"
	remote.Parent = kit
	remote.OnServerEvent:Connect(Server.onRemote)
	local api = kit:FindFirstChild("Api") or Instance.new("BindableFunction")
	api.Name = "Api"
	api.Parent = kit
	api.OnInvoke = Server.api
	ProximityPromptService.PromptTriggered:Connect(Server.onPrompt)
	local function onPlayer(player)
		player.CharacterAdded:Connect(function(char)
			if player:GetAttribute("CutsceneLock") then
				Server.release(player) -- respawned mid-scene: the client already restored itself
			end
			if player:GetAttribute("Awakened") then
				Server.onDied(player) -- a new body starts plain
			end
			hookDeath(player, char)
		end)
		-- a body removed with no death (a game's own character swap or cleanup) ends the awakened state at once too
		player.CharacterRemoving:Connect(function(char)
			Server.bodyGone(player, char)
		end)
		if player.Character then
			hookDeath(player, player.Character)
		end
		Server.join(player)
	end
	Players.PlayerAdded:Connect(onPlayer)
	for _, p in ipairs(Players:GetPlayers()) do
		task.spawn(onPlayer, p)
	end
	Players.PlayerRemoving:Connect(Server.leave)
	task.spawn(Server.watchZones)
end

return Server
