-- Shake: trauma-squared camera shake, translation and roll only (vault: Camera Shake and Camera FX).
-- Method by fwjelaa (FWJ STUDIOS).
local Shake = {}
Shake.DECAY = 1.45 -- trauma lost per second
Shake.FREQ = 16 -- Hz
Shake.MAX_ROLL = math.rad(2.6)
Shake.MAX_STUDS = 0.35

function Shake.new()
	return { trauma = 0, seed = math.random() * 1000 }
end

function Shake.add(s, amount)
	s.trauma = math.clamp(s.trauma + amount, 0, 1)
end

function Shake.step(s, dt, t, scale)
	s.trauma = math.max(0, s.trauma - Shake.DECAY * dt)
	local k = s.trauma * s.trauma * (scale or 1)
	if k <= 0 then
		return CFrame.identity
	end
	local f = t * Shake.FREQ
	local x = math.noise(s.seed, f) * Shake.MAX_STUDS * k
	local y = math.noise(s.seed + 10, f) * Shake.MAX_STUDS * k
	local roll = math.noise(s.seed + 20, f) * Shake.MAX_ROLL * k
	return CFrame.new(x, y, 0) * CFrame.Angles(0, 0, roll)
end

-- 1 within `full` studs, 0 beyond `none`, smooth between (an onlooker's shake: full at 30 studs, none at 150, spec 6)
function Shake.falloff(distance, full, none)
	full, none = full or 30, none or 150
	if distance <= full then
		return 1
	end
	if distance >= none then
		return 0
	end
	local x = (distance - full) / (none - full)
	return 1 - x * x * (3 - 2 * x)
end

return Shake
