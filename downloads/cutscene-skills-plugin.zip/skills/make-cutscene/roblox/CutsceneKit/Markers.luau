-- Markers: which cues are due between two timeline times, and the lasting state at a time (for late joins).
-- Method by fwjelaa (FWJ STUDIOS).
local Markers = {}
Markers.STATEFUL = { Letterbox = true }

function Markers.due(markers, tPrev, tNow)
	local out = {}
	for _, m in ipairs(markers) do
		if m[1] > tPrev and m[1] <= tNow then
			table.insert(out, m)
		end
	end
	return out
end

function Markers.stateAt(markers, t)
	local state = {}
	for _, m in ipairs(markers) do
		if m[1] <= t and Markers.STATEFUL[m[2]] then
			state[m[2]] = m[3]
		end
	end
	return state
end

return Markers
