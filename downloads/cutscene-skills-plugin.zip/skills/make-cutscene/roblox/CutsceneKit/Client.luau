-- Client side of CutsceneKit: starts the scenes the server schedules for this player, plays everyone else's awakenings
-- as an onlooker, and draws every awakened character's aura. Method by fwjelaa (FWJ STUDIOS).
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Aura = require(script.Parent.Aura)
local Director = require(script.Parent.Director)
local Onlooker = require(script.Parent.Onlooker)
local Vfx = require(script.Parent.Vfx)

local Client = {}

function Client.start()
	local player = Players.LocalPlayer
	-- background clip preload: a load error here must never stop the scenes
	local preloader
	local okPreload, result = pcall(function()
		return require(script.Parent.Preload).start(player)
	end)
	if okPreload then
		preloader = result
	else
		warn("CutsceneKit: preload did not start: " .. tostring(result))
	end
	local remote = script.Parent:WaitForChild("Remote")
	local current
	local function check()
		local name = player:GetAttribute("CutsceneName")
		local startAt = player:GetAttribute("CutsceneStartAt")
		local anchor = player:GetAttribute("CutsceneAnchor")
		if type(name) ~= "string" or type(startAt) ~= "number" or typeof(anchor) ~= "CFrame" then
			return
		end
		if current and current.name == name and current.startAt == startAt then
			return
		end
		if preloader then
			pcall(preloader.now, name) -- this scene's clips jump the background queue, before the Director's own load
		end
		local folder = ReplicatedStorage:FindFirstChild("Cutscenes")
		local module = folder and folder:FindFirstChild(name)
		if not module then
			warn("CutsceneKit: ReplicatedStorage.Cutscenes." .. name .. " is missing")
			remote:FireServer("Ended", name, startAt, "load-failed") -- it never played: free the lock, keep it unseen
			return
		end
		if current and not current.done then
			current.finish("replaced")
		end
		current = Director.play({
			module = module,
			anchor = anchor,
			startAt = startAt,
			player = player,
			onSkip = function()
				remote:FireServer("Skip", name)
			end,
			-- every other end: the server frees the player at once instead of waiting out its timer
			onEnd = function(reason)
				remote:FireServer("Ended", name, startAt, reason)
			end,
		})
		current.name, current.startAt = name, startAt
	end
	player:GetAttributeChangedSignal("CutsceneStartAt"):Connect(check)
	check()
	task.spawn(Vfx.preload)
	-- other players' awakenings and every aura: a failure here warns and never stops this player's own scenes
	local okOnlook, errOnlook = pcall(Onlooker.watch, player)
	if not okOnlook then
		warn("CutsceneKit: the onlooker did not start: " .. tostring(errOnlook))
	end
	local okAura, errAura = pcall(Aura.watch)
	if not okAura then
		warn("CutsceneKit: the auras did not start: " .. tostring(errAura))
	end
end

return Client
