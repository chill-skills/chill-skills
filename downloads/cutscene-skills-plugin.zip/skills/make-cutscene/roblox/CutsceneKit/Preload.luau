-- Preloads every installed scene's uploaded clips on the client, so a player's first view starts on time. Method by fwjelaa (FWJ STUDIOS).
-- A cold clip load can take as long as the server's start lead; the Director's wait and late-seek stay as the fallback.
local Preload = {}

local ASSET = "^rbxassetid://%d+$"
local PLAYER_ROLE = "player" -- the cast role Director gives the player's own copy
local BATCH = 20
Preload.MAX_CLIPS = 200 -- background preload stops here; the scene about to play (now) ignores the cap

-- ids a scene needs for this rig: the Stage clip, the whole Anims[rig] table, and the other rig's NPC clips (an NPC's
-- rig is its own, not the player's). Refs that aren't rbxassetid:// ids (Studio-only "clips in Clips") are skipped.
function Preload.collect(data, rig)
	local ids, seen = {}, {}
	local function add(ref)
		if type(ref) == "string" and string.match(ref, ASSET) and not seen[ref] then
			seen[ref] = true
			table.insert(ids, ref)
		end
	end
	local anims = type(data) == "table" and type(data.Anims) == "table" and data.Anims or nil
	if not anims then
		return ids
	end
	add(anims.Stage)
	for _, key in ipairs({ "R15", "R6" }) do
		local roles = anims[key]
		if type(roles) == "table" then
			local sorted = {}
			for role in pairs(roles) do
				table.insert(sorted, role)
			end
			table.sort(sorted, function(a, b)
				return tostring(a) < tostring(b)
			end)
			for _, role in ipairs(sorted) do
				if key == rig or role ~= PLAYER_ROLE then
					add(roles[role])
				end
			end
		end
	end
	return ids
end

function Preload.rigOf(character)
	local hum = character and character:FindFirstChildOfClass("Humanoid")
	return hum and hum.RigType.Name == "R6" and "R6" or "R15"
end

-- env: contentProvider, getFolder() -> ReplicatedStorage.Cutscenes or nil, distanceOf(module) -> studs to the scene's
-- trigger anchor or nil, spawn (task.spawn), newAnimation(id) -> Animation, require, warn.
-- Returns { run(rig) -> ids queued, now(name, rig) -> ids, kept }.
function Preload.new(env)
	local requireFn = env.require or require
	local warnFn = env.warn or warn
	local self = { kept = {}, queued = {}, loaded = {} }
	local warnedModule = {}

	local function modulesOf(rig)
		local folder = env.getFolder()
		local found = {}
		for _, module in ipairs(folder and folder:GetChildren() or {}) do
			if module:IsA("ModuleScript") then
				local ok, data = pcall(requireFn, module)
				if ok then
					table.insert(found, { module = module, ids = Preload.collect(data, rig) })
				elseif not warnedModule[module.Name] then
					warnedModule[module.Name] = true
					warnFn(("CutsceneKit: preload could not read %s: %s"):format(module.Name, tostring(data)))
				end
			end
		end
		return found
	end

	-- loads ids in batches; a failed batch frees its ids to be tried again, and never errors
	local function load(ids)
		local anims = {}
		for _, id in ipairs(ids) do
			if not self.loaded[id] then
				local anim = env.newAnimation(id)
				table.insert(self.kept, anim) -- referenced for good: a collected Animation would drop out of the cache
				table.insert(anims, { id = id, anim = anim })
			end
		end
		env.spawn(function()
			for i = 1, #anims, BATCH do
				local batch, batchIds = {}, {}
				for j = i, math.min(i + BATCH - 1, #anims) do
					if not self.loaded[anims[j].id] then
						table.insert(batch, anims[j].anim)
						table.insert(batchIds, anims[j].id)
					end
				end
				if #batch > 0 then
					local ok, err = pcall(env.contentProvider.PreloadAsync, env.contentProvider, batch)
					if ok then
						for _, id in ipairs(batchIds) do
							self.loaded[id] = true
						end
					else
						for _, id in ipairs(batchIds) do
							self.queued[id] = nil
						end
						warnFn("CutsceneKit: clip preload failed: " .. tostring(err))
					end
				end
			end
		end)
	end

	-- the whole background queue, nearest scene first (no known anchor goes last), up to MAX_CLIPS clips
	function self.run(rig)
		local scenes = modulesOf(rig)
		local distances = {}
		for _, sc in ipairs(scenes) do
			local ok, d = pcall(env.distanceOf, sc.module)
			distances[sc] = ok and type(d) == "number" and d or math.huge
		end
		table.sort(scenes, function(a, b)
			if distances[a] ~= distances[b] then
				return distances[a] < distances[b]
			end
			return a.module.Name < b.module.Name
		end)
		local count = 0
		for _ in pairs(self.queued) do
			count += 1
		end
		local fresh = {}
		for _, sc in ipairs(scenes) do
			for _, id in ipairs(sc.ids) do
				if not self.queued[id] and count < Preload.MAX_CLIPS then
					self.queued[id] = true
					count += 1
					table.insert(fresh, id)
				end
			end
		end
		if #fresh > 0 then
			load(fresh)
		end
		return fresh
	end

	-- one scene, right now, in its own task ahead of whatever the background queue still holds
	function self.now(name, rig)
		local ids = {}
		for _, sc in ipairs(modulesOf(rig)) do
			if sc.module.Name == name then
				for _, id in ipairs(sc.ids) do
					if not self.loaded[id] then
						self.queued[id] = true
						table.insert(ids, id)
					end
				end
			end
		end
		if #ids > 0 then
			load(ids)
		end
		return ids
	end

	return self
end

-- Wires it to the real game: after the game has loaded, again when a scene module is added, and when the character's
-- rig type changes. deps overrides the globals (tests). Returns { preload, now(name) }.
function Preload.start(player, deps)
	deps = deps or {}
	local g = deps.game or game
	local ReplicatedStorage = g:GetService("ReplicatedStorage")
	local ContentProvider = g:GetService("ContentProvider")
	local spawn = deps.spawn or task.spawn
	local defer = deps.defer or task.defer
	local state = { rig = "R15" }
	local env = {
		contentProvider = ContentProvider,
		spawn = spawn,
		getFolder = function()
			return ReplicatedStorage:FindFirstChild("Cutscenes")
		end,
		distanceOf = deps.distanceOf or function(module)
			local character = player.Character
			local root = character and character:FindFirstChild("HumanoidRootPart")
			local zones = workspace:FindFirstChild("CutsceneZones")
			if not root then
				return nil
			end
			for _, z in ipairs(zones and zones:GetChildren() or {}) do
				if z:IsA("BasePart") and z:GetAttribute("Cutscene") == module.Name then
					return (z.Position - root.Position).Magnitude
				end
			end
			return nil
		end,
		newAnimation = deps.newAnimation or function(id)
			local anim = Instance.new("Animation")
			anim.AnimationId = id
			return anim
		end,
		require = deps.require,
		warn = deps.warn,
	}
	local preload = Preload.new(env)
	local ready = false -- the background queue waits for the game; now() never does
	local function run()
		if not ready then
			return
		end
		local ok, err = pcall(preload.run, state.rig)
		if not ok then
			(deps.warn or warn)("CutsceneKit: preload failed: " .. tostring(err))
		end
	end
	local function onCharacter(character)
		spawn(function()
			local hum = character:WaitForChild("Humanoid", 10)
			if not hum then
				return
			end
			local rig = Preload.rigOf(character)
			if rig ~= state.rig then
				state.rig = rig
				run()
			end
		end)
	end
	spawn(function()
		if not g:IsLoaded() then
			g.Loaded:Wait()
		end
		local folder = ReplicatedStorage:WaitForChild("Cutscenes", 30)
		if not folder then
			return
		end
		folder.ChildAdded:Connect(function()
			defer(run) -- the module's source may not be set the instant it is parented
		end)
		local character = player.Character
		if character and character:WaitForChild("Humanoid", 10) then
			state.rig = Preload.rigOf(character) -- know the rig before the first run, or R6 players load R15 clips
		end
		ready = true
		run()
	end)
	player.CharacterAdded:Connect(onCharacter)
	if player.Character then
		onCharacter(player.Character)
	end
	return {
		preload = preload,
		now = function(name)
			return preload.now(name, state.rig)
		end,
	}
end

return Preload
