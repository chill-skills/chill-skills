-- Schedule: when a scene starts and whether a client should still join it. Method by fwjelaa (FWJ STUDIOS).
local Schedule = {}
Schedule.LEAD = 0.75 -- seconds between the server's decision and the first frame (vault: 0.5-1.0)
Schedule.ON_TIME = 0.25 -- a client this close to the start counts as on time
Schedule.LATE_SKIP = 1.5 -- arriving with less than this left skips the scene (vault: 1-2 s)
Schedule.END_SLACK = 0.25 -- an end reported or seen this close to a scene's length counts as its normal end (clock skew)

function Schedule.startAt(now)
	return now + Schedule.LEAD
end

function Schedule.elapsed(startAt, now)
	return now - startAt
end

function Schedule.decide(startAt, duration, now)
	local t = now - startAt
	if t < 0 then
		return "wait"
	end
	if t >= duration then
		return "over"
	end
	if t > Schedule.ON_TIME and duration - t < Schedule.LATE_SKIP then
		return "skip"
	end
	return "play"
end

return Schedule
