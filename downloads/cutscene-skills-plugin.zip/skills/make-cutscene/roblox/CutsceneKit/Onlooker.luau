-- Onlooker: what everyone else sees when someone awakens (spec 6): the caster's animation (it replicates by itself),
-- the VFX at the scene's anchor from this client's own copy of the timeline, and a small shake that fades with
-- distance (full at 30 studs, none at 150). Their camera is never taken. Watches every other Player and every NPC
-- caster (tag CutsceneCaster). Method by fwjelaa (FWJ STUDIOS).
local CollectionService = game:GetService("CollectionService")
local GuiService = game:GetService("GuiService")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Data = require(script.Parent.Data)
local Director = require(script.Parent.Director)
local Markers = require(script.Parent.Markers)
local Schedule = require(script.Parent.Schedule)
local Shake = require(script.Parent.Shake)
local Vfx = require(script.Parent.Vfx)

local Onlooker = {}
Onlooker.TAG = "CutsceneCaster" -- = Server.TAG = Aura.TAG (Awaken.test checks they agree)
Onlooker.FULL, Onlooker.NONE = 30, 150 -- studs (spec 6)
Onlooker.SCALE = 0.5 -- an onlooker's shake is a small share of the caster's
Onlooker.KINDS = { awakening = true, ultimate = true }
Onlooker.TAIL = 4 -- s the VFX keep fading after the scene's end
Onlooker.warned = {} -- keys already warned about (a test clears one to see it warn again)

local function warnOnce(key, msg)
	if not Onlooker.warned[key] then
		Onlooker.warned[key] = true
		warn("CutsceneKit: " .. msg)
	end
end

-- True when an onlooked scene stopping now isn't its normal end, so its VFX (FwjelaaVFX ones too) stop at once, as the
-- caster's own Director does: a new scene (newStartAt), or a release (death, respawn, an Ended, Release) before the
-- scene's length. A release within Schedule.END_SLACK of the end is its normal end, and fades for TAIL.
function Onlooker.early(startAt, length, now, newStartAt)
	return type(newStartAt) == "number" or now - startAt < length - Schedule.END_SLACK
end

-- the scene subject is starting, if an onlooker sees it: data, anchor, startAt; else nil
function Onlooker.sceneOf(subject, now)
	local name, startAt, anchor = subject:GetAttribute("CutsceneName"), subject:GetAttribute("CutsceneStartAt"),
		subject:GetAttribute("CutsceneAnchor")
	if type(name) ~= "string" or type(startAt) ~= "number" or typeof(anchor) ~= "CFrame" then
		return nil
	end
	local folder = ReplicatedStorage:FindFirstChild("Cutscenes")
	local module = folder and folder:FindFirstChild(name)
	if not module then
		return nil
	end
	local ok, data = pcall(require, module)
	if not ok or type(data) ~= "table" or not Data.validate(data) or not Onlooker.KINDS[data.Kind] then
		return nil
	end
	local decision = Schedule.decide(startAt, data.Length, now)
	if decision == "over" or decision == "skip" then
		return nil -- late joiners skip a scene with under 1.5 s left (spec 6)
	end
	return data, anchor, startAt
end

-- opts = { now = function? } ; returns a handle { stop(immediate?), folder, startAt, length, now } or nil. stop() lets
-- the VFX (FwjelaaVFX ones included) fade for TAIL seconds (the normal end); stop(true) clears them at once
-- (Onlooker.early). A setup error removes the folder and is raised for watch to warn about.
function Onlooker.play(subject, opts)
	local now = opts and opts.now or function()
		return workspace:GetServerTimeNow()
	end
	local data, anchor, startAt = Onlooker.sceneOf(subject, now())
	if not data then
		return nil
	end
	local cfg = Data.config(data)
	local char = (subject:IsA("Player") and subject.Character) or (subject:IsA("Model") and subject) or nil
	local folder = Instance.new("Folder")
	folder.Name = "CutsceneOnlook"
	folder.Parent = workspace
	local ctx = { data = data, cfg = cfg, anchor = anchor, cast = { player = char }, cues = {} }
	local okSetup, setupErr = pcall(function()
		ctx.fx = Vfx.new({ parent = folder, element = cfg.Element, ignore = { char } })
		Director.prepareVfx(ctx)
	end)
	if not okSetup then
		if ctx.fx then
			pcall(Vfx.clear, ctx.fx)
		end
		folder:Destroy()
		error(setupErr, 0)
	end
	local shake = Shake.new()
	local camera = workspace.CurrentCamera
	local renderName = "CutsceneKitOnlook_" .. HttpService:GenerateGUID(false)
	local handle = { folder = folder, startAt = startAt, length = data.Length, now = now, done = false }
	local tPrev = Director.firstPrev(math.max(0, now() - startAt))
	local conn
	function handle.stop(immediate)
		if handle.done then
			return
		end
		handle.done = true
		pcall(RunService.UnbindFromRenderStep, RunService, renderName)
		if conn then
			conn:Disconnect()
		end
		pcall(Vfx.setTimeScale, ctx.fx, 1) -- the tail falls at normal speed
		local externals = ctx.externals or {}
		ctx.externals = nil
		task.delay(immediate and 0 or Onlooker.TAIL, function()
			for _, stopExternal in ipairs(externals) do
				pcall(stopExternal)
			end
			pcall(Vfx.clear, ctx.fx)
			folder:Destroy()
		end)
	end
	local function cue(m)
		if m[2] == "VFX" then
			Director.fireVfx(ctx, m)
		elseif m[2] == "Slowmo" then
			Vfx.setTimeScale(ctx.fx, tonumber(m[3]) or 1)
		elseif m[2] == "Shake" and camera then
			local d = (camera.CFrame.Position - anchor.Position).Magnitude
			Shake.add(shake, (tonumber(m[3]) or 0.3) * Shake.falloff(d, Onlooker.FULL, Onlooker.NONE) * Onlooker.SCALE)
		end
	end
	conn = RunService.Heartbeat:Connect(function()
		local t = now() - startAt
		if t < 0 then
			return
		end
		local due = Markers.due(data.Markers, tPrev, t)
		tPrev = t -- first: a cue that throws is skipped, never retried every frame
		for _, m in ipairs(due) do
			table.insert(ctx.cues, m[2])
			local ok, err = pcall(cue, m)
			if not ok then
				warnOnce(("cue:%s:%s"):format(tostring(m[2]), tostring(m[3])),
					("an onlooker's %s cue failed and was skipped: %s"):format(tostring(m[2]), tostring(err)))
			end
		end
		folder:SetAttribute("T", t)
		folder:SetAttribute("Cues", table.concat(ctx.cues, ","))
		if t >= data.Length then
			handle.stop()
		end
	end)
	if camera and not GuiService.ReducedMotionEnabled then
		RunService:BindToRenderStep(renderName, Enum.RenderPriority.Camera.Value + 1, function(dt)
			if camera.CameraType ~= Enum.CameraType.Scriptable then -- never fight a scene that owns this camera
				camera.CFrame = camera.CFrame * Shake.step(shake, dt, os.clock(), 1)
			end
		end)
	end
	return handle
end

-- Every client runs this once (Client.start).
function Onlooker.watch(localPlayer)
	local active = setmetatable({}, { __mode = "k" }) -- [subject] = handle; drop() removes a caster that is gone
	local function check(subject)
		if subject == localPlayer then
			return -- the caster's own client runs the cinematic (Director)
		end
		local startAt = subject:GetAttribute("CutsceneStartAt")
		local cur = active[subject]
		if cur and cur.startAt == startAt then
			return
		end
		if cur then
			-- fades only on its normal end; a death, an early release or a new scene stops it at once
			cur.stop(Onlooker.early(cur.startAt, cur.length, cur.now(), startAt))
			active[subject] = nil
		end
		if type(startAt) == "number" then
			local ok, h = pcall(Onlooker.play, subject)
			if not ok then
				warn("CutsceneKit: onlooker failed: " .. tostring(h))
			elseif h then
				active[subject] = h
			end
		end
	end
	local function hook(subject)
		subject:GetAttributeChangedSignal("CutsceneStartAt"):Connect(function()
			check(subject)
		end)
		check(subject)
	end
	local function drop(subject)
		if active[subject] then
			active[subject].stop(true)
			active[subject] = nil
		end
	end
	for _, p in ipairs(Players:GetPlayers()) do
		hook(p)
	end
	Players.PlayerAdded:Connect(hook)
	Players.PlayerRemoving:Connect(drop)
	for _, m in ipairs(CollectionService:GetTagged(Onlooker.TAG)) do
		hook(m)
	end
	CollectionService:GetInstanceAddedSignal(Onlooker.TAG):Connect(hook)
	CollectionService:GetInstanceRemovedSignal(Onlooker.TAG):Connect(drop)
end

return Onlooker
