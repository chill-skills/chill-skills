-- Data: the format contract for a cutscene data module, and its config defaults. kit/schema.py checks the same rules
-- with the same messages in Python: change one, change the other. Method by fwjelaa (FWJ STUDIOS).
local Lib = require(script.Parent.VfxPresets)
local Data = {}
Data.KINDS = { story = true, intro = true, awakening = true, ultimate = true }
Data.REPLAY = { always = true, session = true, saved = true }
Data.MAX_LENGTH = 30 -- s: clips are capped at about 30 s until consecutive clip segments exist (spec 5.9)
Data.FOV_MIN, Data.FOV_MAX = 1, 120
Data.LETTERBOX_MAX = 0.2
Data.RIGS = { "R15", "R6" }
Data.CUE_KINDS = { vfx = true, screen = true, sfx = true, face = true }
Data.SCREEN = { grade = true, bloom = true, flash = true, speedlines = true, focus = true, burst = true, word = true,
	backdrop = true }
Data.SCREEN_TEXT = "grade, bloom, flash, speedlines, focus, burst, word or backdrop"
Data.COLOR_ROLES = { main = true, hot = true, dark = true, glow = true, spark = true, debris = true, accent = true,
	deep = true, white = true, black = true } -- kit/vfxlib.py ROLES
Data.FONTS = { "Bangers", "LuckiestGuy", "FredokaOne", "PermanentMarker", "Creepster", "DenkOne" } -- kit/vfxlib.py FONTS
Data.WORD_TEXT_MAX = 16
Data.STROKE_MAX = 0.07
Data.SIZE_MAX = 2
Data.CASTLIGHT_BRIGHT, Data.CASTLIGHT_RANGE = 10, 60
Data.LOOKS = { eyes = true, outline = true, tint = true }
Data.GRADE = { "Brightness", "Contrast", "Saturation" }
Data.SLOWMO_MIN = 0.05
Data.AWAKENED = { Duration = 30, Aura = "Flame", Look = { "eyes", "outline" } } -- defaults (Data.config)

-- keys 1..n with no gaps and nothing else
local function isList(v)
	if type(v) ~= "table" then
		return false
	end
	local n = 0
	for _ in pairs(v) do
		n += 1
	end
	return n == #v
end

local function isNumbers(v, n)
	if not isList(v) or #v ~= n then
		return false
	end
	for i = 1, n do
		if type(v[i]) ~= "number" then
			return false
		end
	end
	return true
end

-- "player", "npc2" or "player.Head"
function Data.isFollow(v)
	if type(v) ~= "string" then
		return false
	end
	local role = string.match(v, "^(%w+)%.[%w_]+$") or string.match(v, "^(%w+)$")
	return role ~= nil and (role == "player" or role == "target" or string.match(role, "^npc[1-9]%d?$") ~= nil)
end

-- the first marker with this name, or nil
function Data.firstMarker(d, name)
	for _, m in ipairs(type(d.Markers) == "table" and d.Markers or {}) do
		if type(m) == "table" and m[2] == name then
			return m
		end
	end
	return nil
end

local function cueProblems(key, cue, need)
	local label = tostring(key)
	need(type(key) == "string", ("Cues key %s must be a string like VFX:Burst"):format(label))
	if not need(type(cue) == "table" and Data.CUE_KINDS[cue.kind] == true,
		("Cues[%s] needs a kind: vfx, screen, sfx or face"):format(label)) then
		return
	end
	if cue.kind == "vfx" then
		if cue.external == true then
			need(type(cue.preset) == "string", ("Cues[%s].preset must be a string"):format(label))
		else
			need(type(cue.preset) == "string" and Lib.Presets[cue.preset] ~= nil,
				("Cues[%s].preset %s is not a VFX preset"):format(label, tostring(cue.preset)))
		end
		need(cue.at == nil or isNumbers(cue.at, 3), ("Cues[%s].at must be 3 numbers {x, y, z}"):format(label))
		need(cue.yaw == nil or type(cue.yaw) == "number", ("Cues[%s].yaw must be a number of degrees"):format(label))
		need(cue.follow == nil or Data.isFollow(cue.follow),
			("Cues[%s].follow must be a role or role.Part, like player.Head"):format(label))
		need(cue.scale == nil or (type(cue.scale) == "number" and cue.scale > 0),
			("Cues[%s].scale must be a number > 0"):format(label))
		need(cue.element == nil or Lib.Elements[cue.element] ~= nil,
			("Cues[%s].element %s is not a VFX element"):format(label, tostring(cue.element)))
	elseif cue.kind == "screen" then
		Data.screenProblems(label, cue, need)
	end
end

local function isColour(v)
	return type(v) == "string" and (Data.COLOR_ROLES[v] == true or string.match(v, "^#%x%x%x%x%x%x$") ~= nil)
end

local function isNum(v)
	return type(v) == "number"
end

-- a screen cue's fields (kit/schema.py screen_problems is the twin): the manga effects' points, sizes, images,
-- colours and sound-word text
function Data.screenProblems(label, cue, need)
	local effect = cue.effect
	need(Data.SCREEN[effect] == true, ("Cues[%s].effect must be %s"):format(label, Data.SCREEN_TEXT))
	for _, f in ipairs({ "at", "focus" }) do
		local v = cue[f]
		need(v == nil or isNumbers(v, 2) or isNumbers(v, 3),
			("Cues[%s].%s must be 2 numbers (x, y on the screen, 0-1) or 3 numbers {x, y, z}"):format(label, f))
	end
	need(cue.follow == nil or Data.isFollow(cue.follow),
		("Cues[%s].follow must be a role or role.Part, like player.Head"):format(label))
	need(cue.life == nil or (isNum(cue.life) and cue.life > 0),
		("Cues[%s].life must be a number of seconds > 0"):format(label))
	need(cue.rot == nil or isNum(cue.rot), ("Cues[%s].rot must be a number of degrees"):format(label))
	for _, f in ipairs({ "alpha", "density" }) do
		local v = cue[f]
		need(v == nil or (isNum(v) and v >= 0 and v <= 1), ("Cues[%s].%s must be a number from 0 to 1"):format(label, f))
	end
	for _, f in ipairs({ "color", "fill" }) do
		need(cue[f] == nil or isColour(cue[f]),
			("Cues[%s].%s must be white, black, a colour role or #rrggbb"):format(label, f))
	end
	if effect == "burst" or effect == "word" then
		need(cue.size == nil or (isNum(cue.size) and cue.size > 0 and cue.size <= Data.SIZE_MAX),
			("Cues[%s].size must be a share of the screen height, more than 0 and at most %d"):format(label, Data.SIZE_MAX))
	end
	if effect == "burst" or effect == "backdrop" then
		local manga = Lib.Manga or {}
		local img = cue.image
		local ok = img == nil
			or (type(img) == "string" and (manga[img] ~= nil or string.match(img, "^rbxassetid://%d+$") ~= nil))
		if not ok then
			local names = {}
			for n in pairs(manga) do
				table.insert(names, n)
			end
			table.sort(names)
			need(false, ("Cues[%s].image must be a manga texture (%s) or rbxassetid://<number>"):format(label,
				table.concat(names, ", ")))
		end
	end
	if effect == "backdrop" then
		need(cue.dist == nil or (isNum(cue.dist) and cue.dist > 0), ("Cues[%s].dist must be a number of studs > 0"):format(label))
	end
	if effect == "word" then
		local n = type(cue.text) == "string" and utf8.len(cue.text) or nil
		need(n ~= nil and n >= 1 and n <= Data.WORD_TEXT_MAX,
			("Cues[%s].text must be 1-%d characters (a sound word like POW!!)"):format(label, Data.WORD_TEXT_MAX))
		need(cue.stroke == nil or (isNum(cue.stroke) and cue.stroke >= 0 and cue.stroke <= Data.STROKE_MAX),
			("Cues[%s].stroke must be 0-%s of the text size (thicker fills the letters in)"):format(label,
				tostring(Data.STROKE_MAX)))
		local fontOk = cue.font == nil
		for _, f in ipairs(Data.FONTS) do
			fontOk = fontOk or cue.font == f
		end
		need(fontOk, ("Cues[%s].font must be one of %s"):format(label, table.concat(Data.FONTS, ", ")))
	end
end

-- Plan 3's rules (kit/schema.py vfx_problems is the twin): Slowmo markers, Cues, and the Config keys of awakenings
function Data.checkVfx(d, need)
	local length = type(d.Length) == "number" and d.Length or 0
	if isList(d.Markers) then
		for i, m in ipairs(d.Markers) do
			if type(m) == "table" and m[2] == "Slowmo" then
				-- a real number or plain decimal text: no hex, no booleans (kit/schema.py _float is the twin)
				local raw, k = m[3], nil
				if type(raw) == "number" then
					k = raw
				elseif type(raw) == "string" and string.match(raw, "^ *%d*%.?%d+ *$") ~= nil then
					k = tonumber(raw)
				end
				need(k ~= nil and k >= Data.SLOWMO_MIN and k <= 1,
					("Slowmo marker %d must be a number from %s to 1"):format(i, tostring(Data.SLOWMO_MIN)))
			end
		end
	end
	-- a list is not a cue table (an empty one is fine: JSON can't tell {} from [])
	if d.Cues ~= nil and need(type(d.Cues) == "table" and (next(d.Cues) == nil or not isList(d.Cues)),
		"Cues must be a table of marker = cue") then
		for key, cue in pairs(d.Cues) do
			cueProblems(key, cue, need)
		end
	end
	local c = d.Config
	if type(c) ~= "table" then
		return
	end
	need(c.Cooldown == nil or (type(c.Cooldown) == "number" and c.Cooldown >= 0),
		"Config.Cooldown must be a number of seconds >= 0")
	need(c.Element == nil or Lib.Elements[c.Element] ~= nil,
		("Config.Element %s is not a VFX element"):format(tostring(c.Element)))
	if c.Grade ~= nil and need(type(c.Grade) == "table", "Config.Grade must be a table") then
		for _, k in ipairs(Data.GRADE) do
			local v = c.Grade[k]
			need(v == nil or (type(v) == "number" and v >= -1 and v <= 1), ("Config.Grade.%s must be a number from -1 to 1"):format(k))
		end
		need(c.Grade.Tint == nil or (type(c.Grade.Tint) == "string" and string.match(c.Grade.Tint, "^%x%x%x%x%x%x$") ~= nil),
			"Config.Grade.Tint must be 6 hex digits like ffd9a0")
	end
	local a = c.Awakened
	if a ~= nil and need(type(a) == "table", "Config.Awakened must be a table") then
		need(a.Duration == nil or (type(a.Duration) == "number" and a.Duration > 0),
			"Config.Awakened.Duration must be a number of seconds > 0")
		need(a.Aura == nil or Lib.Auras[a.Aura] ~= nil, ("Config.Awakened.Aura %s is not an aura style"):format(tostring(a.Aura)))
		local lookOk = a.Look == nil or isList(a.Look)
		if lookOk and a.Look then
			for _, l in ipairs(a.Look) do
				lookOk = lookOk and Data.LOOKS[l] == true
			end
		end
		need(lookOk, "Config.Awakened.Look must be a list of eyes, outline or tint")
		need(a.At == nil or (type(a.At) == "number" and a.At >= 0 and a.At <= length + 1e-3),
			"Config.Awakened.At must be a time inside the scene")
		need(a.Element == nil or Lib.Elements[a.Element] ~= nil,
			("Config.Awakened.Element %s is not a VFX element"):format(tostring(a.Element)))
	end
	-- a neutral key light on each cast member (CutsceneKit.Screen.castLight)
	local light = c.CastLight
	if light ~= nil and need(type(light) == "boolean" or type(light) == "table",
		"Config.CastLight must be true, false or a table {Color, Brightness, Range}") and type(light) == "table" then
		need(light.Color == nil or (type(light.Color) == "string" and string.match(light.Color, "^%x%x%x%x%x%x$") ~= nil),
			"Config.CastLight.Color must be 6 hex digits like ffffff")
		need(light.Brightness == nil or (isNum(light.Brightness) and light.Brightness >= 0
			and light.Brightness <= Data.CASTLIGHT_BRIGHT),
			("Config.CastLight.Brightness must be a number from 0 to %d"):format(Data.CASTLIGHT_BRIGHT))
		need(light.Range == nil or (isNum(light.Range) and light.Range >= 1 and light.Range <= Data.CASTLIGHT_RANGE),
			("Config.CastLight.Range must be a number from 1 to %d"):format(Data.CASTLIGHT_RANGE))
	end
end

function Data.validate(d)
	local problems = {}
	local function need(cond, msg)
		if not cond then
			table.insert(problems, msg)
		end
		return cond
	end
	if type(d) ~= "table" then
		return false, { "the module must return a table" }
	end
	need(d.Name == nil or type(d.Name) == "string", "Name must be a string")
	need(Data.KINDS[d.Kind] == true, "Kind must be story, intro, awakening or ultimate")
	local length = type(d.Length) == "number" and d.Length or nil
	need(length ~= nil and length > 0 and length <= Data.MAX_LENGTH,
		("Length must be more than 0 and at most %d s"):format(Data.MAX_LENGTH))

	local anims = type(d.Anims) == "table" and d.Anims or nil
	need(anims ~= nil and type(anims.Stage) == "string", "Anims.Stage missing (the camera clip)")
	for _, rig in ipairs(Data.RIGS) do
		local refs = anims and anims[rig]
		if refs ~= nil then
			local ok = type(refs) == "table"
			if ok then
				for _, ref in pairs(refs) do
					ok = ok and type(ref) == "string"
				end
			end
			need(ok, ("Anims.%s must map roles to clip refs (strings)"):format(rig))
		end
	end

	if d.Places ~= nil and need(type(d.Places) == "table", "Places must be a table of role = {x, y, z, rx, ry, rz}") then
		for role, p in pairs(d.Places) do
			local ok = isList(p) and #p == 6
			for i = 1, ok and 6 or 0 do
				ok = ok and type(p[i]) == "number"
			end
			need(ok, ("Places.%s must be 6 numbers {x, y, z, rx, ry, rz}"):format(tostring(role)))
		end
	end

	if d.Fov ~= nil and need(isList(d.Fov), "Fov must be a list of {time, fov}") then
		local last = -math.huge
		for i = 1, #d.Fov do
			local e = d.Fov[i]
			local ok = type(e) == "table" and type(e[1]) == "number" and type(e[2]) == "number"
			need(ok, ("Fov entry %d must be {time, fov}"):format(i))
			if ok then
				need(e[1] >= last, ("Fov times go backwards at %d"):format(i))
				need(e[2] >= Data.FOV_MIN and e[2] <= Data.FOV_MAX,
					("Fov entry %d must be %d-%d degrees"):format(i, Data.FOV_MIN, Data.FOV_MAX))
				need(e[1] >= 0 and e[1] <= (length or 0) + 1e-3, ("Fov entry %d is outside the scene"):format(i))
				last = e[1]
			end
		end
	end

	if d.Lines ~= nil and need(type(d.Lines) == "table", "Lines must be a table of id = {speaker, text}") then
		for id, line in pairs(d.Lines) do
			local label = tostring(id)
			need(type(id) == "string", ("Lines key %s must be a string"):format(label))
			need(type(line) == "table" and type(line.text) == "string", ("Lines[%s] needs a text"):format(label))
			if type(line) == "table" then
				need(line.speaker == nil or type(line.speaker) == "string", ("Lines[%s].speaker must be a string"):format(label))
				need(line.hold == nil or (type(line.hold) == "number" and line.hold > 0), ("Lines[%s].hold must be a number of seconds > 0"):format(label))
				need(line.voice == nil or type(line.voice) == "string", ("Lines[%s].voice must be a string"):format(label))
			end
		end
	end

	if need(type(d.Markers) == "table", "Markers missing") and need(isList(d.Markers), "Markers must be a list with no gaps") then
		local last = -math.huge
		for i = 1, #d.Markers do
			local m = d.Markers[i]
			local ok = type(m) == "table" and type(m[1]) == "number" and type(m[2]) == "string"
			need(ok, ("marker %d malformed"):format(i))
			if ok then
				need(m[1] >= 0, ("marker %d is before 0 s"):format(i))
				need(m[1] >= last, ("markers not sorted at %d"):format(i))
				need(m[1] <= (length or 0) + 1e-3, ("marker %d after the end"):format(i))
				last = m[1]
				if m[2] == "Line" then
					need(type(d.Lines) == "table" and type(m[3]) == "string" and d.Lines[m[3]] ~= nil,
						("Line marker %s has no Lines entry"):format(tostring(m[3])))
				elseif m[2] == "Letterbox" then
					need(m[3] == "in" or m[3] == "out", ("Letterbox marker %d must be in or out"):format(i))
				end
			end
		end
	end

	-- spec 14: roles dressed as an adapted character (their models wait in the module's Costumes folder)
	if d.Costumes ~= nil and need(isList(d.Costumes), "Costumes must be a list of roles like player or npc1") then
		local seen = {}
		for i, role in ipairs(d.Costumes) do
			local ok = type(role) == "string" and (role == "player" or role == "target" or string.match(role, "^npc[1-9]%d?$") ~= nil)
			need(ok, ("Costumes entry %d must be a role (player, target, npc1..npc99)"):format(i))
			if ok then
				need(not seen[role], ("Costumes lists %s twice"):format(role))
				seen[role] = true
			end
		end
	end
	need(d.Config == nil or type(d.Config) == "table", "Config must be a table")
	if type(d.Config) == "table" then
		local c = d.Config
		need(c.Replay == nil or Data.REPLAY[c.Replay] == true, "Config.Replay must be always, session or saved")
		need(c.Skip == nil or c.Skip == false or (type(c.Skip) == "number" and c.Skip >= 0),
			"Config.Skip must be false or a number of seconds >= 0")
		need(c.Letterbox == nil or (type(c.Letterbox) == "number" and c.Letterbox >= 0 and c.Letterbox <= Data.LETTERBOX_MAX),
			"Config.Letterbox must be a number from 0 to " .. tostring(Data.LETTERBOX_MAX))
		need(c.Style == nil or type(c.Style) == "string", "Config.Style must be a string")
		local hideOk = c.Hide == nil or isList(c.Hide)
		if hideOk and c.Hide then
			for _, p in ipairs(c.Hide) do
				hideOk = hideOk and type(p) == "string"
			end
		end
		need(hideOk, "Config.Hide must be a list of paths like Gate/Guard")
		if hideOk and c.Hide then
			for _, p in ipairs(c.Hide) do
				need(p ~= "" and string.sub(p, 1, 1) ~= "/" and p ~= "Workspace" and string.sub(p, 1, 10) ~= "Workspace/",
					("Config.Hide path '%s' is not valid: use a path like Gate/Guard (not empty, no leading /, no Workspace/ prefix)"):format(p))
			end
		end
		need(c.Costume == nil or type(c.Costume) == "boolean", "Config.Costume must be true or false")
		if c.Costume == true then
			local hasPlayer = false
			for _, role in ipairs(isList(d.Costumes) and d.Costumes or {}) do
				hasPlayer = hasPlayer or role == "player"
			end
			need(hasPlayer, "Config.Costume is true but Costumes has no player")
			need(d.Kind == "story" or d.Kind == "intro",
				"Config.Costume works in story and intro scenes only (the player acts as a local copy there)")
		end
	end
	Data.checkVfx(d, need)
	return #problems == 0, problems
end

function Data.config(d)
	local c = table.clone(d.Config or {})
	if c.Skip == nil then
		c.Skip = (d.Kind == "story" or d.Kind == "intro") and 2 or false
	end
	-- awakenings and ultimates are moves: they replay every time unless the scene says otherwise
	c.Replay = c.Replay or ((d.Kind == "awakening" or d.Kind == "ultimate") and "always" or "saved")
	c.Letterbox = c.Letterbox or 0.11
	c.Style = c.Style or "anime"
	c.Cooldown = c.Cooldown or 0
	c.Element = c.Element or "teal"
	if d.Kind == "awakening" then
		local a = table.clone(c.Awakened or {})
		a.Duration = a.Duration or Data.AWAKENED.Duration
		a.Aura = a.Aura or Data.AWAKENED.Aura
		a.Look = a.Look or table.clone(Data.AWAKENED.Look)
		a.Element = a.Element or c.Element
		local impact = Data.firstMarker(d, "Impact")
		a.At = a.At or (impact and impact[1]) or d.Length -- the aura arrives with the burst
		c.Awakened = a
	end
	return c
end

return Data
