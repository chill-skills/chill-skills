-- Snapshot: remembers everything a cutscene changes on this client and puts exactly that back.
-- Method by fwjelaa (FWJ STUDIOS).
local Snapshot = {}
Snapshot.CORE = {
	Enum.CoreGuiType.PlayerList,
	Enum.CoreGuiType.Health,
	Enum.CoreGuiType.Backpack,
	Enum.CoreGuiType.Chat,
	Enum.CoreGuiType.EmotesMenu,
}

-- env = { camera = Camera, playerGui = Instance?, starterGui = StarterGui?, controls = { Enable, Disable }?,
--         userInput = UserInputService? }
function Snapshot.capture(env)
	local s = {
		env = env, guis = {}, core = {}, hidden = {}, anchored = {}, made = {}, restored = false,
		savedLtm = {}, names = {},
	}
	local cam = env.camera
	s.camera = { Type = cam.CameraType, Subject = cam.CameraSubject, CFrame = cam.CFrame, Fov = cam.FieldOfView }
	if env.root then -- env.root: the player's HumanoidRootPart; the blend back aims at this pose relative to it
		s.camera.Rel = env.root.CFrame:ToObjectSpace(cam.CFrame)
	end
	if env.playerGui then
		for _, g in ipairs(env.playerGui:GetChildren()) do
			if g:IsA("ScreenGui") and g.Enabled then
				table.insert(s.guis, g)
				g.Enabled = false
			end
		end
	end
	if env.starterGui then
		for _, kind in ipairs(Snapshot.CORE) do
			local ok, on = pcall(env.starterGui.GetCoreGuiEnabled, env.starterGui, kind)
			if ok then
				s.core[kind] = on
				pcall(env.starterGui.SetCoreGuiEnabled, env.starterGui, kind, false)
			end
		end
	end
	if env.controls then
		-- only a Disable that worked needs its Enable back
		s.controls = pcall(env.controls.Disable, env.controls)
	end
	if env.userInput then
		-- first-person and shift-lock games lock the mouse: free it so the Skip button can be clicked. Only a setting
		-- that changed is put back.
		local ui = env.userInput
		local okRead, behavior, icon = pcall(function()
			return ui.MouseBehavior, ui.MouseIconEnabled
		end)
		if okRead then
			s.mouse = {}
			if pcall(function()
				ui.MouseBehavior = Enum.MouseBehavior.Default
			end) then
				s.mouse.Behavior = behavior
			end
			if pcall(function()
				ui.MouseIconEnabled = true
			end) then
				s.mouse.Icon = icon
			end
		end
	end
	return s
end

function Snapshot.track(s, inst)
	table.insert(s.made, inst)
	return inst
end

-- remembers the value the game had, so restore puts that back (not 0)
function Snapshot.hidePart(s, d)
	if s.savedLtm[d] == nil then
		s.savedLtm[d] = d.LocalTransparencyModifier
		table.insert(s.hidden, d)
	end
	d.LocalTransparencyModifier = 1
end

local function nameSaved(s, h)
	for _, n in ipairs(s.names) do
		if n[1] == h then
			return true
		end
	end
	return false
end

-- hides the overhead name and health bar of every Humanoid in inst (or inst itself);
-- overlapping Hide paths visit a Humanoid twice, so only the first visit saves the game's value
function Snapshot.hideNames(s, inst)
	local list = inst:GetDescendants()
	table.insert(list, inst)
	for _, h in ipairs(list) do
		if h:IsA("Humanoid") then
			if not nameSaved(s, h) then
				table.insert(s.names, { h, h.DisplayDistanceType })
			end
			h.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
		end
	end
end

function Snapshot.hide(s, model)
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") or d:IsA("Decal") then
			Snapshot.hidePart(s, d)
		end
	end
end

-- the default camera scripts rewrite LocalTransparencyModifier on your own character, so re-apply every frame
function Snapshot.keepHidden(s)
	for _, d in ipairs(s.hidden) do
		if d.Parent then
			d.LocalTransparencyModifier = 1
		end
	end
end

function Snapshot.anchor(s, part)
	table.insert(s.anchored, { part, part.Anchored })
	part.Anchored = true
end

local function cameraSteps(s, step)
	if s.cameraDone then
		return
	end
	s.cameraDone = true
	local cam, c = s.env.camera, s.camera
	step("camera type", function()
		cam.CameraType = c.Type
	end)
	-- a subject that is gone (respawn) is left for the default camera to pick up the new Humanoid
	if c.Subject == nil or c.Subject.Parent ~= nil then
		step("camera subject", function()
			cam.CameraSubject = c.Subject
		end)
	end
	step("camera fov", function()
		cam.FieldOfView = c.Fov
	end)
	if c.Type == Enum.CameraType.Scriptable then
		step("camera cframe", function()
			cam.CFrame = c.CFrame
		end)
	end
end

-- The camera alone, after the Director's blend back to the player's camera. Returns the steps that failed.
function Snapshot.restoreCamera(s)
	local failed = {}
	cameraSteps(s, function(name, fn, ...)
		local ok, err = pcall(fn, ...)
		if not ok then
			table.insert(failed, ("%s (%s)"):format(name, tostring(err)))
		end
	end)
	if #failed > 0 then
		warn("CutsceneKit: restore could not undo: " .. table.concat(failed, "; "))
	end
	return failed
end

-- Puts everything back (opts.camera = false leaves the camera to Snapshot.restoreCamera). Returns the steps that
-- failed ("<step> (<error>)"), and warns once if any did.
function Snapshot.restore(s, opts)
	local keepCamera = opts and opts.camera == false
	if s.restored then
		-- a camera-less restore leaves the camera to restoreCamera; a later plain restore still gives it back
		if keepCamera or s.cameraDone then
			return {}
		end
		return Snapshot.restoreCamera(s)
	end
	s.restored = true
	local failed = {}
	-- every step in its own pcall: one throwing step must never leave the player's HUD hidden
	local function step(name, fn, ...)
		local ok, err = pcall(fn, ...)
		if not ok then
			table.insert(failed, ("%s (%s)"):format(name, tostring(err)))
		end
	end
	for i = #s.made, 1, -1 do
		step("destroy " .. tostring(s.made[i]), s.made[i].Destroy, s.made[i])
	end
	step("unhide parts", function()
		for _, d in ipairs(s.hidden) do
			if d.Parent then
				d.LocalTransparencyModifier = s.savedLtm[d] or 0
			end
		end
	end)
	step("name displays", function()
		for _, n in ipairs(s.names) do
			if n[1].Parent then
				n[1].DisplayDistanceType = n[2]
			end
		end
	end)
	step("unanchor parts", function()
		for _, a in ipairs(s.anchored) do
			if a[1].Parent then
				a[1].Anchored = a[2]
			end
		end
	end)
	if not keepCamera then
		cameraSteps(s, step)
	end
	step("screen guis", function()
		for _, g in ipairs(s.guis) do
			if g.Parent then
				g.Enabled = true
			end
		end
	end)
	for kind, on in pairs(s.core) do
		step("core gui " .. tostring(kind), s.env.starterGui.SetCoreGuiEnabled, s.env.starterGui, kind, on)
	end
	if s.controls then
		step("controls", s.env.controls.Enable, s.env.controls)
	end
	if s.mouse then
		local ui = s.env.userInput
		if s.mouse.Behavior ~= nil then
			step("mouse behavior", function()
				ui.MouseBehavior = s.mouse.Behavior
			end)
		end
		if s.mouse.Icon ~= nil then
			step("mouse icon", function()
				ui.MouseIconEnabled = s.mouse.Icon
			end)
		end
	end
	if #failed > 0 then
		warn("CutsceneKit: restore could not undo: " .. table.concat(failed, "; "))
	end
	return failed
end

return Snapshot
