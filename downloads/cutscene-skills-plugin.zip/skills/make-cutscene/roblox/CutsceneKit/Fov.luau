-- Fov: the camera's vertical field of view over time. Two entries at the same time are a cut. Method by fwjelaa (FWJ STUDIOS).
local Fov = {}

function Fov.sample(track, t)
	local n = #track
	if n == 0 then
		return nil
	end
	if t <= track[1][1] then
		return track[1][2]
	end
	if t >= track[n][1] then
		return track[n][2]
	end
	for i = n - 1, 1, -1 do -- the last entry at or before t
		local a = track[i]
		if a[1] <= t then
			local b = track[i + 1]
			if b[1] <= a[1] then
				return b[2]
			end
			return a[2] + (b[2] - a[2]) * ((t - a[1]) / (b[1] - a[1]))
		end
	end
	return track[n][2]
end

return Fov
