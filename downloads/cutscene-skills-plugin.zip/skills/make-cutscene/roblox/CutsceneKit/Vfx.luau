-- Vfx: CutsceneKit's VFX timeline (client only: every client renders its own copy).
-- Method by fwjelaa (FWJ STUDIOS).
-- Presets are data (CutsceneKit.VfxPresets, generated from vfx/presets.json by kit/vfxlib.py); this module builds them
-- from Roblox built-ins (ParticleEmitter, Trail, parts, CylinderHandleAdornment, PointLight) and engine textures, and
-- plays them on one Heartbeat. Bursts use Emit(); nothing is left Enabled. Effects are built ahead (prepare) and
-- started on their marker (fire): emitting right after creating an emitter can fail (research/03 section 3).
-- Rules from fwjelaa-vfx: three values (white core, element body, dark ink), escalation without clutter, the character
-- stays readable, at most 2 lights per effect.
local ContentProvider = game:GetService("ContentProvider")
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")

local Lib = require(script.Parent.VfxPresets)

local Vfx = {}
Vfx.MAX_LIVE = 900 -- live particles across every effect on this client (PC); default until spike S14 measures
Vfx.MAX_LIVE_TOUCH = 360
Vfx.CULL = 220 -- studs from the camera: an effect this far away doesn't play (unless the player is important)
Vfx.LOW_DETAIL = 160 -- studs: decor layers off, counts halved
Vfx.BUSY = 0.75 -- above this share of the live cap: decor off, counts halved
Vfx.MIN_SCALE = 0.05 -- the slowest Slowmo
Vfx.PARK = CFrame.new(0, -5000, 0) -- where prepared effects wait, out of sight
-- a CylinderHandleAdornment's axis is its Z: this lays it flat; default until spike S12 measures (S12 also checks that
-- InnerRadius draws a ring, not a disc)
Vfx.RING_FLAT = CFrame.Angles(math.rad(90), 0, 0)
Vfx.live = 0 -- particles emitted by effects that are still alive (an estimate for the cap)

local running = {} -- [player] = true while it has effects to step
local beat = nil
local warned = {}

local function warnOnce(key, msg)
	if not warned[key] then
		warned[key] = true
		warn("CutsceneKit VFX: " .. msg)
	end
end

Vfx.EASE = {
	linear = function(x)
		return x
	end,
	["in"] = function(x)
		return x * x
	end,
	out = function(x)
		return 1 - (1 - x) * (1 - x)
	end,
	inout = function(x)
		if x < 0.5 then
			return 2 * x * x
		end
		return 1 - 2 * (1 - x) * (1 - x)
	end,
	in3 = function(x)
		return x * x * x
	end,
	out3 = function(x)
		return 1 - (1 - x) ^ 3
	end,
	hold = function(x)
		return x >= 1 and 1 or 0
	end,
}

local function ease(name, x)
	return (Vfx.EASE[name or "linear"] or Vfx.EASE.linear)(math.clamp(x, 0, 1))
end

-- v = a number, {from, to} over `life` with `easeName`, or keys {{t, v[, ease]}, ...} (ease shapes the way INTO a key)
function Vfx.curve(v, lt, life, easeName)
	if type(v) == "number" then
		return v
	end
	if type(v[1]) == "number" then
		return v[1] + (v[2] - v[1]) * ease(easeName, (life and life > 0) and lt / life or 1)
	end
	local n = #v
	if lt <= v[1][1] then
		return v[1][2]
	end
	for i = 2, n do
		local b = v[i]
		if lt <= b[1] then
			local a = v[i - 1]
			local span = b[1] - a[1]
			return a[2] + (b[2] - a[2]) * ease(b[3], span > 0 and (lt - a[1]) / span or 1)
		end
	end
	return v[n][2]
end

-- a number or {{x, v}, ...} (x from 0 to 1 over a particle's life) -> NumberSequence, values times k
function Vfx.seq(v, k)
	k = k or 1
	if type(v) == "number" then
		return NumberSequence.new(v * k)
	end
	local points = {}
	for _, p in ipairs(v) do
		table.insert(points, NumberSequenceKeypoint.new(p[1], p[2] * k))
	end
	return NumberSequence.new(points)
end

local function range(v, k)
	k = k or 1
	if type(v) == "table" then
		return NumberRange.new(math.min(v[1], v[2]) * k, math.max(v[1], v[2]) * k)
	end
	return NumberRange.new((v or 0) * k)
end

local function vec(t, k)
	if type(t) ~= "table" then
		return Vector3.zero
	end
	return Vector3.new(t[1] or 0, t[2] or 0, t[3] or 0) * (k or 1)
end

function Vfx.hex(s)
	local h = string.gsub(s or "", "^#", "")
	local r, g, b = tonumber(string.sub(h, 1, 2), 16), tonumber(string.sub(h, 3, 4), 16), tonumber(string.sub(h, 5, 6), 16)
	return Color3.fromRGB(r or 255, g or 255, b or 255)
end

-- an element's colours by role: main, hot, dark, glow, spark, debris, accent (hot if the element has none), deep
-- (main halfway to dark), white, black
function Vfx.palette(element)
	local src = Lib.Elements[element or ""]
	if not src then
		if element then
			warnOnce("element:" .. tostring(element), ("unknown element %s, using teal"):format(tostring(element)))
		end
		src = Lib.Elements.teal
	end
	local pal = {}
	for role, hex in pairs(src) do
		pal[role] = Vfx.hex(hex)
	end
	pal.accent = pal.accent or pal.hot
	pal.deep = pal.main:Lerp(pal.dark, 0.5)
	pal.white = Color3.new(1, 1, 1)
	pal.black = Color3.new(0, 0, 0)
	return pal
end

-- a role name, or "#rrggbb"
function Vfx.color(pal, role)
	if type(role) == "string" and string.sub(role, 1, 1) == "#" then
		return Vfx.hex(role)
	end
	return pal[role or "main"] or pal.main
end

local function colors(pal, role)
	if type(role) == "table" then
		return ColorSequence.new(Vfx.color(pal, role[1]), Vfx.color(pal, role[2]))
	end
	return ColorSequence.new(Vfx.color(pal, role))
end

-- the same rule as kit/vfxlib.py budget()
function Vfx.budget(name)
	local out = { particles = 0, lights = 0, highlights = 0, parts = 0 }
	local preset = Lib.Presets[name]
	for _, L in ipairs(preset and preset.layers or {}) do
		if L.kind == "emit" then
			out.particles += L.count
		elseif L.kind == "light" then
			out.lights += 1
		elseif L.kind == "ring" or L.kind == "shape" then
			out.parts += 1
		elseif L.kind == "trail" or L.kind == "rocks" then
			out.parts += L.count
		elseif L.kind == "bolt" or L.kind == "cracks" then
			out.parts += L.count * L.segments * 2
		end
	end
	return out
end

function Vfx.preset(name)
	return Lib.Presets[name]
end

function Vfx.touch()
	return UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled
end

-- 1 on PC, 0.6 on phones and tablets, at most 0.5 when the player set graphics quality to 1-3 (0.5 drops decor layers)
function Vfx.quality()
	local q = Vfx.touch() and 0.6 or 1
	local ok, level = pcall(function()
		return UserSettings():GetService("UserGameSettings").SavedQualityLevel.Value
	end)
	if ok and type(level) == "number" and level > 0 and level <= 3 then
		q = math.min(q, 0.5)
	end
	return q
end

function Vfx.cap()
	return Vfx.touch() and Vfx.MAX_LIVE_TOUCH or Vfx.MAX_LIVE
end

-- count scale, decor on, culled. Decor needs quality above 0.5: phones (0.6) keep it, graphics level 1-3 (0.5) don't.
function Vfx.detail(p, pos)
	local cam = workspace.CurrentCamera
	local dist = cam and (cam.CFrame.Position - pos).Magnitude or 0
	if dist > Vfx.CULL and not p.important then
		return 0, false, true
	end
	local k, decor = p.quality, p.quality > 0.5
	if dist > Vfx.LOW_DETAIL or Vfx.live > Vfx.BUSY * Vfx.cap() then
		k *= 0.5
		decor = false
	end
	return k, decor, false
end

function Vfx.preload()
	local list = {}
	for _, id in pairs(Lib.Textures) do
		table.insert(list, id)
	end
	pcall(ContentProvider.PreloadAsync, ContentProvider, list)
end

local function newPart(name, parent)
	local p = Instance.new("Part")
	p.Name = name
	p.Anchored = true
	p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = false, false, false, false
	p.Massless = true
	p.Transparency = 1
	p.Size = Vector3.new(0.2, 0.2, 0.2)
	p.Material = Enum.Material.Neon
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.CFrame = Vfx.PARK
	p.Parent = parent
	return p
end

local function unit(rng)
	local z = rng:NextNumber(-1, 1)
	local a = rng:NextNumber(0, 2 * math.pi)
	local r = math.sqrt(1 - z * z)
	return Vector3.new(r * math.cos(a), z, r * math.sin(a))
end

local function cone(rng, axis, deg)
	local ref = math.abs(axis.Y) < 0.9 and Vector3.yAxis or Vector3.xAxis
	local p = axis:Cross(ref).Unit
	local q = axis:Cross(p)
	local th = math.rad(deg) * math.sqrt(rng:NextNumber())
	local ph = rng:NextNumber(0, 2 * math.pi)
	return (axis * math.cos(th) + (p * math.cos(ph) + q * math.sin(ph)) * math.sin(th)).Unit
end

local function aim(pos, dir)
	local up = math.abs(dir.Y) > 0.99 and Vector3.xAxis or Vector3.yAxis
	return CFrame.lookAt(pos, pos + dir, up)
end

-- where one particle starts and which way it flies, in the effect's frame (EmissionDirection Front = the attachment's
-- look vector, so aiming the attachment aims the particle)
local function spawn(L, rng, k)
	local at = vec(L.at, k)
	local r = (L.radius or 0) * k
	local dir = L.dir or "none"
	if dir == "up" then
		local a = rng:NextNumber(0, 2 * math.pi)
		local pos = at + Vector3.new(math.cos(a), 0, math.sin(a)) * r * math.sqrt(rng:NextNumber())
		return aim(pos, cone(rng, Vector3.yAxis, L.spread or 0))
	elseif dir == "cone" then
		return aim(at, cone(rng, Vector3.new(0, 0, -1), L.spread or 30))
	elseif dir == "sphere" then
		local d = (unit(rng) + Vector3.yAxis * (L.up or 0)).Unit
		return aim(at + d * r * rng:NextNumber(), d)
	elseif dir == "disc" then
		local a = rng:NextNumber(0, 2 * math.pi)
		local radial = Vector3.new(math.cos(a), 0, math.sin(a))
		return aim(at + radial * r * rng:NextNumber(0.5, 1), (radial + Vector3.yAxis * (L.up or 0)).Unit)
	elseif dir == "ringin" then
		local a = rng:NextNumber(0, 2 * math.pi)
		local radial = Vector3.new(math.cos(a), 0, math.sin(a))
		return aim(at + radial * r, -radial)
	elseif dir == "converge" then
		local d = (unit(rng) + Vector3.yAxis * (L.up or 0)).Unit
		return aim(at + d * r, -d)
	end
	return CFrame.new(at)
end

-- the floor under pos: its height, material and colour (rocks and cracks take the ground's look)
local function ground(e, pos)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	local ignore = { e.player.parent }
	for _, inst in ipairs(e.player.ignore) do
		table.insert(ignore, inst)
	end
	for _, pl in ipairs(Players:GetPlayers()) do
		if pl.Character then
			table.insert(ignore, pl.Character)
		end
	end
	params.FilterDescendantsInstances = ignore
	params.RespectCanCollide = true
	local hit = workspace:Raycast(pos + Vector3.new(0, 3, 0), Vector3.new(0, -12, 0), params)
	if not hit then
		return pos.Y, nil, nil
	end
	local color = hit.Instance:IsA("BasePart") and hit.Instance.Color or nil
	if hit.Instance:IsA("Terrain") then
		local ok, c = pcall(workspace.Terrain.GetMaterialColor, workspace.Terrain, hit.Material)
		color = ok and c or Color3.fromRGB(110, 104, 96)
	end
	return hit.Position.Y, hit.Material, color
end

-- One builder per layer kind. Each returns { t, decor, start(lt)?, update(lt) }; lt = seconds since the layer started.
local Build = {}

function Build.emit(L, e)
	local att = Instance.new("Attachment")
	att.Name = "Emit"
	att.Parent = e.anchor
	local em = Instance.new("ParticleEmitter")
	em.Enabled = false
	em.Rate = 0
	em.Texture = Lib.Textures[L.texture] or ""
	em.Color = colors(e.pal, L.role)
	em.LightEmission = L.le or 1
	em.LightInfluence = 0
	em.Brightness = L.bright or 1
	em.Size = Vfx.seq(L.size or 1, e.scale)
	em.Transparency = Vfx.seq(L.transp or 0)
	if L.squash then
		em.Squash = Vfx.seq(L.squash)
	end
	em.Lifetime = range(L.life)
	em.Speed = range(L.speed or 0, e.scale)
	em.SpreadAngle = Vector2.zero
	em.EmissionDirection = Enum.NormalId.Front
	em.Orientation = (L.orient == "vpar" and Enum.ParticleOrientation.VelocityParallel)
		or (L.orient == "vperp" and Enum.ParticleOrientation.VelocityPerpendicular)
		or Enum.ParticleOrientation.FacingCamera
	em.Rotation = range(L.rot or 0)
	em.RotSpeed = range(L.spin or 0)
	em.Drag = L.drag or 0
	em.Acceleration = vec(L.acc, e.scale)
	em.ZOffset = L.zoff or 0
	em.LockedToPart = false
	em.VelocityInheritance = 0
	em.TimeScale = e.player.timeScale
	em.Parent = att
	table.insert(e.emitters, em)
	local n, done = 0, 0
	return {
		t = L.t or 0,
		decor = L.decor,
		start = function()
			n = L.count > 0 and math.max(1, math.floor(L.count * e.detail + 0.5)) or 0
			e.particles += n
			Vfx.live += n
		end,
		update = function(lt)
			if done >= n then
				return
			end
			local over = L.over or 0
			local due = over > 0 and math.min(n, math.floor(n * math.clamp(lt / over, 0, 1)) + 1) or n
			for _ = done + 1, due do
				att.WorldCFrame = e.frame * spawn(L, e.rng, e.scale)
				em:Emit(1)
			end
			done = due
		end,
	}
end

function Build.ring(L, e)
	local holder = newPart("Ring", e.model)
	local a = Instance.new("CylinderHandleAdornment")
	a.Name = "Ring"
	a.Adornee = holder
	a.Angle = 360
	a.Height = (L.height or 0.06) * e.scale
	a.Radius, a.InnerRadius = 0.05, 0
	a.Color3 = Vfx.color(e.pal, L.role)
	a.Transparency = 1
	a.AlwaysOnTop = false
	a.CFrame = Vfx.RING_FLAT
	a.Parent = holder
	return {
		t = L.t or 0,
		decor = L.decor,
		update = function(lt)
			if lt > L.life then
				a.Transparency = 1
				return
			end
			local r = Vfx.curve(L.r, lt, L.life, L.ease or "out3") * e.scale
			local w = math.max(0.02, Vfx.curve(L.width, lt, L.life, L.ease or "out3") * e.scale)
			a.Radius = r + w / 2
			a.InnerRadius = math.max(0, r - w / 2)
			local alpha = L.alpha and Vfx.curve(L.alpha, lt, L.life) or (1 - lt / L.life)
			a.Transparency = 1 - math.clamp(alpha, 0, 1)
			holder.CFrame = e.frame * CFrame.new(vec(L.at, e.scale))
				* CFrame.Angles(math.rad(L.tilt or 0), math.rad((L.spin or 0) * lt), 0)
		end,
	}
end

function Build.shape(L, e)
	local p = newPart("Shape", e.model)
	p.Material = Enum.Material[L.material or "Neon"]
	p.Color = Vfx.color(e.pal, L.role)
	p.Shape = L.shape == "ball" and Enum.PartType.Ball or Enum.PartType.Cylinder
	local k = e.scale
	return {
		t = L.t or 0,
		decor = L.decor,
		update = function(lt)
			if lt > L.life then
				p.Transparency = 1
				return
			end
			local r = math.max(0.025, Vfx.curve(L.r, lt, L.life, "out") * k)
			local base = e.frame * CFrame.new(vec(L.at, k)) * CFrame.Angles(0, math.rad((L.spin or 0) * lt), 0)
			if L.shape == "ball" then
				p.Size = Vector3.one * (2 * r)
				p.CFrame = base
			elseif L.shape == "column" then
				local h = math.max(0.05, Vfx.curve(L.h, lt, L.life, "out") * k)
				p.Size = Vector3.new(h, 2 * r, 2 * r)
				p.CFrame = base * CFrame.new(0, h / 2, 0) * CFrame.Angles(0, 0, math.rad(90))
			else
				p.Size = Vector3.new((L.thick or 0.05) * k, 2 * r, 2 * r)
				p.CFrame = base * CFrame.Angles(0, 0, math.rad(90))
			end
			local alpha = L.alpha and Vfx.curve(L.alpha, lt, L.life) or (1 - lt / L.life)
			p.Transparency = 1 - math.clamp(alpha, 0, 1)
		end,
	}
end

function Build.trail(L, e)
	local lines = {}
	for i = 1, L.count do
		local holder = newPart("Wind", e.model)
		local a0, a1 = Instance.new("Attachment"), Instance.new("Attachment")
		a0.Parent, a1.Parent = holder, holder
		local tr = Instance.new("Trail")
		tr.Attachment0, tr.Attachment1 = a0, a1
		tr.Lifetime = L.trailLife or 0.25
		tr.FaceCamera = true
		tr.LightEmission = L.le or 1
		tr.LightInfluence = 0
		tr.Color = colors(e.pal, L.role)
		tr.Transparency = NumberSequence.new(1 - (L.alpha or 0.7), 1)
		tr.WidthScale = NumberSequence.new(1, 0)
		tr.MinLength = 0.05
		tr.Enabled = false
		tr.Parent = holder
		lines[i] = { holder = holder, a0 = a0, a1 = a1, trail = tr,
			phase = (i - 1) / L.count * 2 * math.pi + e.rng:NextNumber(-0.3, 0.3) }
	end
	local function place(line, lt)
		local k = e.scale
		local x = math.clamp(lt / L.life, 0, 1)
		local ang = line.phase + L.turns * 2 * math.pi * x
		local r = Vfx.curve(L.radius, lt, L.life, "inout") * k
		local h = Vfx.curve(L.height, lt, L.life, "out") * k
		local w = Vfx.curve(L.width, lt, L.life) * k
		line.holder.CFrame = e.frame * CFrame.new(vec(L.at, k)) * CFrame.Angles(0, ang, 0) * CFrame.new(r, h, 0)
		line.a0.Position = Vector3.new(0, -w / 2, 0)
		line.a1.Position = Vector3.new(0, w / 2, 0)
	end
	return {
		t = L.t or 0,
		decor = L.decor,
		start = function(lt)
			for _, line in ipairs(lines) do
				place(line, lt) -- in place first, so the trail never streaks in from the parking spot
				line.trail:Clear()
				line.trail.Enabled = true
			end
		end,
		update = function(lt)
			for _, line in ipairs(lines) do
				if lt > L.life then
					line.trail.Enabled = false
				else
					place(line, lt)
				end
			end
		end,
	}
end

function Build.bolt(L, e)
	local bolts = {}
	for i = 1, L.count do
		local segs = {}
		for j = 1, L.segments do
			local core = newPart("Bolt", e.model)
			core.Color = Vfx.color(e.pal, L.role or "hot")
			local glow = newPart("BoltGlow", e.model)
			glow.Color = Vfx.color(e.pal, L.glow or "main")
			segs[j] = { core = core, glow = glow }
		end
		bolts[i] = segs
	end
	local nextAt, shown = 0, false
	local function hide()
		for _, segs in ipairs(bolts) do
			for _, s in ipairs(segs) do
				s.core.Transparency, s.glow.Transparency = 1, 1
			end
		end
		shown = false
	end
	local function redraw()
		local k = e.scale
		local from = (e.frame * CFrame.new(vec(L.at, k))).Position
		for _, segs in ipairs(bolts) do
			local axis = unit(e.rng) * e.rng:NextNumber(L.radius[1], L.radius[2]) * k
			local side = axis:Cross(math.abs(axis.Unit.Y) < 0.9 and Vector3.yAxis or Vector3.xAxis).Unit
			local up = axis.Unit:Cross(side)
			local prev = from
			local n = #segs
			for j, s in ipairs(segs) do
				local x = j / n
				local p = from + axis * x
				if j < n then
					local amp = (L.jitter or 0.5) * k * math.sin(math.pi * x)
					p += side * e.rng:NextNumber(-amp, amp) + up * e.rng:NextNumber(-amp, amp)
				end
				local len = (p - prev).Magnitude
				if len > 1e-3 then
					local cf = CFrame.lookAt((prev + p) / 2, p)
					s.core.Size = Vector3.new(L.width * k, L.width * k, len)
					s.core.CFrame = cf
					s.core.Transparency = 0
					s.glow.Size = Vector3.new(L.width * 3 * k, L.width * 3 * k, len)
					s.glow.CFrame = cf
					s.glow.Transparency = 0.6
				end
				prev = p
			end
		end
		shown = true
	end
	return {
		t = L.t or 0,
		decor = L.decor,
		update = function(lt)
			if lt > L.life then
				if shown then
					hide()
				end
				return
			end
			if lt >= nextAt then
				nextAt = lt + (L.flicker or 0.05)
				if e.rng:NextNumber() < 0.75 then -- a bolt flickers: some redraws are dark frames
					redraw()
				else
					hide()
				end
			end
		end,
	}
end

function Build.rocks(L, e)
	local rocks = {}
	for i = 1, L.count do
		local p = newPart("Rock", e.model)
		p.Material = Enum.Material.Slate
		local s = e.rng:NextNumber(L.size[1], L.size[2]) * e.scale
		p.Size = Vector3.new(s, s * e.rng:NextNumber(0.6, 1), s * e.rng:NextNumber(0.7, 1.1))
		rocks[i] = { part = p, size = s }
	end
	local floor = 0
	return {
		t = L.t or 0,
		decor = L.decor,
		start = function()
			local origin = (e.frame * CFrame.new(vec(L.at, e.scale))).Position
			local y, material, color = ground(e, origin)
			floor = y
			for i, r in ipairs(rocks) do
				if L.material == "ground" and material then
					r.part.Material = material
					r.part.Color = color
				else
					r.part.Color = Vfx.color(e.pal, (L.material and L.material ~= "ground") and L.material or "debris")
				end
				local a = L.mode == "rim" and (i / #rocks) * 2 * math.pi + e.rng:NextNumber(-0.15, 0.15)
					or e.rng:NextNumber(0, 2 * math.pi)
				local radial = Vector3.new(math.cos(a), 0, math.sin(a))
				r.p0 = Vector3.new(origin.X, floor, origin.Z) + radial * e.rng:NextNumber(L.radius[1], L.radius[2]) * e.scale
				local speed = L.speed and e.rng:NextNumber(L.speed[1], L.speed[2]) or 0
				local upSpeed = L.up and e.rng:NextNumber(L.up[1], L.up[2]) or 0
				r.v = (radial * speed + Vector3.yAxis * upSpeed) * e.scale
				r.lift = (L.lift and e.rng:NextNumber(L.lift[1], L.lift[2]) or 0) * e.scale
				r.axis = unit(e.rng)
				r.yaw = math.atan2(radial.X, radial.Z)
				r.part.Transparency = 0
			end
		end,
		update = function(lt)
			if lt > L.life then
				for _, r in ipairs(rocks) do
					r.part.Transparency = 1
				end
				return
			end
			local sink = L.sink or 0.4
			local fadeAt = L.life - sink
			for _, r in ipairs(rocks) do
				local pos, rot
				local rest = floor + r.size * 0.3
				if L.mode == "eject" then
					local g = (L.gravity or 60) * e.scale
					pos = r.p0 + r.v * lt - Vector3.new(0, 0.5 * g * lt * lt, 0)
					if pos.Y < rest then
						pos = Vector3.new(pos.X, rest, pos.Z) -- landed
					end
					rot = CFrame.fromAxisAngle(r.axis, math.rad((L.spin or 0) * math.min(lt, 1.2)))
				elseif L.mode == "rim" then
					local x = Vfx.EASE.out3(math.clamp(lt / (L.rise or 0.12), 0, 1))
					pos = r.p0 + Vector3.new(0, -r.size + r.size * 1.25 * x, 0)
					rot = CFrame.Angles(0, r.yaw, 0) * CFrame.Angles(math.rad(L.tilt or 30), 0, 0)
				else -- lift: rise, hang and bob, then drop
					local rise = L.rise or 0.8
					local up = r.lift * Vfx.EASE.out(math.clamp(lt / rise, 0, 1))
					local bob = math.sin(lt * 2.2 + r.yaw) * 0.15 * e.scale * math.clamp(lt / rise, 0, 1)
					local dropAt = rise + (L.hang or 2)
					local fall = lt > dropAt and 0.5 * 60 * e.scale * (lt - dropAt) ^ 2 or 0
					pos = Vector3.new(r.p0.X, math.max(rest, r.p0.Y + r.size * 0.3 + up + bob - fall), r.p0.Z)
					rot = CFrame.fromAxisAngle(r.axis, math.rad((L.spin or 30) * lt))
				end
				if lt > fadeAt then -- sink into the floor and fade (rocks never just vanish)
					local x = math.clamp((lt - fadeAt) / sink, 0, 1)
					pos -= Vector3.new(0, r.size * x, 0)
					r.part.Transparency = x
				end
				r.part.CFrame = CFrame.new(pos) * rot
			end
		end,
	}
end

function Build.cracks(L, e)
	local cracks = {}
	for i = 1, L.count do
		local segs = {}
		for j = 1, L.segments do
			local edge = newPart("CrackEdge", e.model)
			edge.Material = Enum.Material.SmoothPlastic
			edge.Color = Vfx.color(e.pal, "dark")
			local glow = newPart("Crack", e.model)
			glow.Color = Vfx.color(e.pal, L.role or "glow")
			segs[j] = { edge = edge, glow = glow }
		end
		cracks[i] = segs
	end
	return {
		t = L.t or 0,
		decor = L.decor,
		start = function()
			local k = e.scale
			local origin = (e.frame * CFrame.new(vec(L.at, k))).Position
			local y = ground(e, origin) + 0.03
			for i, segs in ipairs(cracks) do
				local a = (i / #cracks) * 2 * math.pi + e.rng:NextNumber(-0.25, 0.25)
				local step = e.rng:NextNumber(L.length[1], L.length[2]) * k / #segs
				local p = Vector3.new(origin.X, y, origin.Z) + Vector3.new(math.cos(a), 0, math.sin(a)) * (L.from or 0.4) * k
				for _, s in ipairs(segs) do
					a += e.rng:NextNumber(-(L.jitter or 0.5), L.jitter or 0.5)
					local q = p + Vector3.new(math.cos(a), 0, math.sin(a)) * step
					s.a, s.b = p, q
					p = q
				end
			end
		end,
		update = function(lt)
			local k = e.scale
			local grown = math.clamp(lt / L.grow, 0, 1)
			local fadeAt = L.grow + (L.hold or 0.5)
			local alpha = lt > fadeAt and 1 - math.clamp((lt - fadeAt) / (L.fade or 0.4), 0, 1) or 1
			if lt > L.life then
				alpha = 0
			end
			for _, segs in ipairs(cracks) do
				local n = #segs
				for j, s in ipairs(segs) do
					local x = math.clamp(grown * n - (j - 1), 0, 1)
					local b = s.a:Lerp(s.b, x)
					local len = (b - s.a).Magnitude
					if x <= 0 or alpha <= 0 or len < 1e-3 then
						s.edge.Transparency, s.glow.Transparency = 1, 1
					else
						local cf = CFrame.lookAt((s.a + b) / 2, b)
						local w = L.width * k * (1 - 0.5 * (j - 1) / n) -- thinner toward the tip
						s.glow.Size = Vector3.new(w, 0.04, len)
						s.glow.CFrame = cf
						s.glow.Transparency = 1 - alpha
						s.edge.Size = Vector3.new(w * 2.4, 0.03, len + w)
						s.edge.CFrame = cf * CFrame.new(0, -0.01, 0)
						s.edge.Transparency = 1 - alpha * 0.8
					end
				end
			end
		end,
	}
end

function Build.light(L, e)
	local att = Instance.new("Attachment")
	att.Name = "Light"
	att.Parent = e.anchor
	local light = Instance.new("PointLight")
	light.Shadows = false
	light.Brightness = 0
	light.Range = L.range * e.scale
	light.Color = Vfx.color(e.pal, L.role)
	light.Parent = att
	return {
		t = L.t or 0,
		update = function(lt)
			if lt > L.life then
				light.Brightness = 0
				return
			end
			att.WorldPosition = (e.frame * CFrame.new(vec(L.at, e.scale))).Position
			light.Brightness = math.max(0, Vfx.curve(L.brightness, lt, L.life))
		end,
	}
end

-- opts = { parent = Instance?, element = string?, manual = bool? (the owner calls Vfx.step), important = bool? (never
-- culled: the cinematic viewer's own scene), quality = number?, ignore = { Instance }? (left out of ground raycasts) }
function Vfx.new(opts)
	opts = opts or {}
	local parent = opts.parent
	if not parent then
		parent = Instance.new("Folder")
		parent.Name = "CutsceneVfx"
		parent.Parent = workspace
	end
	return { parent = parent, element = opts.element, effects = {}, prepared = {}, timeScale = 1,
		manual = opts.manual == true, important = opts.important == true, quality = opts.quality or Vfx.quality(),
		ignore = opts.ignore or {} }
end

-- Builds a preset's instances now (parked out of sight); Vfx.fire starts it. opts = { element, scale, follow =
-- BasePart? (the effect rides on it), offset = CFrame? (from the followed part, or after the fire CFrame) }
function Vfx.prepare(p, name, opts)
	opts = opts or {}
	local preset = Lib.Presets[name]
	if not preset then
		warnOnce("preset:" .. tostring(name), ("no VFX preset %s"):format(tostring(name)))
		return nil
	end
	local model = Instance.new("Model")
	model.Name = "Vfx_" .. name
	local e = { name = name, preset = preset, player = p, model = model, layers = {}, emitters = {}, age = 0,
		life = preset.life, scale = opts.scale or 1, pal = Vfx.palette(opts.element or p.element), frame = Vfx.PARK,
		follow = opts.follow, offset = opts.offset or CFrame.identity, rng = Random.new(), detail = 1,
		particles = 0, started = false, done = false, key = preset.key == true }
	e.anchor = newPart("Anchor", model)
	for _, L in ipairs(preset.layers) do
		local make = Build[L.kind]
		if make then
			table.insert(e.layers, make(L, e))
		else
			warnOnce("kind:" .. tostring(L.kind), ("%s: unknown layer kind %s"):format(name, tostring(L.kind)))
		end
	end
	model:SetAttribute("Preset", name)
	model.Parent = p.parent
	table.insert(p.prepared, e)
	return e
end

function Vfx.destroy(e)
	if e.done then
		return
	end
	e.done = true
	Vfx.live = math.max(0, Vfx.live - e.particles)
	e.model:Destroy()
end

function Vfx.stepEffect(e, dt)
	if e.done then
		return
	end
	e.age += dt
	if e.follow and e.follow.Parent then
		e.frame = e.follow.CFrame * e.offset
	end
	if e.age >= e.life then
		Vfx.destroy(e)
		return
	end
	for _, layer in ipairs(e.layers) do
		if not layer.skip then
			local lt = e.age - layer.t
			if lt >= 0 then
				if not layer.started then
					layer.started = true
					if layer.start then
						layer.start(lt)
					end
				end
				layer.update(lt)
			end
		end
	end
end

-- a step error removes that effect only (the first frame in Vfx.fire included); false when it did
local function safeStep(e, dt)
	local ok, err = pcall(Vfx.stepEffect, e, dt)
	if not ok then
		warnOnce("step:" .. e.name, ("%s failed and was removed: %s"):format(e.name, tostring(err)))
		Vfx.destroy(e)
	end
	return ok
end

function Vfx.step(p, dt)
	local k = p.timeScale
	for i = #p.effects, 1, -1 do
		local e = p.effects[i]
		safeStep(e, dt * k)
		if e.done then
			table.remove(p.effects, i)
		end
	end
	for i = #p.prepared, 1, -1 do
		if p.prepared[i].done then
			table.remove(p.prepared, i)
		end
	end
end

-- one Heartbeat steps every player that has effects; it disconnects when none do
function Vfx.run(p)
	if p.manual or running[p] then
		return
	end
	running[p] = true
	if not beat then
		beat = RunService.Heartbeat:Connect(function(dt)
			for q in pairs(running) do
				Vfx.step(q, dt)
				if #q.effects == 0 then
					running[q] = nil
				end
			end
			if next(running) == nil and beat then
				beat:Disconnect()
				beat = nil
			end
		end)
	end
end

-- Starts a prepared effect at cf (ignored when it follows a part). False when it is culled (too far), gone, or breaks
-- on its first frame.
function Vfx.fire(e, cf)
	if not e or e.started or e.done then
		return false
	end
	local p = e.player
	if e.follow then
		if not e.follow.Parent then
			Vfx.destroy(e)
			return false
		end
		e.frame = e.follow.CFrame * e.offset
	elseif cf then
		e.frame = cf * e.offset
	end
	local detail, decor, culled = Vfx.detail(p, e.frame.Position)
	if culled then
		Vfx.destroy(e)
		return false
	end
	e.detail = detail
	for _, layer in ipairs(e.layers) do
		layer.skip = layer.decor == true and not decor
	end
	e.started = true
	if not safeStep(e, 0) then
		return false
	end
	table.insert(p.effects, e)
	Debris:AddItem(e.model, e.life / Vfx.MIN_SCALE + 5) -- safety net if the loop ever dies
	Vfx.run(p)
	return true
end

function Vfx.play(p, name, cf, opts)
	local e = Vfx.prepare(p, name, opts)
	if e and Vfx.fire(e, cf) then
		return e
	end
	return nil
end

-- Slowmo: k in [MIN_SCALE, 1] slows the timeline and every particle already in the air
function Vfx.setTimeScale(p, k)
	p.timeScale = math.clamp(k, Vfx.MIN_SCALE, 1)
	for _, e in ipairs(p.prepared) do
		for _, em in ipairs(e.emitters) do
			em.TimeScale = p.timeScale
		end
	end
end

-- the models of live effects (keyOnly: the presets marked key, which impact frames highlight)
function Vfx.models(p, keyOnly)
	local out = {}
	for _, e in ipairs(p.effects) do
		if not e.done and (not keyOnly or e.key) then
			table.insert(out, e.model)
		end
	end
	return out
end

function Vfx.clear(p)
	running[p] = nil
	for _, e in ipairs(p.prepared) do
		Vfx.destroy(e)
	end
	table.clear(p.prepared)
	table.clear(p.effects)
end

return Vfx
