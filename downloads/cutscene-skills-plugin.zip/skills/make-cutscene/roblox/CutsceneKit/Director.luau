-- Director: plays one cutscene on this client. Method by fwjelaa (FWJ STUDIOS).
-- The camera rides on a local Stage rig at the scene anchor (Motor6D "CutsceneCamera"); the cast clips start on the
-- same frame; the data module's markers fire screen effects, VFX, dialogue and shake by timeline time. Story and intro
-- scenes act with local clones; awakenings and ultimates act with the player's real character (the server pinned it at
-- the anchor), so everyone else sees the animation. Everything it changes goes back through one cleanup path; a normal
-- end (or a skip) blends the camera back to the player's camera over BLEND seconds. Results: end, skip, died, respawn,
-- load-failed, late, overtime, invalid, error (and replaced, when the server starts another scene).
local AnimationClipProvider = game:GetService("AnimationClipProvider")
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local StarterGui = game:GetService("StarterGui")
local UserInputService = game:GetService("UserInputService")

local Data = require(script.Parent.Data)
local Fov = require(script.Parent.Fov)
local Letterbox = require(script.Parent.Letterbox)
local Markers = require(script.Parent.Markers)
local Schedule = require(script.Parent.Schedule)
local Screen = require(script.Parent.Screen)
local Shake = require(script.Parent.Shake)
local Snapshot = require(script.Parent.Snapshot)
local Subtitles = require(script.Parent.Subtitles)
local Vfx = require(script.Parent.Vfx)

local Director = {}
Director.LOAD_TIMEOUT = 5
Director.OVERTIME = 2
Director.PIN = false -- true pins cast tracks to the stage track every frame (only if the spike measured drift)
Director.RENDER_NAME = "CutsceneKitCamera"
Director.SKIP_ACTION = "CutsceneKitSkip"
Director.BLEND_NAME = "CutsceneKitBlend"
Director.BLEND = 0.55 -- s: the blend back to the player's camera (spec 5.1, 6)
Director.POP_MARGIN = 0.4 -- studs the camera stays in front of a wall between it and the caster
Director.VFX_TAIL = 3 -- s the scene's VFX may keep fading after a normal end (debris sinking, smoke)
Director.LIVE = { awakening = true, ultimate = true } -- kinds acted by the real character
-- R15 part names a cue can follow, and the R6 part that stands in for each
Director.R6_PARTS = {
	UpperTorso = "Torso", LowerTorso = "Torso", LeftHand = "Left Arm", RightHand = "Right Arm",
	LeftUpperArm = "Left Arm", RightUpperArm = "Right Arm", LeftLowerArm = "Left Arm", RightLowerArm = "Right Arm",
	LeftFoot = "Left Leg", RightFoot = "Right Leg", LeftUpperLeg = "Left Leg", RightUpperLeg = "Right Leg",
	LeftLowerLeg = "Left Leg", RightLowerLeg = "Right Leg",
}
-- studs from the caster's head: when walls pull the camera this close, the caster fades locally (as the default camera
-- does in first person) instead of showing the inside of its head; fully from FADE_FULL in (a standard head's reach),
-- and fully whenever the camera is inside one of its parts
Director.FADE_NEAR = 1.5
Director.FADE_FULL = 1

local warned = {}
Director.warned = warned -- the causes already warned about (each warns once per session)
local function warnOnce(key, msg)
	if not warned[key] then
		warned[key] = true
		warn("CutsceneKit: " .. msg)
	end
end
-- results opts.onEnd is not told about: a skip has its own remote, and a replaced scene's server already moved on
Director.UNREPORTED = { skip = true, replaced = true }

function Director.reportsEnd(reason)
	return not Director.UNREPORTED[reason]
end

function Director.liveCast(kind)
	return Director.LIVE[kind] == true
end

-- "Gate/Guard" -> Workspace.Gate.Guard, or nil when any step is missing.
-- Mirror of Capture.resolve (roblox/authoring/Capture.luau): keep the two in sync.
function Director.resolve(path)
	local inst = workspace
	for name in string.gmatch(path or "", "[^/]+") do
		inst = inst:FindFirstChild(name)
		if not inst then
			return nil
		end
	end
	return inst ~= workspace and inst or nil
end

-- world NPCs the cast replaces (Config.Hide), so the scene never shows them twice: parts and decals go invisible
-- locally and the overhead name goes off; Snapshot.restore puts back what the game had
function Director.hideConfigured(s, paths, sceneName)
	for _, path in ipairs(paths or {}) do
		local inst = Director.resolve(path)
		if not inst then
			warn(("CutsceneKit: %s: Config.Hide %q is not in Workspace"):format(sceneName, path))
		else
			if inst:IsA("BasePart") then
				Snapshot.hidePart(s, inst)
			end
			Snapshot.hide(s, inst)
			Snapshot.hideNames(s, inst)
		end
	end
end

-- Wraps a per-frame step: the first error warns once with its traceback and calls onFail; the body never runs again.
function Director.guard(label, fn, onFail)
	local failed = false
	return function(...)
		if failed then
			return
		end
		local ok, err = xpcall(fn, debug.traceback, ...)
		if not ok then
			failed = true
			warn(("CutsceneKit: %s: %s"):format(label, tostring(err)))
			onFail(err)
		end
	end
end

-- An Animation for a clip ref: "rbxassetid://<id>", or (Studio only) the name of a KeyframeSequence in module.Clips.
function Director.animation(module, ref)
	local anim = Instance.new("Animation")
	if string.match(ref, "^rbxassetid://%d+$") then
		anim.AnimationId = ref
		return anim
	end
	local clips = module:FindFirstChild("Clips")
	local kfs = clips and clips:FindFirstChild(ref)
	if not kfs then
		warn(("CutsceneKit: clip %s is neither an asset id nor in %s.Clips"):format(ref, module:GetFullName()))
		return nil
	end
	anim.AnimationId = AnimationClipProvider:RegisterAnimationClip(kfs)
	return anim
end

function Director.stage(anchor, parent)
	local model = Instance.new("Model")
	model.Name = "CutsceneStage"
	local root = Instance.new("Part")
	root.Name = "StageRoot"
	local cam = Instance.new("Part")
	cam.Name = "CutsceneCamera"
	for _, p in { root, cam } do
		p.Size = Vector3.new(0.2, 0.2, 0.2)
		p.Transparency = 1
		p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = false, false, false, false
		p.CFrame = anchor
		p.Parent = model
	end
	root.Anchored = true
	local motor = Instance.new("Motor6D")
	motor.Name = "CutsceneCamera"
	motor.Part0 = root
	motor.Part1 = cam
	motor.Parent = root
	local controller = Instance.new("AnimationController")
	controller.Parent = model
	Instance.new("Animator").Parent = controller
	model.PrimaryPart = root
	model.Parent = parent
	return model, motor
end

function Director.strip(model)
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BaseScript") or d:IsA("ForceField") then
			d:Destroy()
		end
	end
	local hum = model:FindFirstChildOfClass("Humanoid")
	if hum then
		hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
	end
	return model
end

function Director.clonePlayer(character)
	local was = character.Archivable
	character.Archivable = true
	local copy = character:Clone()
	character.Archivable = was
	copy.Name = "CutscenePlayer"
	-- first-person headless fix: the camera scripts hide your own head (and hats); the copy must show everything
	for _, d in ipairs(copy:GetDescendants()) do
		if d:IsA("BasePart") or d:IsA("Decal") then
			d.LocalTransparencyModifier = 0
		end
	end
	return Director.strip(copy)
end

-- Spec 14: a role's costume model (SceneInstall built <role>_R15 and <role>_R6 into the module's Costumes folder): the
-- one for the player's rig, else the other (a creature has one rig), or nil
function Director.costume(module, role, rig)
	local folder = module:FindFirstChild("Costumes")
	local other = rig == "R6" and "R15" or "R6"
	local m = folder and (folder:FindFirstChild(role .. "_" .. rig) or folder:FindFirstChild(role .. "_" .. other))
	return m and m:IsA("Model") and m or nil
end

-- Dresses the cast: every role in data.Costumes acts as a local copy of its costume, matching the player's rig. The
-- player only with Config.Costume, and only in place of their local copy: the real character is never changed, so
-- nothing has to be undone after an end, a skip, a death or an error (the copies go with the scene's folder).
function Director.dress(module, data, cfg, cast, folder, character)
	local hum = character and character:FindFirstChildOfClass("Humanoid")
	local rig = hum and hum.RigType == Enum.HumanoidRigType.R6 and "R6" or "R15"
	for _, role in ipairs(data.Costumes or {}) do
		local playerMayWear = cfg.Costume == true
			and (data.Kind == "story" or data.Kind == "intro")
			and cast.player ~= nil
			and cast.player.Parent == folder
		local wear = role ~= "player" or playerMayWear
		local src = wear and Director.costume(module, role, rig)
		if src then
			local copy = Director.strip(src:Clone())
			copy.Name = role == "player" and "CutscenePlayer" or role
			if cast[role] then
				cast[role]:Destroy()
			end
			copy.Parent = folder
			cast[role] = copy
		elseif wear then
			-- a costumed NPC isn't in the Cast folder, so without its model it is left out; the player keeps their copy
			warn(("CutsceneKit: %s: no costume for %s in its Costumes folder (install the scene again); %s")
				:format(module.Name, role, role == "player" and "it plays as it is" or "it is left out"))
		end
	end
end

-- Stand a cast member on its spot: place = {x, y, z, rx, ry, rz} from the anchor, y = 0 on the floor.
function Director.place(model, anchor, place)
	local hum = model:FindFirstChildOfClass("Humanoid")
	local root = model:FindFirstChild("HumanoidRootPart")
	if not hum or not root then
		warn(("CutsceneKit: cast member %s needs a Humanoid and a HumanoidRootPart; it stays unanimated"):format(model.Name))
		return nil
	end
	local p = place or { 0, 0, 0, 0, 0, 0 }
	local stand = hum.RigType == Enum.HumanoidRigType.R15 and (hum.HipHeight + root.Size.Y / 2) or 3
	root.Anchored = true
	model.PrimaryPart = root
	model:PivotTo(anchor * CFrame.new(p[1], p[2] + stand, p[3])
		* CFrame.Angles(math.rad(p[4] or 0), math.rad(p[5] or 0), math.rad(p[6] or 0)))
	local animator = hum:FindFirstChildOfClass("Animator")
	if not animator then
		animator = Instance.new("Animator")
		animator.Parent = hum
	end
	return animator, hum.RigType == Enum.HumanoidRigType.R6 and "R6" or "R15"
end

-- Where the marker scan starts: an on-time start begins before 0 so a marker at 0 still fires.
function Director.firstPrev(tStart)
	return tStart <= Schedule.ON_TIME and -1 or tStart
end

-- The real character of an awakening or ultimate: the server already pinned it at the anchor; only its Animator is
-- needed (its tracks replicate, so every other player sees them).
function Director.liveRig(model)
	local hum = model:FindFirstChildOfClass("Humanoid")
	if not hum then
		warn(("CutsceneKit: %s has no Humanoid; it stays unanimated"):format(model.Name))
		return nil
	end
	local animator = hum:FindFirstChildOfClass("Animator")
	if not animator then
		animator = Instance.new("Animator")
		animator.Parent = hum
	end
	return animator, hum.RigType == Enum.HumanoidRigType.R6 and "R6" or "R15"
end

-- the cue for a marker: Cues["VFX:Burst"], else Cues["VFX"]
function Director.cueFor(data, name, value)
	local cues = data.Cues
	if type(cues) ~= "table" then
		return nil
	end
	return (value and value ~= "" and cues[name .. ":" .. value]) or cues[name]
end

-- a part of a cast member by R15 name (R6 rigs answer with the nearest R6 part); the root when it is missing
function Director.partOf(model, name)
	if not model then
		return nil
	end
	local p = model:FindFirstChild(name or "HumanoidRootPart")
	if not (p and p:IsA("BasePart")) and name and Director.R6_PARTS[name] then
		p = model:FindFirstChild(Director.R6_PARTS[name])
	end
	if p and p:IsA("BasePart") then
		return p
	end
	local root = model:FindFirstChild("HumanoidRootPart")
	return (root and root:IsA("BasePart")) and root or nil
end

-- "player" (its root) or "player.Head" -> that part in the scene's cast
function Director.follow(ctx, spec)
	if type(spec) ~= "string" then
		return nil
	end
	local role, part = string.match(spec, "^([^%.]+)%.?(.*)$")
	return Director.partOf(ctx.cast[role], part ~= "" and part or nil)
end

local function cueFrame(cue)
	local at = cue.at or { 0, 0, 0 }
	return CFrame.new(at[1], at[2], at[3]) * CFrame.Angles(0, math.rad(cue.yaw or 0), 0)
end

-- where a VFX cue plays: its part (follow) or the scene anchor, moved by at and turned by yaw
function Director.origin(ctx, cue)
	local part = Director.follow(ctx, cue.follow)
	return (part and part.CFrame or ctx.anchor) * cueFrame(cue)
end

local function vfxOptions(ctx, cue)
	local part = Director.follow(ctx, cue.follow)
	return { element = cue.element or ctx.cfg.Element, scale = cue.scale, follow = part,
		offset = part and cueFrame(cue) or nil }
end

-- Builds every VFX marker's effect before the scene starts (emit right after creating can fail: research/03 s3).
function Director.prepareVfx(ctx)
	ctx.prepared = ctx.prepared or {}
	for _, m in ipairs(ctx.data.Markers) do
		if m[2] == "VFX" and ctx.prepared[m] == nil then
			local cue = Director.cueFor(ctx.data, "VFX", m[3])
			if cue and cue.kind == "vfx" and not cue.external then
				ctx.prepared[m] = Vfx.prepare(ctx.fx, cue.preset, vfxOptions(ctx, cue)) or false
			end
		end
	end
end

-- A cue for a FwjelaaVFX preset, when the game has fwjelaa-vfx installed (ReplicatedStorage.FwjelaaVFX). Its effects
-- live in that library's own folder, so its play() result (a stop function) goes in ctx.externals: the scene's finish
-- calls every one of them, on every end. Every failure warns once per cause and never throws. Returns the stop function.
function Director.external(ctx, cue)
	local preset = tostring(cue.preset)
	local module = ReplicatedStorage:FindFirstChild("FwjelaaVFX")
	if not (module and module:IsA("ModuleScript")) then
		warnOnce("fwjelaa:missing", ("a cue plays FwjelaaVFX preset %s, but ReplicatedStorage.FwjelaaVFX is not installed"):format(preset))
		return nil
	end
	local ok, lib = pcall(require, module)
	if not ok then
		warnOnce("fwjelaa:require", "ReplicatedStorage.FwjelaaVFX failed to load: " .. tostring(lib))
		return nil
	end
	if type(lib) ~= "table" or type(lib.play) ~= "function" then
		warnOnce("fwjelaa:api", "ReplicatedStorage.FwjelaaVFX has no play function; its cues are skipped")
		return nil
	end
	local okPlay, stop = pcall(lib.play, cue.preset, Director.origin(ctx, cue), { element = cue.element or ctx.cfg.Element,
		scale = cue.scale, important = true })
	if not okPlay then
		warnOnce("fwjelaa:play:" .. preset, ("FwjelaaVFX preset %s failed: %s"):format(preset, tostring(stop)))
		return nil
	end
	if type(stop) ~= "function" then
		warnOnce("fwjelaa:stop", "FwjelaaVFX.play returned no stop function: its effects can't be stopped when a scene ends")
		return nil
	end
	ctx.externals = ctx.externals or {}
	table.insert(ctx.externals, stop)
	return stop
end

function Director.fireVfx(ctx, m)
	local cue = Director.cueFor(ctx.data, "VFX", m[3])
	if not cue then
		return
	end
	if cue.kind == "screen" then
		if ctx.screen then
			Screen.apply(ctx.screen, m[1], { cue })
		end
		return
	end
	if cue.kind ~= "vfx" then
		return
	end
	if cue.external then
		Director.external(ctx, cue)
		return
	end
	local e = ctx.prepared and ctx.prepared[m]
	if ctx.prepared then
		ctx.prepared[m] = nil
	end
	if not e then
		e = Vfx.prepare(ctx.fx, cue.preset, vfxOptions(ctx, cue))
	end
	if e and Vfx.fire(e, Director.origin(ctx, cue)) and ctx.screen then
		Screen.apply(ctx.screen, m[1], e.preset.screen)
	end
end

-- what an impact frame keeps visible: the cast, then the key VFX (Screen takes at most 8)
function Director.subjects(ctx)
	local out = {}
	for _, model in pairs(ctx.cast or {}) do
		table.insert(out, model)
	end
	if ctx.fx then
		for _, model in ipairs(Vfx.models(ctx.fx, true)) do
			table.insert(out, model)
		end
	end
	return out
end

function Director.cue(ctx, m)
	local name, value = m[2], m[3]
	table.insert(ctx.cues, name)
	if name == "Letterbox" and ctx.letterbox then
		Letterbox.set(ctx.letterbox, value ~= "out")
	elseif name == "Line" then
		local line = ctx.data.Lines and ctx.data.Lines[value]
		if line and ctx.subtitles then
			Subtitles.show(ctx.subtitles, line)
			ctx.lineClearAt = m[1] + (line.hold or Subtitles.hold(line.text or ""))
		end
	elseif name == "Shake" then
		Shake.add(ctx.shake, tonumber(value) or 0.3)
	elseif name == "VFX" then
		Director.fireVfx(ctx, m)
	elseif name == "Impact" then
		if ctx.screen then
			Screen.impact(ctx.screen, m[1], Director.subjects(ctx))
		end
	elseif name == "Flash" then
		if ctx.screen then
			Screen.flash(ctx.screen, m[1], tonumber(value) or 0.85)
		end
	elseif name == "Slowmo" then
		if ctx.fx then
			Vfx.setTimeScale(ctx.fx, tonumber(value) or 1)
		end
	end
	-- Cut is carried by the Fov track and the camera clip, End by the clip's length; SFX and Face arrive in Plans 6-7
end

-- the camera, pulled in front of anything solid between the caster and it (awakenings play wherever the player
-- stands, so no kit check ever saw that spot); never past the focus itself, even with a wall right behind the caster
function Director.clearCamera(focus, cf, params)
	local d = cf.Position - focus
	if d.Magnitude < 0.05 then
		return cf
	end
	local hit = workspace:Raycast(focus, d, params)
	if not hit then
		return cf
	end
	return CFrame.new(focus + d.Unit * math.max(hit.Distance - Director.POP_MARGIN, 0)) * cf.Rotation
end

-- how far the caster fades for a camera this many studs from its head: 0 from FADE_NEAR out, 1 at FADE_FULL and in
function Director.fadeFor(dist)
	return math.clamp((Director.FADE_NEAR - dist) / (Director.FADE_NEAR - Director.FADE_FULL), 0, 1)
end

-- true when pos is inside one of model's parts (their boxes)
function Director.insideModel(model, pos)
	for _, p in ipairs(model:GetDescendants()) do
		if p:IsA("BasePart") then
			local rel = p.CFrame:PointToObjectSpace(pos)
			local h = p.Size / 2
			if math.abs(rel.X) <= h.X and math.abs(rel.Y) <= h.Y and math.abs(rel.Z) <= h.Z then
				return true
			end
		end
	end
	return false
end

-- Fades a model locally (LocalTransparencyModifier) to k. state remembers each part's own value the first time it is
-- touched; k = 0 (or Director.unfade) puts those values back. Re-applied every frame, after the camera scripts.
function Director.fade(state, model, k)
	if k <= 0 or not model then
		Director.unfade(state)
		return
	end
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") or d:IsA("Decal") then
			local own = state[d]
			if own == nil then
				own = d.LocalTransparencyModifier
				state[d] = own
			end
			d.LocalTransparencyModifier = math.max(own, k)
		end
	end
end

function Director.unfade(state)
	for d, own in pairs(state) do
		if d.Parent then
			d.LocalTransparencyModifier = own
		end
	end
	table.clear(state)
end

-- One frame of the camera guard (live scenes). g = { params, caster, root, keep = { Instance }, fade = {}, k }:
-- the camera goes in front of anything solid between the caster's head and it, and when that leaves it within
-- FADE_NEAR of the head the caster fades (g.k). The characters to see through are read again every frame, so someone
-- who spawns mid-scene is left out of the ray too.
function Director.guardCamera(g, cf)
	local root = g.root
	if not (root and root.Parent) then
		g.k = 0
		Director.unfade(g.fade)
		return cf
	end
	local ignore = table.clone(g.keep)
	table.insert(ignore, g.caster)
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	g.params.FilterDescendantsInstances = ignore
	local head = root.Position + Vector3.new(0, 1.5, 0)
	local out = Director.clearCamera(head, cf, g.params)
	local k = Director.fadeFor((out.Position - head).Magnitude)
	if k > 0 and k < 1 and Director.insideModel(g.caster, out.Position) then
		k = 1 -- a big head or a hat: the inside of a part is never drawn half faded
	end
	g.k = k
	Director.fade(g.fade, g.caster, k)
	return out
end

-- Reduced Motion: the same position and look, with the roll taken out
function Director.noRoll(cf)
	local look = cf.LookVector
	if math.abs(look.Y) > 0.99 then
		return cf
	end
	return CFrame.lookAt(cf.Position, cf.Position + look)
end

-- smootherstep: no jolt at either end of the blend
function Director.blendAlpha(x)
	x = math.clamp(x, 0, 1)
	return x * x * x * (x * (x * 6 - 15) + 10)
end

-- where the blend ends: the player's camera from before the scene, kept relative to the character
function Director.blendTarget(s, character)
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if s.camera.Rel and root then
		return root.CFrame * s.camera.Rel
	end
	return s.camera.CFrame
end

-- Blends from the scene's last camera to the player's over BLEND seconds, then gives the camera back (Snapshot).
-- Returns a function that ends the blend at once (a new scene starting).
function Director.blendBack(s, camera, player, from, fromFov, done)
	local t0 = os.clock()
	local over = false
	local function finish()
		if over then
			return
		end
		over = true
		pcall(RunService.UnbindFromRenderStep, RunService, Director.BLEND_NAME)
		local target = Director.blendTarget(s, player.Character)
		Snapshot.restoreCamera(s)
		pcall(function()
			camera.CFrame = target -- the camera scripts carry on from exactly here
		end)
		if done then
			done()
		end
	end
	local step = Director.guard("blend back", function()
		local x = (os.clock() - t0) / Director.BLEND
		local char = player.Character
		local hum = char and char:FindFirstChildOfClass("Humanoid")
		if x >= 1 or not hum or hum.Health <= 0 then
			finish()
			return
		end
		local k = Director.blendAlpha(x)
		camera.CFrame = from:Lerp(Director.blendTarget(s, char), k)
		camera.FieldOfView = fromFov + (s.camera.Fov - fromFov) * k
	end, finish)
	pcall(RunService.UnbindFromRenderStep, RunService, Director.BLEND_NAME)
	RunService:BindToRenderStep(Director.BLEND_NAME, Enum.RenderPriority.Camera.Value + 1, step)
	return finish
end

function Director.offerSkip(s, playerGui, skipEvent)
	if playerGui then
		local gui = Snapshot.track(s, Instance.new("ScreenGui"))
		gui.Name = "CutsceneSkip"
		gui.ResetOnSpawn = false
		gui.DisplayOrder = 52
		local b = Instance.new("TextButton")
		b.Name = "Skip"
		b.AnchorPoint = Vector2.new(1, 1)
		b.Position = UDim2.new(1, -24, 1, -24)
		b.Size = UDim2.fromOffset(120, 44)
		b.BackgroundColor3 = Color3.new(0, 0, 0)
		b.BackgroundTransparency = 0.35
		b.TextColor3 = Color3.new(1, 1, 1)
		b.TextSize = 20
		b.FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold)
		b.Text = "Skip"
		local corner = Instance.new("UICorner")
		corner.CornerRadius = UDim.new(0, 8)
		corner.Parent = b
		b.Activated:Connect(function()
			skipEvent:Fire()
		end)
		b.Parent = gui
		gui.Parent = playerGui
	end
	ContextActionService:BindAction(Director.SKIP_ACTION, function(_, state)
		if state == Enum.UserInputState.Begin then
			skipEvent:Fire()
		end
		return Enum.ContextActionResult.Sink
	end, false, Enum.KeyCode.ButtonB, Enum.KeyCode.Return)
end

-- The player's movement controls, or nil. Never waits: a place without a PlayerModule (replaced or stripped) would
-- otherwise delay the first frame by the whole wait, and the scene would start late and miss its first cues.
function Director.findControls(player)
	local scripts = player:FindFirstChild("PlayerScripts")
	local module = scripts and scripts:FindFirstChild("PlayerModule")
	if not module then
		return nil
	end
	local ok, controls = pcall(function()
		return require(module):GetControls()
	end)
	return ok and controls or nil
end

function Director.play(opts)
	local handle = { done = false }
	local module, player, anchor = opts.module, opts.player, opts.anchor
	local now = opts.now or function()
		return workspace:GetServerTimeNow()
	end
	local function report(reason)
		if opts.onEnd and Director.reportsEnd(reason) then
			task.spawn(opts.onEnd, reason)
		end
	end
	if Director.blending then
		Director.blending() -- a new scene starts while the last one still blends back: give the camera back first
	end
	local data = require(module)
	local ok, problems = Data.validate(data)
	if not ok then
		warn("CutsceneKit: " .. module.Name .. " is invalid: " .. table.concat(problems, "; "))
		handle.done, handle.reason = true, "invalid"
		player:SetAttribute("CutsceneLastResult", "invalid")
		handle.finish = function() end
		report("invalid")
		return handle
	end
	local cfg = Data.config(data)
	local live = Director.liveCast(data.Kind)
	player:SetAttribute("CutsceneLastResult", nil)

	local camera = workspace.CurrentCamera
	local playerGui = player:FindFirstChildOfClass("PlayerGui")
	local controls = Director.findControls(player)
	local character = player.Character
	local s = Snapshot.capture({
		camera = camera,
		playerGui = playerGui,
		starterGui = StarterGui,
		controls = controls,
		userInput = UserInputService,
		root = character and character:FindFirstChild("HumanoidRootPart"),
	})
	local folder = Snapshot.track(s, Instance.new("Folder"))
	folder.Name = "CutsceneLocal"
	local skipEvent = Instance.new("BindableEvent")
	skipEvent.Name = "Skip"
	skipEvent.Parent = folder
	folder.Parent = workspace
	-- the scene's VFX live outside the tracked folder so they can finish fading after a normal end
	local vfxFolder = Instance.new("Folder")
	vfxFolder.Name = "CutsceneVfx"
	vfxFolder.Parent = workspace

	local conns, tracks, castTracks = {}, {}, {}
	local started, finished = false, false
	local reduced = GuiService.ReducedMotionEnabled
	local ctx = { data = data, cfg = cfg, anchor = anchor, cast = {}, shake = Shake.new(), cues = {} }
	ctx.fx = Vfx.new({ parent = vfxFolder, element = cfg.Element, important = true, ignore = { folder } })
	ctx.screen = Screen.new({
		camera = camera,
		playerGui = playerGui,
		track = function(inst)
			return Snapshot.track(s, inst)
		end,
		reduced = reduced,
		palette = Vfx.palette(cfg.Element),
		base = cfg.Grade,
		-- the manga effects: points on the cast, backdrop cards behind it, its key light
		cast = ctx.cast,
		anchor = anchor,
		world = folder,
		follow = function(spec)
			return Director.follow(ctx, spec)
		end,
	})
	local lastCF, lastFov = nil, nil

	local function finish(reason)
		if finished then
			return
		end
		finished = true
		-- pcall'd: a throwing unbind must never skip the restore below
		pcall(RunService.UnbindFromRenderStep, RunService, Director.RENDER_NAME)
		pcall(ContextActionService.UnbindAction, ContextActionService, Director.SKIP_ACTION)
		for _, c in ipairs(conns) do
			c:Disconnect()
		end
		for _, tr in ipairs(tracks) do
			pcall(tr.Stop, tr, live and 0.2 or 0) -- the real character eases back into its own animations
		end
		-- every cleanup step warns and carries on: one failing step must never skip the restore below
		local function try(what, fn, ...)
			local okStep, stepErr = pcall(fn, ...)
			if not okStep then
				warn(("CutsceneKit: %s: %s failed: %s"):format(module.Name, what, tostring(stepErr)))
			end
		end
		-- before the restore, on every path: no impact frame or grade is left under the camera, and a subject's own
		-- Highlight (switched off by an impact frame) is back on
		try("clearing the screen layer", Screen.clear, ctx.screen)
		-- the caster faded only while walls jammed the camera against it: its own look comes back now
		local jammed = ctx.guard ~= nil and ctx.guard.k > 0
		if ctx.guard then
			try("unfading the caster", Director.unfade, ctx.guard.fade)
		end
		-- FwjelaaVFX effects live in that library's own folder: after a normal end they get the kit's VFX_TAIL too, then
		-- stop; any other end (a skip, a death, a replacement ...) stops them at once
		local externals = ctx.externals or {}
		ctx.externals = nil
		local function stopExternals()
			for _, stopExternal in ipairs(externals) do
				try("stopping a FwjelaaVFX effect", stopExternal)
			end
		end
		if reason == "end" and #externals > 0 then
			task.delay(Director.VFX_TAIL, stopExternals)
		else
			stopExternals()
		end
		local fx = ctx.fx
		try("resetting Slowmo", Vfx.setTimeScale, fx, 1) -- the VFX tail falls at normal speed
		local normal = reason == "end" or reason == "skip"
		task.delay(normal and Director.VFX_TAIL or 0, function()
			try("clearing the scene's VFX", Vfx.clear, fx)
			vfxFolder:Destroy()
		end)
		-- a camera jammed against a wall behind the caster goes straight back: a blend from there would pass through
		-- the caster, now unfaded
		local blend = normal and lastCF ~= nil and Director.BLEND > 0 and not jammed
		Snapshot.restore(s, { camera = not blend })
		handle.done, handle.reason = true, reason
		player:SetAttribute("CutsceneLastResult", reason)
		report(reason)
		if blend then
			local stop
			stop = Director.blendBack(s, camera, player, lastCF, lastFov, function()
				if Director.blending == stop then
					Director.blending = nil
				end
			end)
			Director.blending = stop
		end
	end
	handle.finish = finish
	handle.ctx = ctx -- the scene's context (tests reach the camera guard and cues through it)

	local okSetup, setupErr = xpcall(function()
		-- stage and cast
		local stage, motor = Director.stage(anchor, folder)
		local cast = ctx.cast
		if character and live then
			cast.player = character -- the server pinned it at the anchor; its animation replicates to everyone
		elseif character then
			local copy = Director.clonePlayer(character)
			copy.Parent = folder
			cast.player = copy
			Snapshot.hide(s, character)
			local hrp = character:FindFirstChild("HumanoidRootPart")
			if hrp then
				Snapshot.anchor(s, hrp)
			end
		end
		if character then
			local hum = character:FindFirstChildOfClass("Humanoid")
			if hum then
				table.insert(conns, hum.Died:Connect(function()
					finish("died")
				end))
			end
		end
		table.insert(conns, player.CharacterRemoving:Connect(function()
			finish("respawn")
		end))
		local castFolder = module:FindFirstChild("Cast")
		for _, m in ipairs(castFolder and castFolder:GetChildren() or {}) do
			if m:IsA("Model") then
				local copy = Director.strip(m:Clone())
				copy.Parent = folder
				cast[m.Name] = copy
			end
		end
		Director.dress(module, data, cfg, cast, folder, character)
		if not live then -- a story scene is private; an awakening happens in the world, with everyone in it
			for _, other in ipairs(Players:GetPlayers()) do
				if other ~= player and other.Character then
					Snapshot.hide(s, other.Character)
				end
			end
		end

		Director.hideConfigured(s, cfg.Hide, module.Name)

		-- clips
		local stageAnim = Director.animation(module, data.Anims.Stage)
		if not stageAnim then
			finish("load-failed")
			return
		end
		local stageTrack = stage.AnimationController.Animator:LoadAnimation(stageAnim)
		stageTrack.Looped = false -- an uploaded clip may be saved looping; a scene plays once
		table.insert(tracks, stageTrack)
		for role, model in pairs(cast) do
			local animator, rig
			if live and role == "player" then
				animator, rig = Director.liveRig(model)
			else
				animator, rig = Director.place(model, anchor, data.Places and data.Places[role])
			end
			local ref = animator and data.Anims[rig] and data.Anims[rig][role]
			if ref then
				local anim = Director.animation(module, ref)
				if not anim then
					finish("load-failed")
					return
				end
				local tr = animator:LoadAnimation(anim)
				tr.Looped = false
				tr.Priority = Enum.AnimationPriority.Action4
				table.insert(tracks, tr)
				table.insert(castTracks, tr)
			end
		end

		-- screen and VFX
		if cfg.CastLight then
			Screen.castLight(ctx.screen, cfg.CastLight) -- after dress: the lights go on the copies that act
		end
		if playerGui then
			ctx.letterbox = Snapshot.track(s, Letterbox.create(playerGui, cfg.Letterbox))
			ctx.subtitles = Snapshot.track(s, Subtitles.create(playerGui))
		end
		Director.prepareVfx(ctx)
		if live and character then
			-- the camera guard: the scene plays wherever the caster stands (Director.guardCamera, every frame)
			local params = RaycastParams.new()
			params.FilterType = Enum.RaycastFilterType.Exclude
			params.RespectCanCollide = true
			params.IgnoreWater = true
			ctx.guard = { params = params, caster = character, root = character:FindFirstChild("HumanoidRootPart"),
				keep = { folder, vfxFolder }, fade = {}, k = 0 }
		end

		table.insert(conns, skipEvent.Event:Connect(function()
			if not started or finished or not cfg.Skip then
				return
			end
			if Schedule.elapsed(opts.startAt, now()) < cfg.Skip then
				return
			end
			if opts.onSkip then
				task.spawn(opts.onSkip)
			end
			finish("skip")
		end))
		table.insert(conns, RunService.Heartbeat:Connect(function()
			if not finished and Schedule.elapsed(opts.startAt, now()) > data.Length + Director.OVERTIME then
				finish("overtime")
			end
		end))

		task.spawn(function()
			local okRun, runErr = xpcall(function()
				for _, tr in ipairs(tracks) do
					tr:Play(0, 1, 0) -- speed 0: loads the clip; every track starts moving on the same frame below
				end
				local t0 = os.clock()
				local loaded = false
				while not finished and not loaded and os.clock() - t0 < Director.LOAD_TIMEOUT do
					loaded = true
					for _, tr in ipairs(tracks) do
						if tr.Length == 0 then
							loaded = false
						end
					end
					if not loaded then
						task.wait()
					end
				end
				if finished then
					return
				end
				if not loaded then
					warn(("CutsceneKit: %s: a clip did not load in %d s (wrong id, or not owned by this game's owner?)"):format(module.Name, Director.LOAD_TIMEOUT))
					finish("load-failed")
					return
				end
				if stageTrack.Length < data.Length - 0.05 then
					warn(("CutsceneKit: %s: the camera clip ends at %.2f s, before the scene (%.2f s); the scene ends with it"):format(module.Name, stageTrack.Length, data.Length))
				end
				for _, tr in ipairs(castTracks) do
					if tr.Length < data.Length - 0.05 then
						warn(("CutsceneKit: %s: a cast clip ends at %.2f s, before the scene (%.2f s)"):format(module.Name, tr.Length, data.Length))
					end
				end
				local decision = Schedule.decide(opts.startAt, data.Length, now())
				while decision == "wait" and not finished do
					task.wait()
					decision = Schedule.decide(opts.startAt, data.Length, now())
				end
				if finished then
					return
				end
				if decision ~= "play" then
					finish("late")
					return
				end
				local tStart = math.max(0, Schedule.elapsed(opts.startAt, now()))
				for _, tr in ipairs(tracks) do
					tr.TimePosition = math.min(tStart, tr.Length - 1e-3)
					tr:AdjustSpeed(1)
				end
				if ctx.letterbox and tStart > Schedule.ON_TIME then
					Letterbox.set(ctx.letterbox, Markers.stateAt(data.Markers, tStart).Letterbox == "in", true)
				end
				camera.CameraType = Enum.CameraType.Scriptable
				started = true
				local tPrev = Director.firstPrev(tStart)
				local step = Director.guard(module.Name .. " failed while playing", function(dt)
					if finished then
						return
					end
					-- a stopped (or stopping) stage track no longer holds the camera's pose: the scene is over
					if not stageTrack.IsPlaying then
						finish("end")
						return
					end
					local t = stageTrack.TimePosition
					if t >= data.Length then
						finish("end")
						return
					end
					if Director.PIN then
						for _, tr in ipairs(castTracks) do
							if math.abs(tr.TimePosition - t) > 1 / 120 then
								tr.TimePosition = t
							end
						end
					end
					Snapshot.keepHidden(s)
					local cf = anchor * motor.C0 * motor.Transform * motor.C1:Inverse()
					if ctx.guard then
						cf = Director.guardCamera(ctx.guard, cf)
					end
					if reduced then
						cf = Director.noRoll(cf)
					end
					camera.CFrame = cf * Shake.step(ctx.shake, dt, t, reduced and 0 or 1)
					local fov = Fov.sample(data.Fov or {}, t)
					if fov then
						camera.FieldOfView = fov
					end
					lastCF, lastFov = camera.CFrame, camera.FieldOfView
					for _, m in ipairs(Markers.due(data.Markers, tPrev, t)) do
						Director.cue(ctx, m)
					end
					if ctx.lineClearAt and t >= ctx.lineClearAt then
						if ctx.subtitles then
							Subtitles.clear(ctx.subtitles)
						end
						ctx.lineClearAt = nil
					end
					Screen.step(ctx.screen, t)
					tPrev = t
					folder:SetAttribute("T", t)
					folder:SetAttribute("Cues", table.concat(ctx.cues, ","))
					folder:SetAttribute("Screen", table.concat(ctx.screen.log, ","))
				end, function()
					finish("error")
				end)
				RunService:BindToRenderStep(Director.RENDER_NAME, Enum.RenderPriority.Camera.Value + 1, step)
				if cfg.Skip then
					task.delay(math.max(0, cfg.Skip - tStart), function()
						if not finished then
							Director.offerSkip(s, playerGui, skipEvent)
						end
					end)
				end
			end, debug.traceback)
			if not okRun then
				warn(("CutsceneKit: %s failed while starting: %s"):format(module.Name, tostring(runErr)))
				finish("error")
			end
		end)
	end, debug.traceback)
	if not okSetup then
		warn(("CutsceneKit: %s failed during setup: %s"):format(module.Name, tostring(setupErr)))
		finish("error")
	end
	return handle
end

return Director
