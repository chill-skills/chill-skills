-- Zones: is a point inside a (turned) box, with hysteresis so standing on the edge doesn't re-trigger.
-- Point-in-box on the root, never Touched (fires per limb, misses respawns). Method by fwjelaa (FWJ STUDIOS).
local Zones = {}
Zones.EXIT_MARGIN = 4 -- studs (vault: 3-6)

function Zones.inside(cf, size, point, margin)
	local p = cf:PointToObjectSpace(point)
	local h = size / 2 + Vector3.one * (margin or 0)
	return math.abs(p.X) <= h.X and math.abs(p.Y) <= h.Y and math.abs(p.Z) <= h.Z
end

function Zones.step(cf, size, point, wasInside)
	local now = Zones.inside(cf, size, point, wasInside and Zones.EXIT_MARGIN or 0)
	return now, now and not wasInside
end

function Zones.anchor(zone)
	local a = zone:FindFirstChild("Anchor")
	if a and a:IsA("Attachment") then
		return a.WorldCFrame
	end
	return zone.CFrame * CFrame.new(0, -zone.Size.Y / 2, 0)
end

return Zones
