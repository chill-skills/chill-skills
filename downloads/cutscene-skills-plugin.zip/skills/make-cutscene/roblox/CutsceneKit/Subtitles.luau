-- Subtitles: dialogue lines, anime-subtitle style. Inside the bottom letterbox bar when it is on and tall enough,
-- otherwise on a dark rounded plate low in the picture, inside the safe area. Method by fwjelaa (FWJ STUDIOS).
-- Manhwa boxes and dialogue boxes come in a later plan.
local Subtitles = {}
Subtitles.SPEAKER_COLOR = "#FFD34D"

function Subtitles.escape(s)
	return (string.gsub(string.gsub(string.gsub(s, "&", "&amp;"), "<", "&lt;"), ">", "&gt;"))
end

function Subtitles.hold(text)
	return math.clamp(1.6 + 0.045 * #text, 1.6, 6)
end

-- Layout numbers (all exposed so the tests and the bundle agree).
Subtitles.MIN_TEXT = 20 -- readable on a phone; was 14
Subtitles.MAX_TEXT = 48 -- 1.4x the old 34, rounded
Subtitles.MAX_LINES = 2
Subtitles.SAFE_WIDTH = 0.84
Subtitles.STROKE_THICKNESS = 2
Subtitles.PLATE_TRANSPARENCY = 0.4
Subtitles.BAR_FILL = 0.9 -- share of the bar height the label may use
Subtitles.LINE_HEIGHT = 1.15 -- px per text px, used to decide whether the bar is tall enough
Subtitles.PLATE_HEIGHT = 0.15 -- plate band height as a share of the (safe) screen
Subtitles.PLATE_BOTTOM = 0.94 -- plate bottom edge, upper than the screen edge so it stays off the home bar
local PLATE_PAD = 0.04 -- plate is this much wider than the text column
local LETTERBOX_NAME = "CutsceneLetterbox"
local FALLBACK_HEIGHT = 1080

-- Bottom device inset in px (the home indicator): how far the device-safe area stops short of the screen's bottom edge.
-- Game code may not call GuiService's safe-zone query (RobloxScript only), so this measures it the supported way: two
-- empty ScreenGuis next to the subtitles, one with ScreenInsets None and one with DeviceSafeInsets, compared by their
-- absolute bottoms and removed again at once. Outside a PlayerGui nothing is laid out, which reads as 0.
function Subtitles.measureBottomInset(parent)
	if not parent then
		return 0
	end
	local full = Instance.new("ScreenGui")
	full.Name = "_CutsceneInsetFull"
	full.ScreenInsets = Enum.ScreenInsets.None
	local safe = Instance.new("ScreenGui")
	safe.Name = "_CutsceneInsetSafe"
	safe.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
	local ok, inset = pcall(function()
		full.Parent = parent
		safe.Parent = parent
		if full.AbsoluteSize.Y <= 0 or safe.AbsoluteSize.Y <= 0 then
			return 0
		end
		return (full.AbsolutePosition.Y + full.AbsoluteSize.Y) - (safe.AbsolutePosition.Y + safe.AbsoluteSize.Y)
	end)
	full:Destroy()
	safe:Destroy()
	return ok and math.max(0, tonumber(inset) or 0) or 0
end

local function bottomInset(gui)
	local forced = gui:GetAttribute("BottomInset")
	if type(forced) == "number" then
		return forced
	end
	return Subtitles.measureBottomInset(gui.Parent)
end

local function viewportHeight(gui)
	local forced = gui:GetAttribute("ViewportHeight")
	if type(forced) == "number" then
		return forced
	end
	local camera = workspace.CurrentCamera
	if camera and camera.ViewportSize.Y > 0 then
		return camera.ViewportSize.Y
	end
	if gui.AbsoluteSize.Y > 0 then
		return gui.AbsoluteSize.Y
	end
	return FALLBACK_HEIGHT
end

-- The bottom bar, if the scene's letterbox is showing: its height as a share of the screen, else nil.
local function bottomBar(gui)
	local parent = gui.Parent
	local lb = parent and parent:FindFirstChild(LETTERBOX_NAME)
	local bar = lb and lb:FindFirstChild("Bottom")
	local fraction = lb and lb:GetAttribute("Fraction")
	if bar and type(fraction) == "number" and fraction > 0 and bar.Size.Y.Scale > 0.001 then
		return fraction, bar
	end
	return nil, bar
end

local function refresh(gui)
	local plate = gui:FindFirstChild("Plate")
	local label = gui:FindFirstChild("Line")
	if plate and label then
		plate.Visible = gui:GetAttribute("Mode") == "plate" and label.Text ~= ""
	end
end

-- Puts the line inside the bottom letterbox bar when there is one and it is tall enough, otherwise on a dark plate.
-- viewportOverride (tests) sticks on the gui; in a running game the camera viewport is used.
function Subtitles.layout(gui, viewportOverride, bottomInsetOverride)
	local label = gui.Line
	local plate = gui.Plate
	local fraction = bottomBar(gui)
	if viewportOverride then
		gui:SetAttribute("ViewportHeight", viewportOverride)
	end
	if bottomInsetOverride then
		gui:SetAttribute("BottomInset", bottomInsetOverride)
	end
	local height = viewportHeight(gui)
	local inset = bottomInset(gui)
	local needed = Subtitles.MIN_TEXT * Subtitles.MAX_LINES * Subtitles.LINE_HEIGHT
	if fraction and fraction * height - inset >= needed then
		-- The bars ignore every inset, so this gui must too or the label drifts off the bar.
		gui.IgnoreGuiInset = true
		gui.ScreenInsets = Enum.ScreenInsets.None
		gui:SetAttribute("Mode", "bar")
		label.AnchorPoint = Vector2.new(0.5, 0.5)
		-- Centre in the part of the bar above the bottom inset.
		local usable = fraction - inset / height
		label.Position = UDim2.new(0.5, 0, 1 - fraction + usable / 2, 0)
		label.Size = UDim2.new(Subtitles.SAFE_WIDTH, 0, usable * Subtitles.BAR_FILL, 0)
	else
		gui.IgnoreGuiInset = false
		gui.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
		gui:SetAttribute("Mode", "plate")
		local centreY = Subtitles.PLATE_BOTTOM - Subtitles.PLATE_HEIGHT / 2
		plate.AnchorPoint = Vector2.new(0.5, 0.5)
		plate.Position = UDim2.new(0.5, 0, centreY, 0)
		plate.Size = UDim2.new(Subtitles.SAFE_WIDTH + PLATE_PAD, 0, Subtitles.PLATE_HEIGHT, 0)
		label.AnchorPoint = Vector2.new(0.5, 0.5)
		label.Position = UDim2.new(0.5, 0, centreY, 0)
		label.Size = UDim2.new(Subtitles.SAFE_WIDTH, 0, Subtitles.PLATE_HEIGHT * Subtitles.BAR_FILL, 0)
	end
	refresh(gui)
end

-- The letterbox tweens in and out; follow it so the line moves into the bar (or onto the plate) when it settles.
local function hookLetterbox(gui)
	if gui:GetAttribute("Hooked") then
		return
	end
	local _, bar = bottomBar(gui)
	if not bar then
		return
	end
	gui:SetAttribute("Hooked", true)
	local last = gui:GetAttribute("Mode")
	bar:GetPropertyChangedSignal("Size"):Connect(function()
		local on = bottomBar(gui) ~= nil
		if on ~= (last == "bar") then
			Subtitles.layout(gui)
			last = gui:GetAttribute("Mode")
		end
	end)
end

function Subtitles.create(parent)
	local gui = Instance.new("ScreenGui")
	gui.Name = "CutsceneSubtitles"
	gui.ResetOnSpawn = false
	gui.DisplayOrder = 51
	local plate = Instance.new("Frame")
	plate.Name = "Plate"
	plate.BackgroundColor3 = Color3.new(0, 0, 0)
	plate.BackgroundTransparency = Subtitles.PLATE_TRANSPARENCY
	plate.BorderSizePixel = 0
	plate.Visible = false
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 12)
	corner.Parent = plate
	plate.Parent = gui
	local label = Instance.new("TextLabel")
	label.Name = "Line"
	label.BackgroundTransparency = 1
	label.FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold)
	label.TextScaled = true
	label.TextWrapped = true
	label.RichText = true
	label.TextXAlignment = Enum.TextXAlignment.Center
	label.TextYAlignment = Enum.TextYAlignment.Center
	label.TextColor3 = Color3.new(1, 1, 1)
	label.TextStrokeTransparency = 1
	label.Text = ""
	local size = Instance.new("UITextSizeConstraint")
	size.MinTextSize = Subtitles.MIN_TEXT
	size.MaxTextSize = Subtitles.MAX_TEXT
	size.Parent = label
	local stroke = Instance.new("UIStroke")
	stroke.Color = Color3.new(0, 0, 0)
	stroke.Thickness = Subtitles.STROKE_THICKNESS
	stroke.Transparency = 0
	stroke.LineJoinMode = Enum.LineJoinMode.Round
	stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
	stroke.Parent = label
	label.Parent = gui
	gui.Parent = parent
	Subtitles.layout(gui)
	hookLetterbox(gui)
	return gui
end

function Subtitles.show(gui, line)
	local who = ""
	if line.speaker and line.speaker ~= "" then
		who = ('<font color="%s">%s</font>  '):format(Subtitles.SPEAKER_COLOR, Subtitles.escape(line.speaker))
	end
	gui.Line.Text = who .. Subtitles.escape(line.text or "")
	hookLetterbox(gui)
	Subtitles.layout(gui)
end

function Subtitles.clear(gui)
	gui.Line.Text = ""
	refresh(gui)
end

return Subtitles
