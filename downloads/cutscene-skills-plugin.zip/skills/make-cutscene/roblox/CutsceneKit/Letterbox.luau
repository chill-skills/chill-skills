-- Letterbox: two black bars that ignore safe areas (vault: ScreenInsets None, SafeAreaCompatibility None).
-- Method by fwjelaa (FWJ STUDIOS).
local TweenService = game:GetService("TweenService")

local Letterbox = {}
Letterbox.TIME = 0.25

function Letterbox.create(parent, fraction)
	local gui = Instance.new("ScreenGui")
	gui.Name = "CutsceneLetterbox"
	gui.IgnoreGuiInset = true
	gui.ScreenInsets = Enum.ScreenInsets.None
	gui.SafeAreaCompatibility = Enum.SafeAreaCompatibility.None
	gui.ClipToDeviceSafeArea = false
	gui.ResetOnSpawn = false
	gui.DisplayOrder = 50
	gui:SetAttribute("Fraction", fraction)
	for _, name in { "Top", "Bottom" } do
		local f = Instance.new("Frame")
		f.Name = name
		f.BackgroundColor3 = Color3.new(0, 0, 0)
		f.BorderSizePixel = 0
		f.Size = UDim2.new(1, 0, 0, 0)
		f.AnchorPoint = name == "Top" and Vector2.new(0, 0) or Vector2.new(0, 1)
		f.Position = name == "Top" and UDim2.new(0, 0, 0, 0) or UDim2.new(0, 0, 1, 0)
		f.Parent = gui
	end
	gui.Parent = parent
	return gui
end

function Letterbox.set(gui, on, instant)
	local size = UDim2.new(1, 0, on and gui:GetAttribute("Fraction") or 0, 0)
	for _, f in { gui.Top, gui.Bottom } do
		if instant then
			f.Size = size
		else
			TweenService:Create(f, TweenInfo.new(Letterbox.TIME, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Size = size }):Play()
		end
	end
end

return Letterbox
