-- Aura: the awakened state on a character (spec 6, 7): flame wisps from the body, dark specks, an outline in the power
-- colour, glowing eyes with a short streak, one soft light (above and behind); then the power-down. Every client draws
-- every awakened character itself from the attributes the server sets on the Player (or on an NPC caster tagged
-- CutsceneCaster): Awakened (scene name), AwakenedAt, AwakenedEndsAt (server time) and AwakenedEnd (expire | ended |
-- died). Nothing here replicates. Emitter rates change only during the short ramps. Method by fwjelaa (FWJ STUDIOS).
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Data = require(script.Parent.Data)
local Lib = require(script.Parent.VfxPresets)
local Vfx = require(script.Parent.Vfx)

local Aura = {}
Aura.TAG = "CutsceneCaster"
Aura.TICK = 0.1 -- s between attribute checks
Aura.FAR = 220 -- studs from the camera: no aura is drawn beyond this
Aura.MAX_FULL = 4 -- auras drawn in full at once (the nearest); the rest are the outline only
Aura.MAX_FULL_TOUCH = 2
-- R6 has no hands, feet or upper torso: the nearest part, and how far along it (studs on its Y axis)
Aura.R6 = {
	Head = { "Head", 0 },
	UpperTorso = { "Torso", 0.5 },
	LowerTorso = { "Torso", -0.7 },
	LeftHand = { "Left Arm", -0.9 },
	RightHand = { "Right Arm", -0.9 },
	LeftFoot = { "Left Leg", -0.9 },
	RightFoot = { "Right Leg", -0.9 },
}

-- "off" (never awakened), "wait" (the scene hasn't reached its awakening yet), "on", "down" (power-down due), "gone"
function Aura.phase(at, endsAt, endKind, now)
	if endKind == "died" then
		return "gone"
	end
	if type(at) ~= "number" then
		return "off"
	end
	if now < at then
		return "wait"
	end
	if type(endsAt) == "number" and now >= endsAt then
		return "down"
	end
	return "on"
end

function Aura.point(character, name)
	local part = character:FindFirstChild(name)
	if part and part:IsA("BasePart") then
		return part, Vector3.zero
	end
	local r6 = Aura.R6[name]
	part = r6 and character:FindFirstChild(r6[1])
	if part and part:IsA("BasePart") then
		return part, Vector3.new(0, r6[2], 0)
	end
	return nil, nil
end

local function emitter(a, parent, spec, rate)
	local em = Instance.new("ParticleEmitter")
	em.Name = "CutsceneAura"
	em.Texture = Lib.Textures[spec.texture or "sparkle"] or ""
	local role = spec.role
	em.Color = type(role) == "table" and ColorSequence.new(Vfx.color(a.pal, role[1]), Vfx.color(a.pal, role[2]))
		or ColorSequence.new(Vfx.color(a.pal, role))
	em.LightEmission = spec.le or 1
	em.LightInfluence = 0
	em.Size = Vfx.seq(spec.size or 0.3)
	em.Transparency = Vfx.seq(spec.transp or 0)
	em.Lifetime = NumberRange.new(spec.life[1], spec.life[2])
	em.Speed = NumberRange.new(spec.speed[1], spec.speed[2])
	em.SpreadAngle = Vector2.new(spec.spread or 0, spec.spread or 0)
	em.EmissionDirection = Enum.NormalId.Top
	em.Acceleration = spec.acc and Vector3.new(spec.acc[1], spec.acc[2], spec.acc[3]) or Vector3.zero
	em.Drag = spec.drag or 0
	em.Rate = 0
	em.Enabled = true -- a persistent aura is the one place an emitter stays on; Rate 0 until it ramps in
	em.Parent = parent
	table.insert(a.emitters, { e = em, rate = rate })
	return em
end

-- look = { "eyes", "outline", "tint" } (any of them). opts = { quality = Vfx.quality(), full = true }:
-- decor (specks, eye trails, the light) needs quality above 0.5; a not-full aura is the outline Highlight only.
function Aura.attach(character, styleName, element, look, opts)
	opts = opts or {}
	local full = opts.full ~= false
	local decor = full and (opts.quality or Vfx.quality()) > 0.5
	local style = Lib.Auras[styleName or ""] or Lib.Auras.Flame
	local a = { character = character, style = style, element = element, pal = Vfx.palette(element), made = {},
		emitters = {}, eyes = {}, k = 0, target = 1, outline = 1, fill = 1, full = full, decor = decor }
	local function track(inst)
		table.insert(a.made, inst)
		return inst
	end
	for _, name in ipairs(full and style.points or {}) do
		local part, off = Aura.point(character, name)
		if part then
			local att = track(Instance.new("Attachment"))
			att.Name = "CutsceneAura_" .. name
			att.Position = off
			att.Parent = part
			emitter(a, att, style.wisps, style.wisps.rate)
		end
	end
	local sp, soff = Aura.point(character, style.specks.point)
	if decor and sp then
		local att = track(Instance.new("Attachment"))
		att.Name = "CutsceneAuraSpecks"
		att.Position = soff
		att.Parent = sp
		emitter(a, att, style.specks, style.specks.rate)
	end
	local has = {}
	for _, l in ipairs(look or {}) do
		has[l] = true
	end
	if not full then
		has = { outline = true }
	end
	if has.outline or has.tint then
		local h = track(Instance.new("Highlight"))
		h.Name = "CutsceneAura"
		h.Adornee = character
		h.DepthMode = Enum.HighlightDepthMode.Occluded
		h.OutlineColor = Vfx.color(a.pal, style.outline.role)
		h.FillColor = Vfx.color(a.pal, style.outline.role)
		h.OutlineTransparency, h.FillTransparency = 1, 1
		h.Parent = character
		a.highlight = h
		a.outline = has.outline and style.outline.transparency or 1
		a.fill = has.tint and style.outline.fill or 1
	end
	local head = character:FindFirstChild("Head")
	if has.eyes and style.eyes and head and head:IsA("BasePart") then
		local face = head:FindFirstChild("FaceFrontAttachment")
		local base = (face and face:IsA("Attachment")) and face.Position or Vector3.new(0, 0, -head.Size.Z / 2)
		for _, side in ipairs({ -1, 1 }) do
			local eye = track(Instance.new("Attachment"))
			eye.Name = "CutsceneAuraEye"
			eye.Position = base + Vector3.new(side * head.Size.X * 0.155, head.Size.Y * 0.08, -0.05)
			eye.Parent = head
			local tip = track(Instance.new("Attachment"))
			tip.Name = "CutsceneAuraEyeTip"
			tip.Position = eye.Position + Vector3.new(0, 0.07, 0)
			tip.Parent = head
			local em = emitter(a, eye, { texture = style.eyes.texture or "sparkle", role = style.eyes.role, le = 1,
				size = style.eyes.size, life = { style.eyes.life, style.eyes.life }, speed = { 0, 0 } }, style.eyes.rate)
			em.LockedToPart = true
			if decor then
				local tr = track(Instance.new("Trail"))
				tr.Name = "CutsceneAuraEye"
				tr.Attachment0, tr.Attachment1 = eye, tip
				tr.Lifetime = style.eyes.trail
				tr.FaceCamera = true
				tr.LightEmission = 1
				tr.LightInfluence = 0
				tr.Color = ColorSequence.new(Vfx.color(a.pal, style.eyes.role))
				tr.Transparency = NumberSequence.new(0.1, 1)
				tr.WidthScale = NumberSequence.new(1, 0)
				tr.Enabled = false
				tr.Parent = head
				table.insert(a.eyes, tr)
			end
		end
	end
	local torso = Aura.point(character, "UpperTorso")
	if decor and torso and style.light then
		local att = track(Instance.new("Attachment"))
		att.Name = "CutsceneAuraLight"
		att.Position = Vector3.new(0, 1.5, 1) -- above and behind: the light never washes out the face
		att.Parent = torso
		local light = Instance.new("PointLight")
		light.Shadows = false
		light.Brightness = 0
		light.Range = style.light.range
		light.Color = Vfx.color(a.pal, style.light.role)
		light.Parent = att
		a.light = light
	end
	Aura.set(a, 0)
	return a
end

-- intensity 0..1
function Aura.set(a, k)
	a.k = k
	for _, em in ipairs(a.emitters) do
		em.e.Rate = em.rate * k
	end
	if a.highlight then
		a.highlight.OutlineTransparency = 1 - (1 - a.outline) * k
		a.highlight.FillTransparency = 1 - (1 - a.fill) * k
	end
	for _, tr in ipairs(a.eyes) do
		tr.Enabled = k > 0.5
	end
	if a.light then
		a.light.Brightness = a.style.light.brightness * k
	end
end

-- moves the intensity toward the target (rampIn / rampOut seconds for the whole way); true while it moves
function Aura.step(a, dt)
	if a.dead or a.k == a.target then
		return false
	end
	local up = a.target > a.k
	local speed = 1 / math.max(0.01, (up and a.style.rampIn or a.style.rampOut) or 0.3)
	local k = a.k + (up and 1 or -1) * speed * dt
	Aura.set(a, up and math.min(k, a.target) or math.max(k, a.target))
	return true
end

function Aura.powerDown(a, fx)
	if a.down then
		return
	end
	a.down = true
	a.target = 0
	local root = a.character:FindFirstChild("HumanoidRootPart")
	if fx and root and a.style.powerDown then
		local hum = a.character:FindFirstChildOfClass("Humanoid")
		local drop = (hum and hum.RigType == Enum.HumanoidRigType.R15) and hum.HipHeight + root.Size.Y / 2 or 3
		Vfx.play(fx, a.style.powerDown, root.CFrame * CFrame.new(0, -drop, 0), { element = a.element })
	end
end

function Aura.destroy(a)
	a.dead = true
	for i = #a.made, 1, -1 do
		pcall(a.made[i].Destroy, a.made[i])
	end
	table.clear(a.made)
	table.clear(a.emitters)
	table.clear(a.eyes)
	a.highlight, a.light = nil, nil
end

function Aura.subjects()
	local out = Players:GetPlayers()
	for _, m in ipairs(CollectionService:GetTagged(Aura.TAG)) do
		table.insert(out, m)
	end
	return out
end

function Aura.characterOf(subject)
	if subject:IsA("Player") then
		return subject.Character
	end
	return subject:IsA("Model") and subject or nil
end

-- the scene's Config.Awakened (with its defaults), or nil
function Aura.configOf(name)
	local folder = ReplicatedStorage:FindFirstChild("Cutscenes")
	local module = folder and type(name) == "string" and folder:FindFirstChild(name)
	if not module then
		return nil
	end
	local ok, data = pcall(require, module)
	if not ok or type(data) ~= "table" then
		return nil
	end
	return Data.config(data).Awakened
end

-- how many auras are drawn in full at once
function Aura.maxFull(touch)
	if touch == nil then
		touch = Vfx.touch()
	end
	return touch and Aura.MAX_FULL_TOUCH or Aura.MAX_FULL
end

local function near(char)
	local root = char and char:FindFirstChild("HumanoidRootPart")
	local cam = workspace.CurrentCamera
	return root ~= nil and (not cam or (cam.CFrame.Position - root.Position).Magnitude <= Aura.FAR)
end

-- the subjects drawn in full: the nearest awakened ones within range, at most `limit`; returns a set
function Aura.fullSet(subjects, t, limit)
	limit = limit or Aura.maxFull()
	local cam = workspace.CurrentCamera
	local ranked = {}
	for _, subject in ipairs(subjects) do
		local phase = Aura.phase(subject:GetAttribute("AwakenedAt"), subject:GetAttribute("AwakenedEndsAt"),
			subject:GetAttribute("AwakenedEnd"), t)
		local char = Aura.characterOf(subject)
		if (phase == "on" or phase == "down") and near(char) then
			local root = char:FindFirstChild("HumanoidRootPart")
			table.insert(ranked, { subject = subject, d = cam and (cam.CFrame.Position - root.Position).Magnitude or 0 })
		end
	end
	table.sort(ranked, function(x, y)
		return x.d < y.d
	end)
	local set = {}
	for i = 1, math.min(limit, #ranked) do
		set[ranked[i].subject] = true
	end
	return set
end

-- one subject, one check: attaches, powers down or removes its aura (states[subject] = { aura, at })
-- opts = { quality = Vfx.quality(), full = true }
function Aura.update(states, subject, t, fx, opts)
	opts = opts or {}
	local quality = opts.quality or Vfx.quality()
	local full = opts.full ~= false
	local st = states[subject]
	local at = subject:GetAttribute("AwakenedAt")
	local phase = Aura.phase(at, subject:GetAttribute("AwakenedEndsAt"), subject:GetAttribute("AwakenedEnd"), t)
	local char = Aura.characterOf(subject)
	if st and st.aura and (st.aura.character ~= char or st.at ~= at or not near(char)) then
		Aura.destroy(st.aura) -- respawned, awakened again, or out of range
		st.aura = nil
	end
	if st and st.aura and not st.aura.down and (st.aura.full ~= full or st.aura.decor ~= (full and quality > 0.5)) then
		Aura.destroy(st.aura) -- the quality or the nearest-N ranking changed: rebuild at the new level
		st.aura = nil
	end
	if phase == "on" then
		if not (st and st.aura) and char and char.Parent and near(char) then
			local cfg = Aura.configOf(subject:GetAttribute("Awakened"))
			if cfg then
				st = st or {}
				states[subject] = st
				st.at = at
				st.aura = Aura.attach(char, cfg.Aura, cfg.Element, cfg.Look, { quality = quality, full = full })
			end
		end
	elseif phase == "down" then
		if st and st.aura and not st.aura.down then
			Aura.powerDown(st.aura, fx)
		end
	elseif st and st.aura then
		Aura.destroy(st.aura)
		st.aura = nil
	end
end

-- Every client runs this once (Client.start): draws every awakened character. Returns the Heartbeat connection.
function Aura.watch(now, fx)
	now = now or function()
		return workspace:GetServerTimeNow()
	end
	fx = fx or Vfx.new({})
	local states = {}
	local acc = 0
	return RunService.Heartbeat:Connect(function(dt)
		for _, st in pairs(states) do
			local a = st.aura
			if a then
				Aura.step(a, dt)
				if a.down and a.k <= 0 then
					Aura.destroy(a)
					st.aura = nil
				end
			end
		end
		acc += dt
		if acc < Aura.TICK then
			return
		end
		acc = 0
		local t = now()
		local seen = {}
		local subjects = Aura.subjects()
		local quality = Vfx.quality()
		local full = Aura.fullSet(subjects, t)
		for _, subject in ipairs(subjects) do
			seen[subject] = true
			local ok, err = pcall(Aura.update, states, subject, t, fx, { quality = quality, full = full[subject] == true })
			if not ok then
				warn("CutsceneKit: aura update failed: " .. tostring(err))
			end
		end
		for subject, st in pairs(states) do
			if not seen[subject] then
				if st.aura then
					Aura.destroy(st.aura)
				end
				states[subject] = nil
			end
		end
	end)
end

return Aura
