-- CutsceneKit: in-game cutscenes made with /make-cutscene. Method by fwjelaa (FWJ STUDIOS).
-- Server scripts:
--   local CutsceneKit = require(game.ReplicatedStorage.CutsceneKit)
--   CutsceneKit.Play(player, "Name")      -- a personal story/intro scene (zones in Workspace.CutsceneZones call it)
--   CutsceneKit.Awaken(player, "Name")    -- an awakening where the player stands, then the awakened state (aura) for
--                                         -- Config.Awakened.Duration; an NPC Model with a Humanoid can awaken too
--   CutsceneKit.EndAwakening(player)      -- the power-down now
--   CutsceneKit.Forget(player, "Name")    -- lets the player see a "saved"/"session" scene again
-- Each returns true, or false and why ("busy", "seen", "awakened", "cooldown" and the seconds left, ...).
-- A ProximityPrompt with attribute Cutscene = "Name" (made by /make-cutscene's installer) starts that scene too.
local RunService = game:GetService("RunService")

local CutsceneKit = {}
CutsceneKit.Version = script:GetAttribute("Version")

function CutsceneKit.startServer()
	assert(RunService:IsServer(), "CutsceneKit.startServer runs on the server")
	require(script.Server).start()
end

function CutsceneKit.startClient()
	assert(RunService:IsClient(), "CutsceneKit.startClient runs on a client")
	require(script.Client).start()
end

function CutsceneKit.Play(player, name, anchor)
	assert(RunService:IsServer(), "CutsceneKit.Play runs on the server")
	return require(script.Server).play(player, name, anchor)
end

function CutsceneKit.Awaken(subject, name, anchor)
	assert(RunService:IsServer(), "CutsceneKit.Awaken runs on the server")
	return require(script.Server).awaken(subject, name, anchor)
end

function CutsceneKit.EndAwakening(subject)
	assert(RunService:IsServer(), "CutsceneKit.EndAwakening runs on the server")
	return require(script.Server).endAwakening(subject)
end

function CutsceneKit.Forget(player, name)
	assert(RunService:IsServer(), "CutsceneKit.Forget runs on the server")
	return require(script.Server).forget(player, name)
end

return CutsceneKit
