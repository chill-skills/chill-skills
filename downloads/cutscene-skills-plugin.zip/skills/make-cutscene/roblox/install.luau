-- CutsceneKit installer: (re)installs the in-game cutscene system into the open place. Method by fwjelaa (FWJ STUDIOS).
-- This is a template: `py kit/run.py bundle` embeds the kit's files and writes out/install.luau. Send that file with the
-- Studio MCP's execute_luau (Edit mode) or paste it into View > Command Bar. Your cutscenes (ReplicatedStorage.Cutscenes)
-- and zones (Workspace.CutsceneZones) are kept; the kit's own module and scripts are replaced by fresh copies.
local EMBED = nil -- filled in by kit/bundle.py
assert(EMBED, "run `py kit/run.py bundle` and send out/install.luau, not this template")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")
local StarterPlayerScripts = game:GetService("StarterPlayer"):WaitForChild("StarterPlayerScripts")

local root = Instance.new("ModuleScript")
root.Name = "CutsceneKit"
root.Source = EMBED.files["CutsceneKit/CutsceneKit.luau"]
root:SetAttribute("Version", EMBED.version)
for _, name in EMBED.modules do
	local m = Instance.new("ModuleScript")
	m.Name = name
	m.Source = EMBED.files["CutsceneKit/" .. name .. ".luau"]
	m.Parent = root
end
local server = Instance.new("Script")
server.Name = "CutsceneServer"
server.Source = EMBED.files["scripts/CutsceneServer.server.luau"]
local client = Instance.new("LocalScript")
client.Name = "CutsceneClient"
client.Source = EMBED.files["scripts/CutsceneClient.client.luau"]
-- fresh instances every install, so require() never hands back a stale cached module
for _, spec in { { ReplicatedStorage, "CutsceneKit" }, { ServerScriptService, "CutsceneServer" }, { StarterPlayerScripts, "CutsceneClient" } } do
	local old = spec[1]:FindFirstChild(spec[2])
	if old then
		old:Destroy()
	end
end
root.Parent = ReplicatedStorage
server.Parent = ServerScriptService
client.Parent = StarterPlayerScripts
for _, spec in { { ReplicatedStorage, "Cutscenes" }, { workspace, "CutsceneZones" } } do
	if not spec[1]:FindFirstChild(spec[2]) then
		local f = Instance.new("Folder")
		f.Name = spec[2]
		f.Parent = spec[1]
	end
end
return ("CutsceneKit %s installed (%d modules)"):format(EMBED.version, #EMBED.modules)
