-- IntroOnJoin (server): an example that plays a story intro made with /make-cutscene for each player when their
-- character first spawns on this server (give the scene "Replay": "always" and it plays on every join; a respawn on
-- the same server never replays it). Method by fwjelaa (FWJ STUDIOS).
-- Put it in ServerScriptService. It waits for the kit's Api (ReplicatedStorage.CutsceneKit.Api, made by the
-- CutsceneServer script) and for the character, then calls Api:Invoke("Play", player, SCENE): the kit pins the player
-- at the scene's trigger anchor (an `api` trigger in Workspace.CutsceneZones), so the intro ends with the player there.
-- It never throws, and it does nothing when the scene isn't installed (no ReplicatedStorage.Cutscenes.<SCENE>).
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local SCENE = "ForbiddenGate" -- the intro's id: its data module is ReplicatedStorage.Cutscenes.<SCENE>
local KIT_WAIT = 60 -- s to wait for ReplicatedStorage.CutsceneKit and its Api before giving up quietly
local ROOT_WAIT = 15 -- s to wait for the new character's HumanoidRootPart (the kit pins it)
local DELAY = 1.5 -- s after the character spawns: the player's client starts the kit and warms the scene's clips

local tried = {} -- [player] = true once this player's first character on this server has been handled
local api = nil -- the kit's BindableFunction, once found
local noKit = false -- the kit never showed up: stop waiting for it
local said = false -- one warning per server at most

local function warnOnce(msg)
	if not said then
		said = true
		warn("IntroOnJoin: " .. tostring(msg) .. " (later problems are not logged)")
	end
end

local function findApi()
	if api or noKit then
		return api
	end
	local kit = ReplicatedStorage:WaitForChild("CutsceneKit", KIT_WAIT)
	local found = kit and kit:WaitForChild("Api", KIT_WAIT)
	if found and found:IsA("BindableFunction") then
		api = found
	else
		noKit = true
	end
	return api
end

local function installed()
	local folder = ReplicatedStorage:FindFirstChild("Cutscenes")
	local module = folder and folder:FindFirstChild(SCENE)
	return module ~= nil and module:IsA("ModuleScript")
end

local function playIntro(player, char)
	local kitApi = findApi()
	if not kitApi or not installed() then
		return -- no kit or no scene in this place: nothing to play
	end
	if not char:WaitForChild("HumanoidRootPart", ROOT_WAIT) then
		return
	end
	task.wait(DELAY)
	-- still here, still the same body (a death or a leave during the wait cancels the intro)
	if player.Parent ~= Players or player.Character ~= char or char.Parent == nil then
		return
	end
	local called, ok, why = pcall(kitApi.Invoke, kitApi, "Play", player, SCENE)
	if not called then
		warnOnce("CutsceneKit's Play errored: " .. tostring(ok))
	elseif ok ~= true then
		warnOnce(("%s did not start for %s: %s"):format(SCENE, player.Name, tostring(why)))
	end
end

local function onCharacter(player, char)
	if tried[player] then
		return -- only the first spawn on this server plays the intro
	end
	tried[player] = true
	task.spawn(function()
		local ok, err = pcall(playIntro, player, char)
		if not ok then
			warnOnce(err)
		end
	end)
end

local function watch(player)
	player.CharacterAdded:Connect(function(char)
		onCharacter(player, char)
	end)
	if player.Character then
		onCharacter(player, player.Character)
	end
end

Players.PlayerAdded:Connect(watch)
for _, player in ipairs(Players:GetPlayers()) do
	task.spawn(watch, player)
end
Players.PlayerRemoving:Connect(function(player)
	tried[player] = nil
end)
