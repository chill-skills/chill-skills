-- AwakenKeyBind (server): an example key bind for an awakening made with /make-cutscene (spec 2: the viewer decides
-- the trigger; this is one way). Method by fwjelaa (FWJ STUDIOS).
-- A client is never trusted. All it can send is "pressed": the server picks the scene (SCENE) and the place (where the
-- player stands, CutsceneKit.Awaken's own choice; nothing position-like from a client is ever read). A press is looked
-- at once per RATE s per player, and the cheap checks run before CutsceneKit.Awaken (which loads and checks the scene):
-- not in a scene, not awakened, MIN_GAP s since this user's last awakening began (even when the scene's
-- Config.Cooldown is 0) and the scene's own cooldown. CutsceneKit.Awaken checks the rest (alive, the replay policy).
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local SCENE = "" -- set by `py kit/run.py studio <id> keybind`: the one scene this key bind starts
local PRESSED = "pressed" -- the only thing a client may send
local RATE = 0.5 -- s: one press per player is looked at in this window; the others are dropped unanswered
-- s from the start of one awakening to the next for one user, whatever the scene's Config.Cooldown says (default 0).
-- An awakening shields and pins its caster through its cinematic (about 11 s at most: the kit's 0.75 s lead and a
-- 10.5 s scene), and its awakened state can end early (a death, EndAwakening from the game, a short
-- Config.Awakened.Duration, leaving and rejoining). Without this floor a client could chain shielded awakenings; with
-- it the shield is up at most about 11 s of every 30. It is twice the kit's gap for zone and prompt scenes
-- (Server.SCENE_GAP), and with the default 30 s awakened state it never bites. Raise it to suit your game; never set
-- it to 0 on a live server.
local MIN_GAP = 30
-- CutsceneKit.Awaken's answers that mean the scene itself can't start (Server.load's answers, and Server.awaken's for a
-- scene that isn't an awakening): the key bind says so once and stops asking. Every other answer is "not now" for that
-- one player and press, and leaves the key bind on for everyone.
local SCENE_BROKEN = {
	"cutscene names may only use", -- SCENE is not a cutscene id
	"no such cutscene:", -- no module named SCENE in ReplicatedStorage.Cutscenes
	"cutscene module errored:", -- the module errored when it was required
	"invalid:", -- its data didn't pass the kit's checks
	SCENE .. " is a ", -- "<SCENE> is a story scene: start it with Play": not an awakening
}
-- the per-player answers the client is told by name; any other one reaches it as "not now"
local TELL = {
	busy = true,
	awakened = true,
	cooldown = true,
	loading = true,
	seen = true,
	["no living character"] = true,
}

if SCENE == "" then
	warn("AwakenKeyBind: SCENE is not set (run `py kit/run.py studio <id> keybind`, or set it by hand): the key bind "
		.. "is off")
	return
end

local CutsceneKit = require(ReplicatedStorage:WaitForChild("CutsceneKit"))

local remote = ReplicatedStorage:FindFirstChild("AwakenRequest")
if not remote then
	remote = Instance.new("RemoteEvent")
	remote.Name = "AwakenRequest"
	remote.Parent = ReplicatedStorage
end
assert(remote:IsA("RemoteEvent"), "ReplicatedStorage.AwakenRequest must be a RemoteEvent")

-- plain tables, never weak ones: this is security state, and a weak table's Instance keys are not guaranteed to stay
local lastAsk = {} -- [player] = server time of the last press looked at; dropped when the player leaves
local lastStart = {} -- [UserId] = server time that user's last awakening began; kept across a rejoin until MIN_GAP
local off = nil -- why SCENE can't start on this server, once Awaken has said so
local errored = false

local function sceneBroken(why)
	if type(why) ~= "string" then
		return false
	end
	for _, prefix in SCENE_BROKEN do
		if string.sub(why, 1, #prefix) == prefix then
			return true
		end
	end
	return false
end

-- the gap starts for this user, and entries older than MIN_GAP go (one sweep per awakening keeps the table small)
local function started(userId, now)
	for id, at in lastStart do
		if now - at >= MIN_GAP then
			lastStart[id] = nil
		end
	end
	lastStart[userId] = now
end

-- the answer only ever carries the server's own values (the client shows "Ready in N s" for a cooldown)
local function answer(player, ok, why, left)
	remote:FireClient(player, ok, why, left)
end

local function onPress(player, action)
	-- one string argument, exactly PRESSED; whatever else a client sends is never read
	if type(action) ~= "string" or action ~= PRESSED or off then
		return
	end
	local now = workspace:GetServerTimeNow()
	local asked = lastAsk[player]
	if asked and now - asked < RATE then
		return
	end
	lastAsk[player] = now
	if player:GetAttribute("CutsceneLock") then
		answer(player, false, "busy")
		return
	end
	if player:GetAttribute("Awakened") then
		answer(player, false, "awakened")
		return
	end
	local left = 0
	local began = lastStart[player.UserId]
	if began then
		left = began + MIN_GAP - now
	end
	local ready = player:GetAttribute("CutsceneReady_" .. SCENE) -- the scene's own cooldown, set by the kit
	if type(ready) == "number" then
		left = math.max(left, ready - now)
	end
	if left > 0 then
		answer(player, false, "cooldown", left)
		return
	end
	-- the scene name is this script's own and no anchor is passed: the player awakens where it stands
	local called, ok, why, secs = pcall(CutsceneKit.Awaken, player, SCENE)
	if not called then
		-- fail closed: Awaken may have started the shielded cinematic before it threw, so the gap starts anyway
		started(player.UserId, now)
		if not errored then
			errored = true
			warn(("AwakenKeyBind: CutsceneKit.Awaken errored (%s); later errors are not logged"):format(tostring(ok)))
		end
		answer(player, false, "error")
		return
	end
	if ok == true then
		started(player.UserId, now)
		answer(player, true)
	elseif sceneBroken(why) then
		off = why
		warn(("AwakenKeyBind: %s can't start on this server (%s): presses are ignored until it restarts")
			:format(SCENE, off))
		answer(player, false, "unavailable")
	else
		local readyIn = why == "cooldown" and type(secs) == "number" and secs or nil
		answer(player, false, TELL[why] and why or "not now", readyIn)
	end
end

remote.OnServerEvent:Connect(onPress)

Players.PlayerRemoving:Connect(function(player)
	lastAsk[player] = nil -- the gap (lastStart, by UserId) stays: a rejoin must not reset it
end)
