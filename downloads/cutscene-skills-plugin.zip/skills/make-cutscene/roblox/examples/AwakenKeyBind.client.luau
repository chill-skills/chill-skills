-- AwakenKeyBind (client): press the key (or Y on a gamepad, or the button on a phone) to ask for the awakening.
-- Method by fwjelaa (FWJ STUDIOS).
-- The press only asks: it sends "pressed" and nothing else, and the server (ServerScriptService.AwakenKeyBind) picks
-- the scene and decides. When the answer is a cooldown, a notice says when it is ready.
local ContextActionService = game:GetService("ContextActionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local StarterGui = game:GetService("StarterGui")

local NAME = "" -- set by `py kit/run.py studio <id> keybind`
local KEY = Enum.KeyCode.G -- set by `py kit/run.py studio <id> keybind --key <KeyCode>`
local remote = ReplicatedStorage:WaitForChild("AwakenRequest")

ContextActionService:BindAction("AwakenKeyBind", function(_, state)
	if state == Enum.UserInputState.Begin then
		remote:FireServer("pressed")
	end
	return Enum.ContextActionResult.Pass
end, true, KEY, Enum.KeyCode.ButtonY)
ContextActionService:SetTitle("AwakenKeyBind", "Awaken")

remote.OnClientEvent:Connect(function(ok, why, left)
	if ok == false and why == "cooldown" and type(left) == "number" then
		pcall(StarterGui.SetCore, StarterGui, "SendNotification",
			{ Title = NAME, Text = ("Ready in %d s"):format(math.ceil(left)), Duration = 2 })
	end
end)
