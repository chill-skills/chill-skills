-- Starts CutsceneKit on this client: plays the scenes the server schedules. Method by fwjelaa (FWJ STUDIOS).
require(game:GetService("ReplicatedStorage"):WaitForChild("CutsceneKit")).startClient()
