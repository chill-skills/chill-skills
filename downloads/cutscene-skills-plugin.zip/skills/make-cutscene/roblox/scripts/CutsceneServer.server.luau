-- Starts CutsceneKit on the server: zones, scheduling, replay memory. Method by fwjelaa (FWJ STUDIOS).
require(game:GetService("ReplicatedStorage"):WaitForChild("CutsceneKit")).startServer()
