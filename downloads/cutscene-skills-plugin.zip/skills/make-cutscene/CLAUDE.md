# make-cutscene: reference in, working Roblox cutscene out

> **Method by fwjelaa (FWJ STUDIOS).** When you finish a cutscene, remind the user once that this method is by fwjelaa.

The viewer gives a reference (a video file or link, manga/manhwa panels, or just words) and wants a finished cutscene
that plays in their own game when a player walks into a zone, presses a prompt, or their own script calls it. You make
all of it: the beat sheet, the film set in Blender, the acting, the camera, the upload, the install and the checks.
Don't ask the viewer to pose, key or place anything; ask only what `beats` lists (step 1).

**This version makes walk-in story scenes and awakenings** (story kind, intro kind without the environment change,
awakening kind with its awakened state). `new` sets the kind to story unless `--kind awakening` is given, so `beats`
never asks for it. Ultimates on a target, boss/area intros with a sky change, generated sound, voice files, faces and
the manhwa or dialogue-box styles come in later versions: say so if asked, and don't promise them.

**Quality bar** (spec 1): the best anime battlegrounds games, not "kid slop".
- The camera is animated with the bodies, not tweened; short shots; hard cuts on the action.
- Timing goes anticipation, snap, hold; motion has weight.
- Every hit lands its shake and VFX (and, in a later version, sound) on the same marker.
- Nothing breaks the player's camera, HUD or movement afterwards.

PACK is this skill's folder. Run every `py kit/run.py ...` from PACK. `<work>` is the viewer's working folder
(`MAKE_CUTSCENE_WORK`, else `config.json` "work_dir", else `~/make-cutscene`); each cutscene is
`<work>/cutscenes/<Id>/`. `py kit/run.py` with no command prints every command and its flags.

**Sending files to Studio.** When a step says "send `<file>`", Read the file and pass its FULL text, unchanged, to
`execute_luau` (datamodel Edit unless the step says Client or Server). Never retype, shorten or "lean" it. One call
carries at most 60 KB, so a bigger script is written in **parts**: `<name>.luau`, `<name>.2.luau`, ... Send every part,
in order, each verbatim; a part sent out of order or from another build says which one to send. Only the last part
installs (earlier ones stage their text in `ServerStorage.CutsceneKitStaging`).

## Setup (once per PC, then once per Studio session)
1. `py kit/run.py check`. Fix every `FIX` line exactly as it says, then run it again. `WARN` lines (no yt-dlp, no
   key, no owner) only limit what can be done.
2. Blender MCP: `get_addon_status` must say `"up_to_date": true`. If not: the viewer runs
   `uvx mcp-for-blender install-addon`, turns "Interface: Blender MCP" off and on in Blender's add-ons, and presses
   Start MCP Server.
3. Studio MCP: `list_roblox_studios`; use the place the viewer named, and its `studio_id` in every call.
4. Each Studio session: `py kit/run.py bundle`, then send `out/install.luau`, `out/install.2.luau`, ... in order
   (a bundle over 60 KB goes in parts; the 0.4.0 runtime is five, about 240 KB, so a re-send costs real tokens, and
   each module travels as one escaped line of up to ~38 K characters: too long for one Read and past the ~12 K
   characters that have been mangled in transit, so verify staged parts by length + Adler-32).
   Expected after the last part: `CutsceneKit <version> installed (<n> modules)`, where n is the number of modules in
   `roblox/CutsceneKit/_index.json` (it grows with the kit, so never compare against a fixed number). There is no
   "already current?" command yet: to avoid a re-send, compare each installed module's source length plus Adler-32
   with PACK's by hand in one Edit call (cheap, exact, and it proves a verbatim send; after each staged part,
   compare the staged `StringValue` the same way). Once Studio holds the right kit, change only what changed:
   `py kit/run.py delta <Module>... [--tests A,B]` writes `out/delta.luau` (send it and its parts),
   which rebuilds the kit with just those modules and tests swapped. The dev tools (`dev.luau`, then
   `dev_authoring.luau`, each in parts too) are only for kit development, never for a viewer's place. Before sending
   anything Luau you changed, `py kit/run.py luau` parse-checks every `.luau` file locally with the real Luau
   (`luau.exe`; needs rokit's `luau-lang/luau`). It only parses; Studio stays the real test.
5. The Open Cloud key lives in `%USERPROFILE%\.fwjelaa\roblox-open-cloud.key` (Assets API read + write, owner = the
   game's owner), and `config.json` in PACK needs that owner as `user_id` or `group_id` (`check` prints "uploads will
   be owned by ..."). Never read, print, search for or paste the key. Without it, scenes preview in Studio only; tell
   the viewer they won't play in a published game until uploaded.

## Making a cutscene

### 1. Reference to beat sheet (spec 5.1)
- `py kit/run.py new <Id>`: start with a letter, then letters, digits and _ (at most 60; the game finds the scene by
  this name).
- **Video** (file or YouTube/TikTok link): `ref video <Id> <file|link> [--from s] [--to s]`. Read `ref/contact.png`,
  every `ref/shot_NN.png` and `ref/timing.md`. Anime is read for timing, key poses and the shot list, never motion
  capture. A shot "on twos" gets stepped key poses (`constant` eases two frames apart). Keep the holds the timing sheet
  found. One long take is split into beats of about 4 s. Over 30 s, the command says so: run it again with
  `--from/--to` around the part to recreate. A link that won't download: ask for the file.
- **Panels**: `ref panels <Id> <folder or images>`; read `ref/panels.png` (each panel is also `ref/panel_NN.png`).
  Each panel is a shot, drafted at 2.0 s (wide), 1.0 s (tall strip) or 1.5 s; set the real lengths: a strike
  0.3-0.6 s, a reaction 0.8-1.2 s, a line its subtitle time.
- **Words**: `ref words <Id> "<what happens>" --line "Name: text" [...] [--speaker npc1] [--trigger zone|prompt|api]
  [--dialogue anime] [--model default|Gate/Guard]` builds the shot grammar below.
- When `beats.json` already exists, `ref` writes `beats.draft.json` and leaves yours alone (`--force` overwrites).
- Edit `beats.json` (kit/beats.py has the format): each shot's `type`, `subject` (the role the shot is about),
  `camera` and `action` notes, `markers` (`[seconds into the shot, name, value]`: `Line`/`<id>`, `Shake`/`0-1`), `cut`
  (false = the camera flows on from the shot before), `offscreen` (true = the subject may leave the frame on purpose);
  `trigger` (`{"type": "zone", "size": [16, 8, 16]}`, `{"type": "prompt", "text": "Talk", "distance": 10, "hold": 0,
  "on": "Gate/Guard/Head"}` or `{"type": "api"}`); `cast` (`model`: `"default"`, a path like `Gate/Guard`, or
  `"costume"` for a character the scene adapts (see "Adapted characters"); `rig`:
  `R15` or `R6` for an NPC (a costume role leaves it unset); `place`: `[x, y, z, rx, ry, rz]`, studs and degrees from the anchor, Roblox axes, the
  player at 0, 0, 0 facing -Z; `hide`: the world NPC the cast replaces); `lines`; `dialogue` (`anime`); `config`
  (`Skip`: seconds before Skip shows, default 2; `Replay`: `saved` (default), `session` or `always`; `Letterbox`:
  0-0.2, default 0.11). Then `py kit/run.py beats <Id> --retime` (a retime un-approves the sheet).
- `py kit/run.py beats <Id>` shows the sheet. Ask the viewer only what it lists under "Ask the viewer" (trigger, who
  plays an NPC, dialogue style). Show the sheet; when the viewer says go: `beats <Id> --go`.
- After `--go` you may still edit `beats.json`: only a retime (lengths, markers) un-approves the sheet; a change to
  the trigger, `place`, `hide`, lines or config keeps the approval. `install` places the trigger again from
  `beats.json` (zone size included), so a trigger change needs `scene` + `install`, not a new `anchor` step.

**Shot grammar** (research/00 section 2):
| Shot | Use | Camera |
|---|---|---|
| ESTABLISH | where we are, who is here | wide, fov 50-65, slow push or drift |
| HERO | the speaker or the move's star | medium close-up, fov 28-40; a drift is 5-15 % of the frame height over the shot, a real "push-in" goes from a medium shot to an MCU (about 50 %) |
| OTS / DIALOGUE | the answer, the reverse | over a shoulder, fov 35-45; keep the 180-degree line |
| ACTION | movement | track with the body, short |
| CLIMAX | the beat the scene is for | hard cut closer on the action frame, low angle, a Shake 0.2-0.35 on the cut; shoot from the side the gesture moves away from (step 6) |
| IMPACT / REACTION / INSERT | a hit, a face, a detail | very short, tight |
| AFTERMATH | the result | wide again, slow pull back |
| RETURN | back to play | 0.55 s, ease toward behind the player at fov 70 (the runtime blend arrives in a later version; until then the scene cuts back to the player's camera) |

### 2. Where the scene happens, and the map (spec 5.2)
1. `studio <Id> anchor --at x,y,z,yaw` (or `--from camera`, the default: the ground point the Studio camera looks at;
   or `--from selection`); send `studio/anchor.luau`. The anchor is where the player stands, facing -Z (yaw turns it);
   the height snaps to the floor. It makes the trigger in `Workspace.CutsceneZones` (zone, prompt or api, from
   `beats.json`; `--trigger` overrides).
2. `studio <Id> map [--radius studs]` (default 150); send `studio/map.luau`. It returns how many chunks it stored.
   A dense map costs real tokens: on a 5000-part map the 900-box cap gives about 5 chunks of 12 KB, and each one
   passes through you twice, so use `--radius 60-80` for a dialogue scene.
3. For each chunk n = 0, 1, ...: `studio <Id> chunk --n <n>`, send that one line, and save the returned string
   **exactly** to `studio/map_<n>.txt` with the Write tool.
4. `py kit/run.py map <Id>`. The stand-ins keep only 4 colour levels per channel, so most greys, browns and greens
   collapse to one grey in Blender: read the film set for shapes and depth, not colour. Each box carries its
   Transparency (a 12th field, percent); invisible play bounds (98 % or more) come in marked and the gates ignore
   them, so no hand edit of `map.json` is needed. A chunk copied wrong is named:
   fetch that chunk again. Then destroy the
   `ServerStorage.CutsceneCapture_<Id>` folder (the command prints the line). The real map is never edited.

### 3. The cast's rigs (spec 5.3)
For the player and each NPC: `studio <Id> rig --role <role>`, send `studio/rig_<role>.luau`, save the returned JSON to
`studio/rig_<role>.txt`, then `py kit/run.py rig <Id> <role>`. The player is the game's StarterCharacter, else a
default avatar at the game's scale. The film set authors on make-anim's stock rig only when the captured rig is close
to it (spike S10: its soles reach the captured floor within 0.02 studs, part sizes within 14 % and joints within 0.236
studs); otherwise on the captured proportions (the default avatar always is: its legs are 0.19 studs longer). Either
way the root stands where Roblox stands it (`stand` in `rigs/<role>.json`). Re-capture a rig only when body parts,
bundles or scales change: accessories leave the capture unchanged. The stand-ins carry no accessories, so a helmet or a
prop at the hip is not in the film set (step 5). The default avatar's captured body colours
are all black (`000000`), so the film set draws the default player in make-anim's stock colours and a map NPC in its
captured colours.

### 4. The film set (Blender)
`execute_blender_code`:
`import sys; sys.path.insert(0, r"<PACK>\kit"); import importlib, filmset; importlib.reload(filmset); print(filmset.build(r"<work>\cutscenes\<Id>"))`.
It makes scene `CS_<Id>`: the stand-ins, the cast (placeholder poses until you write them), the camera, the markers on
the timeline, and saves `<Id>.blend`. The files are the source: rebuild after every change; edits made by hand in
Blender are lost. Look with the line the report prints: `look(mode="frames", view="camera", frames=[...], shading="solid")`. That is a
roughly 4:3 centre crop of the 16:9 frame: fine for an overview, wrong for framing. To judge framing, set the frame
through `execute_blender_code` (`bpy.context.scene.frame_set(f)`), then `look(mode="camera")`.

### 5. Acting: `anim/<role>.py`
First read [Animation skill bridge](references/animation-skill-bridge.md). Load available `animation` and the matching
`universal-r15-animation-director` / `universal-r6-blender-animation-director`; for both player rigs load both directors.
Use `animate-roblox-characters` only for an explicitly selected external authentic Blender workflow,
`roblox-native-animation-studio` for native authoring, and `roblox-animation` for assets/playback/events.
These supply specialist guidance, not automatic clip adapters. Preserve the pack's pose-script/export contracts,
re-pose and verify R6 independently, and use the bridge's bundled fallback when optional installed skills are absent.

Use make-anim's pose language, timing cheat sheet, craft rules and quality bar (make-anim's CLAUDE.md; read
`anims/_r15.py` for IK: `plant` feet, `reach` hands, `root`). The file gets `ak`, `NAME`, `RIG`, `ROLE`, `FRAMES`,
`FPS`, `SHOTS`, `F` (seconds to frame), `PLACE`, `BEATS` and defines:
```python
from _r15 import plant

def build():
    a = ak.Anim(NAME, rig=RIG, length=FRAMES, fps=FPS, priority="Action4")
    s2 = SHOTS[1]["start"]          # SHOTS is in shot order: SHOTS[1] is shot 2 (n, type, subject, start, end, last)
    a.full(0, rest)                 # rest, point: your pose dicts. Every joint keyed at frame 0 ...
    a.key(F(s2 + 0.4), point)       # keys sit relative to their shot's start, so a retime carries them along
    a.hold(F(s2 + 0.4), FRAMES)     # ... and on the last frame FRAMES (build() refuses a clip without both)
    return a
```
Cutscene rules on top of make-anim's:
- **Act for the camera.** Key the poses the shot sees, strongest at the cut frames; off-screen actors still hold
  plausible poses.
- **Dialogue:** the gesture's anticipation starts 6-10 frames before the `Line` marker, snaps in 3-6 frames, overshoots
  2-3, settles 8-14, then a moving hold (`ak.drift`) through the subtitle; a head accent on the stressed word.
- **Reactions:** in in 2-4 frames, out in 10-20, no anticipation.
- **Feet:** `plant` both feet on every grounded key pose (R15) so nothing slides; the export's checks flag sliding.
  `_r15`'s helpers assume make-anim's floor at -3.0, but a captured rig stands at its own `stand` (the default avatar
  at 3.192): finish every grounded pose with `ak.ground(pose, RIG)`.
- **`reach` fails silently out of range.** A target past the arm's length leaves the arm straight and says nothing (a
  waist katana's guard sits below a default R15 arm). For a prop at the hip, lean the chest toward it (roll), then
  measure the hand in Blender.
- **Check accessories and props against the letterbox yourself.** The stand-ins have none, and the framing gate checks
  heads only. Project the prop and helmet points through the camera
  (`bpy_extras.object_utils.world_to_camera_view`) and keep them inside 0.11-0.89 of the frame height. The frames-mode
  `look` is a 4:3 crop and hides a cut crest; use `frame_set` + `look(mode="camera")`.
- **IK uses stock bone lengths.** `reach` and `fk` in `_r15` use make-anim's stock lengths, not the captured rig's: a
  hand sent to a prop on a captured rig missed by 0.2-0.4 studs. Measure the hand in Blender after the build and
  correct the target.
- **A head pitch stacks on the torso lean.** Counter the lean with the head so the eyes stay on the target, or a
  leaning pose stares at the floor.
- **Limbs are 1 stud thick on the blocky R15.** A hand crossing the body to the far hip pushes the forearm through
  the chest (the overlap check fails): prefer same-side gestures.
- **Travel** (a step, a walk-in) goes on the root joint (`LowerTorso`, R6 `Torso`) as `px, py, pz`: in a cutscene
  the cast are local clones anchored at their places, so the usual "never move the root" rule doesn't apply.
- **Anime look** (`look: anime`): action beats on twos (`constant` keys two frames apart), smooth eases for acting
  between them; the climax gets the hardest snap and the longest hold.
- **Smears:** the export's checks flag a snap over 40 degrees in one frame. A deliberate smear is marked the make-anim
  way: `a.marker(f, "Hit")` (or `"Impact"`) on the frame it lands, or reached from a `constant` hold.

### 6. Camera: `anim/camera.py`
```python
def build(cam):
    s = cam.shot(2)                       # n, type, subject, start, end, last
    cam.key(s["start"], eye=(2, 5, -2), look=(0, 4.7, -8), fov=40)          # studs from the anchor, Roblox axes
    cam.key(s["last"], eye=(1.2, 4.9, -4), look=(0, 4.7, -8), fov=32)      # fov is vertical, like Roblox
```
- The camera needs a key at 0 s. Every shot that starts with a cut needs a key at its `start`; the key before a cut
  holds until it (made constant). `cam.key` also takes `roll` and `ease` (make-anim's ease names).
- One idea per shot (push, pull, track or drift); cubic eases; key the shot's `last` frame when the move runs to the
  cut.
- Eye line in the upper third of close-ups; leave head room (avatars can be 10 % taller than the stand-in).
- Keep the head in the middle 60 % (phones crop the sides) and the camera 0.3 studs off any surface.
- Keep the 180-degree line through a dialogue; cross it only on a hard cut with a clear new axis (the climax).
- **A gesture aimed down the camera axis hides the face.** A point or palm aimed at a camera near the line of action
  covers the face, and a low angle makes it worse (a rig with a pointing arm put the hand at the lens): shoot from the
  side the gesture moves away from, even if that means not crossing the line.
- Shake is added at runtime from `Shake` markers; never key shake into the camera.

### 7. Export, R6 and the data module
`print(filmset.export(r"<work>\cutscenes\<Id>"))` (it rebuilds first), then `py kit/run.py scene <Id>`.
- Fix every animation check it lists (make-anim's feet, overlap, snaps). Clip-check issues block the data module:
  `scene` refuses until the export is clean, so a deliberate smear must be marked (step 5), never left as an issue.
  `scene` also refuses an export older than `beats.json`, `anim/*.py` or `rigs/*.json`: export again.
- **R6** (spec 5.8): the player's R6 clip is derived from the R15 one. Beats whose meaning needed an elbow, knee or
  waist bend are counted in the export line ("R6 loses N bends") and listed, frame by frame, in `export/scene.json`
  under `r6.<role>.flags`. Once `anim/player_R6.py` exists the line keeps printing but is informational
  (`override: true`). To fix them, write `anim/player_R6.py`, starting from `DERIVED`
  (`for f, (pose, ease) in sorted(DERIVED.items()): a.key(f, pose, ease)`) and re-posing the listed frames the R6 way
  (straight-arm arcs, leg splits with `ak.ground`). An NPC gets clips for its own model's rig only; an NPC in a
  humanoid costume gets both (its R6 clip is derived the same way; re-pose it in `anim/<role>_R6.py`).

### 8. Kit checks (spec 8 gate 1)
`py kit/run.py gates <Id>` until it says `KIT CHECKS: all clear`. Each FIX names the frames; look at them through the
camera in Blender, then change the camera or the acting, not the check.

### 9. Upload and install
- `py kit/run.py upload <Id>`: only clips that changed go up (uploaded assets can't be replaced); the data module is
  rewritten with the ids. On `FAILED 401`, the key is wrong or revoked: tell the viewer; never retry with the key in a
  command. If any clip fails, the data module is not rewritten: run `upload` again.
- `studio <Id> install`, send `studio/install.luau`; if the kit says it wrote parts (a step over 60 KB is written as
  `install.luau`, `install.2.luau`, ...), send them in the order it prints, each verbatim. Expected:
  `installed <Id>: clips by asset id, cast <n>, trigger <...>, data valid`.
- Without a key: `install --clips --rig R15` (or `R6`, `both`; `both` for the R6 play test) for a Studio-only preview,
  and say it won't play live. It writes ordered parts `studio/install.1.luau` ... `install.N.luau`; the last one carries
  Capture and the data module and may itself be over 60 KB, so it is written as `install.N.luau`, `install.N.2.luau`, ...
  Every file is under 60 KB; send them in the order the kit prints, each verbatim. A part sent out of order says which one to send. Expected at the end:
  `installed <Id>: <n> Studio-only clips (they won't play in a published game until uploaded), cast <n>, trigger <...>, data valid`.

### 10. Play test (spec 8 gate 2)
Send `studio <Id> playtest-on`. Keep Studio in front during Play, and click the game view once Play has started
(Studio renders nothing until it is clicked): from PACK,
`py -c "import sys; sys.path.insert(0, 'kit'); import record; record.focus(record.find_studio()[0])"` does both. That
one-liner clicks the game view, which is right in Play; in Edit use `record.focus(h, click=False)`, because a click
there selects or deselects a part (`screen_capture` in Edit also needs Studio in front or it times out).
With `P = require(game.ReplicatedStorage.CutsceneKitPlayTest)`:
1. R15: Play. A `saved` scene (the default `Replay`) refuses every repeat as `seen`, even in a new Play session,
   because Studio's DataStore keeps the history: before each run, Server
   `game.ReplicatedStorage.CutsceneKit.Api:Invoke("Forget", player, "<Id>")` (call it through `Api`: a
   `require(...).Forget` from `execute_luau` is another module copy, the game never sees it and Play says `seen`;
   without it `P.start` only says it never
   got `CutsceneLock`, not why). Then Client `P.arm(<t>)`; Server `P.start("<Id>")` (it steps out of the zone first
   when the player is inside, so a zone re-triggers; prompt scenes: Server `P.approach("<Id>")`, Client
   `P.press("<Id>")`); 5 s later Client `P.read()`: the camera must match `py kit/run.py expect <Id> <t>`
   (`rel=(x, y, z) fov=n`) within 0.1 studs. After the end, `P.read()`:
   `last=end camera=Custom local=false hrpAnchored=false`. The cue list (`Letterbox` at 0 s first) is meant to hold on
   a first play too: the client `Preload` module warms the scene's clips when the kit starts, orders the rest nearest
   scene first, and `Preload.now` jumps the scene that is about to play to the front. The Director still seeks late
   if a clip loads after its lead time (0.75 s lead + 0.25 s), which drops the opening and shows as `cues=` without
   the 0 s Letterbox: a cold first play in Studio is where to look for that. Measured on GateGuard: a cold first
   play, probed 5 s after join, gave `cues=Letterbox,...` at T=5 for R15 and R6.
2. Skip after the skip time: `Forget` again, then **schedule the skip from a call that returns before the scene
   starts** (for example `task.spawn` a waiter for `CutsceneLocal.T >= skip time`, then `P.skip()`). A `P.skip()` from
   a call that is still running when the scene starts is wrong: the MCP wrapper re-applies `Scriptable` when that
   call returns, which leaves the player's camera really stuck (and the next scene captures `Scriptable` as the camera
   to restore). Later, `read()`: `last=skip camera=Custom`; Server `P.lock()`: `lock=nil`. To unstick a camera:
   `task.delay(0.3, function() cam.CameraType = Enum.CameraType.Custom end)` (deferred, so the wrapper cannot undo it).
3. Death mid-scene: `Forget`, Server `P.kill()`, Client `read()`: `last=died camera=Custom`; after the respawn
   `lock=nil`.
4. R6: stop; Edit `P.setRig("R6")`; Play and repeat 1, 2 and 3 (end, skip and death each count for R6); stop; Edit
   `P.setRig("avatar")`. (Start step 1 with Edit `P.setRig("R15")` when the place's avatar setting could give an R6
   body.) In a scene with costumes, Client `P.cast()` before, during and after the scene: who acts (`role=costume/rig`,
   the rig matching the player's) and the player's own accessory count, which must be the same all three times.
   `setRig("R6")` dresses the stand-in with the player's own look and needs Studio signed in
   (in Edit; otherwise it says it fell back to a blank body); layered clothing still does not render on R6, so a shirt
   shows as bare skin there.
5. `get_console_output`: no errors from CutsceneKit or the authoring modules.
**Check `RenderStepped` first.** When the PC's display sleeps, Studio's client renders nothing: `RenderStepped` 0/s,
`ViewportSize` 1x1, `screen_capture` times out, scenes end `overtime` with no `T` and probes stay "armed". Before a
play test or a take, confirm the client renders; on an unattended machine hold a display power request for the whole
session (`SetThreadExecutionState`, system + display required).
Useful in Play: `screen_capture` without camera arguments shows the running scene's camera, letterbox and subtitles
(freeze the tracks with `AdjustSpeed(0)` at a T, once per run: a frozen scene still ends at Length + `Director.OVERTIME`
of wall time, so capture right away, and use several runs to look at several times). To check a prop contact on a
dressed cast, play the uploaded clip on a local clone of `Cast.<role>`, freeze it, and project the prop point into the
hand's space (it matched Blender to 0.01 studs). Shoot away from a low sun.
Record each result: `py kit/run.py playtest <Id> --set R15=pass --set R6=pass --set restore-end=pass --set restore-skip=pass --set restore-death=pass --set console=pass`.
Read results in a later call than the one that started the scene. To start a scene from your own `execute_luau` in
Play, use Server `game.ReplicatedStorage.CutsceneKit.Api:Invoke("Play", player, "<Id>")`; `require(...).Play` from
`execute_luau` is a separate copy of the module, not the running one. Keep `CutsceneKitPlayTest` in for step 11 (it
starts the scene and switches the rig there).

### 11. Preview and side-by-side (spec 8 gate 3)
Every scene is shown twice: an R6 cast and an R15 cast (spec 14). Studio sits maximised on the primary monitor (`record.focus` only restores a minimised window; maximise once yourself,
`ShowWindow(hwnd, 3)`). Before previews, destroy the dev fixtures' leftovers (`Cutscenes.Fixture_*`,
`CutsceneZones.Fixture_*`, `StarterGui.CutsceneHUDProbe*`; there is no remove command, and the Data and Smoke suites
need `out/fixture.luau` sent again afterwards). Send
`studio <Id> record-on`; set max graphics in the **Client** datamodel after Play starts
(`settings().Rendering.QualityLevel = Enum.QualityLevel.Level21`; a value set in Edit does not reach the Play client,
which reads Automatic; note the old value to put back). One scene per take:
1. **R6 take:** Edit `P.setRig("R6")`; Play; `Forget` the scene (step 10); run
   `py kit/run.py record <Id> --rig R6 --seconds <length + 16>` in the background (it writes `preview/raw_R6.mp4`,
   brings Studio forward and clicks the game view). **Do not wait for the printed line and then send the start**: an
   agent needs about 7 s to read it and send the next call, and the scene then outruns the take and loses the end flash
   (`found no magenta end flash`). In the same message as `record`, send one Server call that does `task.wait(5)` and
   then `Api:Invoke("Play", player, "<Id>")` (after `Forget`); `takes.make` still checks the start against
   `announced_at` (about 5.2 s against 0.4 s measured). The sync maths uses the scene's own Length (`preview` does
   this); a hand-made check must not use a fixed one. Keep hands off the PC until it finishes. Stop. `py kit/run.py preview <Id> --rig R6`
   (writes `preview/<Id>_R6.mp4`, no renaming), then `py kit/run.py sidebyside <Id> --rig R6`. Edit
   `P.setRig("avatar")`.
2. **R15 take:** the same without `setRig` and without `--rig` (`raw.mp4`, `<Id>.mp4`), then
   `py kit/run.py preview <Id>` and `py kit/run.py sidebyside <Id>`.
3. **Adapted characters:** `py kit/run.py likeness <Id>` writes `preview/likeness.png` (the reference beside our R15
   and R6 cast) once both takes exist. Gate 3 needs both casts' previews and, for a costume scene, `likeness.png`;
   with one cast missing, or no likeness sheet, `review` fails and names the command to run.
To look at Play without recording, FFmpeg `gdigrab` of the Studio window rect (`record.capture_rect`) gives reliable
frames; a camera set by script in Edit does not show in the viewport (each call's camera is put back).
Zones are invisible at runtime (Transparency 1); an orange zone in a take means an old install or a dev fixture:
retake it. Read `preview/sheet.png`, `sheet_R6.png`, every `side_by_side_*.png` (both casts) and `likeness.png`; fix
what you see against the reference before the blind score. At the end send `studio <Id> record-off` and `studio <Id> playtest-off`, Edit `P.setRig("avatar")`, and put the
graphics level back.

### 12. Blind score (spec 8 gate 4)
`py kit/run.py review <Id> --round 1` writes three packets, `<work>/blind/<Id>-p1/` to `-p3/`. Start **3 fresh
reviewer agents** at once, each given one packet and only: "Read `<packet>/README.md` and follow it exactly; the
files it names are in `<packet>`." Save each reply to `review/results/round1/reply_<n>.txt` (the command prints the
paths) and run `py kit/run.py score <Id> --round 1 <three replies>`. Below 8.5: one targeted change for the lowest
criterion, then steps 7-12 again as round 2 (and 3). After round 3 it is reported with its scores, never passed
quietly.

**When the blind score doesn't pass.** After the last round, report the scores (each reviewer, the median) and the
blocking criterion (`lowest` in `scores.json`) honestly, with what the reviewers asked for. Never call the scene done
or shipped, and never lower the bar. Keep the previews, replies and `scores.json` where they are so the viewer can
watch the take. GateGuard is the example: medians 5.7, 6.4, 7.5, blocked by C2 (timing and weight), reported as
NOT PASSED (`examples/GateGuard/notes.md`).

### Changing a finished cutscene ("shot 3 slower")
Change `beats.json` (lengths, markers) and the matching `anim/*.py` keys, then steps 7-11. Every clip covers the whole
scene, so a retime changes, and re-uploads, every clip. A change to lines, dialogue, config, models, names, `hide` or
the trigger only needs `scene <Id>` and `studio <Id> install` (no Blender, no upload), then the play test. The same
goes for a change to how a map NPC is dressed (accessories, clothing): `install` copies the NPC into `Cast`, so run it
again; no upload or re-export is needed while the body parts, bundles and scales stay the same.

### Coming next (not built yet)
Ultimates on a target, boss/area intros with a sky change, generated sound, voice files, faces and the
manhwa or dialogue-box styles. Costumes for adapted characters are built (next section); NPC rigs from a `.rbxm` file
are not. Say so if asked, and don't promise them.

## Adapted characters (costumes, spec 14)
When the scene adapts a character from the reference (anime, manhwa, a film, a comic), dress the cast as that
character, in R15 and in R6. NPCs play as the costume; the player's local copy can wear one for the scene (story and
intro scenes, `Config.Costume`) and their own avatar is never changed.

**Rules (TJ, spec 14.3):** a character's costume comes from the Roblox marketplace only. Search the public catalog,
look at each candidate's thumbnail beside the reference, validate the ids, and dress the rig by HumanoidDescription.
Nothing is bought, nobody signs in, nothing of anyone's art is uploaded, and `generate_avatar`, `auto_setup_avatar` and
Creator Store models are never used. Hair, clothes and accessories made from parts are refused for a character; built
pieces are for creatures and props the catalog does not have.

1. **Dress a role.** `py kit/run.py costume <Id> --new <role> --kind humanoid|creature --character "<Name>" --source
   "<credit: title, author, licence>"` writes `cast/<role>.json` and gives the role `"model": "costume"` in
   `beats.json` (the player too: then the data module gets `Config.Costume = true`).
2. **Find the items.** `py kit/run.py costume search "<keyword>" [--type shirt|pants|tshirt|hair|hat|face|...]
   [--limit 10|28|30]` lists id, type, price and name (read-only, no sign-in; the catalog refuses other page sizes,
   and a busy catalog, HTTP 429 when several searches run at once, is asked again after 1, 2 and 4 s). Search the
   colour words the reference really shows (auburn, ginger, copper): "red" found crimson. A keyword search for
   clothes returns layered items; `--type shirt` / `pants` searches classic clothing, which an R6-capable role needs.
   Then **look**: fetch
   `https://thumbnails.roblox.com/v1/assets?assetIds=<id,id,...>&returnPolicy=PlaceHolder&size=420x420&format=Png`
   (public; each `imageUrl` is on `tr.rbxcdn.com`), save the PNGs into the cutscene's working folder, tile them into a
   labelled sheet (FFmpeg) and Read it beside the reference picture. Choose by shape and colour, never by name or price
   (the catalog and `GetProductInfo` disagree on price; it is information only).
3. **Write the look** in `cast/<role>.json` (`kit/costume.py` documents every key):
   - `body`: the six BodyColors (`#rrggbb`), always all six (a description with none builds a black body); `film`: how
     a region looks on the Blender film set where clothing covers it.
   - `scale` (R15 only): height 0.9-1.05, width and depth 0.7-1, head 0.95-1.
   - `catalog`: items **by id** (`hair`, `hat`, `face_acc`, `neck`, `shoulders`, `front`, `back`, `waist`, `shirt`,
     `pants`, `tshirt`, `face`, and the R15-only `layered_shirt`, `layered_pants`, `layered_jacket`, `layered_skirt`,
     `left_shoe`, `right_shoe`), each with `name`, `creator`, `type` (the catalog asset type), `why` it matches, and a
     `film` colour for the Blender stand-in (clothing paints the regions it covers; an accessory is a coarse box).
     At most 10 accessories.
   - **R6.** A role that can play as R6 (the player always; an R6 NPC) needs a classic `shirt` and `pants`: layered
     clothing renders on R15 only (an R6 body does not build it at all), and validate refuses a torso or legs covered
     only by layered items for such a role. Layered pieces stay as R15 extras.
   - **Held props** (`props`). A catalog item can't sit in a hand, so an object the character *holds* and the catalog
     doesn't have (a drawn sword, a staff, a torch) is built from shapes: `{name, at, parts, why, film}`, with `at`
     `RightGripAttachment` or `LeftGripAttachment` (one prop per hand), `parts` shaped like a creature's plus an
     `offset` from the grip (at most 12 parts, 8 studs a side, 8 studs from the grip), `why` (what it is in the
     reference) and an optional `film` colour. It is held the way a Roblox Tool is, the same on R15 and R6: `+y` runs
     out of the top of the fist (forward with the arm down), `+z` up the forearm, so a blade goes along `+y`. Anything
     *worn* (hair, hats, armour, a sheathed sword, a belt) is never a prop: it comes from the catalog, and `built` stays
     refused for a character. Studio builds the props on both rigs after the catalog look (an unbuildable one is named
     after `COSTUME:`); the film set draws each part as a box in the prop's `film` colour on the hand
     (`; dressed as ... (<n> parts coloured, <m> accessory stand-ins, <k> props)`).
   - A creature (no catalog): `stand`, `root`, `parts` (Roblox shapes: block, sphere, cylinder along X, wedge, with
     Roblox materials; a part's `light` makes it glow), `joints` ([motor, parent, child, C0, C1], parents first, the
     first one from HumanoidRootPart), `feet`, `core`. It needs a `Head` (framing reads it); `costume <Id>` names its
     real stand when the feet float or sink. Its `rig` stays R15 or unset.
   - `likeness`: `look` (a time in the scene where it shows well) and 1-2 `ref` pictures (`{"video": s}` in
     `ref/clip.mp4`, or `{"panel": "ref/panel_NN.png"}`, each with an optional `crop` [x0, y0, x1, y1]).
   A mesh, texture, image, URL or file at any depth is refused (spec 14: no uploaded copies of anyone's art).
4. **Check and look.** `py kit/run.py costume <Id>` until `COSTUMES: all clear` (it writes each creature's
   `rigs/<role>.json`). `studio <Id> costume-look` builds a tagged lineup (`Workspace._CostumeLineup`, R15 and R6 side
   by side), send it, `screen_capture` from the positions it returns, compare with the reference pictures, fix the
   spec, repeat. `costume-look-off` removes it, and `studio <Id> remove` deletes it too.
5. **Rigs.** A humanoid costume's rig is captured from the costume itself (`studio <Id> rig --role <role>`, then
   `rig <Id> <role>`): the film set acts on the body that will play. A creature's rig comes from step 4.
6. **Acting.** A humanoid costume acts like any R15 role (`plant`, then `ak.ground(p, RIG)` onto its own floor). A
   creature keys its own joints: `+x` lifts a part's front, `+y` turns it to its left, a left wing rises with `-z`; the
   first joint takes `px, py, pz`. An NPC in a humanoid costume gets a derived R6 clip; a creature has one rig (its
   Humanoid with RequiresNeck off, measured to animate and not die on a Client) and plays in both casts.
7. **Install** builds every costume in Studio (`installed ...: costumes <n>`), in the module's `Costumes` folder as
   `<role>_R15` / `<role>_R6` models. Catalog items load from Roblox when the costume is built, in Edit. The build
   itself never fails on a bad id: a wrong id just builds without that item (and Output logs the failed asset), and a
   bad Shirt or Pants id still makes a Shirt/Pants with Roblox's fallback template. So `Costume.verify` asks the catalog
   (`GetProductInfo`) once per id per install and retries an unanswered call 3 times with backoff. It leaves an item
   off only on a definite answer (wrong type, 404/400, invalid id) and names it after `COSTUME:` in the install line.
   When an item can't be checked at all, it refuses the whole install ("retry the install"): never a half-dressed
   costume. Fix a named item's id in the spec and install again.
8. **Gates:** `gates` checks the costumes; record both casts; `likeness <Id>`; the blind score adds C7 "Character
   likeness" (weight 2, costume scenes only). Credit every reference in `notes.md`.

**Under the hood (so a surprise is explicable).** Accessories are applied with `SetAccessories(list, false)`
(`true` wipes the earlier slots). A prop that a character holds (a creature's or prop's `Handle`) gets an Attachment
named like the body attachment, because a plain weld does not follow the animated body (the Humanoid re-welds it to
the Head). The costume is a local copy in the scene's folder; the Director swaps the cast's copies for the costume copy
matching the player's rig (else the other one; a missing model warns and the role plays as it is).

**Replay `always` has a silent 15 s cooldown.** On a live server a scene set to replay `always` won't start again for
15 s after its start (or its whole run, if the scene is longer than that), however the player triggers it (zone re-entry or prompt); there is
no message. Studio Play is exempt, so a test never sees it. Tell a viewer who asks why a prompt "does nothing".

**An intro on every join** (a story scene with an `api` trigger anchored where the player should end up, `Replay`
`always`): the example server script `roblox/examples/IntroOnJoin.server.luau` (set its `SCENE`, put it in
ServerScriptService) plays it when each player's first character spawns on a server, never on a respawn; it never
throws and does nothing when the scene isn't installed (`kit/tests/test_intro_on_join.py` runs it in the real Luau).
The kit pins the player at the anchor, so put the place's SpawnLocation there too (a death then respawns them on the
same spot). Narration that runs across cuts needs its own `hold` per line in `beats.json` (otherwise each line clears
at the end of its shot). In Studio the intro starts on Play, so a test or take started right after joining overlaps it:
wait for its end first.

**Demo maps** are built with the fwjelaa make-map skill (`/fwjelaa:make-map`: its kit, checks, walk test and budget),
in a realistic or anime style, never blocky, then captured by this kit like any viewer's map. The kit never writes
Lighting; a demo set's lighting belongs to the demo set. Set lights (GateGuard's `GuardKey`, `GuardRim` and `GuardFill`
spot lights) belong in the map's own build: they are not in make-map's build file, so a rebuild of the map drops them
unless they are added there. A cast NPC moved to a new set keeps its path (`Gate/Guard`), or update `model` and `hide`.

## Awakenings (kind `awakening`)
An awakening is a move, not a story: `CutsceneKit.Awaken(player, "<Id>")` plays it where the player stands (or an NPC:
`Awaken(model, ...)`), it can't be skipped, it replays every time (30 s cooldown by default), and it leaves an
awakened state: an aura every player sees for `Config.Awakened.Duration` seconds, then a power-down
(`EndAwakening(player)` is the power-down now, or right after the cinematic if it is still playing). Everyone else
sees the animation, the VFX and a small shake; only the caster's camera is taken. The runtime is installed
(<n> modules; read n from `roblox/CutsceneKit/_index.json`, never hard-code it).

**What `Awaken` does (runtime 0.3.0).** `Awaken(subject, name, anchor?)` returns `ok, why`. A player's character Model
counts as the player; anything that isn't an Instance is answered `false, why`. The optional `anchor` teleports the
caster, so a game must never pass one the client chose. Cooldowns live in memory per subject (a rejoin resets them; the
example key bind's own gap survives a rejoin). An unskippable scene's early client `Ended` doesn't free the caster
before the scene's end. Auras: at most 4 are full (2 on touch), the rest are outline only; decor layers need quality
above 0.5. The camera guard fades the caster out in tight spots. External FwjelaaVFX effects fade on a normal end and
stop at once otherwise.

1. **Beat sheet.** From a shot script in words: `py kit/run.py script <Id> <file.md> --kind awakening --fit 10 --trigger api
   --dialogue anime`, then edit `beats.json`. From a video or panels: `new <Id> --kind awakening`, then
   `ref video|panels`, and make sure `kind` in `beats.json` says `awakening`. Keep it to 4-10 s (gate: 10.5 s). Give it
   the beats of research/03 section 1: lock-in, charge (1-1.5 s), build, the burst (one `Impact` marker on the release
   frame), aftermath, return.
2. **Markers.** `VFX` with a preset name (or a cue key), `Impact` (impact frames + white flash; the aura arrives on the
   first one), `Flash` (power 0-1), `Shake` (0-1), `Slowmo` (0.05-1; it slows the VFX and the particles in the air, not
   the clips: author slow motion into the acting). At most 2 Impact/Flash in any second (the runtime drops the third).
3. **Cues** (`beats.json` "cues"): `{"VFX:<value>": {"kind": "vfx", "preset": "Pillar", "at": [0, 0, -2], "yaw": 0,
   "follow": "player.Head", "element": "azure", "scale": 1.2}}`; `at` may be `"player.face"` / `"player.head"` (from
   the film set's framing). A preset of fwjelaa-vfx: `"external": true` (needs `ReplicatedStorage.FwjelaaVFX` in the
   game and its uploaded textures). Screen pulses: `{"kind": "screen", "effect": "grade" | "bloom" | "flash" |
   "speedlines" | "focus" | "burst" | "word" | "backdrop", ...}` (the manga ones: "Manga screen effects").
4. **Presets** (`py kit/run.py vfx` lists them with budgets): Charge, Burst, Pillar, Crater, Shockwave, Cracks, Lift,
   Wind, Lightning, Dust, Embers, Spark (follow a hand), Wisps (follow UpperTorso), EyeFlare (follow Head), PowerDown.
   Escalate a few layers; never stack two big bursts in one beat; the character stays readable. Tune a preset in
   `vfx/presets.json` (then `vfx`, `test`, `delta VfxPresets`), never in the Luau.
5. **Config** (`beats.json` "config"): `Element` (teal, violet, fire, ice, lightning, void, plasma, holy, azure,
   crimson), `Cooldown`, `Grade` (`{"Tint": "ffd2a8", "Saturation": -0.1}`: the scene's own colour, restored after),
   `Awakened` (`Duration`, `Aura` "Flame", `Look` ["eyes", "outline", "tint"], `At` if not the first Impact).
6. **Acting.** The real character plays the clip (pinned at its place by the server), so a kneel or a crouch is on the
   root joint like any cutscene. Anticipation before every rise (a dip of 4-8 frames), the stand-up snaps in 4-6, the
   burst pose holds 10-20 frames while the shockwave passes. Re-pose the R6 beats `scene` lists (kneels lose the knee).
7. **Camera.** Frame what the guides show (`vfx guides` in the build report): the pillar's top, the shockwave's reach.
   A close-up of the eyes at the ignition, a low angle at the burst, a wide for the crater. The runtime pulls the camera
   in front of walls between the caster and the lens: keep shots within about 12 studs of the caster when you can
   (the scene plays wherever the player stands).
8. **Install.** `upload`, `studio <Id> install` (trigger api: the trigger part only holds the demo spot), then the key
   bind if the viewer wants one: `studio <Id> keybind --key G`. The example key bind
   (`roblox/examples/AwakenKeyBind.*`, RemoteEvent `ReplicatedStorage.AwakenRequest`) fixes the scene name on the
   server and the client sends only "pressed"; `MIN_GAP` is 30 s, kept per UserId; `--key` takes letters (not W A S D
   I O), digits, F1-F12 (not F9 or F11) and a few named keys, and refuses movement, chat and system keys; only
   scene-level answers (`SCENE_BROKEN`) switch it off, every other answer is "not now" for that press.
9. **Play test** (`playtest-on`, then `P = require(game.ReplicatedStorage.CutsceneKitPlayTest)`): Server `P.awaken(name)`;
   Client `P.arm(t)` / `P.read()` / `P.fx()`; `P.aura()` after the burst and after `Duration`; Server `P.endAwaken()`;
   a second `P.awaken` -> `cooldown`; Server `P.awakenNpc(name)` and Client `P.onlook()` (the camera stays the
   player's); Server `P.kill()` mid-scene. Keys: `R15 R6 restore-end restore-death console aura power-down onlooker
   cooldown keybind`.

## Manga screen effects (runtime 0.4.0)
Manhwa hits are flat 2D: focus lines, a white spiky burst, sound words, a per-shot backdrop, and Impact frames (the
`Impact` marker, as before). Each is a screen cue fired by a VFX marker (`[0.42, "VFX", "Pow"]` in a shot) and keyed
`VFX:<value>` in `beats.json` "cues"; a preset's `screen` list takes the same entries. All local to the player whose
camera the scene takes, cleaned up by the Snapshot. Points (`at`, or `focus` for lines): `[x, y]` = screen 0-1 from the
top left; `[x, y, z]` = studs from the anchor; `"player.face"` / `"npc1.head"` (resolved from the film set);
`"follow": "npc1.UpperTorso"` = that cast part every frame (`at` is then an offset in its space). Textures are ours
(`vfx/manga/`, made in Blender by `make_manga.py`, ids in `textures.json`, copied into `VfxPresets.Manga`): `lines`,
`burst` (round), `burst2` (long), backdrops `whiteburst`, `inksmoke`, `plum`; any `rbxassetid://<n>` works too.
```json
"VFX:Lines": {"kind": "screen", "effect": "speedlines", "focus": [0.42, 0.55], "life": 0.6, "alpha": 1, "density": 0.8, "color": "black"},
"VFX:Hit":   {"kind": "screen", "effect": "burst", "image": "burst", "follow": "player.RightHand", "size": 0.5, "life": 0.45, "rot": -10},
"VFX:Pow":   {"kind": "screen", "effect": "word", "text": "POW!!", "at": [0.28, 0.2], "size": 0.22, "rot": -12, "life": 1.0, "fill": "black", "stroke": 0},
"VFX:Bg":    {"kind": "screen", "effect": "backdrop", "image": "whiteburst", "life": 1.6}
```
- **speedlines**: four rotated quadrant cells round the focus, a new cell each 1/12 s (on twos); `density` 0.5 and up
  doubles the lines; `alpha` is the opacity; old `life`/`alpha` cues still work. Off under Reduced Motion.
- **burst**: `size` in screen heights (default 0.45), scales in over ~2 frames, flickers between its two cells, fades
  over the last 35 %. A burst of 0.6 or more counts as a flash (the 2-a-second rule; off under Reduced Motion).
- **word**: a TextLabel (never an image: moderation rejects text-like images) in Bangers (`font`: LuckiestGuy,
  FredokaOne, PermanentMarker, Creepster, DenkOne), `fill` white/black/#rrggbb, `stroke` 0-0.07 of the text size
  (default 0.06; the edge takes the opposite shade), punched in by a UIScale 1.6 -> 1 over 0.05 s, a tiny shake on twos,
  out over 0.15 s. `size` in screen heights (default 0.16), 1-16 characters.
- **backdrop**: a camera-locked card with an unlit SurfaceGui (`image`, `color` tints it, or a flat `color` alone),
  at `dist` studs (default 30) but always 3 studs behind the farthest cast member, so it never covers one; sized to the
  view. The newest one started shows. The set between the cast and the card still shows (floor tiles, walls close
  behind), so put backdrops on shots where the set behind the cast is open.
- **CastLight** (`config`, off by default): `"CastLight": {"Color": "ffffff", "Brightness": 1.5, "Range": 10}` (or
  `true`) puts a neutral PointLight on each cast member, 3 studs from its head toward the camera, so a white tee stays
  white in a red-lit set (never tint the view red with a grade: it kills the white).
- Budgets: at most 6 manga layers (lines, bursts, words) at once; the runtime drops the rest and `gates` names it.

## Files
| File | What |
|---|---|
| `beats.json` | the beat sheet (kit/beats.py has the format); `beats.draft.json` is a newer draft from `ref` |
| `notes.md` | decisions, measured numbers, review rounds |
| `ref/` | the reference: `clip.mp4`, `contact.png`, `shot_NN.png`, `timing.md`/`.json`, or `panels.png`, `panel_NN.png` |
| `map.json` | stand-ins: boxes `[x, y, z, sx, sy, sz, rx, ry, rz, rgb]` from the anchor (rotation = `CFrame.fromOrientation`), terrain cells |
| `rigs/<role>.json` | captured rig with `stand` (where Roblox stands the root) and `foot` |
| `cast/<role>.json` | a role's costume, for a character the scene adapts (`kit/costume.py` has the format) |
| `anim/*.py` | the acting (`<role>.py`, `player_R6.py`) and the camera (`camera.py`): the source of the film set |
| `export/` | clips (`.json` + `.rbxmx`), `scene.json`, `framing.json`, `<Id>.luau`, `manifest.json`, `ids.json`, `gates.json` |
| `studio/` | rendered Studio steps (`<step>.luau`, `<step>.2.luau` ... when over 60 KB, `install.<k>.luau`) and the strings Studio returned (`map_<n>.txt`, `rig_<role>.txt`) |
| `preview/` | `raw.mp4`, `raw_R6.mp4`, `<Id>.mp4`, `<Id>_R6.mp4`, `frames/`, `sheet.png`, `side_by_side_<n>.png`, `side_by_side_R6_<n>.png`, `sheet_R6.png`, `likeness.png` |
| `examples/GateGuard/` (in PACK) | the demo's data only: `beats.json`, `anim/*.py`, `GateGuard.luau`, `notes.md` (no media) |
| `review/` | `playtest.json`; `results/round<N>/` with the packet record, replies and `scores.json` |
| `<Id>.blend` | the film set, rebuilt from the files |
| `<work>/blind/<Id>-p<n>/` | the blind packets (nothing else goes in them) |

## Gotchas (measured)
- **Studio's MCP blocks HttpService to localhost.** Everything goes in as self-contained Luau (`bundle`, `studio`).
  This also stops make-map's `serve` and `install.luau`: for a set built with make-map, send its kit as self-contained
  Luau too.
- **Everything sent to or returned from Studio passes through you.** One call carries at most 60 KB: a Studio step
  over that is written as parts; send `<step>.luau`, `<step>.2.luau`, ... in order, and the last part runs it. Map
  chunks at 12,000 characters (spike S7: three such chunks copied with no wrong character), and install uploaded
  scenes by asset id (usually one part) rather than with embedded clips (ordered parts). Every Capture step (anchor,
  map, rig per role) is about 18 KB because each embeds the whole Capture module: a two-role scene sends about 90 KB
  before the install, and the runtime install is about 70 KB more.
- **Copy returned chunks exactly.** `map` checks each chunk's Adler-32 and names the one to fetch again.
- **An unfocused Studio stops rendering, and Play renders nothing until the game view is clicked.** Keep it in front
  during Play; `record` brings it forward and clicks the viewport itself (spike S9: before a click Studio rendered
  0 frames in 2 s, after it 115), then parks the cursor on the title bar, and stops and deletes the take if another
  window comes up.
- **An `execute_luau` call that spans a scene can see the camera type reset by the MCP wrapper**: it re-applies the
  camera type it saw at the start of the call. Arm probes, then read them in a later call; a check that starts
  mid-scene can read `Scriptable` falsely, so run it once more from a clean state before calling it a bug. It can also
  leave the player's camera really `Scriptable` (a skip fired from a call that spans the scene start): schedule the
  skip from a call that returns first, and unstick with a deferred `task.delay` (step 10).
- **A `saved` scene needs `Api:Invoke("Forget", player, id)` before each test re-run** (Studio's DataStore keeps the
  history across Play sessions). The place must also be saved by the person (File > Save); the Studio MCP can't save
  it, so everything installed lives only as long as that Studio session until they do.
- **Start scenes in Play through `ReplicatedStorage.CutsceneKit.Api:Invoke(...)`**: `require(...).Play` from
  `execute_luau` gets a separate module instance.
- **`require()` caches by instance.** Every installer and step makes fresh ModuleScripts; never re-require an edited
  one. A replaced ModuleScript needs a new instance, and every module that required it must be re-created too: re-send
  `out/install.luau` rather than patch one module.
- **This Studio build's Play client has no PlayerModule**, so the controls path is only unit-tested here.
- **R15 avatars use AnimationConstraints** (since May 2026: the default avatar has 15 and no Motor6Ds); capture reads
  their attachments; the clips behave the same.
- **Markers fire from the data module's list by time**, not from the clips' KeyframeMarkers (late joins and seeks work).
- **A clip with one key looks unloaded** (Length 0): every exported clip has keys at 0 and at the end; `scene` checks.
- **Clip checks block the data module.** Mark deliberate smears the make-anim way (a Hit/Impact marker, or a constant
  hold); never ship around a check.
- **A world NPC the cast replaces shows twice** unless `cast.<role>.hide` names it (it becomes `Config.Hide`). Hide
  covers its parts, decals and the Humanoid's name and health display, nothing else (BillboardGuis, particles and
  lights stay).
- **Prompt presses are checked on the server**: a live character, within the prompt's distance (plus 4 studs), the
  scene's own prompt, and the prompt Enabled. A prompt for a scene the player has seen stays visible and does nothing:
  give prompt scenes `"Replay": "always"`, or disable the prompt after the first play.
- **A ProximityPrompt pressed from `execute_luau`:** `InputHoldBegin` / `InputHoldEnd` in a Client call works: the
  scene starts at once (`CutsceneLock` set) and ends with `CutsceneLastResult = end`; the server handler
  (`Server.onPrompt`) was also tested directly, and a press from 50 studs away is refused.
- **Uploaded assets can't be replaced**: `ids.json` remembers each clip's hash, so only changed clips upload.
- **Kit tests.** `py kit/run.py test` is the Python suite (every test must be OK); `py kit/run.py luau` parses every
  `.luau` file with the real Luau; the Luau suites also run inside Studio from the dev bundles (15 suites, 151 cases
  when Plan 2 Task 23 ran; the figure grows with each new suite).
- **`GuiService:GetSafeZoneOffsets` is RobloxScript-only.** `Subtitles` measures the bottom inset with a pair of probe
  ScreenGuis (`ScreenInsets` None and DeviceSafeInsets); proven on desktop (0), not on a phone.
- **Test helpers that swap module seams must save the real ones once.** Deferred restores run in order, so a second
  swap in one case restores a fake.
- **Blender 5 has no `Action.fcurves`**: make-anim's `animkit.all_fcurves` reads the channelbags.
- **`kit/` module names must not collide with make-anim's** (both folders are on `sys.path` in Blender).
- **FOV is vertical in Roblox**: the film set's camera uses sensor fit VERTICAL, 24 mm, so lens and FOV convert exactly.
  For the same reason the preview's centred 16:9 crop of a wider game view is exactly what a 16:9 screen shows.
- **The default avatar stands its root at 3.192 studs** (HipHeight 2.192 + half the root's 2-stud height; head top
  5.458; spike S10), not make-anim's 3.0; captured rigs carry it, so re-ground `_r15` poses with `ak.ground(pose, RIG)`.
- **Studio window recording:** FFmpeg ddagrab of the window's DWM frame rect, clamped to the primary monitor (spike S9:
  57.8 fps on a 1920x1032 window, padded to 60 fps with about 23 % duplicate frames, so judder in a preview is not a
  defect; gfxcapture reached 38 fps and gdigrab 46). The overlay's two-pulse END flash, 0.25 s after the scene's last
  frame, gives the sync: one scene per take. The game view is the flash's box, cropped to its centred 16:9.
- **The record overlay only runs in Studio with `ReplicatedStorage.CutsceneKitRecord` set**; `record-off` and `remove`
  delete it.
- **The blind score is tied to the build.** Kit checks, play test and preview must carry the current export's hash, or
  `review` and `score` refuse them; a failed hard gate caps a score at 5.0. Replies are read as 0-2 per criterion (a
  reply in n/2 or n/10 is scaled and noted).

- **A costume is a local copy.** The Director swaps the cast's copies for costume copies of the player's rig; the
  real character is never changed, so an end, a skip, a death or an error needs nothing extra.
- **Catalog items load from Roblox when the costume is built** (in Edit, at install): a wrong id builds without it,
  and the install line names an item that didn't arrive.
- **Every scene is recorded twice**: `P.setRig("R15")` before the first Play, `P.setRig("R6")` before the second;
  `record` and `preview` take `--rig R6`.
- **A creature has one rig for both casts** (its Humanoid with RequiresNeck off).
- **Awakenings play where the player stands**, a spot no kit check saw: the runtime pulls the camera in front of walls;
  test one awakening next to a wall.
- **An NPC caster plays only uploaded clips** (the server plays them); Studio-only clips play only on a player's client.
- **Slowmo slows VFX, not clips.** Put slow motion into the acting's timing.
- **Impact frames need a sky dome** (`Screen.SKY_DOME` = true; `Screen.IMPACT_A` = Brightness -1, Saturation -1, white
  fill; `Screen.IMPACT_B` = Brightness 1, Saturation -1, black fill; default until spike S12 measures); only one
  Highlight per object shows, so the aura outline steps aside for the two frames.
- **VFX use engine textures only**: glow forcefield_glow_main, spark fire_sparks_main, sparkle sparkles_main, smoke
  smoke_main, flame fire_main, core explosion01_core_main, shock explosion01_shockwave_main, dust
  explosion01_smoke_main, square SquareParticle.png, all under `rbxasset://textures/particles/` as in
  `vfx/presets.json` (default until spike S11 measures); no uploads, nothing to license. The manga screen effects use
  our own uploaded textures (`vfx/manga/textures.json`); a new upload needs about a minute before it shows.
- **The live-particle budget is 900 on a PC, 360 on touch** (`Vfx.MAX_LIVE`; default until spike S14 measures), and
  `gates` checks a scene against `cues.PEAK` = 1500 particles alive at once (default until spike S14 measures).
- **Every bundle over 60 KB goes in parts**: send them in order; a stale part is refused by name.
- **While iterating, send deltas** (`delta <Module> --tests <Suite>`), and the canonical bundles at milestones.

## Safety
- The Open Cloud key is only ever read by `paths.load_key()` and sent to Roblox; never print, echo or paste it.
- Only upload when the viewer asked for a playable scene (or said go to everything).
- The map is only read; the only things the kit adds to a place are the trigger, the data module and its cast, and the
  dev helpers it removes again (`playtest-off`, `record-off`, `remove`).
- Recording borrows the screen: only run `record` when the viewer is off the PC or said go.
