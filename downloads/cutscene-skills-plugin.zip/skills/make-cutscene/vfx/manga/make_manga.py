"""Manga screen-effect textures for CutsceneKit.Screen: focus lines, impact bursts and three panel backdrops, drawn as
flat ink shapes (no blur) in Blender, rendered orthographic to sRGB PNGs. Original work, method by fwjelaa
(FWJ STUDIOS); shippable with the kit.

In Blender (makes the scene MangaVFX, renders, writes manga.blend; the other scenes are not touched):
    import sys; sys.path.insert(0, r"<PACK>/vfx/manga"); import make_manga; print(make_manga.build())
Then, in a normal Python with Pillow, from PACK:
    py vfx/manga/make_manga.py sheets      the 2x2 flipbooks (focus_lines.png, impact_burst.png) from the cells
    py vfx/manga/make_manga.py contact     contact.png: every texture on grey, white and black

Layout (textures.json has the ids): focus_lines.png = 4 quadrant cells (512 px; the focus is each cell's top-left
corner, lines run out to the bottom-right; 16 px clear margin on the right and bottom), shown as four rotated copies
around the focus, each picking a cell on twos. impact_burst.png = cells 0-1 shape A (round), 2-3 shape B (long), two
jitter frames each. whiteburst.png, inksmoke.png, plum.png = 1024 opaque backdrops.
"""
import math
import random
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
CELLS = HERE / "_cells"
CELL, MARGIN = 512, 16


def lin(hexs):
    """#rrggbb (sRGB) -> linear RGBA for an Emission colour (the Standard view transform gives the hex back)."""
    out = []
    for i in (1, 3, 5):
        c = int(hexs[i:i + 2], 16) / 255
        out.append(c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4)
    return (*out, 1.0)


class Canvas:
    """Polygons in pixel coordinates (top-left origin, y down) of a w x h image, gathered by colour and layer."""

    def __init__(self, name, w, h, ox):
        self.name, self.w, self.h, self.ox = name, w, h, ox
        self.groups = {}

    def poly(self, pts, color, layer=0):
        self.groups.setdefault((color, layer), []).append(pts)

    def circle(self, x, y, r, color, layer=0, n=10):
        self.poly([(x + r * math.cos(2 * math.pi * k / n), y + r * math.sin(2 * math.pi * k / n)) for k in range(n)],
                  color, layer)

    def wedge(self, cx, cy, a, r_in, r_out, w, color, layer=0):
        """A tapered ink line pointing at (cx, cy): its tip at r_in, w px wide at r_out."""
        ca, sa = math.cos(a), math.sin(a)
        self.poly([(cx + r_in * ca, cy + r_in * sa), (cx + r_out * ca - w / 2 * sa, cy + r_out * sa + w / 2 * ca),
                   (cx + r_out * ca + w / 2 * sa, cy + r_out * sa - w / 2 * ca)], color, layer)

    def build(self, bpy, coll, mats):
        for (color, layer), polys in self.groups.items():
            verts, faces = [], []
            for pts in polys:
                faces.append(list(range(len(verts), len(verts) + len(pts))))
                verts += [(self.ox + x - self.w / 2, self.h / 2 - y, layer * 0.5) for x, y in pts]
            me = bpy.data.meshes.new(f"MV_{self.name}_{color[1:]}_{layer}")
            me.from_pydata(verts, [], faces)
            me.materials.append(mats(color))
            ob = bpy.data.objects.new(me.name, me)
            coll.objects.link(ob)


# ---------------------------------------------------------------- the drawings

def focus_cell(seed):
    """One quadrant of manga focus lines: the focus at the top-left corner, lines thick at the far edge, tapering in,
    a clear centre; nothing within half a degree of the quadrant's edges (the copies meet there)."""
    size = CELL - MARGIN
    cv = Canvas(f"lines{seed}", size, size, 0)
    rnd = random.Random(1000 + seed)
    edge = math.radians(0.5)
    for _ in range(64):  # clusters of 1-4 lines, the manga way
        base = rnd.uniform(edge, math.pi / 2 - edge)
        for _ in range(rnd.choice((1, 1, 1, 2, 2, 3, 4))):
            a = base + math.radians(rnd.gauss(0, 0.7))
            if not edge <= a <= math.pi / 2 - edge:
                continue
            kind = rnd.random()
            w = rnd.uniform(1.0, 2.4) if kind < 0.6 else rnd.uniform(2.6, 4.6) if kind < 0.9 else rnd.uniform(5, 8)
            r_in = CELL * rnd.triangular(0.17, 0.9, 0.45)
            cv.wedge(0, 0, a, r_in, 740, w, "#ffffff")
    return cv


def burst_cell(shape, frame):
    """A white spiky impact burst with a rough black ink edge, ink hatching in its valleys and flying shards.
    shape "A" is round, "B" long (along x); frame 1 re-seeds the details for a jitter on twos."""
    size = CELL - 2 * MARGIN
    c = size / 2
    cv = Canvas(f"burst{shape}{frame}", size, size, 0)
    rnd = random.Random(2000 + (0 if shape == "A" else 100))  # the silhouette: the same in both frames
    jit = random.Random(3000 + (0 if shape == "A" else 100) + frame)  # the details: new each frame
    n = 34 if shape == "A" else 38
    rmax = c - 8
    sx, sy = (1.0, 1.0) if shape == "A" else (1.0, 0.52)
    pts_w, pts_k = [], []
    for k in range(2 * n):
        a = 2 * math.pi * k / (2 * n) + rnd.uniform(-0.035, 0.035)
        if k % 2 == 0:
            pick = rnd.random()
            r = rmax * (rnd.uniform(0.84, 0.98) if pick < 0.3 else rnd.uniform(0.6, 0.8) if pick < 0.8
                        else rnd.uniform(0.44, 0.55)) * jit.uniform(0.93, 1.0)
            if shape == "B":
                r *= 0.72 + 0.28 * abs(math.cos(a)) ** 0.5
        else:
            r = rmax * rnd.uniform(0.27, 0.4)
        ex, ey = math.cos(a) * sx, math.sin(a) * sy
        pts_w.append((c + r * ex, c + r * ey))
        grow = jit.uniform(13, 22) if k % 2 == 0 else jit.uniform(7, 10)
        pts_k.append((c + (r + grow) * ex, c + (r + grow) * ey))
    cv.poly(pts_k, "#000000", 0)
    cv.poly(pts_w, "#ffffff", 1)
    for _ in range(34):  # ink streaks thrown out of the impact, thick at the body, tapering outward
        a = jit.uniform(0, 2 * math.pi)
        ex, ey = math.cos(a) * sx, math.sin(a) * sy
        k = math.hypot(ex, ey)
        r0, r1 = rmax * jit.uniform(0.42, 0.62) * k, rmax * jit.uniform(0.88, 1.0) * k
        w = jit.uniform(3, 8)
        ca, sa = ex / k, ey / k
        cv.poly([(c + r1 * ca, c + r1 * sa), (c + r0 * ca - w / 2 * sa, c + r0 * sa + w / 2 * ca),
                 (c + r0 * ca + w / 2 * sa, c + r0 * sa - w / 2 * ca)], "#000000", 0)
    for k in range(1, 2 * n, 2):  # hatching in from each valley
        x, y = pts_w[k]
        dx, dy = x - c, y - c
        d = math.hypot(dx, dy)
        for _ in range(jit.choice((1, 2, 2))):
            a = math.atan2(dy, dx) + jit.uniform(-0.06, 0.06)
            cv.wedge(c, c, a, d * jit.uniform(0.5, 0.78), d + 2, jit.uniform(2, 4), "#000000", 2)
    for _ in range(14):  # shards flying out
        a = jit.uniform(0, 2 * math.pi)
        r = rmax * jit.uniform(0.86, 0.98)
        x, y = c + r * math.cos(a) * sx, c + r * math.sin(a) * sy
        ln, wd = jit.uniform(10, 22), jit.uniform(3, 6)
        ca, sa = math.cos(a), math.sin(a)
        cv.poly([(x + ln * ca, y + ln * sa), (x - wd * sa, y + wd * ca), (x - ln * 0.4 * ca, y - ln * 0.4 * sa),
                 (x + wd * sa, y - wd * ca)], "#000000", 3)
    return cv


def whiteburst():
    """Panel 8's background: white paper, fine radial ink streaks from the edge toward a clear centre, debris."""
    s = 1024
    cv = Canvas("whiteburst", s, s, 3000)
    cv.poly([(-20, -20), (s + 20, -20), (s + 20, s + 20), (-20, s + 20)], "#ffffff", 0)
    rnd = random.Random(4000)
    for _ in range(420):
        a = rnd.uniform(0, 2 * math.pi)
        grey = rnd.random() < 0.35
        w = rnd.uniform(0.8, 2.2) if grey or rnd.random() < 0.7 else rnd.uniform(2.5, 5.5)
        cv.wedge(s / 2, s / 2, a, s / 2 * rnd.triangular(0.36, 1.1, 0.7), 760, w, "#a8a8a8" if grey else "#111111",
                 1 if grey else 2)
    for _ in range(70):  # specks and chips of debris
        a, r = rnd.uniform(0, 2 * math.pi), s / 2 * rnd.uniform(0.28, 0.95)
        x, y = s / 2 + r * math.cos(a), s / 2 + r * math.sin(a)
        if rnd.random() < 0.6:
            cv.circle(x, y, rnd.uniform(1.2, 3.2), "#111111", 3, 7)
        else:
            ln, ca, sa = rnd.uniform(5, 12), math.cos(a), math.sin(a)
            cv.poly([(x + ln * ca, y + ln * sa), (x - 2 * sa, y + 2 * ca), (x - ln * ca, y - ln * sa)], "#111111", 3)
    return cv


def inksmoke():
    """Panel 6's background: black with ragged dark-red ink tongues rising from the bottom, black ink over them."""
    s = 1024
    cv = Canvas("inksmoke", s, s, 6000)
    cv.poly([(-20, -20), (s + 20, -20), (s + 20, s + 20), (-20, s + 20)], "#050102", 0)
    rnd = random.Random(5000)
    reds = ("#1e0205", "#2f0407", "#45060a", "#5e090d", "#7a0d10")

    def tongue(x0, top, base_w, color, layer, bottom=None):
        steps = 30
        bottom = s + 40 if bottom is None else bottom
        bend, freq, ph = rnd.uniform(-90, 90), rnd.uniform(1.5, 3.5), rnd.uniform(0, 6.3)
        left, right = [], []
        for i in range(steps + 1):
            f = i / steps  # 0 at the bottom, 1 at the tip
            y = bottom - (bottom - top) * f
            cx = x0 + bend * f * f + 22 * math.sin(ph + freq * f * 3.1)
            hw = base_w / 2 * (1 - f) ** 0.6 * (1 + 0.3 * math.sin(ph * 2 + f * 11))
            left.append((cx - hw - rnd.uniform(0, 5), y))
            right.append((cx + hw + rnd.uniform(0, 5), y))
        cv.poly(left + right[::-1], color, layer)

    for i in range(70):  # smoky red tongues rising from the bottom, the darker ones taller
        k = rnd.randrange(len(reds))
        tongue(rnd.uniform(-40, s + 40), rnd.uniform(-80, 380) + 90 * k, rnd.uniform(30, 120), reds[k], 1 + k)
    for _ in range(26):  # dark smoke hanging from the top
        tongue(rnd.uniform(-40, s + 40), rnd.uniform(300, 620), rnd.uniform(40, 110), rnd.choice(reds[:2]), 6,
               bottom=-40)
    for _ in range(30):  # black ink licking down over them
        x0, w = rnd.uniform(-40, s + 40), rnd.uniform(20, 90)
        top = rnd.uniform(-60, 200)
        bot = top + rnd.uniform(250, 700)
        pts = [(x0 - w / 2, top), (x0 + w / 2, top)]
        for i in range(1, 13):
            f = i / 12
            pts.append((x0 + w / 2 * (1 - f) + rnd.uniform(-6, 6) + 25 * math.sin(f * 4), top + (bot - top) * f))
        pts.append((x0 + rnd.uniform(-8, 8), bot + 30))
        for i in range(11, 0, -1):
            f = i / 12
            pts.append((x0 - w / 2 * (1 - f) + rnd.uniform(-6, 6) + 25 * math.sin(f * 4), top + (bot - top) * f))
        cv.poly(pts, "#050102", 7)
    for _ in range(18):  # a few thin brighter streaks
        tongue(rnd.uniform(0, s), rnd.uniform(250, 760), rnd.uniform(3, 7), rnd.choice(("#9c1216", "#b5181b")), 8)
    return cv


def plum():
    """Panels 1, 3, 4: dark plum, lighter in the middle, with tiny pink and lilac specks and a few 4-point glints.
    The glow is stepped rings (flat ink tones), not a blur."""
    s = 1024
    cv = Canvas("plum", s, s, 9000)
    tones = ("#120509", "#19070d", "#200912", "#290c17", "#330f1d", "#3d1323")
    cv.poly([(-20, -20), (s + 20, -20), (s + 20, s + 20), (-20, s + 20)], tones[0], 0)
    rnd = random.Random(6000)
    for i, tone in enumerate(tones[1:], 1):
        r = s * 0.75 * (1 - i / len(tones)) + 60
        pts = []
        for k in range(48):
            a = 2 * math.pi * k / 48
            rr = r * (1 + rnd.uniform(-0.07, 0.07))
            pts.append((s * 0.52 + rr * math.cos(a) * 1.15, s * 0.45 + rr * math.sin(a)))
        cv.poly(pts, tone, i)
    colors = ("#ff9fd2", "#e58ac0", "#c9a2ff", "#ffffff", "#ff6fae")
    for _ in range(420):
        x, y = rnd.uniform(0, s), rnd.uniform(0, s)
        r = rnd.choice((0.9, 1.1, 1.3, 1.6, 2.0, 2.6))
        cv.circle(x, y, r, rnd.choice(colors) if r > 1.2 else "#b0628c", 10, 6)
    for _ in range(14):
        x, y, r = rnd.uniform(0, s), rnd.uniform(0, s), rnd.uniform(5, 13)
        t = r * 0.18
        col = rnd.choice(("#ffd6ec", "#ffffff"))
        cv.poly([(x, y - r), (x + t, y), (x, y + r), (x - t, y)], col, 11)
        cv.poly([(x - r, y), (x, y - t), (x + r, y), (x, y + t)], col, 11)
    return cv


# ---------------------------------------------------------------- Blender

def build(out=None):
    import bpy
    out = Path(out or HERE)
    CELLS.mkdir(parents=True, exist_ok=True)
    old = bpy.data.scenes.get("MangaVFX")
    if old:
        for ob in list(old.objects):
            bpy.data.objects.remove(ob)
        bpy.data.scenes.remove(old)
    sc = bpy.data.scenes.new("MangaVFX")
    try:
        sc.render.engine = "BLENDER_EEVEE"
    except TypeError as e:
        raise SystemExit(f"no EEVEE: {e}")
    sc.render.film_transparent = True
    sc.render.filter_size = 0.9
    sc.render.image_settings.file_format = "PNG"
    sc.render.image_settings.color_mode = "RGBA"
    sc.render.image_settings.color_depth = "8"
    sc.view_settings.view_transform = "Standard"
    sc.view_settings.look = "None"
    sc.view_settings.exposure, sc.view_settings.gamma = 0, 1
    sc.render.resolution_percentage = 100
    try:
        sc.eevee.taa_render_samples = 32
    except AttributeError:
        pass
    cache = {}

    def mats(color):
        if color not in cache:
            m = bpy.data.materials.new(f"MV_{color[1:]}")
            m.use_nodes = True
            nt = m.node_tree
            for n in list(nt.nodes):
                nt.nodes.remove(n)
            em = nt.nodes.new("ShaderNodeEmission")
            em.inputs[0].default_value = lin(color)
            em.inputs[1].default_value = 1.0
            o = nt.nodes.new("ShaderNodeOutputMaterial")
            nt.links.new(em.outputs[0], o.inputs[0])
            cache[color] = m
        return cache[color]

    cam_data = bpy.data.cameras.new("MV_Camera")
    cam_data.type = "ORTHO"
    cam_data.clip_start, cam_data.clip_end = 0.1, 200
    cam = bpy.data.objects.new("MV_Camera", cam_data)
    sc.collection.objects.link(cam)
    sc.camera = cam
    jobs = []
    for q in range(4):
        cv = focus_cell(q)
        cv.ox = q * 3000 - 40000
        jobs.append((cv, CELLS / f"lines_{q}.png"))
    for i, (shape, frame) in enumerate((("A", 0), ("A", 1), ("B", 0), ("B", 1))):
        cv = burst_cell(shape, frame)
        cv.ox = i * 3000 - 20000
        jobs.append((cv, CELLS / f"burst_{i}.png"))
    for cv in (whiteburst(), inksmoke(), plum()):
        jobs.append((cv, out / f"{cv.name}.png"))
    colls = []
    for cv, _ in jobs:
        coll = bpy.data.collections.new(f"MV_{cv.name}")
        sc.collection.children.link(coll)
        cv.build(bpy, coll, mats)
        colls.append(coll)
    win = bpy.context.window
    before = win.scene
    win.scene = sc
    done = []
    try:
        for (cv, path), coll in zip(jobs, colls):
            for other in colls:
                other.hide_render = other is not coll
            sc.render.resolution_x, sc.render.resolution_y = cv.w, cv.h
            cam_data.ortho_scale = max(cv.w, cv.h)
            cam.location = (cv.ox, 0, 50)
            sc.render.filepath = str(path)
            bpy.ops.render.render(write_still=True)
            done.append(path.name)
    finally:
        win.scene = before
    for coll in colls:
        coll.hide_render = False
    blend = out / "manga.blend"
    bpy.data.libraries.write(str(blend), {sc}, fake_user=True, compress=True)
    return f"rendered {len(done)}: {', '.join(done)}; wrote {blend.name}"


# ---------------------------------------------------------------- sheets and the contact sheet (Pillow)

def sheets():
    from PIL import Image
    for name, prefix, offset in (("focus_lines.png", "lines", (0, 0)), ("impact_burst.png", "burst", (MARGIN, MARGIN))):
        sheet = Image.new("RGBA", (2 * CELL, 2 * CELL), (0, 0, 0, 0))
        for i in range(4):
            cell = Image.open(CELLS / f"{prefix}_{i}.png").convert("RGBA")
            sheet.paste(cell, ((i % 2) * CELL + offset[0], (i // 2) * CELL + offset[1]))
        sheet.save(HERE / name)
    return "wrote focus_lines.png, impact_burst.png"


def contact():
    from PIL import Image, ImageDraw
    tiles = []

    def on(img, bg, tint=None):
        im = img.convert("RGBA").resize((340, 340), Image.LANCZOS)
        if tint:
            im = Image.merge("RGBA", (*[Image.new("L", im.size, v) for v in tint], im.getchannel("A")))
        base = Image.new("RGBA", im.size, bg)
        base.alpha_composite(im)
        return base

    lines, burst = Image.open(HERE / "focus_lines.png"), Image.open(HERE / "impact_burst.png")
    tiles += [("lines on grey", on(lines, (110, 110, 110, 255))),
              ("lines black on white", on(lines, (255, 255, 255, 255), (0, 0, 0))),
              ("burst on grey", on(burst, (110, 110, 110, 255))), ("burst on white", on(burst, (255, 255, 255, 255)))]
    tiles += [(n, on(Image.open(HERE / f"{n}.png"), (0, 0, 0, 255))) for n in ("whiteburst", "inksmoke", "plum")]
    # the runtime's layout: four rotated quadrant cells around the focus, black, on a 16:9 white screen
    w, h, fx, fy = 640, 360, 384, 170
    side = int(1.04 * max(math.hypot(x - fx, y - fy) for x in (0, w) for y in (0, h)))
    screen = Image.new("RGBA", (w, h), (255, 255, 255, 255))
    rnd = random.Random(7)
    for rot, (dx, dy) in ((0, (0, 0)), (90, (-1, 0)), (180, (-1, -1)), (270, (0, -1))):
        q = rnd.randrange(4)
        cell = lines.crop(((q % 2) * CELL, (q // 2) * CELL, (q % 2 + 1) * CELL, (q // 2 + 1) * CELL)).resize((side, side))
        cell = cell.rotate(-rot, expand=True)
        black = Image.merge("RGBA", (*[Image.new("L", cell.size, 0)] * 3, cell.getchannel("A")))
        screen.paste(black, (fx + dx * side, fy + dy * side), black)
    tiles.append(("lines on screen (runtime layout)", screen.resize((340, 191))))
    sheet = Image.new("RGB", (4 * 350, 2 * 370), (40, 40, 40))
    d = ImageDraw.Draw(sheet)
    for i, (label, im) in enumerate(tiles):
        x, y = (i % 4) * 350 + 5, (i // 4) * 370 + 22
        sheet.paste(im.convert("RGB"), (x, y))
        d.text((x, y - 16), label, fill=(255, 255, 255))
    sheet.save(HERE / "contact.png")
    return "wrote contact.png"


if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else ""
    print(sheets() if what == "sheets" else contact() if what == "contact" else __doc__)
