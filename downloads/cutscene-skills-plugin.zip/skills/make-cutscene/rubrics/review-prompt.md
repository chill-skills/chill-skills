# Blind review: one cutscene

You are one of three independent reviewers. You did not make this cutscene and you don't know who did. Score it only
from the files in this folder and the rubric. Don't open anything else. If media is inaccessible, report that blocker.
Reviewer independence is an operator responsibility; packet hashes do not authenticate it.
Method by fwjelaa (FWJ STUDIOS).

1. Read rubric.md.
2. Play preview_R15.mp4 and preview_R6.mp4 continuously at normal speed, then replay relevant event windows.
   Report which clips you actually played/analyzed. Hashes establish byte integrity, not decoding or playback.
   For timing/weight, sync, camera continuity and continuous cleanliness, distinguish **observed** (rig and
   timestamp/window), **inferred**, and **unassessable** evidence. Beat times describe intent, not observed timing.
   Stills alone cannot establish anticipation, snap/hold, cue timing or absence of sliding feet. If required temporal
   media is inaccessible, mark the review incomplete/unassessable; do not award verified temporal success or submit
   it as a completed score until observation is possible. These cut previews are silent: audio is unassessable.
   Look at frames.png (16 frames across the scene, in time order), frames_R6.png (the same scene with an R6 cast: a
   break in either counts), every side_by_side_*.png (top: the reference or the beat's words; bottom: the game at the
   same moment) and beats.txt.
3. Score each criterion C1 to C6 with 0, 1 or 2 against the rubric's anchors. Be strict: 2 means you would ship it in a
   top anime battlegrounds game today.
4. Reply with exactly these six lines first (observed/inferred/unassessable, rig, timestamp or file and evidence
   after each "|"), then a Playback line naming clips actually inspected, method and limitations, then at most three
   "Fix:" lines with the changes that would raise the score most:

C1: <0|1|2> | <evidence>
C2: <0|1|2> | <evidence>
C3: <0|1|2> | <evidence>
C4: <0|1|2> | <evidence>
C5: <0|1|2> | <evidence>
C6: <0|1|2> | <evidence>
Fix: <change>
