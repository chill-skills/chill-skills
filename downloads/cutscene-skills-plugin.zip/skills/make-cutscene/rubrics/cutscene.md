# Rubric: in-game cutscene (make-cutscene)

Method by fwjelaa (FWJ STUDIOS). Spec section 8, gate 4: three independent reviewers score from the packet only; the
median of their three scores must be 8.5 or more. Scored like the fwjelaa quality-score skill: each criterion 0, 1 or
2 against the anchors; score = 10 x sum(weight x points / 2) / sum(weight), rounded to 0.1.

## Hard gates (technical eligibility, not craft points)
The legacy scoring cap on a failed hard gate remains 5.0. Independently report every failed or missing required gate as a release blocker: a score cannot waive it. Operator-entered playtest results are not automated execution evidence.
- G1 Kit checks clear (export/gates.json): camera never inside a stand-in, subject centre-safe, no unplanned camera
  jumps, markers and cues in sync, flash rate, budgets, make-anim's animation checks, R6 bends handled.
- G2 Studio play test passed as R15 and as R6, with restore verified after a normal end, a skip and a death, and no
  console errors (review/playtest.json). An awakening can't be skipped; instead it also passes its aura and
  power-down, the onlooker's view (the camera is never taken), the cooldown and the example key bind.
- G3 Both previews were recorded in-game, one with an R15 cast and one with an R6 cast (spec 14), with their
  side-by-side sheets, and the likeness sheet when the scene adapts a character.

## Criteria (0 / 1 / 2)
| # | Criterion | W | 0 | 1 | 2 |
|---|---|---|---|---|---|
| C1 | Camera language: purposeful framing, viewpoint, movement or stillness, and motivated transitions | 3 | framing or transitions obscure essential action, intention or geography without purpose | readable but generic; some choices distract or add no useful information | framing and transitions direct attention and support meaning; motivated stillness or long takes can earn full marks |
| C2 | Timing and weight: performance fits the intended action, thought and physical support | 3 | timing obscures the intended behavior; unsupported weight or unintentional float undermines it | intent mostly reads; some decisions, holds or weight transfers feel rushed or unearned | convincing timing, support and consequence for the intended behavior; soft acting and purposeful holds can earn full marks |
| C3 | Screen layer and VFX readability: letterbox, subtitles, and impact frames and VFX when the scene has them | 2 | clutter, or text you can't read | readable but plain or a little busy | clean, readable, supports each beat |
| C4 | Sync: lines, shakes, cuts and effects land on their beats | 2 | visibly off | mostly on | every cue lands on its beat |
| C5 | Match to the reference: shot list, key poses and timing follow it (for words: every described beat happens, in order) | 2 | loses the reference | follows it loosely | clearly the same scene |
| C6 | Cleanliness: no clipping, popping, sliding feet, stray UI, broken camera or HUD | 2 | a visible break | a small blemish | clean |
| C7 | Character likeness (only when README.md asks for it: the scene adapts a character): hair, outfit colours, accessories and build read as that character, with the R15 and the R6 cast | 2 | another person | the palette is right, but key parts are missing or wrong | clearly that character in both casts |

## Evidence sufficiency
A score is a project convention, not certification of cinematic quality, accessibility, rights or safety. Keep technical blockers, evidence gaps and creative ratings separate. G1 framing and flash-event checks are limited tests, not complete accessory/derived-R6 framing or rendered-flash analysis.

Assess C2 timing/weight and C4 temporal sync from current moving takes, not sampled stills alone. If required media is missing or the reviewer cannot inspect it, report **not assessable** outside numeric scoring and obtain suitable evidence; do not substitute 0, 1 or 2 for an unknown or invent parser syntax. Zero means an observed failure, not unavailable evidence. Preserve C1–C6, conditional C7, their weights and the existing reply format for complete assessable reviews. Optional effects are not required to earn full marks; evaluate the cues actually used.

Record exact take/rig and timestamp or sampled frame for findings, including uncertainty. Do not infer all actors are R6 from an R6 player-preview label. Actual moving-take evidence must match the packet/build under review.

Still-image evidence: frames.png (16 frames across the scene in time order, labelled with the time), frames_R6.png (the same with
an R6 cast), side_by_side_*.png (the reference or the beat's words on top, the game at the same beat below; the R6_
sheets show the R6 cast), beats.txt (the beat sheet and what the reference was), and likeness.png when the scene adapts
a character (the reference character beside the game's R15 and R6 cast).
