## C7: character likeness (this scene adapts characters)

This scene dresses its cast as characters from the reference (spec 14). Also look at likeness.png: one row per
character, the reference on the left, then the game's R15 cast and R6 cast at the same moment. Score C7 too, against
the rubric's C7 row, and reply with seven lines (C1 to C7) instead of six, C7 after C6:

C7: <0|1|2> | <evidence>
