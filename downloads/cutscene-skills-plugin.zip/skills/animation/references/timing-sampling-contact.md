# Timing, interpolation, and contact references

## Authoritative sources

- [F-Curve Properties — Blender Manual](https://docs.blender.org/manual/en/latest/editors/graph_editor/fcurves/properties.html): interpolation applies between the active key and the next; automatic handle smoothing can overshoot and propagate changes. Use curve inspection rather than assuming smooth handles preserve contacts.
- [Editing Strips — Blender Manual, Bake Action](https://docs.blender.org/manual/en/latest/editors/nla/editing/strip.html#bake-action): baking evaluates final motion, with frame-step and visual-keying options; visual keying includes constraints. Baking is a sampling operation, not proof of equivalence at all times.
- [Actions — Blender Manual](https://docs.blender.org/manual/en/latest/animation/actions.html): the cyclic intent property does not itself make an action cycle; Blender's documented cyclic range includes the duplicated initial pose one loop apart. Do not impose that endpoint convention on every engine without checking its playback semantics.
- [IKControl — Roblox Creator Hub](https://create.roblox.com/docs/reference/engine/classes/IKControl): a target is a world-space goal, controls override a selected chain, SmoothTime introduces target smoothing, and Weight=0 is not equivalent to disabling a control.
- [Create character animations — Roblox Creator Hub](https://create.roblox.com/docs/tutorials/use-case-tutorials/animation/create-an-animation): rigs and pose-based animation authoring in Studio; use a rig compatible with the intended character rather than treating poses as independent world-space transforms.

## Applied workflow (recommendations, not biological limits)

1. Establish a timebase and annotate intentional events/contact intervals. Frame-offset conversion is arithmetic; action phase durations remain artistic or reference-derived choices.
2. Preserve an editable source, bake evaluated transforms only where the delivery pipeline requires it, and disable duplicate solver evaluation when checking the baked copy.
3. Compare source and destination world-space contact points at keys and between keys. Refine sampling where reconstruction diverges, and repeat after simplification/import.
4. Choose a contact frame: world for stationary ground, support-object local for moving surfaces. Measure displacement from the intended contact anchor; allow explicitly intended toe pivots or hand release.
5. Set tolerances from project scale, framing, and gameplay needs. Report them as project acceptance criteria, never universal anatomical or biomechanical constants.

The source pages document software behavior. The validation procedure above is a synthesis for production, not a claim that the vendors prescribe a universal animation sample rate or contact-error threshold. The Blender `latest` documentation and Roblox rollout behavior can change; check the installed version and live rig.
