---
name: animation
description: Animation principles, keyframing, curves and blending.
version: 1.0.0
metadata:
  hermes:
    tags: [animation, keyframes, graph-editor, state-machines]
    related_skills: [rigging, blender-rig-animate, animate-roblox-characters]
---

# 3D Animation

## Most important animation quality requirement

**Generated animations must feel loose, fluid, and highly detailed, with excellent smoothing and intentional easing—not stiff or robotic.**

Prioritize relaxed posing, flowing arcs, purposeful overlap, follow-through, and refined secondary motion. Tune acceleration, deceleration, and settling per action phase rather than applying uniform smoothing everywhere. Preserve readable impacts, deliberate holds, weight, stable contacts, and rig integrity; loose means expressive, not uncontrolled. Detail must serve the action, not add random movement or unnecessary keys. Review moving playback and in-betweens before declaring this requirement met. This is the highest artistic priority, not permission to bypass correctness or verification.

## When to Use

- Applying animation principles, keyframe spacing, Graph Editor curve work or blending/state machines.
- Any DCC or engine; platform-specific pipelines live in the Roblox and Blender skills.
- Not for: Roblox characters → `animate-roblox-characters`. Blender rig + clip authoring → `blender-rig-animate`.

## Research and platform boundaries

Research the relevant engine/editor documentation before implementation. Record which API behavior is documented and which workflow choices require testing. Platform-neutral principles do not establish support for a particular enum, rig, export format or runtime feature. For Roblox work load `fwjelaa` and the applicable R6/R15 director; for Studio-only authoring also load `roblox-native-animation-studio`. Preserve a requested native route instead of requiring Blender.

## Animation Principles

### The 12 Principles of Animation
- **Squash and Stretch**: Convey weight, flexibility, and impact
- **Anticipation**: Prepare audience for upcoming actions
- **Staging**: Present action clearly and unmistakably
- **Straight Ahead vs Pose to Pose**: Different animation workflows
- **Follow-Through and Overlapping Action**: Natural movement flow
- **Slow In and Slow Out**: Natural acceleration and deceleration
- **Arcs**: Natural curved paths of motion
- **Secondary Action**: Reinforce primary action with complementary movements
- **Timing**: Duration of an action in seconds and frames at a declared frame rate; distinguish timing from spacing (how far a pose or property changes between samples)
- **Exaggeration**: Enhance actions for clarity and appeal
- **Solid Drawing**: 3D form and weight
- **Appeal**: Engaging and memorable characters

### Additional Principles
- **Weight**: Convey mass and gravity
- **Balance**: Maintain equilibrium
- **Rhythm**: Create pleasing patterns of movement
- **Personality**: Infuse character into movement
- **Readability**: Ensure actions are clear and understandable

## Keyframe Animation Techniques

### Keyframing Workflow
- **Blocking**: Establish key poses that define the action
- **Breakdowns**: Add intermediate poses to define timing
- **In-Betweening**: Fill in frames between keys
- **Polishing**: Refine curves and add secondary motion
- **Review**: Check animation from multiple angles

### Key Types
- **Pose Keys**: Define the main poses of an action
- **Timing Keys**: Define the timing and spacing
- **Breakdown Keys**: Define the transition between poses
- **In-Between Keys**: Fill in the motion between breakdowns

### Keyframe Spacing
- **Linear**: Constant rate of change of the interpolated channel between adjacent keys; this does not guarantee constant world-space hand/foot speed through a rotating hierarchy
- **Ease In**: Slow start, accelerates
- **Ease Out**: Fast start, decelerates
- **Ease In Out**: Slow start and end, fast middle
- **Custom**: Custom spacing for specific effects

## Procedural Animation

### Procedural Techniques
- **Physics-Based**: Use physics simulation for realistic movement
- **Inverse Kinematics**: Calculate joint positions from end effector
- **Forward Kinematics**: Calculate end effector from joint positions
- **Constraint-Based**: Use constraints to drive animation
- **Mathematical Functions**: Use sine waves, noise, etc.

### Procedural Applications
- **Cloth Simulation**: Simulate cloth physics
- **Hair Simulation**: Simulate hair movement
- **Particle Systems**: Simulate particles and fluids
- **Crowd Simulation**: Simulate crowd behavior
- **Vegetation**: Simulate plant movement

### Procedural vs Keyframed
- **Procedural**: Rule-, constraint-, or simulation-driven; may be deterministic and artist-directed, and is not necessarily physics-based
- **Keyframed**: Controlled, predictable, artist-directed
- **Hybrid**: Combine both approaches for best results

## Animation Curves and Graph Editor

### Curve Types
- **Linear**: Straight line between keys
- **Bezier**: Smooth curves with handles
- **Stepped**: Instant transitions
- **Constant**: Hold value until next key

### Curve Editing
- **Tangent Handles**: Control curve shape at keys
- **Tangent Types**: Auto, Clamped, Linear, Stepped, Free
- **Curve Smoothing**: Reduce noise in curves
- **Curve Filtering**: Apply filters to curves
- **Curve Copying**: Copy curves between attributes

### Graph Editor Techniques
- **Offset Keys**: Offset keys for overlapping action
- **Scale Keys**: Scale timing of animation
- **Mirror Keys**: Mirror keys for symmetrical actions
- **Cycle Keys**: Create looping animations
- **Bake Simulation**: Convert procedural animation to keys

## Animation Blending and State Machines

### Animation Blending
- **Blend Shapes**: Blend between facial expressions
- **Blend Trees**: Blend between animations based on parameters
- **Layer Blending**: Blend between animation layers
- **Additive Blending**: Add animation on top of base animation
- **Crossfading**: Smooth transition between animations

### State Machines
- **States**: Individual animations or animation groups
- **Transitions**: Movement between states
- **Conditions**: Rules for when transitions occur
- **Parameters**: Variables that control transitions
- **Blend Trees**: Blend between animations based on parameters

### Animation Layers
- **Base Layer**: Primary animation
- **Additive Layers**: Additive animation on top
- **Override Layers**: Override base animation
- **Masking**: Apply layers to specific body parts
- **Layer Blending**: Control layer influence

## Performance Optimization for Animations

### Optimization Techniques
- **Reduce Key Count**: Remove unnecessary keys
- **Simplify Curves**: Reduce curve complexity
- **Use IK/FK Efficiently**: Don't overuse IK
- **Optimize Blend Trees**: Reduce blend tree complexity
- **Use Animation Compression**: Compress animation data
- **Reduce Bone Count**: Remove only bones not required by deformation, animation bindings, attachments, or the destination's standardized rig contract

### Real-Time Considerations
- **Frame Rate**: Maintain target frame rate
- **Memory Usage**: Minimize animation memory
- **CPU Usage**: Reduce animation CPU cost
- **GPU Usage**: Minimize GPU impact
- **Network**: Reduce network bandwidth for multiplayer

### Platform-Specific Optimization
- **Mobile**: Lower bone count, simpler animations
- **Console**: Medium optimization, balance quality and performance
- **PC**: Higher quality, more complex animations
- **VR**: High frame rate priority, reduced complexity
- **AR**: Real-time performance priority

## Timing, Sampling, and Contact Validation

Read [Timing, interpolation, and contact references](references/timing-sampling-contact.md) for authoritative sources and the scope of the workflow recommendations below.

- Declare clip duration, authoring frame rate, playback speed, root-motion policy, and event/contact times before polishing; convert frame offsets with `seconds = (frame - start_frame) / fps` rather than treating a frame count as a duration.
- Block readable action phases before smoothing; for a strike, distinguish preparation, extension/contact (if any), recoil, and recovery. Choose phase timing from the intended action and reference, not a supposedly universal punch duration or joint-speed limit.
- Preserve deliberately fast transitions and holds; easing every segment can soften an impact or add unwanted stops at densely sampled keys.
- Distinguish authored sparse keys, evaluated baked samples, and runtime interpolation. Adding keys alone does not improve motion: compare the reconstructed motion at between-key times, especially around fast arcs, contacts, and loop seams.
- Choose bake/sample rate by reconstruction error and destination behavior. Include event and contact boundaries explicitly; do not assume a fixed sample rate guarantees contact accuracy or preserves a short impact.
- Use linear interpolation as a candidate for dense baked samples, not a universal rule. Check whether the destination interpolates rotations differently; avoid automatic per-sample easing unless the resulting velocity profile is intended.
- Compare evaluated world-space trajectories before and after baking, compression, key reduction, and import. A joint-channel match at keys does not prove that hands or feet follow the same path between keys.
- Validate contact over a declared interval and in its supporting surface's coordinate system; a planted foot may remain fixed relative to a moving platform rather than the world. Identify the intended contact point (sole, toe pivot, palm, or knuckles), not merely the part origin.
- Check contact entry/exit, foot sliding, penetration, unintended limb flips, and recovery at normal speed and slow playback. Distinguish intentional pivot/slip from a locked contact instead of imposing full-foot locking on every action.
- For loops, inspect pose and velocity continuity at the wrap; matching endpoint poses alone can still produce a visible jerk. Test the actual runtime loop behavior rather than assuming an intent flag makes it cycle.
- Record measured errors, coordinate spaces, units, rig scale, sample interval, and project-specific acceptance tolerances. Do not describe arbitrary angle, acceleration, reach, or slip cutoffs as universal biomechanical laws.

## Animation Export and Integration

### Export Formats
- **FBX**: Most common format, supports animation
- **Maya ASCII/Binary**: Maya native format
- **Blender**: Blender native format
- **Collada (DAE)**: Open standard format
- **glTF/GLB**: Web-ready format

### Export Settings
- **Bake Animation**: When the destination cannot reproduce the source constraints/IK/drivers, bake their evaluated result onto supported joint channels; preserve the editable source and verify the baked result without double-applying the original solvers
- **Sample Rate**: Set keyframe sampling rate
- **Animation Compression**: Apply compression to reduce file size
- **Root Motion**: Include or exclude root motion
- **Animation Takes**: Export specific animation takes

### Integration
- **Unity**: Import FBX, create Animator Controller, set up animation clips
- **Unreal**: Import FBX, create Animation Blueprint, set up animation montage
- **Godot**: Import glTF/FBX, create AnimationPlayer, set up animation tree
- **Web**: Use Three.js or Babylon.js with glTF animations
- **Custom**: Parse animation data and apply to custom systems
