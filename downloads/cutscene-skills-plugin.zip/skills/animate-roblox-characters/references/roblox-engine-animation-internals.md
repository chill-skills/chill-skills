# Roblox Engine Internals, CurveAnimation, IKControl & Procedural Physics Reference

Deep engineering reference covering the Roblox animation runtime, Motor6D vs. `AnimationConstraint` mathematics, `CurveAnimation` / `FloatCurveKey` procedural construction, `IKControl` solver tuning, FACS `FaceControls`, and quaternion SLERP / critically damped spring physics.

---

## 1. The Exact Joint Transform Equation (`Motor6D` & `AnimationConstraint`)

For Motor6D's kinematic joint relation, and AnimationConstraint when operating kinematically, use the following world-space target relation. It is not an invariant for every articulated joint: a force-limited physical AnimationConstraint can lag its target.

$$\text{Part0.CFrame} \times C_0 \times \text{Transform} = \text{Part1.CFrame} \times C_1$$

Solving for the child part's world transform or the animation delta `Transform`:

$$\text{Part1.CFrame} = \text{Part0.CFrame} \times C_0 \times \text{Transform} \times C_1^{-1}$$

$$\text{Transform} = C_0^{-1} \times \left(\text{Part0.CFrame}^{-1} \times \text{Part1.CFrame}\right) \times C_1$$

### Critical Runtime Execution Order (`RunService` Pipeline)
1. **`RunService.PreAnimation`**: Fires *before* the Roblox `Animator` evaluates active `AnimationTrack` instances and writes to `Motor6D.Transform` / `AnimationConstraint.Transform`.
2. **`Animator` Step**: Evaluates blended keyframes/curves across all playing priorities (`Core` < `Idle` < `Movement` < `Action` < `Action2` < `Action3` < `Action4`) and schedules deferred `Transform` updates.
3. **`RunService.PreSimulation`**: Use this phase for post-Animator procedural Transform overlays; joint transforms are applied in a deferred batch before physics. Reading transforms at other phases is not inherently invalid, but their evaluation timing differs.
   - Prefer Transform over per-frame Motor6D C0/C1 mutation for animation. AnimationConstraint C0/C1 aliases are read-only; do not modify RigAttachment frames to implement overlays. Preserve bind geometry and inspect the current joint class.
   - Never accumulate an overlay onto stale output when the Animator is stopped, throttled, or not driving the joint. Establish baseline ownership, remove/reset only your prior contribution before evaluation, and disconnect/reset on teardown. Multiplication order determines overlay space.

### Avatar Joint Upgrade (`AnimationConstraint` vs `Motor6D`)
Modern Roblox R15 rigs with the Avatar Joint Upgrade replace `Motor6D` instances with `AnimationConstraint` (paired with `BallSocketConstraint` for ragdoll/physical simulation). Dual-compatible joint lookup helper:

```lua
local function findRigJoint(parentPart: Instance, jointName: string): (Motor6D | AnimationConstraint)?
    local ac = parentPart:FindFirstChild(jointName)
    if ac and (ac:IsA("AnimationConstraint") or ac:IsA("Motor6D")) then
        return ac
    end
    -- Fail closed: an arbitrary sibling joint may drive another limb.
    return nil
end
```

---

## 2. `CurveAnimation` Architecture (`Vector3Curve`, `EulerRotationCurve`, `RotationCurve`)

Unlike frame-baked `KeyframeSequence` hierarchies, `CurveAnimation` (a subclass of `AnimationClip`) stores independent channel curves arranged in a `Folder` hierarchy mirroring the `Motor6D` / `Bone` hierarchy from `HumanoidRootPart`.

| Instance Class | Purpose | Sub-Channels / Methods |
|---|---|---|
| `CurveAnimation` | Root `AnimationClip` container | Hierarchical `Folder` tree named after rig parts/bones |
| `Vector3Curve` | Named `"Position"` inside a joint `Folder` | `:X()`, `:Y()`, `:Z()` returning `FloatCurve`; `:GetValueAtTime(t)` returns `{number}` |
| `EulerRotationCurve` | Named `"Rotation"` inside a joint `Folder` | `:X()`, `:Y()`, `:Z()` (`FloatCurve`; verify angular units with a known-angle round trip before supplying keys); `RotationOrder` (`Enum.RotationOrder.XYZ`, `YXZ`, etc.); `:GetRotationAtTime(t)` returns `CFrame` |
| `RotationCurve` | Named `"Rotation"` (Quaternion curve) | Stores `RotationCurveKey(time, cframe, interpolationMode)` evaluated via SLERP/Squad |
| `FloatCurve` | Single scalar curve (`X`, `Y`, `Z`, or FACS AU) | `:InsertKey(FloatCurveKey.new(t, val, mode))` or `:SetKeys({FloatCurveKey})` |
| `FloatCurveKey` | Keyframe point on a `FloatCurve` | `.Time`, `.Value`, `.Interpolation` (`Constant`, `Linear`, `Cubic`), `.LeftTangent`, `.RightTangent` |

### Programmatic `CurveAnimation` Generator (Luau)

Supply `rotKeysValidatedUnits` only after validating angular units and RotationOrder with GetRotationAtTime on an isolated known-angle and compound-rotation probe. Do not assume the scalar curve uses the same units as CFrame.Angles. This constructor alone is not an import/playback test.

Sources: [FloatCurveKey](https://create.roblox.com/docs/reference/engine/datatypes/FloatCurveKey), [EulerRotationCurve](https://create.roblox.com/docs/reference/engine/classes/EulerRotationCurve), [Motor6D](https://create.roblox.com/docs/reference/engine/classes/Motor6D), [AnimationConstraint](https://create.roblox.com/docs/reference/engine/classes/AnimationConstraint).

```lua
local function createCubicFloatKey(t: number, value: number, leftSlope: number, rightSlope: number): FloatCurveKey
    local key = FloatCurveKey.new(t, value, Enum.KeyInterpolationMode.Cubic)
    key.LeftTangent = leftSlope
    key.RightTangent = rightSlope
    return key
end

local function buildJointEulerCurve(
    parentFolder: Instance,
    jointName: string,
    rotationOrder: Enum.RotationOrder,
    posKeys: { [string]: { FloatCurveKey } },
    rotKeysValidatedUnits: { [string]: { FloatCurveKey } }
): Folder
    local jointFolder = Instance.new("Folder")
    jointFolder.Name = jointName
    jointFolder.Parent = parentFolder

    local posCurve = Instance.new("Vector3Curve")
    posCurve.Name = "Position"
    posCurve.Parent = jointFolder
    if posKeys.X then posCurve:X():SetKeys(posKeys.X) end
    if posKeys.Y then posCurve:Y():SetKeys(posKeys.Y) end
    if posKeys.Z then posCurve:Z():SetKeys(posKeys.Z) end

    local rotCurve = Instance.new("EulerRotationCurve")
    rotCurve.Name = "Rotation"
    rotCurve.RotationOrder = rotationOrder
    rotCurve.Parent = jointFolder
    if rotKeysValidatedUnits.X then rotCurve:X():SetKeys(rotKeysValidatedUnits.X) end
    if rotKeysValidatedUnits.Y then rotCurve:Y():SetKeys(rotKeysValidatedUnits.Y) end
    if rotKeysValidatedUnits.Z then rotCurve:Z():SetKeys(rotKeysValidatedUnits.Z) end

    return jointFolder
end
```

---

## 3. Native `IKControl` Solver Architecture & Anti-Snap Rules

`IKControl` must be parented to a `Humanoid` or `AnimationController` containing an `Animator`, not to the Animator itself. It overrides the configured chain's animation pose. Configure Type, ChainRoot, EndEffector and Target before deliberately enabling it. For R15, load `universal-r15-animation-director` and its runtime/IK reference before constructing controls.

| Property | Recommended R15 Value | Engineering Notes |
|---|---|---|
| `Type` | `Transform` (full 6-DOF), `Position` (3-DOF), `Rotation`, `LookAt` | Use `Position` or `Transform` for feet/hands; `LookAt` for head/upper-torso tracking |
| `ChainRoot` | `LeftUpperLeg` / `RightUpperLeg` / `LeftUpperArm` / `RightUpperArm` | **Never** set `ChainRoot` to `HumanoidRootPart` or `LowerTorso` for limb IK (causes whole-body tipping) |
| `EndEffector` | `LeftFoot` / `RightFoot` / `LeftHand` / `RightHand` (or `Attachment`) | Using an `Attachment` on the sole or palm gives exact contact point control |
| `EndEffectorOffset` | `CFrame.identity` (or sole/grip offset) | Applied in the local space of `EndEffector` on top of `Target` |
| `Pole` | Rig-relative Attachment positioned for the desired bend plane | Roblox character forward is normally local -Z; inspect the actual rig. Pole placement helps control bending but cannot guarantee immunity to singularities |
| `SmoothTime` | `0.05` – `0.15` seconds | Critically damps target jumps; **Note**: Setting `Weight = 0` alone does not fully bypass `SmoothTime`/`Pole` evaluation—set `Enabled = false` when completely inactive |
| `Weight` | `0.0` – `1.0` | Driven dynamically by animation curves or raycast ground confidence |

### Foot-contact construction requirements

The previous partial setup was removed: it parented the control incorrectly, omitted Target, and hard-coded pole offsets. Do not reuse it from history.

Discover the actual chain and measured sole attachment; create a disabled control under the verified Humanoid or AnimationController; assign Type, ChainRoot, EndEffector, Target and an anatomically calibrated pole; then enable it deliberately. A complete contact implementation also needs stance anchors, moving-platform handling when applicable, reach policy, release/blend behavior, and cleanup of owned instances. Verify evaluated sole position AND orientation throughout stance and transitions. Smoothing and Weight zero do not establish foot locking; disable the control when it must not solve.

---

## 4. Quaternions, SLERP, and Exponential Map Blending

From Ken Shoemake's spherical linear interpolation (SLERP) on the unit 3-sphere $S^3$ ($q \in \mathbb{H}, \|q\|=1$):

$$\text{Slerp}(q_0, q_1; t) = \frac{\sin((1-t)\Omega)}{\sin\Omega} q_0 + \frac{\sin(t\Omega)}{\sin\Omega} q_1, \quad \cos\Omega = q_0 \cdot q_1$$

### Antipodal Double-Cover Pitfall ($q$ vs $-q$)
Because unit quaternions double-cover $SO(3)$ ($q$ and $-q$ represent the exact same 3D rotation), any blender or exporter converting matrices to quaternions **must** enforce the shortest-arc hemisphere condition:
- If $q_{k-1} \cdot q_k < 0$, negate $q_k \leftarrow -q_k$ before keyframing or interpolating.
- This avoids a long arc in naive interpolation, but shortest-path SLERP implementations already correct equivalent quaternion signs. Normalize samples and test the actual implementation; preserve intentional multi-turn motion with intermediate keys rather than blindly shortening it.

### Critically Damped Spring Damper (Analytical Closed-Form for Procedural Overlays)
For procedural recoil, breathing, weapon sway, and landing compression layered onto `Motor6D.Transform` in `PreSimulation`, use an exact framerate-independent critically damped spring ($\zeta = 1$, natural frequency $\omega_n = 2\pi f$):

$$x(t + \Delta t) = \left( (x_0 - x_{\text{target}})(1 + \omega_n \Delta t) + v_0 \Delta t \right) e^{-\omega_n \Delta t} + x_{\text{target}}$$

$$v(t + \Delta t) = \left( v_0 (1 - \omega_n \Delta t) - (x_0 - x_{\text{target}}) \omega_n^2 \Delta t \right) e^{-\omega_n \Delta t}$$

--- 

## 5. FACS (`FaceControls`) Dynamic Head Animation

Roblox Dynamic Heads expose 50+ normalized `[0.0, 1.0]` properties on the `FaceControls` child of `Head`, mapped to Paul Ekman's Facial Action Coding System (FACS) Action Units (AUs) and stored inside `FaceControls` sub-folders in `CurveAnimation` / `KeyframeSequence`:

| Expression | Primary FACS `FaceControls` Properties (`0.0` – `1.0`) |
|---|---|
| **Natural Blink** | `LeftEyeClosed = 1.0`, `RightEyeClosed = 1.0` (asymmetric by 1–2 frames for organic appeal; slight `LeftCheekRaiser = 0.15`) |
| **Genuine Smile (Duchenne, AU6 + AU12)** | `LeftLipCornerPuller = 0.8`, `RightLipCornerPuller = 0.8`, `LeftCheekRaiser = 0.55`, `RightCheekRaiser = 0.55`, `JawDrop = 0.15` |
| **Combat Effort / Roar (AU4 + AU9 + AU26)** | `Corrugator = 0.9`, `LeftBrowLowerer = 0.85`, `RightBrowLowerer = 0.85`, `LeftNoseWrinkler = 0.6`, `RightNoseWrinkler = 0.6`, `JawDrop = 0.75`, `LowerLipDepressor = 0.7` |
| **Shock / Hit React (AU1 + AU2 + AU5 + AU26)** | `LeftInnerBrowRaiser = 0.9`, `RightInnerBrowRaiser = 0.9`, `LeftOuterBrowRaiser = 0.85`, `RightOuterBrowRaiser = 0.85`, `LeftEyeUpperLidRaiser = 0.8`, `RightEyeUpperLidRaiser = 0.8`, `JawDrop = 0.65` |
| **Saccadic Eye Tracking** | `EyesLookLeft`, `EyesLookRight`, `EyesLookUp`, `EyesLookDown` (eyes lead head turn by 2–4 frames with stepped/fast cubic transitions) |

---

## 6. Priority Stack & Event Marker Synchronization

Always assign explicit `AnimationPriority` values so layered tracks blend deterministically per joint:
1. **`Action4`** (Highest): Fatal hit-stun, cinematic finisher, forced knockdown.
2. **`Action3`**: Combat attacks, dodges, parries, weapon reloads.
3. **`Action2`**: Upper-body item usage, aiming down sights, waving/emotes while moving.
4. **`Action`**: Standard interactive actions, jumps, climbs.
5. **`Movement`**: Walk, run, strafe, swim, crouch-walk.
6. **`Idle`**: Standing breathing loop, fidget variants.
7. **`Core`** (Lowest): Default Roblox catalog fallback animations.

Use named animation events, represented by `KeyframeMarker` children of Keyframes in `KeyframeSequence`, accessed via `AnimationTrack:GetMarkerReachedSignal("FootstepLeft")`, `"HitFrame"`, `"VFXSpawn"`, and `"CancelWindow"` rather than fragile `task.wait()` timers so gameplay stays locked to `AnimationTrack:AdjustSpeed()` changes.
