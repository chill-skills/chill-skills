# Authoring, export and verification contract

## Scope
Explicit native Studio work does not require Blender, GIFs, or Blender confirmation. Route native R15 to `universal-r15-animation-director`. The Blender security, authenticated rig lineage, protected working copy, persistent GUI and preview requirements remain in force only for the Blender route.

## Editable curves versus transport samples
- Keep sparse authoring curves editable. Bezier handles and designed easing specify timing; neither a Bezier label nor key count proves good motion.
- Bake evaluated transforms, including constraints and drivers, to the verified export skeleton. Preserve the source action and bind the correct Action **and slot**; do not merge unrelated channelbags or NLA strips. Record FPS (`render.fps / render.fps_base`), sample interval, source/export frame range, root policy and target rig.
- Dense linear samples are valid: easing is encoded by their spacing. Sampling agrees at sample times but does not preserve the continuous source curve exactly between samples. Compare imported target transforms at sample times and midpoints, especially impacts, contact changes and high-angular-speed segments. Increase/adapt sampling until declared position/angular/contact tolerances pass. Do not promise 100% fidelity from 30/60 FPS alone.
- Do not apply ease-in/out independently to each baked interval or blindly convert baked keys to Bezier; both can introduce velocity ripple or overshoot. Reduce keys only after measuring the resulting error against the evaluated source.
- A stationary local IK channel does not guarantee a stationary world-space sole when its parent moves. Measure actual sole/contact points on the evaluated output; linear interpolation is an option, not a contact solver.
- Loop endpoint pose equality is necessary but insufficient: compare one-sided velocities and contact state. Retain the closing key in export when required by its duration semantics; omit the duplicate from preview frame playback.

## Roblox API boundaries
- `Pose.EasingStyle` uses `PoseEasingStyle`, not `TweenService`'s larger `EasingStyle` set. Use supported enum values and test direction behavior on the actual target; legacy Cubic behavior is not a reason to invent enum mappings.
- `FloatCurveKey.Interpolation` uses `KeyInterpolationMode.Constant`, `Linear`, or `Cubic`. Cubic is a **Hermite** segment with this key's RightTangent and the next key's LeftTangent (slopes). Arbitrary Blender Bezier handle time coordinates are not losslessly transferable by merely copying slopes; fit/reparameterize or sample and validate.
- `EulerRotationCurve` has an explicit `RotationOrder`. Preserve the intended order and verify units through the documented API and a known-angle round trip. Do not treat Euler channels as quaternion SLERP or silently force every rig to XYZ.
- Verify hierarchy, rest matrices, units, action range and root policy on the actual target. Metadata-backed Motor6D exporters and skinned FBX pipelines are distinct; a file existing is not proof that Studio played it correctly. Separate local export success, Studio playback success and publishing authorization in reports.

## Auditor use
The bundled `animation_tools.audit_action` has a legacy Bezier-only final-curve gate. Its interpolation-only failure is not proof that a dense linear export or intentional mixed authoring is invalid. Report that diagnostic explicitly alongside independent representation-aware source-versus-import error measurements and visual review; do not claim the audit passed, invent unsupported policy arguments, or convert a correct bake solely to pass. Authenticity, contact, hierarchy and loop failures remain blocking. The pose-authoring helper also restricts interpolation choices; inspect its accepted inputs before using it and do not represent it as a general-purpose bake importer.

## Sources
- [Editing Strips — Bake Action](https://docs.blender.org/manual/en/latest/editors/nla/editing/strip.html): evaluated baking, frame step and Visual Keying.
- [Actions](https://docs.blender.org/manual/en/latest/animation/actions.html): slots, layers, strips and cyclic intent.
- [F-Curve Properties](https://docs.blender.org/manual/en/latest/editors/graph_editor/fcurves/properties.html): outgoing-segment interpolation.
- [PoseEasingStyle](https://create.roblox.com/docs/reference/engine/enums/PoseEasingStyle): supported pose enum members.
- [FloatCurveKey](https://create.roblox.com/docs/reference/engine/datatypes/FloatCurveKey): interpolation and Hermite tangent semantics.
- [EulerRotationCurve](https://create.roblox.com/docs/reference/engine/classes/EulerRotationCurve): rotation order and sampled rotation API.

Numeric tolerances and artistic defaults in these skills are project policy, not platform guarantees. Report measured evidence and unverified steps explicitly.
