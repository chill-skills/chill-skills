"""Rebuilds the bundled Cautioned 2.6.3 add-on zip from its base64 copy.

Claude's plugin uploader rejects zip files nested inside a zip, so the
unmodified release archive ships as rbx_anims_v2.6.3.zip.b64. The decoded
bytes are identical; callers still verify the pinned SHA-256.
"""
from __future__ import annotations

import base64
import tempfile
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
ZIP_REL = "assets/blender-addons/rbx_anims_v2.6.3.zip"


def resolve(relative: str = ZIP_REL) -> Path:
    """Return a real path to the add-on zip, decoding the .b64 copy if needed."""
    path = SKILL_ROOT / relative
    if path.is_file():
        return path
    encoded = path.with_name(path.name + ".b64")
    if not encoded.is_file():
        return path
    try:
        path.write_bytes(base64.b64decode(encoded.read_text()))
        return path
    except OSError:
        cache = Path(tempfile.gettempdir()) / "animate-roblox-characters" / path.name
        cache.parent.mkdir(parents=True, exist_ok=True)
        if not cache.is_file():
            cache.write_bytes(base64.b64decode(encoded.read_text()))
        return cache
