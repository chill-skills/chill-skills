---
name: universal-r6-blender-animation-director
version: 5.0.0
description: 'R6 Roblox animation in Blender: calibrate, pose, export.'
metadata:
  hermes:
    tags: [roblox, r6, blender, animation, combat]
    related_skills: [animate-roblox-characters, universal-r15-animation-director]
---

# UNIVERSAL ROBLOX R6 BLENDER ANIMATION DIRECTOR (V5.0)

## Most important animation quality requirement

**Generated animations must feel loose, fluid, and highly detailed, with excellent smoothing and intentional easing—not stiff or robotic.**

Prioritize relaxed posing, flowing arcs, purposeful overlap, follow-through, and refined secondary motion. Tune acceleration, deceleration, and settling per action phase rather than applying uniform smoothing everywhere. Preserve readable impacts, deliberate holds, weight, stable contacts, and rig integrity; loose means expressive, not uncontrolled. Detail must serve the action, not add random movement or unnecessary keys. Review moving playback and in-betweens before declaring this requirement met. This is the highest artistic priority, not permission to bypass correctness or verification.

> **MISSION:** Turn any motion request into an exceptionally readable, expressive, biomechanically grounded, and technically flawless **Roblox R6 animation**, authored inside Blender, audited across integer and sub-frame intervals, and prepared for the user's pipeline. This is a production animation system, **not** a collection of preset poses or lazy single-limb scripts.

> **MULTI-EASING-STYLE ENGINE:** Unlike rigid single-interpolation workflows, this skill orchestrates **multiple easing styles per action phase, per bone, and per axis** (`BEZIER` with `AUTO_CLAMPED`/`VECTOR`/`ALIGNED` handles, `SINE`, `QUAD`, `CUBIC`, `QUART`, `QUINT`, `EXPO`, `CIRC`, `BACK`, `BOUNCE`, `ELASTIC`, `LINEAR`, and `CONSTANT`). Easing is combined with purposeful breakdown poses, orthogonal axis phase-shifting for natural 3D arcs, and evaluated world-space contact compensation. Choose interpolation by measured contact error; neither `LINEAR`/`VECTOR` nor any easing family guarantees zero sliding or clipping.

> **ZERO CLIPPING, ZERO PIVOT DISLOCATION, ZERO LAZY POSING:**
> 1. **Pivot Integrity:** Never dislocate shoulder or hip pivots with excessive translation values just to fake reach; rotate around true anatomical sockets and drive reach from the torso and center of mass (CoM).
> 2. **Clearance and continuity:** Inspect evaluated geometry and rotation paths through transitions. Use breakdowns and curve corrections where measured failures require them. Neither OBB samples nor Euler compatibility guarantees collision-free or flip-free continuous motion.
> 3. **Whole-body intent:** Review torso, head and all limbs against the brief. Purposeful stillness, symmetry and isolated overlays are valid; do not add keys or phase lag merely to make every channel move.

> **NO FAKE COMPLETION:** Never claim an animation was created, tested, rendered, baked, or exported unless that step actually succeeded. When Blender/MCP tools are unavailable, provide a complete executable script clearly labeled **unexecuted**.

---

## When to Use

- Creating, polishing, debugging or exporting R6 animations in Blender (or native Studio): combat, barrages, parkour, dodges, idles, reactions.
- Not for: R15 → `universal-r15-animation-director`. Studio-only clips → `roblox-native-animation-studio`.

## Workflow scope and evidence limits

This is a **Blender R6** skill. Explicit native Roblox Studio requests do not require Blender, GIFs, or Blender confirmation. Route native R15 to `universal-r15-animation-director`; keep native R6 in Studio rather than imposing the Blender pipeline. For Blender work, retain authentic rig provenance, protected working copies and verified-source/script security from `animate-roblox-characters`; never execute downloaded embedded scripts merely because their control names match.

Read [references/authoring-export-evidence.md](references/authoring-export-evidence.md) before using the recipes or declaring export readiness. Numeric socket/IK/pose ranges below are **V2.22-oriented artistic heuristics**, not universal anatomical or engine limits. Calibrate against actual geometry, scale, rest pose and solver configuration; a legitimate neutral rigid leg need not satisfy an arbitrary bent-chain maximum. Purposeful stillness and isolated overlays are valid: whole-body participation means coordinated intent, not forced movement on every axis.

The sample `audit_r6_clip` is a **partial diagnostic**, not a full OBB collision solver: it samples arm centerline points, approximates torso bounds, and tests IK target origins rather than evaluated soles. A clean result does not prove zero clipping or complete contact validity. Use evaluated mesh/deform bounds, correct stud conversion, full separating-axis tests or mesh intersection where appropriate, adaptive temporal sampling and visual review. Half-frame samples can miss fast events. Preserve and restore scene/action state during all diagnostics.

## 0. Operating Contract — What the Agent MUST Do

1. **Read & Analyze:** Inspect the user's animation request and attachments. Identify action intent, style, R6 rig variant, duration, FPS, loop behavior, in-place vs. root motion, props/secondary actors, and delivery format.
2. **Inspect the Actual Blender Scene:** Verify armatures, bone names, rotation modes, parenting, constraints, and active Action/slot. Never assume a rig matches V2.22 without checking.
3. **Run the Single-Axis Calibration Probe:** Before authoring complex rotations, verify the exact local-to-world sign mapping on left vs. right limbs so outward abduction is never confused with inward body-clipping adduction.
4. **Create a Motion Brief, Beat Map, Easing Architecture Plan, & Contact Schedule:** Plan the whole-body biomechanics, easing curves per phase, and world-space foot locks before inserting keyframes.
5. **Declare channel ownership:** Review the whole-body pose, but author only the channels the clip owns. Held channels and omitted overlay channels are different; preserve that distinction.
6. **Preserve sockets and inspect arcs:** Measure actual control-to-deform behavior and contact geometry. Choose breakdown timing and path from observed clearance, not a universal angle threshold or outward offset. Do not apply legacy numeric clamps without calibration.
7. **Audit evaluated motion:** Sample keys, interval interiors, contact boundaries and suspected failures, refining around fast events. Measure sole contacts, socket separation, mesh clearance and orientation continuity. Record temporal coverage; the bundled centerline diagnostic is not a full OBB test or continuous collision guarantee.
8. **Bake & Verify Export:** When exporting to Roblox (`.rbxanim`, FBX, or Studio `KeyframeSequence` / `CurveAnimation`), verify that custom Blender easing styles are either cleanly resampled onto the target R6 skeleton (`InternalArmature`) or mapped to compatible Roblox easing enums without losing arcs or contacts.

---

## 1. Establish the Animation's Identity & Biomechanical Brief

Before keying any channel, construct a concise internal **Motion & Easing Brief**:

```text
Clip Name & Purpose:
Style & Energy: (grounded / athletic / heavy / snappy anime / cartoon / stealthy / exhausted / ceremonial)
Rig & Blender Version: (e.g., __PrimaryArmature -> InternalArmature, Blender 4.4 / 5.x)
FPS, Frame Range, Loop?: (e.g., 30 FPS, frames 1..45, one-shot or seamless loop)
Root Motion Strategy: (in-place game controller vs. authored LowerTorso-FK traversal)
Center of Mass (CoM) Path: (vertical drop/rise Δly, lateral shift Δlx, forward/back weight Δlz)
Contact & Support Schedule: (exact frame intervals where LeftLeg-IK / RightLeg-IK are PLANTED, ROLLING, or AIRBORNE)
Easing Architecture per Beat: (which interpolation & easing direction governs Anticipation, Launch, Impact, Overshoot, Settle)
Anti-Clipping Clearance Plan: (which limbs cross the midline or swing > 45° and require outward-bowed breakdowns)
```

---

## 2. Rig Discovery, Coordinate Reference & Mandatory Calibration Probe

### 2.1 R6 Architecture vs. Blender Control Rig

Roblox R6 consists of **six rigid body blocks**: `Torso` ($2 \times 2 \times 1$ studs), `Head` ($1 \times 1 \times 1$ studs), `Left Arm`, `Right Arm`, `Left Leg`, and `Right Leg` (each $1 \times 2 \times 1$ studs). Classic R6 limbs have **no elbows and no knees**.

In the standard **R6 IK + FK Blender Rig V2.22**:
- **Control Armature:** `__PrimaryArmature`
- **Export / Driven Armature:** `InternalArmature`
- **Root / Master:** `MasterControl` (keep at identity $(0,0,0)$ for in-place clips)
- **Pelvis / Torso / CoM:** `LowerTorso-FK`
- **Rigid Arms:** `LeftArm_FK`, `RightArm_FK` (parented to torso)
- **Head:** `Head` (parented to torso)
- **IK Legs:** `LeftLeg-IK`, `RightLeg-IK` (parented to `MasterControl`, **not** `LowerTorso-FK`)
- **IK Knee/Thigh Poles:** `LeftLeg-Pole`, `RightLeg-Pole`

### 2.2 V2.22 Control Basis Reference (Verify via Probe)

- **World Space:** Forward = $+Y$, Backward = $-Y$, Right = $+X$, Left = $-X$, Up = $+Z$, Floor = $Z = 0$.
- **`LowerTorso-FK`:**
  - `location.x`: $+X$ shifts right, $-X$ shifts left.
  - `location.y`: $+Y$ lifts torso up ($+Z$ world), $-Y$ crouches/compresses down ($-Z$ world).
  - `location.z`: $+Z$ pulls torso backward ($-Y$ world), $-Z$ drives torso forward ($+Y$ world).
  - `rotation_euler.x`: $+rx$ arches spine backward, $-rx$ pitches chest forward.
  - `rotation_euler.y`: $+ry$ twists right shoulder forward, $-ry$ twists left shoulder forward.
  - `rotation_euler.z`: lateral hip/torso tilt (roll/bank).
- **`LeftArm_FK` / `RightArm_FK`:**
  - `location.x`: lateral shoulder socket adjustment.
  - `location.y`: vertical shoulder socket adjustment ($-ly$ raises socket slightly, $+ly$ drops socket).
  - `location.z`: fore/aft shoulder protraction ($+lz$ protracts forward, $-lz$ retracts backward).
  - `rotation_euler.x`: forward/backward pitch swing ($+90^\circ$ raises arm horizontally forward).
  - `rotation_euler.y`: lateral abduction (away from body) vs. adduction (across chest). **WARNING:** Left and right arms often have mirrored local signs on `ry` and `rz`.
  - `rotation_euler.z`: axial arm twist / roll.
- **`LeftLeg-IK` / `RightLeg-IK`:**
  - `location.x`: lateral stance width ($+X$ right, $-X$ left).
  - `location.y`: vertical foot lift ($+ly$ lifts foot up in world $+Z$).
  - `location.z`: fore/aft step placement ($-lz$ steps forward $+Y$ world, $+lz$ steps backward $-Y$ world).

### 2.3 Mandatory Left/Right Axis Calibration Probe

One of the most common causes of **limbs rotating into the body** is guessing the sign of `rotation_euler.y` or `rotation_euler.z` on `LeftArm_FK` vs. `RightArm_FK`, causing an intended outward abduction to rotate $40^\circ$ inward through the ribcage.

Before authoring keys on an unverified scene, run this non-destructive probe in Blender Python to measure the exact world-space travel of each limb tip:

```python
import bpy
from math import radians
from mathutils import Vector

def run_rig_calibration_probe(rig_name='__PrimaryArmature'):
    rig = bpy.data.objects[rig_name]
    scene = bpy.context.scene
    deps = bpy.context.evaluated_depsgraph_get()
    
    probe_report = {}
    for bname in ['LowerTorso-FK', 'LeftArm_FK', 'RightArm_FK', 'LeftLeg-IK', 'RightLeg-IK', 'Head']:
        pb = rig.pose.bones.get(bname)
        if not pb:
            continue
        orig_loc = pb.location.copy()
        orig_rot = pb.rotation_euler.copy()
        
        # Tip point in bone-local space (0, length, 0)
        tip_local = Vector((0.0, pb.bone.length, 0.0))
        bpy.context.view_layer.update()
        eval_pb = rig.evaluated_get(deps).pose.bones[bname]
        base_tip_world = rig.matrix_world @ (eval_pb.matrix @ tip_local)
        
        axis_map = {}
        for idx, ax in enumerate(['rx', 'ry', 'rz']):
            pb.rotation_euler = orig_rot.copy()
            pb.rotation_euler[idx] += radians(20.0)
            bpy.context.view_layer.update()
            eval_pb = rig.evaluated_get(deps).pose.bones[bname]
            new_tip_world = rig.matrix_world @ (eval_pb.matrix @ tip_local)
            delta = new_tip_world - base_tip_world
            axis_map[ax] = tuple(round(v, 3) for v in delta)
            
        pb.location = orig_loc
        pb.rotation_euler = orig_rot
        bpy.context.view_layer.update()
        probe_report[bname] = axis_map
    return probe_report
```

**Rule:** For `LeftArm_FK`, a valid outward abduction must move the arm tip toward $-X$ (left). For `RightArm_FK`, a valid outward abduction must move the arm tip toward $+X$ (right). Verify the sign from `probe_report` before keying any lateral arm angles.

---

## 3. Pivot Integrity & Socket-Lock Protocol (Fixing "Rotating in the Wrong Spot")

### 3.1 Why Limbs Appear to Rotate Around the Wrong Pivot

In R6 rigs, `LeftArm_FK` and `RightArm_FK` have their bone head (pivot origin) placed at the upper-torso shoulder socket. When an AI animator applies large local translations (`location.x`, `location.y`, `location.z` $> 0.20$ studs) to "stretch" an arm forward or sideways, **the bone's pivot origin is displaced out of the shoulder socket**. Any subsequent Euler rotation then orbits around that displaced point in mid-air (or deep inside the chest), causing the top of the arm block to swing wildly out of the torso or slice sideways through the body.

### 3.2 Calibrated shoulder socket limits

The following V2.22-oriented values are starting heuristics, not anatomical bounds or portable hard clamps. Measure the actual control-to-deform mapping and socket separation first; choose limits in calibrated units that preserve the intended attachment. Review any deliberate smear separately:

$$|lx| \le 0.06\text{ studs}, \quad |ly| \le 0.08\text{ studs}, \quad -0.08 \le lz \le +0.14\text{ studs}$$

- **Never use arm `location` to create reach.**
- **How to create real biomechanical reach:** Rotate the torso yaw (`LowerTorso-FK.ry` by $15^\circ\text{–}40^\circ$), pitch the torso forward (`LowerTorso-FK.rx` by $-10^\circ\text{–}-25^\circ$), shift the pelvis (`LowerTorso-FK.lz` forward), and add at most $+0.06\text{ to }+0.12\text{ studs}$ of shoulder protraction (`Arm_FK.lz`). This moves the true shoulder socket forward in world space while keeping the arm's pivot locked cleanly to the upper torso.

### 3.3 IK Leg Distance Envelope & Hip Pivot Integrity

Because `LeftLeg-IK` and `RightLeg-IK` are parented to `MasterControl` (world root) while the hips move with `LowerTorso-FK`, moving `LowerTorso-FK` too far up, forward, or sideways without coordinating the IK feet causes two severe pivot bugs:
1. **Unreachable extension:** Measure the actual hip/contact offsets, limb length and control solver. A target beyond reachable distance can clamp or produce a residual; detachment is not an inevitable IK result. Report error against the original target and inspect evaluated sockets.
2. **Compression or bend-plane instability:** Near-degenerate target/pole geometry can cause unstable orientation depending on the control rig. Diagnose its evaluated behavior rather than predicting an inevitable flip from a fixed stud threshold. R6's delivered limb remains rigid even when a Blender helper uses a multi-bone solver.

**Example diagnostic envelope, not an acceptance rule:** The following legacy V2.22 range must be replaced by measured limits before use. A valid straight neutral limb is not an error merely because it exceeds this heuristic:

$$0.65\text{ studs} \le \|\mathbf{p}_{\text{hip\_socket}}(t) - \mathbf{p}_{\text{ankle\_IK}}(t)\| \le 1.96\text{ studs}$$

### 3.4 Dynamic Pole Vector Tracking (Eliminating $180^\circ$ Leg Twists)

Track the intended bend plane through turns, spins, kicks and lunges. A static pole can become unsuitable as the chain moves; near-collinear geometry may cause ambiguity, but does not universally imply an instantaneous flip.
- Choose pole direction and distance from the calibrated solver and desired motion. Preserve continuity through near-straight configurations; test overhead, crossed and turned poses rather than enforcing one forward hemisphere or fixed stud distance.

---

## 4. OBB Anti-Clipping & Euler Continuity Engine (Fixing "Rotating Into the Body & Glitching")

### 4.1 Anatomical Corridors & Cross-Body Clearance Rules

Classic R6 arms ($1 \times 2 \times 1$ blocks) sit immediately adjacent to the $2 \times 2 \times 1$ torso block at $X = \pm 1.5\text{ studs}$.
1. **Zero Inward Adduction Near Neutral Pitch:** When an arm's forward/backward pitch is near vertical rest ($-25^\circ \le rx \le +35^\circ$), **inward adduction toward the torso center is strictly forbidden**. Any inward rotation here drives the inner face of the arm block straight into the ribcage. Keep lateral abduction neutral or slightly open ($3^\circ\text{ to }12^\circ$ outward).
2. **Cross-Body Clearance Corridor:** Before an arm can cross the chest midline (for a cross-body sword slash, left-hook, guard, or hug), it MUST first clear the torso's front plane ($Y = +0.5\text{ studs}$ in torso space) by satisfying:
   - Forward pitch $rx \ge +45^\circ$ (up to $+110^\circ$)
   - Forward shoulder protraction $lz \ge +0.06\text{ studs}$ (up to $+0.14\text{ studs}$)
   Only *after* the arm is pitched in front of the chest may it adduct across the midline.
3. **Backward Swing Clearance:** When swinging an arm backward ($rx < -20^\circ$), abduct the arm slightly **outward** ($5^\circ\text{ to }15^\circ$ away from the torso) so the inner block corner clears the back of the hip/torso.

### 4.2 Outward-Bowed Midpoint Breakdowns for Large Swings

Wide or cross-body swings deserve additional inspection, but neither an angle threshold nor endpoint poses establish penetration. Joint rotation, constraints and moving parents produce paths that are not generally straight chords.

If evaluated geometry intersects unintentionally, add a breakdown at the failing interval and choose an achievable clearance path using calibrated axes. An outward bow or staggered axis timing can help; neither is mandatory nor sufficient. Preserve socket connectivity, check the weapon or prop as well as the limb, and re-evaluate the complete transition after editing.

### 4.3 Continuous Quaternion-Guided Euler Unwrapping (Eliminating $180^\circ$/$360^\circ$ Flips)

Glitching mid-animation almost always happens when Euler angles cross $\pm 180^\circ$ or when two valid Euler decompositions represent similar orientations with opposite signs (e.g., $(175^\circ, 10^\circ, -170^\circ)$ vs. $(-175^\circ, -10^\circ, 170^\circ)$). Interpolating between those two keys spins the limb crazily through every axis in a few frames.

**Rotation repair protocol:**
- Reproduce the first unwanted rotation and inspect constraints, drivers, rotation mode/order, component key times and handles before attributing it to Euler wrapping.
- Protect the source action. For an unintended representation discontinuity, compatibility with the previous Euler can be useful, but it is not a universal gimbal-lock or solver repair. Preserve the actual rotation order and compare evaluated orientations before and after any rewrite.
- Preserve intentional angular winding. Do not automatically shorten spins. Intermediate orientation keys can describe a turn path; verify the resulting interpolation and delivered representation rather than relying on endpoint orientations.
- The embedded legacy unwrap helper is not approved for automatic use on user actions; its limitations are listed in section 7.

---

## 5. Multi-Easing-Style Animation Engine (Blender + Roblox Research & Implementation)

Smooth, weighty, lifelike animation requires varying acceleration and deceleration across different phases of motion and different body masses. Instead of forcing every curve to a single interpolation type, this skill uses a **Multi-Easing-Style Architecture** backed by Blender's native F-Curve engine and mapped cleanly to Roblox's animation systems.

### 5.1 Complete Blender `bpy.types.Keyframe` Interpolation & Easing Reference

In Blender Python (`4.4+` and `5.x`), every `Keyframe` point on an `FCurve` exposes two primary enum properties plus dynamic tuning properties:

1. **`keyframe.interpolation`** (governs the curve segment starting at this keyframe and ending at the next keyframe):
   - `'CONSTANT'`: Stepped hold; value stays locked until the next keyframe. Ideal for instant pose switches, 1–2 frame impact hit-stops, or stepped cartoon styling.
   - `'LINEAR'`: Constant rate of change of the interpolated channel between keys. This does not guarantee constant world-space speed or a planted foot through a rotating hierarchy. For contact compensation, solve against the evaluated sole/contact frame in support space and verify between keys. Use linear baked samples only when reconstruction error meets the declared tolerance.
   - `'BEZIER'`: Custom tangent spline controlled by `handle_left_type` and `handle_right_type`:
     - `'AUTO_CLAMPED'` (**Default safe Bezier**): Smoothly eases without ever overshooting local extrema.
     - `'VECTOR'`: Straight linear tangent pointing directly at the adjacent keyframe.
     - `'ALIGNED'`: Manual smooth continuous tangents across the keyframe.
     - `'FREE'`: Broken tangents for sharp rebounds/impacts (e.g., foot hitting concrete or weapon hitting armor).
     - `'AUTO'`: Unclamped automatic spline (**avoid near floor/body contacts** because it overshoots).
   - **Sinusoidal & Polynomial Easing Family** (ordered from gentlest to sharpest acceleration/deceleration):
     - `'SINE'`: Gentle sinusoidal curve ($\sin(\frac{\pi}{2}t)$). Best for subtle breathing, slow head turns, calm idles, and floating motion.
     - `'QUAD'`: Quadratic curve ($t^2$). Natural, light weight transfers, casual arm gestures, everyday walking swing phases.
     - `'CUBIC'`: Cubic curve ($t^3$). The gold-standard workhorse for athletic body mechanics, torso twists, and expressive character acting.
     - `'QUART'`: Quartic curve ($t^4$). Heavy mass displacement, brisk limb launches, strong braking deceleration.
     - `'QUINT'`: Quintic curve ($t^5$). Explosive combat strikes, rapid dodges, high-velocity anime/stylized slashes.
     - `'EXPO'`: Exponential curve ($2^{10(t-1)}$). Extreme dramatic snap, teleport dashes, shockwave recoil spikes.
     - `'CIRC'`: Circular arc ($\sqrt{1 - (t-1)^2}$). Immediate high-angle launch velocity or abrupt wall-like stopping curve.
   - **Dynamic Physics / Overshoot Easing Family**:
     - `'BACK'`: Cubic curve that overshoots the target and settles back. Controlled by `keyframe.back` (float, default $\approx 1.70158$; recommend $0.6\text{ to }1.35$ for R6 limbs so the overshoot remains subtle and natural).
     - `'BOUNCE'`: Exponentially decaying parabolic bounce at the end of the segment. Useful for heavy weapon slams hitting the ground or stunned knockdowns.
     - `'ELASTIC'`: Damped harmonic sine oscillation controlled by `keyframe.amplitude` and `keyframe.period`. Useful for cartoon recoil, magical aura pulses, or spring-loaded mechanical actions.

2. **`keyframe.easing`** (controls *which end* of the segment receives the easing curvature for `SINE`, `QUAD`, `CUBIC`, `QUART`, `QUINT`, `EXPO`, `CIRC`, `BACK`, `BOUNCE`, `ELASTIC`):
   - `'EASE_IN'`: Starts slow from Keyframe $A$ and accelerates continuously into Keyframe $B$ (ideal for gravity drops, windup launches, and strikes accelerating into impact).
   - `'EASE_OUT'`: Launches at high velocity from Keyframe $A$ and decelerates smoothly into Keyframe $B$ (ideal for follow-through, recoil absorption, landing compression recovery, and settling into a pose).
   - `'EASE_IN_OUT'`: Starts slow from Keyframe $A$, reaches peak speed mid-segment, and decelerates smoothly into Keyframe $B$ (ideal for self-contained weight shifts, anticipation poses, and balanced transitions).
   - `'AUTO'`: Uses Blender's interpolation-family default easing, not a slope-sign rule. Set `'EASE_IN'`, `'EASE_OUT'`, or `'EASE_IN_OUT'` explicitly when the beat requires a specific direction. This property does not reshape BEZIER, LINEAR or CONSTANT segments.

### 5.2 Roblox Animation Easing Compatibility & Export Translation

Understanding how Blender easing translates to Roblox is critical for studio-grade output:

1. **Baked Frame-by-Frame Export (`.rbxanim` via `authentic_rig` or Baked FBX at 30/60 FPS):**
   - When the exporter bakes `InternalArmature` across `frame_start..frame_end`, Blender evaluates the exact mathematical value of `SINE`, `QUAD`, `CUBIC`, `QUART`, `QUINT`, `EXPO`, `CIRC`, `BACK`, `BOUNCE`, `ELASTIC`, or `BEZIER` at every single frame.
   - Dense linear samples validly encode the evaluated easing at sample times, but **do not exactly preserve continuous motion between samples**. Compare source and imported target at sample times and midpoints; increase sampling around contacts, overshoot and rapid rotations until declared positional/angular errors pass. Preserve the sparse editable action separately.
2. **Native Roblox Studio Keyframe / Curve Systems:**
   - **Roblox `KeyframeSequence` (`Pose.EasingStyle` & `Pose.EasingDirection`):**
     - Supports `Enum.PoseEasingStyle.Linear`, `Constant`, `CubicV2`, `Bounce`, and `Elastic` (never use deprecated `Enum.PoseEasingStyle.Cubic`, which had inverted direction math in Roblox's legacy engine; always use `CubicV2`).
     - Supports `Enum.PoseEasingDirection.In`, `Out`, and `InOut`.
   - **Roblox curve channels and TweenService are separate APIs:**
     - `FloatCurveKey.Interpolation` uses `Enum.KeyInterpolationMode.Constant`, `Linear`, or `Cubic`; cubic segments use Hermite tangent slopes, not arbitrary Blender Bezier time/value handles. Fit or sample and measure conversion error.
     - `TweenService` uses the larger `Enum.EasingStyle` set. It is not a `Pose.EasingStyle` or curve-channel interpolation enum. In the recipe table below, `EasingStyle.*` entries are timing analogies for custom sampling/TweenService, **not direct native animation mappings**.

| Motion Phase / Biomechanical Role | Blender `interpolation` | Blender `easing` | Roblox Native Equivalent (`PoseEasingStyle` / `EasingStyle`) | Why It Works & Anti-Glitch Rule |
|---|---|---|---|---|
| **Planted Foot / Support Contact** | Solved compensation; choose interpolation by evaluated error | Explicit per representation | `PoseEasingStyle.Linear` is one sampled-output option, not a lock | Measure the evaluated contact frame relative to its support throughout the interval. Neither linear channels nor vector handles alone prevent sliding or penetration. |
| **Calm Idle Breathing & Gaze Drift** | `'SINE'` | `'EASE_IN_OUT'` | `EasingStyle.Sine` (`InOut`) | Ultra-smooth harmonic rise/fall without robotic linear turnarounds. |
| **Anticipation / Coiling Weight** | `'CUBIC'` or `'QUAD'` | `'EASE_IN_OUT'` | `PoseEasingStyle.CubicV2` (`InOut`) | Gradual muscle loading that builds tension smoothly before launch. |
| **Acceleration into Strike / Jump Takeoff** | `'QUART'` or `'QUINT'` | `'EASE_IN'` | `EasingStyle.Quart` / `Quint` (`In`) | Coils slowly at first, then accelerates to maximum velocity right at the contact/takeoff frame. |
| **Explosive Dash / Recoil / Slash Release** | `'QUINT'` or `'EXPO'` | `'EASE_OUT'` | `EasingStyle.Quint` / `Exponential` (`Out`) | Instant burst of speed out of the impact/launch frame followed by a long cinematic hang/deceleration. |
| **Freefall / Gravity Descent** | Explicit ballistic trajectory or tuned artistic curve | Match intended boundary velocities | Sample into the selected native representation | Circular easing is not constant-gravity motion. Quadratic easing matches only suitable boundary conditions and time/displacement scaling; check the actual trajectory and movement owner rather than inferring physics from an easing name. |
| **Landing Absorption / Recovery** | `'CUBIC'` or `'QUART'` | `'EASE_OUT'` | `PoseEasingStyle.CubicV2` (`Out`) | Rapid initial knee/hip compression right after ground contact that cushions smoothly to a stop. |
| **Secondary Follow-Through & Overshoot** | `'BACK'` (`back=0.8..1.2`) | `'EASE_OUT'` | `EasingStyle.Back` (`Out`) | Automatically carries the limb/head/weapon slightly past the stop pose and settles back naturally. **Never use on floor contacts or inward chest axes.** |
| **Impact Hit-Stop / Freeze Accent** | `'CONSTANT'` (1–3 frames) | `'AUTO'` | `PoseEasingStyle.Constant` | Freezes the contact silhouette for 1–3 frames on heavy hits to amplify perceived kinetic force. |
| **Heavy Ground Slam / Knockdown** | `'BOUNCE'` | `'EASE_OUT'` | `PoseEasingStyle.Bounce` (`Out`) | Decaying impact rebound for dropped props, stunned bodies, or heavy club slams. |

### 5.3 Orthogonal Axis Easing Phase-Shift (Generating 3D Arcs with Zero Extra Keys)

Using one interpolation parameter for three Cartesian translation channels traces a straight segment only in that channel space. Rotational channels, constraints and rotating ancestors generally produce nonlinear world-space paths. Different axis timing can shape an arc, but neither equal nor different easing proves clearance. Inspect the evaluated limb and prop trajectories.

To make a limb trace a **true curved 3D arc** between Keyframe $A$ and Keyframe $B$:
- **Pair `EASE_OUT` on the Opening/Clearance Axis with `EASE_IN` on the Advancing Axis:**
  - *Example (Cross-Body Punch or Sword Slash):*
    - On `Arm_FK.rotation_euler.y` (outward abduction / opening) and `Arm_FK.location.z` (shoulder protraction): use `'CUBIC'` with `'EASE_OUT'` (changes rapidly in the first half of the transition, pushing the arm out in front of the torso immediately).
    - On `Arm_FK.rotation_euler.x` (forward/upward swing): use `'QUART'` with `'EASE_IN'` or `'EASE_IN_OUT'` (accelerates slightly later once the arm is already clear of the ribcage).
  - *Example (Foot Swing Arc in Walk/Run Cycle):*
    - Foot lift (`Leg-IK.location.y` up): `'QUAD'` `'EASE_OUT'` going up to peak clearance, then `'QUAD'` `'EASE_IN'` coming down to heel strike.
    - Foot forward travel (`Leg-IK.location.z`): `'CUBIC'` `'EASE_IN_OUT'` across the full swing duration.
    - These curves can produce a useful swing profile, but need not form a parabola or clear the floor. Measure the evaluated sole geometry, support frame and between-key clearance.

### 5.4 The 3 Golden Rules of Safe Multi-Easing

1. **Solve contacts in the evaluated world/contact frame:** Equal endpoint values with LINEAR or controlled Bezier handles can hold an unparented target, but LINEAR alone does not lock a moving-parent target or guarantee a stationary sole. Compute parent/root compensation, preserve the declared contact anchor and inspect evaluated geometry throughout the interval. Avoid unreviewed overshoot; choose interpolation by measured contact error, not a mandatory enum.
2. **Coordinate airborne IK in a common space:** MasterControl-parented targets are not inherently world-space when MasterControl moves. A shared root trajectory plus intentional relative tuck/extension is a useful baseline, but identical easing labels are neither necessary nor sufficient for valid reach. Measure evaluated hip-to-target distances using the actual rig's reach limits.
3. **Clamp Bezier Handles by Default:** Whenever `interpolation == 'BEZIER'` is used without manual tangent math, enforce `handle_left_type = 'AUTO_CLAMPED'` and `handle_right_type = 'AUTO_CLAMPED'` so curves never invent unwanted overshoots between extreme poses.

---

## 6. Biomechanical Realism & Anti-Lazy Pose Architecture (Fixing "Half-Assed Poses")

### 6.1 Whole-body review with intentional channel ownership

Review the whole body against the action brief; do not reject a wave, isolated overlay, held pose or restrained performance merely because other channels stay still. Grounded forceful actions often benefit from the following coordination pattern; it is an artistic planning model, not a universal force law:

$$\text{Planted Feet} \rightarrow \text{Leg Drive} \rightarrow \text{Pelvis Shift \& Yaw} \rightarrow \text{Torso Pitch/Roll} \rightarrow \text{Shoulder Protraction} \rightarrow \text{Arm Swing} \rightarrow \text{Head Stabilization}$$

Review these roles using this rig's verified controls; their names below are example-rig names, not a universal mapping:
1. **Pelvis/torso:** Choose the translation and rotation needed for support, intent and silhouette. Single-axis motion and holds are valid.
2. **Support leg:** Preserve the declared sole or pivot contact. R6 has no exported articulated knee; helper poles belong to the control rig only.
3. **Mobility leg:** Step, trail, hold or release according to the action. Parallel feet and symmetry can be intentional.
4. **Primary arm:** Shape a readable arc and inspect actual geometry for clearance.
5. **Off-arm:** Choose guard, counterbalance, expression or stillness deliberately; do not add movement merely to satisfy participation.
6. **Head:** Aim in a declared space and evaluate actual gaze. A fixed counter-yaw ratio cannot guarantee target tracking.

### 6.2 Legacy example-rig amplitude suggestions

The table below preserves historical recipe values for reference, not minimum requirements or biomechanical evidence. Its minimum/requirement labels are legacy terminology only. Do not use these numbers as audit thresholds. Choose amplitudes from the brief, measured rig scale and reference; restrained or stationary motion is valid.

| Animation Category | Min CoM Vertical Drop/Rise ($\Delta ly$) | Min Torso Yaw/Pitch Range | Stance & Foot Requirement | Off-Arm & Head Requirement |
|---|---|---|---|---|
| **Grounded Idle / Acting** | $0.03\text{ to }0.07\text{ studs}$ | $3^\circ\text{ to }10^\circ$ asymmetric | Staggered feet ($\Delta lz \ge 0.15\text{ studs}$), locked soles | Relaxed asymmetry ($\ge 6^\circ$ diff between L/R arms), living gaze |
| **Walk / Strafe Cycle** | $0.08\text{ to }0.16\text{ studs}$ | $8^\circ\text{ to }18^\circ$ counter-yaw | Full heel-to-toe roll & swing clearance $\ge 0.18\text{ studs}$ | Opposite arm/leg counter-swing ($\ge 25^\circ\text{ to }45^\circ$), stabilized head |
| **Run / Sprint Cycle** | $0.18\text{ to }0.32\text{ studs}$ | $15^\circ\text{ to }28^\circ$ forward lean + yaw | Distinct airborne phase + strong push-off extension | Vigorous arm drive ($\ge 55^\circ\text{ to }85^\circ$), focused forward sightline |
| **Combat Strike / Slash / Throw** | $0.15\text{ to }0.38\text{ studs}$ | $25^\circ\text{ to }65^\circ$ hip/shoulder whip | Wide lunge step ($\Delta lz \ge 0.65\text{ studs}$) supporting CoM | Strong backward counterbalance or guard on off-arm; head locks target |
| **Jump / Vault / Parkour** | $\ge 0.35\text{ studs}$ crouch, $\ge 1.2\text{ studs}$ apex | $20^\circ\text{ to }45^\circ$ compression-to-extension | Synchronized airborne IK lift + tucked/staggered air silhouette | Upward arm drive on takeoff, balance flare at apex, absorption on land |
| **Hit Reaction / Knockback** | $0.12\text{ to }0.30\text{ studs}$ drop | $20^\circ\text{ to }45^\circ$ impulse fold | Catch-step or slide recovery to re-establish base of support | Asymmetrical whiplash delay on arms and head ($2\text{ to }4$ frames lag) |

### 6.3 Kinematic Chain Phase Lag (Overlapping Action)

Use overlap where it serves the action. Simultaneous arrivals can intentionally communicate a sharp impact, synchronized action or hold. Record timing in seconds at the declared authoring frame rate; no fixed frame lag is universal.
- **Optional example of successive arrivals, to tune rather than enforce:**
  - Frame $t_0$: Pelvis shifts and leg pushes off (`LowerTorso-FK.location`, `Leg-IK`).
  - Frame $t_0 + 1$: Torso rotation whips through (`LowerTorso-FK.rotation_euler`).
  - Frame $t_0 + 2$: Dominant arm reaches peak extension (`RightArm_FK`).
  - Frame $t_0 + 3$: Off-arm and head finish their secondary overshoot/settle (`LeftArm_FK`, `Head`).

---

## 7. Blender 4.4+/5.x Multi-Easing & Anti-Clipping Python Authoring Engine

The embedded helper below is a legacy V2.22-oriented implementation, not a verified production module. Before reuse, check the actual Blender version's Action/slot/channelbag APIs and test on a protected action copy.

Known limitations requiring repair before general use:
- Socket clamps use fixed uncalibrated values and example bone names.
- Rotation authoring silently changes the mode to XYZ instead of preserving the source representation.
- Per-axis settings are not fully validated before scene mutation.
- Euler rewriting assumes XYZ, edits only existing component keys, and does not preserve intentional winding or prove between-key continuity.
- Bone RNA paths are assembled manually rather than obtained through the RNA path API.

Do not call these helpers automatically on user actions. Preserve the code as a historical reference until the specific adapter is repaired and exercised; documentation changes alone do not validate it.

```python
import bpy
from math import radians, degrees
from mathutils import Euler, Vector
from bpy_extras import anim_utils

# Valid Blender Keyframe interpolation and easing enums
VALID_INTERPOLATIONS = {
    'CONSTANT', 'LINEAR', 'BEZIER',
    'SINE', 'QUAD', 'CUBIC', 'QUART', 'QUINT', 'EXPO', 'CIRC',
    'BACK', 'BOUNCE', 'ELASTIC'
}
VALID_EASINGS = {'AUTO', 'EASE_IN', 'EASE_OUT', 'EASE_IN_OUT'}
VALID_HANDLES = {'FREE', 'VECTOR', 'ALIGNED', 'AUTO', 'AUTO_CLAMPED'}

# Anatomical socket clamps for R6 arms to prevent pivot dislocation
ARM_SOCKET_LIMITS = {
    'x': (-0.06, 0.06),
    'y': (-0.08, 0.08),
    'z': (-0.08, 0.14),
}


def get_or_create_channelbag(rig_obj):
    """Compatible with Blender 4.4 and 5.x Slotted Actions."""
    ad = rig_obj.animation_data
    if not ad or not ad.action:
        raise RuntimeError('Rig has no active Action assigned.')
    action = ad.action
    slot = ad.action_slot
    if slot is None:
        slot = action.slots.new(id_type='OBJECT', name=rig_obj.name)
        ad.action_slot = slot

    ensure_fn = getattr(anim_utils, 'action_ensure_channelbag_for_slot', None)
    if ensure_fn:
        return ensure_fn(action, slot)

    get_fn = getattr(anim_utils, 'action_get_channelbag_for_slot', None)
    if get_fn:
        bag = get_fn(action, slot)
        if bag is not None:
            return bag

    for layer in action.layers:
        for strip in layer.strips:
            if strip.type == 'KEYFRAME':
                bag = strip.channelbag(slot, ensure=True)
                if bag:
                    return bag
    raise RuntimeError('Could not resolve or create channelbag for Action slot.')


def clamp_val(v, lo, hi):
    return max(lo, min(hi, v))


def key_pose_eased(
    rig_obj,
    frame,
    bone_name,
    *,
    location=None,
    euler_deg=None,
    interp='CUBIC',
    easing='EASE_IN_OUT',
    axis_easing=None,
    handle_type='AUTO_CLAMPED',
    back=1.1,
    amplitude=0.4,
    period=0.3,
    clamp_socket=True
):
    """
    Insert a keyframe on `bone_name` at `frame` with full Multi-Easing support.
    
    - `interp`: Default interpolation ('LINEAR', 'BEZIER', 'SINE', 'QUAD', 'CUBIC',
      'QUART', 'QUINT', 'EXPO', 'CIRC', 'BACK', 'BOUNCE', 'ELASTIC', 'CONSTANT')
    - `easing`: Default easing direction ('EASE_IN', 'EASE_OUT', 'EASE_IN_OUT', 'AUTO')
    - `axis_easing`: Optional dict overriding (interp, easing) per channel, e.g.:
        {'rx': ('QUART', 'EASE_IN'), 'ry': ('CUBIC', 'EASE_OUT'), 'ly': ('QUAD', 'EASE_OUT')}
    - `clamp_socket`: Enforces anatomical shoulder socket bounds on LeftArm_FK / RightArm_FK.
    """
    if interp not in VALID_INTERPOLATIONS:
        raise ValueError(f'Invalid interpolation: {interp}')
    if easing not in VALID_EASINGS:
        raise ValueError(f'Invalid easing: {easing}')
    if handle_type not in VALID_HANDLES:
        raise ValueError(f'Invalid handle_type: {handle_type}')

    pb = rig_obj.pose.bones.get(bone_name)
    if pb is None:
        raise KeyError(f'Bone {bone_name!r} not found in {rig_obj.name}')

    scene = bpy.context.scene
    scene.frame_set(frame)
    axis_easing = axis_easing or {}

    if location is not None:
        lx, ly, lz = location
        if clamp_socket and bone_name in ('LeftArm_FK', 'RightArm_FK'):
            lx = clamp_val(lx, *ARM_SOCKET_LIMITS['x'])
            ly = clamp_val(ly, *ARM_SOCKET_LIMITS['y'])
            lz = clamp_val(lz, *ARM_SOCKET_LIMITS['z'])
        pb.location = (lx, ly, lz)
        pb.keyframe_insert(data_path='location', frame=frame, group=pb.name)

    if euler_deg is not None:
        if pb.rotation_mode != 'XYZ':
            pb.rotation_mode = 'XYZ'
        pb.rotation_euler = tuple(radians(a) for a in euler_deg)
        pb.keyframe_insert(data_path='rotation_euler', frame=frame, group=pb.name)

    # Apply per-channel interpolation & easing on the newly inserted keyframe points
    bag = get_or_create_channelbag(rig_obj)
    loc_path = f'pose.bones["{bone_name}"].location'
    rot_path = f'pose.bones["{bone_name}"].rotation_euler'
    loc_keys = ('lx', 'ly', 'lz')
    rot_keys = ('rx', 'ry', 'rz')

    for fcu in bag.fcurves:
        ch_tag = None
        if fcu.data_path == loc_path and 0 <= fcu.array_index < 3:
            ch_tag = loc_keys[fcu.array_index]
        elif fcu.data_path == rot_path and 0 <= fcu.array_index < 3:
            ch_tag = rot_keys[fcu.array_index]
        if ch_tag is None:
            continue

        ch_interp, ch_ease = axis_easing.get(ch_tag, (interp, easing))
        for kp in fcu.keyframe_points:
            if abs(kp.co.x - frame) < 1e-4:
                kp.interpolation = ch_interp
                kp.easing = ch_ease
                if ch_interp == 'BEZIER':
                    kp.handle_left_type = handle_type
                    kp.handle_right_type = handle_type
                elif ch_interp == 'BACK':
                    kp.back = back
                elif ch_interp == 'ELASTIC':
                    kp.amplitude = amplitude
                    kp.period = period
        fcu.update()


def unwrap_all_euler_fcurves(rig_obj):
    """
    Eliminates +/-180 deg Euler flips and gimbal sign inversions across all bones
    by making each sequential Euler triplet compatible with its predecessor.
    """
    bag = get_or_create_channelbag(rig_obj)
    for pb in rig_obj.pose.bones:
        rot_path = f'pose.bones["{pb.name}"].rotation_euler'
        fcurves = [
             next((f for f in bag.fcurves if f.data_path == rot_path and f.array_index == i), None)
            for i in range(3)
        ]
        if not all(fcurves):
            continue

        # Collect all unique keyed frames across rx, ry, rz
        frames = sorted({
            round(kp.co.x, 4)
            for fcu in fcurves
            for kp in fcu.keyframe_points
        })
        if len(frames) < 2:
            continue

        prev_eul = None
        for fr in frames:
            vals = [fcu.evaluate(fr) for fcu in fcurves]
            cur_eul = Euler(vals, 'XYZ')
            if prev_eul is not None:
                cur_eul.make_compatible(prev_eul)
                for idx, fcu in enumerate(fcurves):
                    for kp in fcu.keyframe_points:
                        if abs(kp.co.x - fr) < 1e-3:
                            kp.co.y = cur_eul[idx]
            prev_eul = cur_eul

        for fcu in fcurves:
            fcu.update()
```

---

## 8. Automated Sub-Frame OBB Collision, Pivot & Contact Audit (`audit_r6_clip`)

Because nonlinear easing styles (`CUBIC`, `QUINT`, `BACK`, `BEZIER`) curve *between* keyframes, inspecting only the keyed frames is insufficient. A limb may be outside the body at frame 10 and frame 16, yet slice through the chest or dip below the floor at frame $12.5$.

Run this **Sub-Frame OBB & Biomechanical Audit** across every integer and half-frame ($t, t + 0.5$) before delivering any animation:

```python
import bpy
from math import degrees
from mathutils import Vector, Matrix

def audit_r6_clip(
    rig_name='__PrimaryArmature',
    contact_windows=None,
    floor_z=0.0,
    foot_slip_tol=0.04,
    max_half_frame_deg=45.0
):
    """
    Audits the active R6 animation at every 0.5 frame for:
    1. Shoulder Socket Pivot Dislocation (> limits)
    2. IK Leg Hyperextension (> 1.96 studs) or Hyper-Compression (< 0.65 studs)
    3. Arm-into-Torso Oriented Bounding Box (OBB) Clipping
    4. Floor Penetration & Planted Foot Slip
    5. Sub-frame Angular Velocity / Gimbal Glitches (> max_half_frame_deg per 0.5 frame)
    """
    rig = bpy.data.objects[rig_name]
    scene = bpy.context.scene
    deps = bpy.context.evaluated_depsgraph_get()
    contact_windows = contact_windows or {}
    issues = []

    f_start, f_end = scene.frame_start, scene.frame_end
    steps = int((f_end - f_start) * 2) + 1
    prev_mats = {}

    # Pre-record planted foot world anchors at the start of each contact window
    foot_anchors = {}
    for bname, intervals in contact_windows.items():
        foot_anchors[bname] = {}
        for a, b in intervals:
            scene.frame_set(a)
            bpy.context.view_layer.update()
            eval_pb = rig.evaluated_get(deps).pose.bones[bname]
            foot_anchors[bname][(a, b)] = (rig.matrix_world @ eval_pb.matrix).translation.copy()

    for step in range(steps):
        fr = f_start + step * 0.5
        int_frame = int(fr)
        sub_frame = fr - int_frame
        scene.frame_set(int_frame, subframe=sub_frame)
        bpy.context.view_layer.update()
        eval_rig = rig.evaluated_get(deps)

        torso_pb = eval_rig.pose.bones.get('LowerTorso-FK')
        if torso_pb:
            torso_mat_w = eval_rig.matrix_world @ torso_pb.matrix
            torso_inv_w = torso_mat_w.inverted_safe()

            # 1 & 3. Check Arm Socket Lock & Arm-into-Torso OBB Clearance
            for arm_name, side_sign in (('LeftArm_FK', -1.0), ('RightArm_FK', 1.0)):
                arm_pb = eval_rig.pose.bones.get(arm_name)
                if not arm_pb:
                    continue
                loc = arm_pb.location
                if abs(loc.x) > 0.07 or abs(loc.y) > 0.09 or loc.z < -0.09 or loc.z > 0.15:
                    issues.append(f'[Frame {fr:.1f}] {arm_name} socket dislocated: loc={tuple(round(v, 3) for v in loc)}')

                arm_mat_w = eval_rig.matrix_world @ arm_pb.matrix
                # Sample mid-arm and tip points along the rigid R6 arm block in torso-local space
                for s_label, y_dist in (('mid', 1.0), ('tip', 1.85)):
                    pt_world = arm_mat_w @ Vector((0.0, y_dist, 0.0))
                    pt_torso = torso_inv_w @ pt_world
                    # Torso OBB interior approximation: |x| < 0.88, |y| < 0.88, |z| < 0.44
                    if abs(pt_torso.x) < 0.88 and abs(pt_torso.y) < 0.88 and abs(pt_torso.z) < 0.44:
                        issues.append(
                            f'[Frame {fr:.1f}] {arm_name} ({s_label}) clips inside Torso OBB: '
                            f'torso_local={tuple(round(v, 2) for v in pt_torso)}'
                        )

            # 2. Check Hip-to-Ankle IK Leg Distance Envelope
            for leg_name, hip_offset_x in (('LeftLeg-IK', -0.5), ('RightLeg-IK', 0.5)):
                leg_pb = eval_rig.pose.bones.get(leg_name)
                if not leg_pb:
                    continue
                hip_socket_w = torso_mat_w @ Vector((hip_offset_x, -1.0, 0.0))
                ankle_w = (eval_rig.matrix_world @ leg_pb.matrix).translation
                dist = (hip_socket_w - ankle_w).length
                if dist > 1.96:
                    issues.append(f'[Frame {fr:.1f}] {leg_name} over-extended ({dist:.2f} > 1.96 studs) -> leg detachment risk')
                elif dist < 0.65:
                    issues.append(f'[Frame {fr:.1f}] {leg_name} over-compressed ({dist:.2f} < 0.65 studs) -> IK flip risk')

                # 4. Check Floor Penetration & Planted Foot Slip
                if ankle_w.z < floor_z - 0.02:
                    issues.append(f'[Frame {fr:.1f}] {leg_name} penetrates floor (z={ankle_w.z:.3f})')

                for (a, b), anchor in foot_anchors.get(leg_name, {}).items():
                    if a <= fr <= b:
                        slip = (ankle_w - anchor).length
                        if slip > foot_slip_tol:
                            issues.append(f'[Frame {fr:.1f}] {leg_name} slips {slip:.3f} studs during planted window [{a}, {b}]')

        # 5. Sub-frame Angular Velocity Glitch Check
        for pb in eval_rig.pose.bones:
            cur_q = (eval_rig.matrix_world @ pb.matrix).to_quaternion()
            if pb.name in prev_mats:
                diff_q = prev_mats[pb.name].rotation_difference(cur_q)
                deg_step = degrees(diff_q.angle)
                if deg_step > max_half_frame_deg:
                    issues.append(
                        f'[Frame {fr:.1f}] {pb.name} angular spike: {deg_step:.1f} deg in 0.5 frame '
                        f'(check Euler wrap or IK pole flip)'
                    )
            prev_mats[pb.name] = cur_q

    scene.frame_set(f_start, subframe=0.0)
    return issues
```

---

## 9. Eight-Pass Production Pipeline for Every Animation

### PASS 1 — Biomechanical & Easing Blueprint
Define the character's weight, intent, base of support, CoM trajectory, contact intervals, and which easing style governs each phase (`SINE`, `QUAD`, `CUBIC`, `QUART`, `QUINT`, `EXPO`, `CIRC`, `BACK`, `BOUNCE`, `ELASTIC`, `LINEAR`, `CONSTANT`).

### PASS 2 — Whole-Body Golden Poses (6-Part Mandate)
Block the key storytelling poses appropriate to the action: ready, anticipation, launch/passing, extreme/contact, follow-through and recovery. Evaluate the whole-body silhouette and support, but allow purposeful stillness, symmetry and partial-body clips. Verify measured socket connectivity; calibrate any `ARM_SOCKET_LIMITS` before using them.

### PASS 3 — Contact Locks & IK Envelope Solve
Key the verified leg controls and poles. Solve the evaluated sole/contact frame relative to its support, compensating for moving ancestors. Choose interpolation by measured between-key error, not a mandatory LINEAR setting. Measure reach and socket integrity on this rig; the legacy numeric envelope is not a universal acceptance bound.

### PASS 4 — Evaluated clearance and breakdowns
Inspect limb and prop paths through transitions, especially cross-body motion. Add or adjust breakdowns where measured clearance or readability requires them. Choose their timing, direction and interpolation from the actual rig and action, not a fixed angle threshold or compulsory outward bow.

### PASS 5 — Intentional overlap
Choose simultaneous or staggered arrivals from the action brief and reference. Record offsets in seconds at the actual frame rate. Recheck contacts after retiming; no fixed pelvis-to-head delay is mandatory.

### PASS 6 — Curve polish and rotation continuity
Shape spacing to preserve holds, impact and recovery. Inspect actual rotation modes, component key times, handles and intentional winding before correcting a discontinuity. Work on a copy and compare evaluated motion afterward. Do not run the legacy unwrap helper as a universal repair: compatibility of adjacent Euler representations does not eliminate gimbal lock, solver flips or between-key errors.

### PASS 7 — Evaluated audit and multiview review
Use calibrated checks for actual deform geometry, sole/contact frames, socket separation and rotation continuity. Refine temporal samples near impacts and suspected failures; inspect front, side and three-quarter moving playback. The legacy `audit_r6_clip` is a limited example, not an acceptance gate: it uses fixed dimensions, control origins and centerline samples, and does not restore the original frame. Do not execute it unchanged on user scenes. Investigate reported deviations against declared tolerances rather than treating every rapid motion as a defect.

### PASS 8 — Bake to `InternalArmature` & Roblox Verification
Bake the evaluated motion onto the export R6 skeleton (`InternalArmature`) or export via the confirmed `.rbxanim` / FBX pipeline. Verify that loop boundaries match both position and velocity ($P(0) = P(T)$ and $\dot{P}(0^+) \approx \dot{P}(T^-)$).

---

## 10. Action Family Recipes with Multi-Easing & Anti-Clipping

### 10.1 Grounded Expressive Idle (Seamless Loop)
- **Whole-Body Mechanics:** Stagger feet (`LeftLeg-IK.lz = -0.12`, `RightLeg-IK.lz = +0.10`, stance width $\pm 0.05$). Shift pelvis slightly over the lead support leg (`LowerTorso-FK.lx = -0.04`). Offset left and right arms asymmetrically so the silhouette never looks mirrored.
- **Easing Profile:** Use `'SINE'` with `'EASE_IN_OUT'` on `LowerTorso-FK.ly` ($\Delta ly = 0.04\text{ studs}$), `LowerTorso-FK.rx`, and `Head` for organic breathing. Solve and verify stationary support-relative contacts for both feet; LINEAR channels alone do not establish a world lock.

### 10.2 Dynamic Walk / Run Cycle
- **Whole-Body Mechanics:** Full 8-phase gait (`Left Contact -> Down -> Passing -> Up -> Right Contact -> Down -> Passing -> Up -> Left Contact`). Counter-rotate `LowerTorso-FK.ry` ($\pm 10^\circ\text{ to }\pm 22^\circ$) against the leading leg, add lateral hip shift (`lx`) over the stance foot, and counter-swing both arms with outward clearance ($ry = 6^\circ\text{ to }12^\circ$ abducted).
- **Easing Profile:**
  - Stance foot: compensate for the actual root/controller trajectory and evaluate the sole in support space. Linear compensation can suit constant-speed translation, but turns, changing speed and rotating ancestors need evaluated correction.
  - Swing foot lift (`ly`): `'QUAD'` `'EASE_OUT'` lifting to passing peak, `'QUAD'` `'EASE_IN'` descending to heel contact.
  - Swing foot forward stride (`lz`): `'CUBIC'` `'EASE_IN_OUT'`.
  - Pelvis vertical bounce (`LowerTorso-FK.ly`): `'SINE'` `'EASE_OUT'` into peak height, `'SINE'` `'EASE_IN'` into weight acceptance down-pose.

### 10.3 Heavy Melee Slash / Stylized Combat Strike
- **Whole-Body Mechanics:**
  1. *Anticipation (Coil):* Step rear foot back, drop CoM ($\Delta ly = -0.22\text{ studs}$), twist torso away (`ry = -35^\circ`), bring weapon arm back with outward abduction clearance, raise off-arm as a forward balance guard, keep `Head` locked on the forward target (`Head.ry = +22^\circ`).
  2. *Outward-Bowed Mid-Swing Breakdown:* Step lead foot forward (`lz = -0.75\text{ studs}$), drive pelvis forward (`lz = -0.35\text{ studs}$), whip torso yaw toward target (`ry = +10^\circ`), bow striking arm **outward and forward** (`lz = +0.10`, outward `ry`, `rx = +70^\circ`) so the arm clears the ribcage.
  3. *Impact Extreme:* Full torso snap (`ry = +42^\circ`, `rx = -18^\circ`), striking arm extended across target line with `lz = +0.12` chest clearance, off-arm swept back as a dynamic counterbalance (`rx = -35^\circ`, outward `ry`).
  4. *Follow-Through, Overshoot & Recovery:* Carry the blade/arm $6^\circ\text{ to }10^\circ$ past impact, compress the front knee (`LowerTorso-FK.ly = -0.26`), then settle smoothly back to ready stance.
- **Easing Profile:**
  - Anticipation coil: `'CUBIC'` `'EASE_IN_OUT'`.
  - Strike launch to Impact: `'QUINT'` `'EASE_IN'` on forward sweep, paired with `'CUBIC'` `'EASE_OUT'` on outward abduction clearance.
  - Optional 1–2 frame impact accent: `'CONSTANT'`.
  - Follow-through overshoot & settle: `'BACK'` (`back=0.95`) `'EASE_OUT'` on upper body and arms (while planted feet retain verified support-relative compensation).
  - Recovery to Ready: `'CUBIC'` `'EASE_IN_OUT'`.

### 10.4 Explosive Jump, Flip, & Landing Absorption
- **Whole-Body Mechanics:** Deep preparatory crouch ($\Delta ly = -0.38\text{ studs}$, torso pitched forward $rx = -22^\circ$, arms swept back $rx = -45^\circ$) $\rightarrow$ explosive full-body extension at takeoff ($\Delta ly = +0.15\text{ studs}$, arms thrown upward $rx = +135^\circ$) $\rightarrow$ airborne tuck/stagger at apex (lead leg tucked higher than trail leg for an asymmetric silhouette; pole targets raised with pelvis) $\rightarrow$ ground contact $\rightarrow$ deep landing absorption ($\Delta ly = -0.35\text{ studs}$) $\rightarrow$ controlled rise to idle.
- **Easing Profile:**
  - Crouch to Takeoff: `'QUART'` `'EASE_IN'`.
  - Takeoff to Apex (Ascent): `'QUAD'` `'EASE_OUT'` as an artistic starting profile. Coordinate torso, leg targets and poles in a common evaluated space; matching easing labels alone cannot prevent overreach or detachment.
  - Apex to Ground Contact (Descent): `'QUAD'` `'EASE_IN'`.
  - Landing Contact to Deep Compression: `'QUART'` `'EASE_OUT'` (fast initial impact absorption, soft bottoming out).
  - Compression to Standing Recovery: `'CUBIC'` `'EASE_IN_OUT'`.

---

## 11. Troubleshooting Encyclopedia (Clipping, Pivots, Glitches & Easing)

| Symptom | Root Cause | Exact Technical Fix |
|---|---|---|
| **Arm rotates around mid-air or cuts into the chest** | Possible displaced control pivot, wrong rest-space interpretation or competing driver | Inspect control-to-deform mapping and evaluated socket separation before editing. Preserve calibrated attachment frames; create feasible reach through torso and limb motion rather than imposing unmeasured numeric clamps. |
| **Arm slices straight through the ribcage during a swing** | Straight-line chord interpolation across the chest or wrong local `ry` sign | Run the single-axis calibration probe; insert an outward-bowed midpoint breakdown pose; set outward abduction to `EASE_OUT` and forward pitch to `EASE_IN`. |
| **Limb or torso violently spins $360^\circ$ for 1–2 frames** | Euler discontinuity ($\pm 180^\circ$ wrap or flipped Euler decomposition) | Call `unwrap_all_euler_fcurves(rig)` (`cur_euler.make_compatible(prev_euler)`) and verify with `audit_r6_clip()` at $0.5$-frame steps. |
| **Leg flips during a lunge, kick or turn** | Possible degenerate bend plane, competing driver, discontinuous control or unsuitable pole trajectory | Reproduce the first failing transition, inspect evaluated controls and solver settings, and preserve a calibrated continuous bend plane. Measure reach on this rig; do not impose a fixed forward pole or universal stud envelope. |
| **Legs stretch or remain grounded during a jump** | Possible target-space mismatch, unreachable target, stale contact lock or competing driver | Inspect actual parent spaces and contact ownership. Coordinate the airborne root, targets and poles in a common evaluated space, release intended contacts, and verify reach and socket continuity. Identical easing labels are not a general fix. |
| **Planted foot sinks or skates** | Possible overshoot, moving-parent compensation error, wrong contact feature, or competing driver | Reproduce the failing time, inspect evaluated sole/support frames and driver ownership, then solve compensation and validate interval interiors. Changing interpolation alone is not a general fix. |
| **Motion reads as unintentionally stiff** | Possible weak staging, uniform spacing, unsupported weight transfer or missing follow-through | Compare against the action brief and reference. Adjust silhouette, timing, support and secondary motion where needed; do not force minimum amplitudes or motion onto intentionally held channels. |

---

## 12. Quality Rubric & Delivery Protocol

Every animation is evaluated against a **100-point production rubric** before completion:
1. **Whole-Body Posing and Readability (25 pts):** Clear action intent, appropriate support and weight transfer, readable silhouette and deliberate gaze/off-arm choices. Judge held channels, symmetry and partial-body motion against the brief rather than mandatory movement.
2. **Pivot Integrity & Clearance (25 pts):** Measured socket connectivity and reachable targets on the actual rig; evaluated geometry checked against declared clearance tolerances. Record temporal coverage and limitations. The sample centerline diagnostic is not a full OBB solver or proof of continuous collision freedom.
3. **Timing, Spacing and Arcs (20 pts):** Interpolation, breakdowns and overlap serve the intended motion. A simple curve is valid; neither easing variety nor a fixed frame lag earns quality by itself. Verify world-space paths after polishing.
4. **Contacts and rotation continuity (15 pts):** Support-relative contact errors meet declared tolerances; intentional pivots, slides and rapid motion remain intact. Inspect bend-plane continuity and intended rotation paths. Record sampling limits rather than claiming zero error everywhere.
5. **Pipeline & Roblox Readiness (15 pts):** Valid Blender 4.4+/5.x slotted Action, clean loop seam or recovery pose, verified bake/export report.

### Final Delivery Report Template

```text
Animation: <name and concise biomechanical summary>
Rig & Blender Version: <verified armature, driven skeleton, Blender version>
Duration / FPS / Loop: <frame range, FPS, loop or one-shot, root motion mode>
Whole-Body Participation: <how Pelvis, Torso, Both Legs, Both Arms, and Head were coordinated>
Easing Architecture Used: <breakdown of easing styles & directions applied per phase/channel>
Pivot & Anti-Clipping Audit: <results of audit_r6_clip() across 0.5-frame steps: socket lock, OBB clearance, foot slip, Euler continuity>
Deliverable: <Action name / script status / exported file path>
```

## 16. Deep R6 Engine Math & Procedural Reference
Load [references/r6-motor6d-procedural-and-ik-physics.md](references/r6-motor6d-procedural-and-ik-physics.md) for the exact canonical R6 `Motor6D` `C0`/`C1` rest matrices (`RootJoint`, `Neck`, `Right/Left Shoulder`, `Right/Left Hip`), `RunService.PreSimulation` critically damped spring overlays on `Motor6D.Transform`, phantom knee/elbow choreography rules, and quaternion hemisphere continuity checks during `.rbxanim` baking.
