# R6 Motor6D Transform Equations, Procedural Luau Overlays & V2.22 Control Mapping

Deep engineering reference for classic Roblox R6 6-part (`HumanoidRootPart`, `Torso`, `Head`, `Left Arm`, `Right Arm`, `Left Leg`, `Right Leg`) `Motor6D` C0/C1 matrix equations, `RunService.PreSimulation` procedural spring overlays, and Aeresei R6 IK+FK V2.22 Blender control rig choreography.

---

## 1. Inspect Actual R6 `Motor6D` C0 and C1 Rest Matrices

The table below is a nominal stock-rig reference, not authority to overwrite a target's rest matrices. Read actual Part0/Part1, C0/C1 and dimensions, verify the neutral relation, and preserve importer metadata. R6 has six visible rigid body parts plus HumanoidRootPart. The rest-pose Euler decomposition is non-unique; compare matrices, not displayed Euler triples.

In a standard Roblox R6 rig, all 6 `Motor6D` joints satisfy:

$$\text{Part0.CFrame} \times C_0 \times \text{Transform} = \text{Part1.CFrame} \times C_1$$

Notice that Roblox's stock R6 `RootJoint`, `Neck`, and Shoulder/Hip motors include built-in $90^\circ$ Euler rotations in `C0` and `C1`:

| Motor6D Name | Parent (`Part0`) | Child (`Part1`) | Canonical `C0` (`Position`, `EulerXYZ` deg) | Canonical `C1` (`Position`, `EulerXYZ` deg) |
|---|---|---|---|---|
| `RootJoint` | `HumanoidRootPart` | `Torso` | `(0, 0, 0)` · `(-90°, 0°, -180°)` | `(0, 0, 0)` · `(-90°, 0°, -180°)` |
| `Neck` | `Torso` | `Head` | `(0, 1, 0)` · `(-90°, 0°, -180°)` | `(0, -0.5, 0)` · `(-90°, 0°, -180°)` |
| `Right Shoulder` | `Torso` | `Right Arm` | `(1, 0.5, 0)` · `(0°, 90°, 0°)` | `(-0.5, 0.5, 0)` · `(0°, 90°, 0°)` |
| `Left Shoulder` | `Torso` | `Left Arm` | `(-1, 0.5, 0)` · `(0°, -90°, 0°)` | `(0.5, 0.5, 0)` · `(0°, -90°, 0°)` |
| `Right Hip` | `Torso` | `Right Leg` | `(1, -1, 0)` · `(0°, 90°, 0°)` | `(0.5, 1, 0)` · `(0°, 90°, 0°)` |
| `Left Hip` | `Torso` | `Left Leg` | `(-1, -1, 0)` · `(0°, -90°, 0°)` | `(-0.5, 1, 0)` · `(0°, -90°, 0°)` |

### Why Direct `C0` Scripting Breaks Axis Intuitiveness (And Why `Motor6D.Transform` Is Mandatory)
Because `Right Shoulder` and `Right Hip` have $+90^\circ$ Y-rotations baked into `C0`/`C1` while `Left Shoulder` and `Left Hip` have $-90^\circ$ Y-rotations:
- Pitching a limb forward in `Motor6D.Transform` space uses $+Z$ on the Right side and $-Z$ on the Left side when working in raw `Motor6D` space, **whereas** Cautioned's `.rbxanim` importer and Blender's world-aligned rig bones automatically convert bone delta matrices via `nicetransform` / `transform` / `transform1` metadata.
- In runtime Luau procedural code, **always write to `Motor6D.Transform` inside `RunService.PreSimulation`** rather than mutating `C0`, so your procedural tilt, recoil, or foot plant batches cleanly in parallel with the `Animator`.

---

## 2. Procedural R6 Critically Damped Spring Overlay (`RunService.PreSimulation`)

Because R6 lacks knees and elbows, a post-Animator Transform overlay can add velocity lean. The illustrative snippet below is not production lifecycle management: it assumes the Animator freshly rewrites both joints each frame. Before use, prevent stale-overlay accumulation when evaluation stops or is throttled, define baseline ownership and composition order, and disconnect/reset on character teardown. Its analytic spring update is exact for a target held constant during each time step, not for arbitrary continuously changing targets.

```lua
local RunService = game:GetService("RunService")

local function stepCriticallyDampedSpring(pos: Vector3, vel: Vector3, target: Vector3, omega: number, dt: number): (Vector3, Vector3)
    local delta = pos - target
    local expTerm = math.exp(-omega * dt)
    local newPos = (delta * (1 + omega * dt) + vel * dt) * expTerm + target
    local newVel = (vel * (1 - omega * dt) - delta * (omega * omega * dt)) * expTerm
    return newPos, newVel
end

-- Layer velocity-driven torso tilt and landing compression onto R6 RootJoint.Transform
local function attachR6ProceduralOverlay(character: Model)
    local hrp = character:WaitForChild("HumanoidRootPart") :: BasePart
    local torso = character:WaitForChild("Torso") :: BasePart
    local rootJoint = hrp:FindFirstChild("RootJoint") :: Motor6D
    local neck = torso:FindFirstChild("Neck") :: Motor6D
    if not (rootJoint and neck) then return end

    local leanPos, leanVel = Vector3.zero, Vector3.zero
    local omega = 14.0 -- rad/s responsiveness

    return RunService.PreSimulation:Connect(function(dt: number)
        local localVel = hrp.CFrame:VectorToObjectSpace(hrp.AssemblyLinearVelocity)
        local targetLean = Vector3.new(
            math.clamp(-localVel.Z * 0.008, -0.22, 0.22), -- Forward/back pitch
            0,
            math.clamp(-localVel.X * 0.010, -0.25, 0.25)  -- Strafe bank
        )
        leanPos, leanVel = stepCriticallyDampedSpring(leanPos, leanVel, targetLean, omega, dt)

        -- Layer cleanly onto Animator's evaluated Transform
        rootJoint.Transform = rootJoint.Transform * CFrame.Angles(leanPos.X, 0, leanPos.Z)
        neck.Transform = neck.Transform * CFrame.Angles(-leanPos.X * 0.65, 0, -leanPos.Z * 0.65)
    end)
end
```

---

## 3. R6 Illusion of Bend & Phantom Knee/Elbow Choreography

These are optional stylization recipes, not engine requirements or universal safe bounds. Calibrate dimensions, contacts and socket visibility on the actual rig. Vertical means Roblox +Y or Blender world +Z; control-bone local axes must be inspected. For quaternion baking, normalize and use hemisphere continuity for shortest-path segments; shortest-path SLERP already handles sign equivalence, while intentional spins require intermediate samples.

## Authoritative runtime sources
- [Motor6D](https://create.roblox.com/docs/reference/engine/classes/Motor6D): Transform and deferred evaluation timing.
- [AnimationConstraint](https://create.roblox.com/docs/reference/engine/classes/AnimationConstraint): kinematic versus physical operation and migration boundaries.
- [RunService](https://create.roblox.com/docs/reference/engine/classes/RunService): animation/simulation lifecycle events.

### Optional pose recipes

Because each R6 limb is a single $1 \times 2 \times 1\text{ stud}$ rigid monolith with no intermediate hinge:
1. **Phantom Knee Compression (Impact / Down Pose)**: Drop `Torso` vertically ($\Delta z \in [-0.20, -0.38]\text{ st}$), pitch `Torso` forward ($+8^\circ$ to $+14^\circ$), flare the stance leg outward slightly in roll ($\pm 4^\circ$) and yaw ($\pm 8^\circ$), and translate the hip socket within the strict detached-joint envelope ($\le 0.14\text{ st}$) so the viewer's eye perceives leg flexion.
2. **Weapon / Swing Arc Amplification**: Without an elbow hinge, a flat shoulder rotation reads like a stiff clock hand. Combine **Torso anticipation twist** ($-25^\circ$) $\to$ **Torso snap-through** ($+30^\circ$) + **Shoulder diagonal 3-axis sweep** (Pitch + Yaw + Roll) + **1-to-2 frame detached socket extension** ($+0.12\text{ st}$ along the swing vector at the hit frame) to simulate full-arm whip.
3. **Quaternion Hemisphere Continuity**: Whenever baking R6 IK controls (`__PrimaryArmature` in Aeresei V2.22) down to `InternalArmature` deform bones for `.rbxanim` export, normalize and choose consistent hemispheres for intended shortest-path segments. Test the actual interpolator: shortest-path SLERP already handles equivalent signs, and deliberate multi-turn motion needs intermediate keys.
