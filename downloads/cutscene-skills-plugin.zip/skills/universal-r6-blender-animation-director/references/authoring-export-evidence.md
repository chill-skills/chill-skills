# Source-grounded authoring and export practices

## Representation contract
Use sparse Bezier or deliberately selected easing for editing; bake evaluated constraints/drivers onto the verified export skeleton for transport. Dense LINEAR exports are valid, not robotic by definition: sample values encode timing. Finite samples approximate continuous motion. Compare source and imported output at keys and midpoints, adapt sample rate near impacts, then validate contacts, silhouettes, hierarchy and loop velocity. Do not add ease-in/out to each already baked interval. Keep source action, sample FPS/step, rotation order, root strategy and error tolerances in the report.

Blender's Bake Action exposes Visual Keying and Frame Step. Never clear constraints or overwrite the only source action without a protected copy. Inspect the actual action slot/channelbag and NLA contributions; an assigned action without the correct slot is not verified playback.

## API corrections
- PoseEasingStyle and TweenService EasingStyle are different enums. Do not directly assign Sine/Quint/etc. to Pose.EasingStyle. Use supported pose easing, measured curve fitting or dense sampling.
- FloatCurveKey uses Constant/Linear/Cubic KeyInterpolationMode. Cubic uses Hermite slopes. Arbitrary Blender Bezier handles require conversion/approximation, not a renamed enum.
- Preserve EulerRotationCurve.RotationOrder and the Blender bone rotation mode. Never silently force a preanimated quaternion or non-XYZ Euler control to XYZ. For Euler compatibility, evaluate complete triplets in the bone's order; sparse unsynchronized component keys and intentional multi-turn spins require special handling. Hemisphere correction is a representation choice, not proof of collision-free motion.
- Full OBB testing requires more than centerline containment. The embedded diagnostic can miss edge/corner intersections and incorrect sole height. Use actual evaluated bounds, correct origins and units, contact-point trajectories, adaptive sampling and visual checks; never report its empty list as a zero-clipping certificate.
- R6 lacks physical elbow/knee joints in its six rigid body parts. Control-rig IK helpers do not add exportable R15 joints. Read actual Part.Size and rest transforms rather than treating nominal dimensions or fixed socket/leg thresholds as universal.
- A stationary world-space contact requires solving parent/root motion, not merely LINEAR keys. Purposeful stillness, matched beats and same-axis poses are valid; amplitude and frame-lag recipes are artistic starting points, not scientific minimums.

## Verification gates
1. Identify trusted source rig and target hierarchy; preserve metadata and security checks.
2. Audit source curves and evaluated motion separately from baked samples.
3. Record duration in seconds using effective FPS, include intended closing key for exported loop duration, and avoid double-playing the duplicate in previews.
4. Round-trip through the actual target pipeline. Distinguish file export, native Studio playback and published asset ID; never fabricate any of these.
5. A missing runtime/import check remains unverified. Static script compilation cannot certify Blender execution or Studio playback.

## Sources
- [Editing Strips — Bake Action](https://docs.blender.org/manual/en/latest/editors/nla/editing/strip.html)
- [Actions](https://docs.blender.org/manual/en/latest/animation/actions.html)
- [F-Curve Properties](https://docs.blender.org/manual/en/latest/editors/graph_editor/fcurves/properties.html)
- [PoseEasingStyle](https://create.roblox.com/docs/reference/engine/enums/PoseEasingStyle)
- [FloatCurveKey](https://create.roblox.com/docs/reference/engine/datatypes/FloatCurveKey)
- [EulerRotationCurve](https://create.roblox.com/docs/reference/engine/classes/EulerRotationCurve)

These sources define software behavior; rig-specific artistic limits and sample tolerances remain explicit project policy.
