# Performance and editorial decisions

## Listening and subtext

Write a playable intention rather than only an emotion: obtain reassurance, conceal recognition, refuse without provoking. Then identify the stimulus that changes the tactic. A speaker may keep talking while the listener makes the important decision; coverage should follow dramatic information rather than the mouth currently moving.

Design visible evidence at the rig's available resolution. A halted prop task, changed head direction, withdrawn reach or yielded space may communicate more than repetitive talking gestures. A rear view can work when its silhouette carries the decision; a face close-up is not compulsory. Body-only staging is not facial animation. Concealed thought is legitimate when the scene intentionally withholds it, but do not label missing evidence deliberate after a failed review.

## Motivated cuts and holds

| Symptom | Diagnose before editing | Candidate comparison |
|---|---|---|
| Dialogue feels mechanical | Does coverage follow every speaker change? Is anyone listening? | Shared view versus reaction coverage at the actual choice |
| Scene drags | Is information redundant, or is the decisive thought unclear? | Remove repeated evidence, not the only response |
| Scene feels rushed | Can the viewer register stimulus, caption and consequence? | Longer hold around the turn versus another cut |
| Performance seems stiff | Is the pose intentional, supported and readable? | Improve staging/spacing before adding idle noise |
| Cut feels confusing | What changed in eyeline, focus, action phase or geography? | Repair continuity or add an orienting cue |
| Ending feels detached | Is the choice resolved and playable route legible? | Reframe handback around heading and objective |

Locate the thought at moving-playback speed, then inspect nearby frames. Choose whether to cut before a response (anticipation), during it (shared discovery), or after it (consequence). These are hypotheses, not guaranteed emotional effects. Review trim handles and action continuity when an external editor is used; in an authored cutscene, update supported source timing and rebuild rather than treating a flattened movie edit as the runtime source.

## Continuity is physical and dramatic

Track prop hand/orientation, contact and support, travel direction, costume state, eyelines and landmarks. Also track who knows the secret and when the audience learns it. A technically matched insert can still spoil a reveal. Intentional discontinuity is allowed; state its purpose and test comprehension instead of imposing mechanical continuity at all costs.

Declare source FPS or decoded timestamps, authoring timebase and mapping. Do not transfer frame-count recipes blindly. Retiming requires rechecking contacts, captions, cues and recovery; a camera edit alone cannot validate actor timing.

## Research-led worked comparison — proposed, not executed

**Original scene: the observatory message.** An NPC withholds part of some news; the player chooses to inspect an existing nearby instrument. The NPC knows the withheld detail; player/audience learn only that information is incomplete. Record the literal subtitle requirement separately from the intended evasiveness. Do not demand that a silent body rig convey the missing words.

| Beat | Knowledge / performance | Coverage and reaction exit |
|---|---|---|
| Shared task | Establish NPC, player and instrument; NPC interrupts a routine task to disclose incomplete information. | Keep the relationship and destination readable. Speaker change alone is not a cut reason. |
| Player response | Player stops a reach, redirects head/torso, then chooses to investigate. | A: hold shared. B: one listener-favored medium view with identical text and actor timing. Exit when the interrupted action, necessary reading and decision register, not after a borrowed delay. |
| Consequence | NPC yields space or turns away; player commits toward instrument. | Preserve prop support/hand state and landmark direction. Finish in a route-readable view; omit a redundant return shot if already clear. |

**Evidence → hypothesis:** LIS sampled group/isolated views and one verified adjacent-frame cut establish that coverage changes; they do not establish the listener's private thought or an ideal reaction interval. Its later rear view/objective UI suggests visual handback, not restored controls. Piano's recipient-favored compositions offer another listening option but have only nominal preview timing. Ask uninformed reviewers what changed, whose response mattered and where to go; retain held coverage if the insert adds no needed information. Keep disagreement and not-tested status.

**Body-only re-authoring:** R6 needs whole-arm interruption, head/torso orientation and readable distance/silhouette, not R15 joint copying, facial cues or fingers. Re-solve contacts and inspect keys, midpoints and extrema under actual costumes/captions. Keep separate current-build R15/R6 moving takes and verdicts; override-file presence or a successful master render is not R6 acceptance. In this pack the derived player route uses stock R6/default stand, not independently captured R6 player proportions.

Record each reaction's observable exit condition and provisional/tested interval separately. For each beat track audience and every character's knowledge before → after, who can see the stimulus, and whose response must stay visible. These are prose review fields, never new runtime cue data.

## Sound and split edits: editorial scope only

A J-cut introduces incoming-scene audio before its picture; an L-cut continues outgoing-scene audio after the picture changes. They can preserve a thought across a visual transition in a supported editor, but require actual authorized audio, synchronization and a tested output pipeline. A subtitle overlap is not proof of an audio split edit.

For make-cutscene, record intended voice/sound source, onset, tail, perspective, priority, rights and visual/caption equivalent in prose. Current SFX/voice/facial cues are not dispatched end-to-end; do not add fictional cue fields or sound commands. Silence cannot be inferred from a silent video file or a subtitle gap. Actual dialogue cleanup must preserve meaning, natural breaths and intelligibility, not mechanically erase every pause.

## Animatic A/B procedure

1. Fix the scene goal and name one uncertainty: for example, whether the listener's choice is legible before the return wide.
2. Keep source/build identities, rigs, viewport, captions and optional effects comparable. Record intentional differences rather than claiming uncontrolled variants isolate a cause.
3. Change one coverage or timing decision. Use neutral A/B labels; alternate presentation order where feasible and record order effects.
4. Ask without coaching: what happened, who wanted what, when did it change, and where would you go next? Record actual answers separately from your interpretation.
5. Compare against the prediction. Accept, reject or mark inconclusive; a small informal sample is diagnostic, not population evidence.
6. Recheck both rigs, contact/caption/cue timing, accessibility constraints and handback after the chosen edit. Preserve previous evidence and record its build; do not relabel stale captures current.

## Gameplay handback

Plan exit position, heading, objective, camera relationship, control and immediate danger. In the actual authorized engine test, verify natural end, permitted skip, death/respawn and interrupted return; restore owned camera/control/anchor state and clean up temporary actors/tracks/effects. Mark intentionally unavailable skip as not applicable. The planning record cannot prove these behaviors. For make-cutscene, follow its existing review checklist and runtime owner, not a competing camera loop.

## Evidence basis

The relayed movie study (development archive; not bundled) used nominal public scrub-preview samples, not decoded frames; the game study (development archive; not bundled) used decoded sampled stills and one LIS consecutive-frame cut. Neither included continuous viewing, listening or input observation. Preserve source identity, preview interval or decoded file/PTS/timebase, and source-alignment uncertainty; never turn nominal times into exact edits. See [research lessons and official sources](../../make-cutscene/references/movie-research-lessons.md). These are reported observations, not a new viewing by this integration pass. Public access grants no redistribution clearance: keep source media/dialogue out of production skills and assets; use original staging proposals only.

Prior context comes from craft research (development archive; not bundled) and GateGuard contact-sheet study (development archive; not bundled), plus installed editing-skill guidance. Supplemental repository links are not dependencies for standalone use. GateGuard return-wide samples preserve geography but cannot establish a rear-view listener's emotion; that is an evidence gap, not proof of absent reaction.

Primary source pointers retained from that research (not freshly fetched here):
- [How to Approach an Acting Test](https://www.animationmentor.com/blog/how-to-approach-an-acting-test/) — article read by the research worker; motivation/subtext.
- [10 Advanced Acting Performance Tips for Animators](https://www.animationmentor.com/blog/10-advanced-acting-performance-tips-for-animators/) — opening sections extracted; stillness/acting within a pose, not a full-article claim.
- [Learn how to edit video | Adobe](https://www.adobe.com/creativecloud/video/discover/edit-a-video.html) — article text read; iterative pacing and story/emotion priorities.

These sources inform testable choices, not universal durations or proof that the delivered scene succeeds.
