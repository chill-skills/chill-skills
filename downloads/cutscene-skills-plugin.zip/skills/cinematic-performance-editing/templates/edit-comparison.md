# Edit comparison record

Planning/review worksheet only; not runtime schema.

## Identity and question
- Scene/revision; source/build/take identities; rig; viewport/settings:
- Source URL/creator/rights; observed facts separate from interpretations; no source media redistribution:
- Evidence mode and coverage: nominal preview / decoded still / consecutive frames / continuous viewing / audio / actual input; unknowns:
- Nominal label + preview interval OR decoded file identity + PTS/timebase/FPS; source-alignment uncertainty:
- Authored timebase, mapping/offsets; provisional versus actually tested timing:
- Intended change and viewpoint owner:
- One disputed choice; predicted result; observation that would disprove it:

## Performance ledger
| Beat | Literal information / objective / subtext | Audience knowledge before → after | Each character's knowledge before → after | Stimulus → visible response; required visibility | Reaction exit condition; provisional/tested interval |
|---|---|---|---|---|---|
| B01 | | | | | |

## Edit comparison
| Variant | Hold/cut choice and reason | Information gained/lost | Continuity/caption risks | Actual evidence/status |
|---|---|---|---|---|
| A | Held shared view (or declared baseline) | | | Not tested |
| B | One motivated cut/coverage change; same text and actor beat | | | Not tested |

- Sound/J/L-cut intentions, rights and visual equivalent (planning only in make-cutscene):
- Viewer identity/independence; brief exposure; presentation order:
- Actual answers with timestamps; interpretation separately:
- Result: supported / falsified / inconclusive / not tested:
- Chosen revision and remaining disagreement:

## Handback and regression
- Exit position, heading, objective, control, danger:
- Visual handback: destination/landmark/heading readability; not proof of input restoration:
- R15 take/build identity, performance/contact/caption/framing verdict:
- Body-only R6 re-authored action/contact solution; independent take/build identity and verdict:
- Actual costumes/props/viewport; keys, midpoints and extrema inspected; derived-player proportion limits:
- Moving-playback evidence versus still-only limitations:
- Actual engine end/skip/death/interruption/cleanup tests and outcomes:
- Accessibility/rights blockers; untested stages; next evidence owner:
