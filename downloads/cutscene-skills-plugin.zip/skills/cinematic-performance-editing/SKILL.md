---
name: cinematic-performance-editing
description: "Use for scene edits. Shape reactions, cuts and handback."
---

# Cinematic performance editing

Edit around thought, choice and consequence rather than automatic speaker changes. This portable planning/review skill does not implement sound, facial animation, retiming or an animation importer. When used with the shared cutscene pack, preserve **fwjelaa (FWJ STUDIOS)** attribution and its operational safeguards.

## When to load

Load for movie-like cutscenes, dramatic dialogue, listener reactions, motivated cut/hold decisions or a confusing return to gameplay. Preserve the requested style: restrained drama, comedy, action and repeatable NPC dialogue do not share one pace recipe.

## Working sequence

1. **Receive intention and geography.** Identify the scene's change, viewpoint owner, required information, blocking, continuity states and playable exit. If unclear, use bundled [cinematic-scene-direction](../cinematic-scene-direction/SKILL.md). Neither sibling requires global installation; read its file directly when unregistered.
2. **Separate words from performance.** For each character record stimulus → interpretation → choice → visible action. Include the listener and what is deliberately concealed. Let head/torso direction, weight, distance and prop tasks carry body-only acting; do not promise facial or finger channels.
3. **Find the thought before trimming.** Locate where a reaction becomes legible and what consequence follows. Stillness can be active listening. Do not remove every pause, add idle noise to every hold, or replace all reactions with close-ups.
4. **Choose cut or hold by information.** Ask what the incoming view adds, what the outgoing view would lose, and why this moment matters. Compare staying shared, following the speaker, and showing the listener where useful. A cut on action is an option, not a requirement.
5. **Check continuity and readable time.** Compare action phase, look direction, prop/contact state, landmarks, focal position and character knowledge across edits. Preserve subtitle reading time and the response that changes meaning. No universal shot length or reaction delay applies.
6. **Compare blocking animatics before polish.** Keep the dramatic goal fixed and change one disputed coverage/trim choice. Show neutrally labeled alternatives, ask an uninformed viewer what changed, then reveal the brief. Keep inconclusive results and disagreement.
7. **Design and verify handback.** Resolve the last dramatic choice, show the playable destination/heading, and leave room for the actual camera/control return. A convincing final shot does not prove restored controls, cleanup or interruption behavior.

Read [performance and editorial decisions](references/performance-and-edit-decisions.md) for diagnosis, sound boundaries and verification. Copy the [edit comparison record](templates/edit-comparison.md) for a review; its fields are prose, not executable cues.

## Optional expertise and authority

- Discover installed `video-edit-hub` and relevant `video-edit-story-pacing`, `video-edit-dialogue`, `video-edit-continuity`, `video-edit-cut-decisions`, `video-edit-split-edits`, `video-edit-trim-craft` and `video-edit-brief`. Load only the relevant tasks; their installation is not required by this bundled workflow.
- Dialogue cleanup and split edits apply to an actual authorized audio/video edit when that pipeline exists. In make-cutscene, sound, voice and J/L-cut notes remain **planning/editorial only**; no SFX/voice dispatch is added by these skills.
- Existing R15/R6 animation directors remain authoritative for scoped calibration, authoring and export. Preserve deliberate holds, contacts and recovery; do not impose a film-edit preference over joint-space correctness or replace the pack's source scripts.
- For pack delivery, load [movie routing](../make-cutscene/references/movie-cinematic-routing.md), [animation bridge](../make-cutscene/references/animation-skill-bridge.md) and [review checklist](../make-cutscene/references/review-checklist.md). Those integration links are supplemental when using this skill alone.

## Completion evidence

Return the chosen edit rationale, source/timebase identity, comparison findings and unresolved defects. Distinguish planned timing, still-frame observations, moving playback, engine verification and audience interpretation. No invented scores, successful tests or emotional responses. Do not infer motion quality, audible pauses or restored gameplay from a contact sheet.
