# Direction packet

Copy into authorized scene notes. Planning fields only; do not insert them into a runtime schema.

## Scene intention
- Scene/revision; requested style; assumptions:
- Audience knowledge before → after:
- Character objectives, obstacle, tactics and decisive choice:
- Viewpoint owner; information intentionally withheld:
- Essential visible evidence; dialogue dependence:
- Source URL/creator; permission and permitted use (public access is not clearance):
- Evidence mode/coverage: nominal scrub-preview / decoded still / consecutive frames / continuous playback / audio / input observation; unknowns:
- Source timing: nominal label + preview interval OR file identity + decoded PTS/timebase; source alignment/offset certainty:
- Observed fact → interpretation → proposed adaptation (keep separate; no study media in production):
- Rig(s), prop/costume bounds, aspect/viewport, caption/mask constraints:
- Playable entry → exit: position, heading, objective, control, danger:

## Beat and coverage map
| Beat | Audience knowledge before → after | Each character's knowledge before → after | Stimulus / essential text → interpretation → choice | Visible response; whose visibility matters | View/reason; reaction exit condition |
|---|---|---|---|---|---|
| B01 | | | | | |

## Shot card — repeat only as needed
- Shot / included beats:
- Look here, because; reveal/withhold:
- Start/end blocking; landmarks; axis and screen directions:
- Scale/height/angle; camera distance; FOV convention; fixed/move and reason:
- Important gesture/contact/prop; accessory and caption clearance:
- Outgoing/incoming attention and continuity state:
- Reaction exit: observable decision + caption reading + next-action clarity; deliberately withheld response:
- Provisional authored interval/timebase; tested interval and evidence identity (never copy nominal source seconds):
- Held-view versus cut alternative; information gained/lost; expected improvement; disconfirming observation:

## Handoff
- Required reaction and knowledge state per character:
- Pose/contact/root-motion constraints for the scoped animation specialist:
- R15 evidence identity/status; body-only R6 re-authored cue/contact/framing and separate evidence identity/status:
- Visual handback: destination/heading/landmark; actual restoration tests and outcomes separately:
- Unresolved coverage, rights or implementation blocker:
- Evidence: planned / inspected still / moving animatic / engine-tested:
- Next acceptance question, owner and evidence required:
