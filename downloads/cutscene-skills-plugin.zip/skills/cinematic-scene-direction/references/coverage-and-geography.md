# Coverage and geography

## Dramatic blocking

Use objectives as playable verbs: prevent entry, conceal recognition, obtain cooperation. “Sad” alone gives an animator no action. Tie each tactic change to a visible stimulus; allow concealment when the audience is meant to infer rather than see the thought directly. A task with a prop, distance change or deliberate stillness can carry subtext without facial animation.

Block shared space first: who can see whom, what obstructs the route, which surface supports the action, and where gameplay resumes. Keep the camera and cast on one coherent spatial plan. Rehearse the simplest version without optional effects; do not repair unclear causality with more cuts.

## Coverage choices, not a compulsory shot list

| Question | Candidate | Failure to check |
|---|---|---|
| Does the relationship or spatial advantage matter? | Shared two-shot or wider staging | Important hands/response too small |
| What causes the decision? | Detail or motivated reframing | Insert reveals information prematurely |
| Whose interpretation changes the scene? | Listener coverage or readable shared-view response | Automatic speaker alternation hides the turn |
| Does withholding a reaction create useful uncertainty? | Hold on the other character | Accidental omission mistaken for suspense |
| Has the route back to play changed? | Orienting exit view with a known landmark | Attractive final image leaves heading unclear |

Choose scale from required evidence, not a universal escalation from wide to close. Movement must reveal, follow or alter the relationship; otherwise compare a fixed camera. A long take needs attention design and rehearsal, not merely deletion of cuts.

## Lens, distance and attention

Distance changes perspective; FOV changes the visible angular field. Do not treat a named film focal length as a portable game-camera setting. Record actual camera distance, FOV convention, aspect ratio and delivery mask; compose the measured rig and its accessories. A tighter crop at the same position is not equivalent to moving the camera closer.

Inspect foreground competition, subject separation, background landmarks, head direction, acting-hand silhouette and caption occupancy. On body-only rigs, communicate gaze through readable head/torso direction without claiming eye or facial control. Check the smallest intended viewport in the actual output; a desktop thumbnail is only a diagnostic.

## Continuity ledger

For each shot boundary record outgoing and incoming:

- Character positions/facing, travel direction, interaction axis and landmark locations.
- Eyeline target and focal position in the frame; attention relocation may be intentional.
- Action phase, prop hand/orientation, contact/support and costume state.
- What the audience knows versus what each character knows.

If crossing the axis, choose a readable reorientation: visible movement across it, an orienting view, or another explicit spatial cue. These are options, not guarantees. Check the actual edit rather than rejecting every crossing mechanically.

## Knowledge and reaction coverage

For each beat record **audience knowledge before → after**, the same transition for **each character**, the visible cue or necessary text that changes it, and whose response must remain readable. Keep literal information separate from intended subtext; a pose is not proof of a private thought. Choose shared, listener-favored or speaker-favored coverage from that map, not from subtitle speaker changes.

Give the reaction an **exit condition**, not a borrowed duration: the interrupted task or decision reads, essential captions can be read, and the next action is understandable. Record provisional timing separately from tested timing. A still can show a changed orientation, but cannot establish a continuous reaction hold, comprehension or reading time.

## Original worked proposals — not built or tested

These adaptations use principles from the relayed movie study (development archive; not bundled) and game study (development archive; not bundled), not copied dialogue, characters, animation or imagery. The [research lessons](../../make-cutscene/references/movie-research-lessons.md) retain source links and evidence limits; repository provenance is supplemental for standalone use.

### Concealed recommendation: coverage follows changed knowledge

The player thinks a clerk is obstructive; a colleague discloses that the clerk privately recommended them. The clerk knows this already; the colleague knows the recommendation but need not know it was concealed. The audience/player learn it through supported text, while body attitude tests whether help appears reluctant or willing. This adapts Piano's visible triangle and recipient-favored compositions, not a verified speech/reaction timeline.

| View | Blocking / knowledge job | Visible response and exit condition |
|---|---|---|
| Shared baseline | Player left, clerk farther back, colleague right; already-open task doorway visible. Establish who addresses whom. | Clerk attends to a supported ledger or fixed desk task. Hold across speaker changes unless information needs another view. |
| Optional player-favored view | Keep restrained partner context; preserve the player learning the recommendation. | Player interrupts a reach and turns head/torso toward clerk. Exit only when the interruption and necessary caption register; compare with the same beat held in the baseline. |
| Response / spatial return | Clerk yields space; retain or return to the doorway landmark. Combine views if one already supplies both jobs. | Supported whole-body turn/step answers the disclosure; player orients toward the task. End when choice and route are readable, not when a stock reaction timer expires. |

**Disconfirming test:** with identical text and actor timing, compare held shared view against the listener insert. Ask uninformed reviewers what changed about the clerk and where they would go. If both read equally well, retain the simpler coverage. No viewer finding is claimed. R15 and body-only R6 need independent staging and evidence: replace fine hand/finger business with a whole-arm stop, head/torso orientation and silhouette; omit unsupported ledger manipulation rather than invent contact support.

### Reopened observatory: reveal a relationship to space

The player expects a closed archive; a companion notices an already-open route and lit desk. Use an existing captured set in that state, not a new environment-changing feature. Jurassic samples motivate attention before cause and shared-scale explanation; GOW samples motivate doorway/depth staging, **not** an asserted unbroken camera move.

1. **Baseline:** shared view by a known doorway; establish separate attention targets. Player/audience do not yet know the route is available.
2. **Attention:** companion stops a routine task and redirects head/torso; player follows. The companion now knows more than player/audience. Keep the cause out of frame only while that uncertainty is useful.
3. **Explanation:** wider shared view connects people, doorway and desk. Player/audience can now see the route; a straight cut, fixed shared reveal or restrained move are alternatives. Reframe for a final decision only if this view cannot show it.

**Disconfirming test:** compare immediate reveal against attention-first ordering, holding essential information constant. Ask what was noticed and what to do next; no source-derived delay is prescribed. For either rig, check actual costume/prop extents, captions and smallest supported viewport. The final composition prepares agency; actual movement/look control, camera restoration and cleanup still need authorized target-place tests. A revealed route is not proof of playable access.

## Evidence basis and limits

Evidence combines the relayed bounded movie/game visual studies above with prior council research. Movie labels are nominal scrub-preview times (Piano 1 s spacing; Jurassic 2 s), not decoded PTS or exact cuts. Game samples retain decoded excerpt PTS/timebase; only the identified LIS adjacent-frame boundary establishes an exact cut in its retained file. Neither study included continuous viewing, listening or game input observation. Do not infer camera paths, lens calibration, viewer gaze or private emotion from these samples. Public availability does not clear redistribution: keep study media out of portable skills and game assets; reuse only original prose and independently authored staging.

Prior context: Cutscene craft research (development archive; not bundled) records the God of War no-cut/previs and Uncharted production **abstracts**, Animation Mentor acting articles, and their access limits. GateGuard study (development archive; not bundled) inspected contact sheets: geography, silhouette and accessory-clearance concerns, not continuous motion or audible dialogue. These repository provenance links are supplemental; they are not dependencies when copying this skill alone.

Primary source pointers retained from that research (not freshly fetched here):
- [Keyframes and Cardboard Props: The Cinematic Process Behind 'God of War'](https://gdcvault.com/play/1026025/Keyframes-and-Cardboard-Props-The) — official abstract, not full-talk viewing.
- [What is continuity editing in film - Adobe](https://www.adobe.com/creativecloud/video/hub/ideas/what-is-continuity-editing-in-film.html) — article text: axis, eyelines and eye trace.
- [How to Approach an Acting Test](https://www.animationmentor.com/blog/how-to-approach-an-acting-test/) — motivation/subtext guidance, not a controlled audience study.

Use these as hypotheses to test, not universal aesthetic rules or evidence that a particular scene passed.
