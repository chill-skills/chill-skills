---
name: cinematic-scene-direction
description: "Use for movie-style scenes. Direct blocking and coverage."
---

# Cinematic scene direction

Turn dramatic intent into readable blocking and purposeful coverage. This is a portable planning skill, not a renderer, camera API or animation importer. In the shared cutscene pack, preserve the method attribution **fwjelaa (FWJ STUDIOS)** and its operational safeguards.

## When to load

Load for requested movie-like cutscenes, dramatic scene staging, coverage design or unclear geography. Do not force film-style coverage onto every gameplay intro, repeatable conversation or stylized awakening. Infer reversible defaults; ask only when an unresolved choice blocks work.

## Working sequence

1. **Name the change.** State what the audience and each character know before and after. Give each character an objective, obstacle, tactic and consequential choice. Choose whose experience directs attention; it need not be the speaker.
2. **Block before covering.** Sketch positions, entrances/exits, playable destination, landmarks, interaction axis and reachable prop/contact targets. Stage the stimulus, interpretation, choice and consequence. A beat is a change of intention or information, not an obligatory cut.
3. **Find the minimum useful coverage.** Start with a relationship-readable shared view. Add a detail, reverse or reaction only when it supplies information the baseline cannot. A held take can contain several attention shifts. Do not mandate a master/reverse/close-up sequence.
4. **Compose for attention.** For every view finish: “Look here, because…”. Choose distance, height, angle, FOV, depth and motion to reveal or withhold that information. Keep acting hands, props and accessory extrema readable under the delivery mask and captions. A locked camera is valid.
5. **Preserve or deliberately change geography.** Compare screen direction, eyeline, action phase, focal position and landmarks across transitions. A hard cut alone does not explain an axis crossing. Plan the orienting cue or record the intended disorientation.
6. **Hand off a blocking animatic.** Give the performance editor beat ownership, required reactions, provisional shot boundaries, continuity states and playable exit. Compare alternatives before curve polish; do not rate timing from stills.

Read [coverage and geography](references/coverage-and-geography.md) when designing shots. Copy only the needed parts of the [direction packet](templates/direction-packet.md); it is prose, not runtime schema.

## Collaborators and boundaries

- For listening, subtext, cut/hold decisions and animatic comparison, load bundled [cinematic-performance-editing](../cinematic-performance-editing/SKILL.md). Read sibling files directly if the host has not registered them; do not claim they are installed globally.
- In make-cutscene, read [movie routing](../make-cutscene/references/movie-cinematic-routing.md), [capabilities](../make-cutscene/references/capabilities.md) and [animation bridge](../make-cutscene/references/animation-skill-bridge.md). Those pack links are optional integration points; the planning workflow and local reference/template work independently.
- Discover optional installed `video-edit-brief`, `video-edit-story-pacing` and `video-edit-continuity` through the host's skill registry. Load relevant ones if available; absence does not block the bundled workflow. Do not install them automatically.
- Existing R15/R6 animation directors remain authoritative within their scoped authoring/calibration/export workflows. Specify performance intent and evidence, not uncalibrated joint angles or foreign control names.
- Reference viewing does not grant adaptation/upload rights. Record source and permission separately. Do not change a real game map to obtain a film-layout cheat.

## Completion evidence

Deliver a compact direction packet, a reason for each chosen view, and open questions with a test capable of disproving the choice. Label output **planned** until evaluated. Moving animatics establish different evidence from shot sketches; engine playback and gameplay restoration need their own tests. A cinematic adjective, shot count or lens number is not acceptance.
