# Native Studio R15 animation and boxing

## Scope and evidence

Use this workflow for native Studio authoring without requiring Blender. Engine statements below are sourced to Roblox documentation retrieved during this research; boxing principles are from England Boxing's Coaching Handbook Part 1. Solver equations, validation gates, and conversion safeguards are engineering recommendations, not claims that Roblox automatically performs these tasks. This reference was researched without accessing Studio. The subsequent implementation report supplied by the caller describes five sequences tested in native Studio; distinguish that reported evidence from tests independently performed while editing this reference. Repeat runtime acceptance tests on each target rig when authorized.

## 1. Discover the actual graph before authoring

Roblox documents AnimationConstraint as the replacement for Motor6D in upgraded R15 player rigs; it is not a broken or unrigged character merely because Motor6D enumeration returns zero.[1]

- Enumerate model descendants for both classes. For Motor6D record Name, full path, Part0, Part1, C0, C1, Transform. For AnimationConstraint record Attachment0/1 paths, both complete CFrames including rotation, their parent parts, Transform, Enabled, and IsKinematic. Record body dimensions, anchored state, Animator/controller, active tracks and other constraints.
- Build a directed endpoint graph rather than assuming the joint is parented under its child part. Check missing endpoints, duplicate incoming joints, cycles, disconnected parts, and ambiguous body names. Ignore accessory welds when constructing the body Pose hierarchy, but inspect them for mechanical conflicts.
- Standard R15 has 15 body parts plus HumanoidRootPart. Verify the actual connected graph rather than treating a count alone as proof.
- Preserve rig attachments. AnimationConstraint C0/C1/Part0/Part1 are documented read-only compatibility aliases; they map to Attachment0.CFrame, Attachment1.CFrame and their parent parts. Editing RigAttachment.CFrame directly can break retargeting.[1]
- IsKinematic=true follows Transform like Motor6D; false uses force/torque-limited physical tracking and may lag the target.[1]

### Conditional compatibility conversion

Prefer retaining a working native AnimationConstraint graph. Convert only when the specific authoring/export path demonstrably requires Motor6D, on a separate backed-up clone with permission. This is a compatibility workaround, not a Roblox requirement.

For every converted edge, preserve `Part0 = Attachment0.Parent`, `Part1 = Attachment1.Parent`, `C0 = Attachment0.CFrame`, `C1 = Attachment1.CFrame`, and the existing Transform. Copy the FULL frames; do not zero their rotations, substitute attachment positions, or set both offsets equal. These assignments derive from the documented aliases and kinematic equivalence.[1]

Before activating each replacement, disable/remove the old AnimationConstraint on the converted clone and resolve any additional joint constraining the same body edge. Do not destroy unrelated accessory welds. Retain one authoritative driver per edge. Compare rest and sampled animated world transforms against the original kinematic rig and inspect the result before continuing. Do not promise preservation of a force-based simulation through Motor6D conversion.

## 2. Calibrate joint frames, not anatomical Euler recipes

Treat right/up/front vectors from labeled landmarks as candidates, not infallible facts. Reject degenerate landmarks and mirrored/ambiguous frames; verify using face/toe geometry and the model's actual orientation. Calibrate each side independently.

Engineering protocol:
1. Snapshot state; use a disposable clone or a pure forward-kinematics representation. Do not perturb the user's production pose during inspection.
2. For each joint, perturb small positive AND negative local rotations from the same baseline and measure the distal landmark response in world space. Record local basis, sign, scale, and confidence. Reject near-zero/ambiguous results rather than inventing an axis.
3. For twist/yaw, use orientation or off-axis landmarks: a point on the rotation axis cannot identify the direction. Oblique axes may require an axis-angle/basis transform, not selection of one Euler component.
4. Validate anatomical bend direction in the current upper-limb/upper-leg frame. A flexed elbow need not always put the hand in a fixed global front hemisphere. Track the bend plane continuously through turns and punches.
5. Set motion envelopes from the measured rig, intended action, reference, and collision checks. No universal shoulder/elbow angles place gloves at the chin on every avatar. Measure torso, head, glove and limb surfaces; test clearance rather than relying on part centers.

For a Motor6D or kinematic AnimationConstraint, use this target FK relationship (A0/A1 denote C0/C1 or attachment CFrames):

`Wchild = Wparent * A0 * T * inverse(A1)`

For a solved desired child world frame:

`T = inverse(A0) * inverse(Wparent) * Wchild * A1`

This is a target relation, not an assertion that a force-based constraint's actual pose equals its target at every instant. The equivalence is grounded in the documented attachment aliases and Transform behavior.[1][2]

## 3. Build hierarchical KeyframeSequence Pose trees

A Pose is named after the connected BODY PART, not the joint. In the documented R15 example, Pose `LowerTorso` animates joint `Root`; Pose.CFrame changes the joint's Transform, not its rest C0/C1.[3]

At each Keyframe, build the hierarchy from the discovered graph. Standard structure:

```text
Keyframe (Time in seconds)
└── Pose HumanoidRootPart (identity structural root)
    └── Pose LowerTorso (Root Transform)
        ├── Pose UpperTorso (Waist Transform)
        │   ├── Pose Head (Neck Transform)
        │   ├── Pose LeftUpperArm
        │   │   └── Pose LeftLowerArm
        │   │       └── Pose LeftHand
        │   └── Pose RightUpperArm
        │       └── Pose RightLowerArm
        │           └── Pose RightHand
        ├── Pose LeftUpperLeg
        │   └── Pose LeftLowerLeg
        │       └── Pose LeftFoot
        └── Pose RightUpperLeg
            └── Pose RightLowerLeg
                └── Pose RightFoot
```

Do not flatten all Pose objects under the Keyframe, name them LeftShoulder/Root, or put world-space part CFrames into Pose.CFrame. The graph—not instance storage location—defines nesting.[3]

The Pose reference still explains its mapping in Motor6D terms, while the AnimationConstraint reference explicitly documents replacement rigs and Animator-written Transform compatibility. Keep both classes in discovery and verify one small sequence on the actual upgraded rig before authoring a whole set; do not misread the older wording as a requirement to convert.[1][3]

Use strictly ordered unique sample times; include start/end and event-critical times. Set loop and priority deliberately, and add named KeyframeMarkers for semantic events. KeyframeSequence stores the editable pose/time data; it is not itself a published asset.[4][6]

For direct Luau inspection, use `local keys = sequence:GetKeyframes()`, sort by `Time`, count with `#keys`, and compute duration from the maximum time. Inspect poses through each keyframe's descendants and markers through `keyframe:GetMarkers()`. Do not call invented keyframe-count methods or iterate an Instance with `pairs`. Return the compact report with `return HttpService:JSONEncode(report)` from the execution call; printing alone can leave the tool result as `nil` and require a needless full-console retrieval.

For full-body animation emit the complete intended body hierarchy at each sample. For intentionally partial animation decide ownership of missing channels and inspect blending; do not assume omitted joints reset. Save source sequences persistently in edit mode before running preview, since play-session changes are not a substitute for saved authoring data.

- **Resolve `AnimSaves` indirection before replacing clips:** Inspect the actual class of `rig.AnimSaves` and, if it is an `ObjectValue`, follow its `.Value` instance rather than resolving a same-name path again. Editor storage can contain same-name siblings of different classes. Inspect both the rig-local saves and the referenced editor container; only create/assign a container when the reference is missing. Back up each version that will be replaced in either location, preserve `AnimationRigData` metadata, and replace only the requested clip names. Where the project maintains both copies, synchronize those requested sequences and read them back to compare pose/time/marker contents, not just keyframe counts. Saved copies do not prove editor visibility or playback; verify those separately.
- **Match existing clip pose & marker conventions when extending a rig's animation set:** Before authoring new locomotion or action clips on a rig that already has saved sequences (such as an existing idle), inspect the existing `KeyframeSequence`'s first/last keyframe `Pose` transforms and `KeyframeMarker` naming. Anchor one-shot `Action` clips (e.g., crossovers, attacks, emotes) to start and end at the existing idle's exact `t=0` pose so runtime transitions do not pop.

## 4. Distinguish four delivery states

| State | What it proves | What it does not prove |
|---|---|---|
| Saved editable KeyframeSequence | Authoring data exists | Animator binding, visual quality, publishing |
| Manual Transform/FK preview | Pose math/trajectory can be inspected | Correct Pose mapping or track playback |
| Temporary registered Studio track | Local Animator binding/playback works | Online asset availability or permissions |
| Published animation with authorized asset ID | Upload exists | Correct runtime playback until tested |

RegisterKeyframeSequence and RegisterActiveKeyframeSequence produce temporary Studio-only IDs (hash and active:// respectively). These IDs can be used in Animation.AnimationId for local testing but cannot be used outside Studio; publishing/uploading is a separate step.[4]

Preview through `Animator:LoadAnimation(animation)` on a suitable Humanoid or AnimationController rig in Workspace. The Animator must be in Workspace before LoadAnimation. For replicated playback the Animator must initially be created on the server; non-player rigs require server-loaded/started tracks, while player-character rules differ.[5]

Preview procedure:
1. Save authoring sequences and record the test rig/Animator. Isolate competing Animate scripts, tracks and procedural writers on a test clone; restore them afterward.
2. Register the sequence under a supported Studio execution context, assign the returned ID to Animation.AnimationId, and load through Animator. Catch and report API errors rather than silently switching to manual preview and calling it track validation.
3. Play the track; verify loaded nonzero Length for a nonzero-duration sequence, advancing TimePosition, expected named body motion, loop/non-loop behavior, and actual evaluated contacts. A successful LoadAnimation call alone is insufficient.
4. Scrub critical poses and inspect real-time playback from front, side and three-quarter views. Validate the entire interval, not only endpoints.
5. Stop/destroy temporary tracks and disconnect preview callbacks; restore modified state. Retain the saved editable sequence.

Animator normally writes Transform after PreAnimation and before PreSimulation; Motor6D and AnimationConstraint transforms are batch-applied after PreSimulation, before physics.[1][2] Layer procedural offsets at PreSimulation, but do not repeatedly multiply into a stale previous-frame result: use fresh evaluated base transforms or explicitly reset your own base. Throttled evaluation and multiple writers need special care. Never use attachment/C0/C1 edits as a per-frame animation channel.

Publishing through the Animation Editor is separate from saving local animation data; verify the intended creator/experience permissions and test the returned asset ID before reporting a deployable animation.[7] Do not invent IDs or report a temporary registration as publication.

## 5. World-space contact solve is not interpolation

This section is an engineering prescription, not a claim that a KeyframeSequence automatically solves contacts.

For foot/hand local contact frame `C`, compute `Wcontact = Weffector * C`. During a plant hold a target contact frame in world space, or in a moving platform/prop's frame. For a boxing ball-of-foot pivot constrain the designated contact point while allowing the authored foot rotation; do not incorrectly lock the entire sole and heel.

At each sample:
1. Evaluate pelvis/root and upper-body targets.
2. Establish the active contact mode: full sole, heel, ball/toe pivot, grip, sliding contact, or released/swing. Choose targets appropriate to that mode.
3. Solve reach with measured segment lengths (`L1 = (jMid.a0.Position - jProx.a1.Position).Magnitude`, `L2 = (jDist.a0.Position - jMid.a1.Position).Magnitude`) and a continuous knee/elbow pole using the law of cosines and orthonormal basis construction (`CFrame.fromMatrix`); handle unreachable targets by clamping reach within `[|L1 - L2| + eps, (L1 + L2) * 0.996]` or adjusting the root/stance/target according to the brief, never stretching the rig silently.
4. Recover joint-local Transform values using the exact attachment inverse formula (`T = j.a0:Inverse() * Wparent:Inverse() * Wchild * j.a1`). For foot sole lock, offset the desired foot world position by `-(wFootRot * Vector3.new(jAnkle.a1.X, -footSize.Y * 0.5, jAnkle.a1.Z))` before computing the ankle world target `pAnkle = (wFoot * jAnkle.a1).Position` so ankle pitch/roll never pushes the sole through the floor.
5. Evaluate the final graph and measure contact position/orientation residuals, floor penetration, limb clearance and reach limits. Record reach-clamping residuals per limb and contact phase against the ORIGINAL target, not only the clamped endpoint. Clamping prevents invalid IK math but does not satisfy a contact: adjust pelvis, stance or reachable targets and re-solve any required contact outside tolerance. A single aggregate residual cannot identify whether a hand or planted foot failed.
6. Re-solve contacts after transition blends and other pose modifications. Blending a valid idle into a valid action can introduce foot penetration or sliding; checking the pre-blend solver is insufficient.

For prop interactions such as dribbling and crossovers, define one shared timeline for hand contact, release, flight, floor impact, receiving-hand contact and recovery. Solve hands against the measured prop surface during contact windows and validate the receiving hand at transfer. KeyframeMarkers only label events: they do not animate a ball, change possession, or prove hand-to-hand contact. Inspect the existing runtime marker consumers before changing event names/values, and report character-only clips separately from synchronized prop motion or gameplay integration.

Interpolating two valid endpoint joint poses with CFrame:Lerp, quaternion interpolation, eased curves, or dense LINEAR keys does NOT generally keep the effector fixed in world space. Solve contacts throughout the interval and check intermediate evaluated samples; adapt sample density or retain runtime IK if the baked curve fails the declared tolerances. A file containing many keys is not proof of a solved contact.

For in-place locomotion, contact validation must include intended world root travel. LowerTorso/root-joint animation offsets are not by themselves evidence that gameplay HumanoidRootPart displacement will follow them. Declare who owns travel and test both together.

Use scale-relative tolerances agreed in the brief. Report measured maximum residual and test sample rate; do not substitute an unmeasured 'zero sliding' claim. Loop closure includes endpoint pose and velocity continuity where intended, not simply duplicating the first pose at the last key.

## 6. Boxing mechanics translated into animation goals

These are animation/reference principles, not combat instruction or universal joint-angle prescriptions. Page numbers below are the handbook's printed pages, also matching the extracted PDF pages. Distinguish a source's coaching cues from arbitrary local Euler values.

- **Stance/guard, pp. 66–68:** Balance, staggered width/depth, slightly bent knees and a mobile rear heel underpin the stance; protect the target area, keep chin down without excessive tension, elbows protective, and the non-punching hand in guard. Footwork maintains the base rather than crossing feet or bringing them together; use short coordinated movement with minimal bounce.[8]
- **Powerline, p. 72:** Punches are driven from a stable floor-supported base through body rotation or upward drive. Straight punches follow a straight powerline; hooks an arc; uppercuts an upward path. Keep the wrist straight at impact. A generic late wrist-flexion 'snap' is not the same as forearm/hand turnover.[8]
- **Lead straight/jab, p. 73:** Accelerate the relaxed arm with body drive, keep the rear hand protective and chin behind the shoulder, and return promptly to guard. Do not add a visible cocking/back-pull merely to satisfy a generic animation anticipation rule.[8]
- **Rear straight/cross, p. 75:** Coordinate rear ball-of-foot pivot, hips/body rotation and arm extension. Maintain rear-floor contact at the pivot; do not lock the heel flat, overreach, overrotate across the centerline, or let the lead guard wander.[8]
- **Lead hook, p. 77:** Drive from the front foot with heel lift and hip rotation; carry a bent arm through an arc without a large preparatory pullback, loss of base, or premature arm straightening. Keep target gaze/chin protection and recover to guard. The handbook describes a mid-range lead hook; do not present that one variant as every possible hook.[8]
- **Rear uppercut, p. 78:** Use rear-leg/hip upward drive and a short rising forearm path, not an isolated arm swing or exaggerated windup. Avoid throwing the head back or driving across instead of upward; recover guard.[8]
- **Defence, pp. 79, 83–85:** Keep defensive movements controlled and balanced. A duck lowers through knee flexion, not merely a forward waist fold; a slip is a small coordinated head/shoulder displacement with slight knee bend and maintained guard. Recover into a useful stance rather than ending off balance.[8]

Translate these into beat sheets: stance and support → drive → acceleration/contact or near-contact → recovery/guard. Derive timing from the requested style/reference. No mandatory 'one-frame lag per joint', fixed wrist angle, permanent micro-bend, or fixed global hand hemisphere guarantees plausible boxing. Stylized hitstop is optional and must be identified as style, not a coaching requirement.

## 7. Observed native Studio pitfalls

The following are implementation observations reported by the caller, not promises of universal engine behavior:

- **Generated rig class:** The tested generated R15 used 15 kinematic AnimationConstraints and no Motor6Ds. A compatibility conversion preserving both exact attachment CFrames worked on that rig. This does not make conversion mandatory for other rigs.
- **Deterministic edit-time FK:** Compute the entire pose into a separate cache of world CFrames in graph order, then apply it to a disposable preview clone with all body parts anchored. Also assign `constraint.Transform = poseCFrame` on each `AnimationConstraint` when posing a clone in Edit mode so active constraints do not fight direct `Part.CFrame` writes. Measure the source Model pivot-to-HRP and pivot-to-sole offsets before positioning a clone. Model:GetPivot() is not universally at floor level, and HRP height is not a universal three studs. Preserve the measured relative frames when placing the clone at the intended floor/contact frame. Do not read parent transforms back from a live unanchored assembly between writes: assembly updates can mutate positions and invalidate the calculation. Preserve and restore original anchored states.
- **Forearm roll changes world-space wrist response:** Forearm pronation changes the wrist's world orientation, not the definition of its own local axes. The reported Y/Z and palm/finger directions belonged to one rig and must not be reused as anatomical rules. Measure local palm/finger witnesses and full wrist bind frames, transform them through the evaluated forearm/hand frames, and solve the required wrist orientation in that actual basis. Verify both sides independently; never swap wrist Euler axes solely because the forearm was twisted.
- **Runtime Animator test setup:** On the stationary test clone, unanchor all body parts except HumanoidRootPart before runtime playback. All-parts-anchored edit posing is not an Animator playback setup. For a mobile gameplay character, restore the intended root/physics policy rather than universally anchoring HRP.
- **Edit versus Play evidence:** RegisterKeyframeSequence followed by Animator:LoadAnimation worked in Studio, but an Edit-mode track kept TimePosition at zero. A real Play-mode test was required to verify advancing playback; successful registration/loading is not sufficient.
- **End-of-track continuity:** Avoid deliberate gaps after a track ends: releasing all animated channels can expose the neutral/rest pose and cause a pop. Maintain an appropriate lower-priority idle underlay or crossfade seamlessly into the next compatible track. Test the full transition and final recovery, not only the active attack interval; stop temporary preview tracks only after returning control to the intended base animation.

## 8. Acceptance and reporting

- Verify the exact requested number of deliverable clips; keep temporary calibration sequences separate.
- Report names, durations, loop/priority, joint class and graph validation, saved location, preview route, and publication state.
- Check full attachment-frame preservation if conversion was necessary; report why conversion was needed.
- Measure contact residuals across declared contact windows, sample in-betweens, and inspect guard/recovery and punch trajectories.
- Report API failures, missing permissions and untested runtime behavior plainly. Documentation research/static math verification is not Studio execution.

## Sources

[1] https://create.roblox.com/docs/en-us/reference/engine/classes/AnimationConstraint.md
[2] https://create.roblox.com/docs/reference/engine/classes/Motor6D.md
[3] https://create.roblox.com/docs/reference/engine/classes/Pose.md
[4] https://create.roblox.com/docs/reference/engine/classes/KeyframeSequenceProvider.md
[5] https://create.roblox.com/docs/reference/engine/classes/Animator.md
[6] https://create.roblox.com/docs/reference/engine/classes/KeyframeSequence.md
[7] https://create.roblox.com/docs/animation/editor.md
[8] https://www.englandboxing.org/wp-content/uploads/2022/03/EB_Boxing-Coaching-Handbook-Part-1_v8-002.pdf
