# R15 spaces, rig discovery and calibration contract

This is an engineering workflow, not a universal anatomical angle table. It replaces the former incomplete `calibrate_r15_bone_axes` fragment, guessed yaw/twist signs, fixed global hinge tests and fixed-size collision audit. Do not resurrect those fragments from conversation history.

## 1. Establish the graph and baseline

### Studio

Inspect the actual selected Model. Collect all body BaseParts, body joint endpoints, complete CFrames and geometry. Traverse Motor6D and AnimationConstraint instances model-wide: storage Parent is not the kinematic parent. For Motor6D record Part0/Part1, C0/C1, Transform and Enabled. For AnimationConstraint record Attachment0/1, their BasePart parents and full CFrames, Transform, Enabled and IsKinematic. Reject null/non-part endpoints, duplicate incoming active body edges, cycles, missing body nodes and disconnected chains. Record disabled joints separately rather than accidentally activating them. Inspect extra welds/constraints for competing rigid connections. Do not mistake accessory welds for R15 body channels.

Standard body paths (verify, do not infer from count):

- HumanoidRootPart -> LowerTorso -> UpperTorso -> Head.
- UpperTorso -> LeftUpperArm -> LeftLowerArm -> LeftHand; corresponding right chain.
- LowerTorso -> LeftUpperLeg -> LeftLowerLeg -> LeftFoot; corresponding right chain.

A0 and A1 are endpoint-local rigid frames, not joint world coordinates. T is the animated joint offset. Identity T is the bind relationship; it need not look like the currently playing idle. Snapshot current state separately. Compare FK with the observed baseline only when the evaluated T, root frame and read timing are consistent. Do not rewrite A0/A1 to force a mismatch away.

For kinematic target FK:

`Wchild = Wparent * A0 * T * inverse(A1)`

For a desired world child frame:

`T = inverse(A0) * inverse(Wparent) * Wchild * A1`

Recover EVERY child from its solved parent, not the old unsolved parent pose. Evaluate the entire graph into a cache before any writes. Recovering T with translation can fit any world frame mathematically; it does not make a disconnected limb physically valid. Unless the brief deliberately permits joint translation, preserve attachment coincidence and use rotation-only articulation except the designated root channel. Check lengths and pivot separation after solving.

AnimationConstraint's C0/C1/Part0/Part1 compatibility aliases are read-only; preserve its attachment frames. Kinematic target equivalence does not imply a force-based physical constraint hits the target exactly. Do not change IsKinematic or convert classes on production rigs merely to pass a test.

### Blender

Inspect actual armature object transform, rest matrices, bone parents, pose matrices, constraints/targets, drivers, custom properties, IK/FK switches, action/slot, NLA and exporter metadata. Use an authentic target rig with its actual rest geometry. Do not substitute a generated block proxy as the deliverable rig.

- `Bone.matrix_local` is a rest matrix in armature space, not a parent-local pose delta.
- An evaluated pose-bone matrix is in armature/object space; multiply by the evaluated armature object's world matrix for world space. Do not apply the world matrix twice.
- `matrix_basis` is a local channel representation; it is not generally the evaluated result when constraints/drivers are active.
- On constrained rigs, author verified controls and measure the driven deform skeleton. Probe control-to-deform response. No response is a failure to diagnose, not a sign to choose arbitrarily.
- Inspect switch semantics/ranges from the rig and measure both modes on a copy. A property containing `IK_FK` does not prove zero means FK.
- Do not blindly apply armature transforms or change bone rolls to repair export: this can invalidate skinning, controls and importer metadata.

For a simple unconstrained parented bone with ordinary inheritance, let Bc/Bp be armature-space rest matrices, Pc/Pp armature-space posed matrices, and D the local pose delta. Then `Pc = Pp * inverse(Bp) * Bc * D`. Thus `D = inverse(Bc) * Bp * inverse(Pp) * Pc`. For a root, `Pc = Bc * D`. These relations are NOT a universal substitute for Blender's inheritance/constraint evaluation. Use supported conversion APIs after checking the installed version when inherit-scale/local-location settings differ; validate by reevaluation. For constrained exports, bake the evaluated deform result through the verified exporter rather than equating D with Roblox T.

## 2. Separate anatomical basis from world coordinates

Find neutral left/right shoulder or hip landmarks, pelvis/head up landmarks and an INDEPENDENT front-direction witness. A verified face marker, source rig orientation metadata or inspected front surface can be a witness; a camera location cannot. A centered symmetric foot may provide no toe-forward evidence.

Construct a candidate orthonormal basis:

1. Normalize the pelvis-to-head up candidate U.
2. Remove its U component from the left-to-right landmark vector and normalize to R.
3. F = normalize(U cross R).
4. Check F against the front witness and R against verified side labels. Reject near-zero vectors and near-collinearity using declared scale-relative tolerances.

For a proper orientation matrix use columns `[R, U, -F]`: Roblox's LookVector is the negative Z column. `[R, U, F]` would be a reflection for this convention. An imported mirror or contradictory label/witness requires explicit mapping repair, not a silent F sign flip. Reject non-finite matrices, shear/nonuniform scale where a rigid inverse is assumed, and negative determinant frames; normalize units separately and preserve a documented conversion boundary.

Store the calibrated basis in root/model coordinates and transform it with the evaluated root when the character turns. Hand-front tests for guard are usually in the current chest frame, not the initial world's front vector. A roll, backflip, crossed arm or backward step is not inherently an inverted joint.

## 3. Offsets: axes AND pivots matter

For an axis direction `aW` in world space and `J = Wparent * A0`:

- An offset before the baseline T, `Tnew = R(aLocal, angle) * Tbase`, uses `aLocal = inverse(rotation(J)) * aW`.
- An offset after it, `Tnew = Tbase * R(aLocal, angle)`, uses `aLocal = inverse(rotation(J * Tbase)) * aW`.

Use rotation/vector transforms, not point transforms, for directions. These choose different pivots when Tbase contains translation. A pre-offset rotates Tbase's translation around the pre-T joint origin; a post-offset retains that translated pivot. If the intended pivot is different, compose the complete translate-rotate-translate transform or solve the desired child world frame and recover T exactly. Do not silently discard translations.

A parent-part rotation is not already a joint T rotation. With a rotated A0, it must be expressed in the joint basis. Rest orientation A1 still matters when reconstructing the child's orientation. This is why recipes that ignore A1 can put an endpoint at the right place while reversing the hand/foot.

For mirroring, do not negate all Euler angles. In a declared common reflection frame S, use reflection conjugation `Rmirror = S * R * S` and reflected position, then remap sides and solve against the TARGET's own bind frames. The resulting orientation must remain proper. Apply this to desired frames/trajectories, not blindly to source T values. Retargeting is a separate binding operation, even when body names match.

## 4. Empirical calibration that fails safely

Work on an isolated clone or mathematical representation. Capture action/frame, pose channels, constraints, switch values, track/IK state and selection changes as appropriate; restore in finally/cleanup even on failure. Do not clear the user's animation to make a probe convenient.

For each independently driven shoulder/hip and elbow/knee:

- Establish a baseline and a distal landmark that actually moves under the tested rotation. A bone head sitting on its own pivot is a bad sensor.
- Apply +epsilon and -epsilon separately FROM that same baseline, evaluate the real driver/dependency graph and measure both responses. Check opposite small-angle behavior, magnitude relative to chain length and sensitivity to a second reasonable epsilon. Tiny/no response, saturation or inconsistent response means fail/ambiguous.
- For a rotation axis a around pivot p, the positional derivative is `a cross (x-p)`. A single point cannot observe rotation around its own pivot-to-point ray. Use two noncollinear landmarks or orientation vectors to resolve twist/yaw. Never assign the unused Euler axis a guessed positive sign.
- Preserve a measured oblique axis or full basis. Choosing the largest X/Y/Z response is only an approximation and cannot certify a rotated attachment frame.
- Calibrate each side independently, then confirm neutral and compound poses. The same axis in both limb parts is not guaranteed, and the same world pole will not remain appropriate when shoulders/hips rotate.

Required short diagnostic sequence, tailored to available controls: neutral; left shoulder forward/out; right shoulder forward/out; each elbow flex; forearm twist with wrist orientation witness; each hip flex/out; each knee flex; ankle/sole orientation; torso turn with raised arms. Repeat representative cases with a turned root. Use modest identifiable perturbations, not an unverified fixed physiological range. Inspect at least front and side; log trajectory direction and FK residual as well as screenshots. Do not start a large batch until the short sequence works.

## 5. Two-bone reach and orientation

Measure endpoints in common spaces. Upper segment length is the distance between its proximal attachment and distal attachment expressed in that SAME part. Similarly measure the lower segment. Never subtract positions taken from different part-local spaces.

For proximal p, target t and positive lengths L1/L2, set d = |t-p|. Reachable distance is `[abs(L1-L2), L1+L2]`. At singular boundaries the bend plane is underdetermined. Clamp only under an explicit solver policy and report distance to the ORIGINAL target. Coincident equal-length fold requires an explicit axial direction and bend plane, not division by zero or a random global fallback.

Choose unit reach direction e. Project the desired pole direction perpendicular to e to obtain bend direction b. If it collapses, transport/reproject a previous valid bend direction or use an explicitly calibrated fallback; if neither survives, fail. Maintain continuity through the pole singular region; do not switch to a different global axis on alternating frames. Intentional bend-plane changes must be authored as continuous trajectories, not suppressed by an absolute sign rule.

For nonsingular d, along distance is `a = (L1^2 - L2^2 + d^2)/(2*d)` and height `h = sqrt(max(0, L1^2-a^2))`; middle point is `p + a*e + h*b`. This solves points, NOT full bone orientation. Match each measured local segment direction and a second local orientation witness to an orthonormal target frame; choose roll from the calibrated bend plane and intended wrist/foot orientation. Recover joint T from those child frames with full A0/A1. Check endpoint error, pivot coincidence, segment length, twist continuity and target hand/foot orientation.

Do not infer hyperextension from a knee being behind a global midpoint. Diagnose signed bend relative to the calibrated posed chain frame; near straightness the bend plane loses observability and needs continuity handling. No universal three-degree minimum or fixed human range is valid for every stylized avatar.

## 6. Export calibration boundary

Export one neutral + asymmetric limb diagnostic before the full clip. Preserve exact source rig mapping, unit scale and one axis conversion. Compare source-evaluated and target-evaluated body/attachment world frames at multiple times after aligning only the declared root conversion. Inspect palm/sole orientation as well as joint positions; these reveal lost A1, swapped handedness and double conversion.

Never call a source-vs-source FK comparison an engine round trip. Never copy a universal guessed Blender-to-Roblox axis permutation over importer metadata. Recalibrate after topology/bind/scale/control changes; root rotation alone should be handled by the declared spaces, not a new guessed sign table.

## Sources

- [Pose](https://create.roblox.com/docs/reference/engine/classes/Pose.md): body-name hierarchy and Transform mapping.
- [AnimationConstraint](https://create.roblox.com/docs/en-us/reference/engine/classes/AnimationConstraint.md): attachment aliases, kinematic/physical behavior, Animator timing.
- [Bone](https://docs.blender.org/api/current/bpy.types.Bone.html) and [PoseBone](https://docs.blender.org/api/current/bpy.types.PoseBone.html): inspect matrix-space and conversion APIs for the installed Blender version.
- [Action](https://docs.blender.org/api/current/bpy.types.Action.html): inspect action/slot APIs rather than assuming a legacy fcurves collection.
