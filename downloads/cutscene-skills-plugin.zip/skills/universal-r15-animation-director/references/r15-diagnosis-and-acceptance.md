# R15 defect diagnosis and acceptance

## Diagnose the first divergence

Capture the exact rig, representation, frame/time, camera-independent expected motion and current driver state. Compare stages in order: intended target -> solver world frames -> recovered local transforms -> saved pose/bone channels -> evaluated source -> exported/reimported target -> runtime blend/physics. Find the FIRST stage that differs. Do not compensate a conversion error with opposite animation angles.

| Symptom | Cheapest discriminating check | Repair class |
|---|---|---|
| Both limbs move backwards | Isolated +/− perturbation; inspect full A0/A1, root/front witness and conversion count | Correct basis/conversion once; regenerate dependent poses |
| Only one side is wrong | Compare that side's actual attachment frames and side mapping | Independent calibration, not negating a shared Euler recipe |
| Hand reaches correctly but palm flips | Track two orientation witnesses plus position; inspect A1 and roll | Solve orientation/twist; preserve full endpoint frames |
| Elbow/knee suddenly swaps sides | Plot projected pole magnitude, bend normal and reach distance around failure | Continuous transported pole; explicit singular fallback; authored roll |
| Glitch only while turning | Express pole/targets in current root/chest frame; compare with fixed world pole | Transform intended local targets every sample |
| Limbs separate or stretch | Measure joint pivot coincidence and segment lengths after inverse solve | Fix inconsistent world-frame solve; reject accidental joint translations |
| Correct static pose, wrong playback | Inspect Animator, Animate, IK, scripts, constraints, NLA, channel weights | Isolate competing writers on a clone, then define ownership |
| Rendered pose contradicts sampled transforms | Check live playback, active action/slot and exact capture frame before changing keys | Pause, set/evaluate the intended state, capture again and verify state; do not repair the wrong pose |
| Guide arm curves into chest despite correct wrist position | Inspect elbow swivel, rest offsets and evaluated limb volumes | Solve hinge, roll, clearance and endpoint together; inspect side/top views |
| Extended arm follows torso rigidly | Compare hand/segment direction in chest space and declared target space over time | Author independent aim and extension/release timing, then recheck clearance and velocity |
| Offset grows every frame | Compare base T with prior offset-applied T | Compose from fresh evaluated base; handle throttled evaluation explicitly |
| Source good, export bad | Neutral/asymmetric diagnostic round trip, compare attachment/world frames | Correct rest mapping, units, bone mapping or duplicated conversion |
| One-frame wrist spin | Inspect orientation angular distance AND interpolation at subframes | Quaternion normalization/hemisphere handling, Euler unwrap, interpolation fix |
| Feet slide between valid keys | Measure evaluated world contact throughout stance and blends | Re-solve contacts; adapt sampling or runtime IK |
| Whole preview floats | Compare Model pivot, HRP and measured sole/floor frames | Preserve measured pivot-to-root offset; no assumed floor-level pivot |
| Track end pops | Evaluate outgoing/incoming tracks and idle at fade boundary | Compatible recovery and ownership/crossfade; do not force every clip to identity |
| Loaded track does not move | Check loaded Length, advancing TimePosition, pose paths, anchored state | Real supported playback context; loading alone is not validation |

## Deterministic Blender pose inspection

Before a static probe or capture, check each window's `screen.is_animation_playing`; when active, cancel playback under that window's context with `bpy.ops.screen.animation_cancel(restore_frame=False)`. Select the intended existing action and compatible slot, call `scene.frame_set(frame, subframe=...)`, and update the view layer. Record the action/slot and actual frame with the geometry measurements. Recheck immediately before subsequent captures if the user may have resumed playback; an earlier pause is not a persistent guarantee.

When image analysis conflicts with measured pose data, first reproduce the same action/frame and use an explicit-frame capture, then inspect a side/top view perpendicular to the reach. Do not accept a visual description of a moving or foreshortened viewport as evidence that the keyed pose has changed. Conversely, do not dismiss visible clipping because joint-center or bone-axis metrics pass.

Use transformed mesh bounds as a conservative clearance screen, labeling the result as a bounds overlap rather than exact mesh penetration. Record the sign convention, scale, exclusions and worst timestamp. Investigate suspect overlaps with evaluated geometry and multiple views; never increase tolerances to convert an unresolved collision into a pass.

## Gates and evidence

Use `pass`, `fail`, `unverified` and `not_applicable`. Only mark pass after exercising the exact gate. Record rig identity and manifest provenance with results; tests on another avatar do not certify this one.

1. **Graph and bind:** unique connected body graph; full rest frames; correct root/side/front; no unresolved drivers. Reject cycles and duplicate incoming edges before FK. Validate finite proper rigid matrices and scale conversion.
2. **Calibration:** each side's shoulder/elbow/wrist and hip/knee/ankle motion has an observed direction; orientation witnesses resolve twist; repeat representative probes with root turned. Record ambiguous/nonresponsive controls instead of inventing signs.
3. **Solver:** measure original-target position/orientation residuals, attachment coincidence, segment lengths and bend-plane continuity. Declared tolerances are scale-relative engineering choices, not universal Roblox limits. Clamped reach is still a failed required contact if outside tolerance.
4. **Evaluated motion:** inspect endpoints, extrema, contact start/end, high angular velocity, transitions and loop seam; include intermediate samples/subframes. Sampling rate, tested time interval, maxima and worst timestamps belong in the report. Dense keys alone do not pass this gate.
5. **Clearance:** evaluate relevant limb/torso/head/glove/prop volumes, not only joint centers. Label bounds/capsule tests as approximations. Confirm suspect frames visually from multiple views. Intended contact is not penetration; declared collision exclusions must correspond to the requested action.
6. **Motion read:** front, side and three-quarter playback show intended action, weight/support, coherent gaze and clean recovery. No compulsory movement on every joint, generic wrist snap, fixed overlap delay or exaggerated anticipation. Match the user's style/reference.
7. **Binding/export:** body-named Pose hierarchy follows discovered graph; complete intended channels and deliberate ownership of omitted ones; units and time base preserved. For Blender, inspect evaluated deform bones, not controls alone. Reimport and compare the delivered representation where available.
8. **Runtime:** actual track length/playhead/body motion verified, plus blend/priority/loop behavior and restoration of temporary state. Manual FK is not Animator evidence. Force-based joints need measured target-tracking checks under intended simulation conditions.
9. **Persistence/delivery:** saved editable artifact exists in edit-time storage; any AnimSaves ObjectValue is resolved and requested copies synchronized without deleting unrelated work. Published asset IDs require an actual authorized upload and subsequent playback check. Temporary Studio IDs are not published assets.

## Regression matrix

Exercise the route used by the request; do not create unrelated scenes merely to fill a table. At minimum design checks for nonidentity A0/A1 and T, left/right independently rotated frames, a turned root, scaled/asymmetric segment lengths, wrist orientation under forearm roll, near-straight reach, unreachable targets, pole alignment, transitions and interpolation. For Blender add constrained-vs-unconstrained controls and export conversion exactly once. For Studio add Motor6D versus available kinematic AnimationConstraint rigs and competing-track isolation.

Synthetic math tests establish algebra and error handling only. Authentic rig calibration, visual motion quality, engine playback, export, collisions and publishing remain distinct tests. If unavailable, state exactly which are unverified rather than weakening gates.

## Compact report

Report deliverable paths/names, rig/joint type, changed cause, tested representation and command/context, pass/fail/unverified gates, measured residuals/worst times where available, and publication state. A skills-only repair does not claim an existing animation was repaired or that Studio playback was tested.
