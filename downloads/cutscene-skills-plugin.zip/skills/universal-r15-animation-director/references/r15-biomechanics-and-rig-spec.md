# R15 rig calibration and motion principles

## Scope

This reference replaces the former canonical numerical 'rest spec'. That table did not contain measured C0/C1 matrices and its anatomical angle/phase numbers were not established universal limits. Use [Native Studio R15 animation and boxing](r15-native-studio-and-boxing.md) for verified engine semantics, conversion safeguards, contact solving and cited boxing mechanics.

## Body hierarchy, not a hardcoded joint class

Standard R15 comprises 15 body parts PLUS HumanoidRootPart, not HumanoidRootPart plus 14 body parts. The usual connected paths are:

- HumanoidRootPart → LowerTorso → UpperTorso → Head.
- UpperTorso → Left/RightUpperArm → LowerArm → Hand.
- LowerTorso → Left/RightUpperLeg → LowerLeg → Foot.

Inspect actual Motor6D and AnimationConstraint endpoints. Neither assumed blocky height/HipHeight nor the presence of a particular joint class is a rest-pose specification. Record exact rest frames, segment lengths, geometry and root orientation. For native Pose mapping and authoritative sources, follow the linked workflow.

## Calibrated anatomical semantics

- Derive candidate front/right/up from verified labeled landmarks; check handedness, face/toe orientation and degeneracy.
- Measure local-axis response independently on each side. Restore a known baseline between perturbations; inspect full frames rather than attachment translations alone.
- Define semantic flexion, extension, abduction and twist in the appropriate segment frame. Do not equate elbow flexion with universal +X or knee flexion with universal -X.
- Use orientation/off-axis landmarks for axial twist. A point on a rotation axis cannot identify that axis's effect.
- Determine usable ranges from the asset, intended motion, solver stability and reference. Human anatomical limits do not directly define safe local Euler limits for a stylized rig.
- Preserve a continuous bend plane during turns and reaching. No fixed global pole coordinate or 'always anterior hand' rule covers every posed chain.

## Support and gait

Treat walking, running, sprinting, stance shuffles and boxing pivots as different support patterns. Author contact windows, root trajectory, foot targets and swing clearance explicitly. Fit duty factor, stride length and timing to the intended reference and character speed rather than a universal studs-per-second gait table.

For walking, distinguish double-support transitions from single-support vaulting; for running, distinguish supported compression from flight. Do not force one pelvis-height phase on all locomotion. Source any claimed quantitative human measurements before calling them physiological facts.

Define the contact feature explicitly: heel, sole, toe/ball or moving grip. Solve the world-space target throughout the contact window, then evaluate the baked result between keys. A pivoting boxing rear foot may keep its ball in contact while the heel rises; locking the entire foot would contradict that motion.

## Coordination and clearance

Coordinate support, pelvis, thorax and limbs to convey the requested action. Peak-velocity relationships are not fixed keyframe offsets; simultaneous samples can represent different joint velocity profiles. Preserve gaze using the target and measured head motion rather than prescribing a universal compensation percentage.

For boxing, follow the linked England Boxing reference: stable/mobile base, protective guard, body-supported punch drive, aligned wrist at impact and prompt guard recovery. Do not transplant a generic 'hand drag then wrist-flexion snap' from a throwing animation into every punch.

Measure actual torso/head/limb/glove surfaces. Point-in-box checks of joint centers can miss interpenetration and are not a complete mesh-clearance test. Use suitable segment/volume tests and visual inspection. Numerical tolerances must be declared for the rig scale and backed by measured residuals, not described as automatic guarantees.

## Straight reaches through torso turns

1. **Separate the requirements.** Specify hand trajectory, elbow extension, palm orientation, shoulder clearance and the intended aiming space. A hand-only fit can reach the target by curling the elbow through the chest; score the whole chain rather than only wrist error.
2. **Measure anatomical landmarks.** Inspect the real shoulder/elbow/wrist pivots and mesh axes. Imported control-bone tails may not coincide with child heads; parallel upper/lower bone axes alone do not certify a straight visible arm. Check pivot-chain alignment and side/top silhouettes without translating joints to conceal a rest offset.
3. **Calibrate elbow and roll independently.** Remove unintended sideways elbow swivel using measured hinge semantics. Neutral local Euler values do not necessarily mean anatomical extension. Keep wrist orientation continuous, and avoid adding forearm roll merely to reduce endpoint error.
4. **Choose independent aim deliberately.** Compare chest-space and root/armature/world-space trajectories. For a reach that should stay aimed while the torso turns, solve the desired direction in the declared independent space, then recover local control rotations against the evaluated parent. Preserve shoulder attachment and solve proximal-to-distal. Do not transplant numerical angles or an aim vector from another rig.
5. **Author entry and release as well as the hold.** Use distinct extension, settling and recovery timing rather than copying the chest curve onto the arm. Sample the unmodified source before batch edits so adjacent keyed frames do not accumulate previous corrections. Preserve an editable backup.
6. **Recheck clearance after compensation and blending.** A world/armature-space aim can clear the apex yet bury the shoulder during wind-up or release. Test upper arm, forearm and hand against torso/head across the entire transition, including subframes. If clearance requires reducing independent aim, report that compromise rather than calling the whole reach world-locked. Per-frame limits can introduce velocity kinks; inspect playback after any projection or clamp.
7. **Verify the requested read.** Inspect a perpendicular side view, top view and full-speed motion. Measure elbow/pivot alignment, hand trajectory and wrist roll separately. A static straight reach is evidence for the pose only; do not claim the stiffness is fixed until continuous motion has been reviewed.
