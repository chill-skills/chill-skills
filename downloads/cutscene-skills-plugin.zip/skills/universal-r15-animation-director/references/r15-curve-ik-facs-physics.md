# R15 runtime, curve and IK boundaries

Use the calibration contract before authoring rotations and the diagnosis reference before declaring a fix. This reference replaces unsafe fallback joint lookup, unverified radians-only curve builders and legacy quaternion-repair code. Engine documentation is evidence of API semantics, not evidence that this project's playback passed.

## Joint frames and runtime ownership

For Motor6D and kinematic AnimationConstraint targets, `Wchild = Wparent * A0 * T * inverse(A1)`. Recover `T = inverse(A0) * inverse(Wparent) * Wchild * A1`. Discover endpoints model-wide; never return an arbitrary sibling joint when the requested name is absent. Preserve both complete bind frames. AnimationConstraint compatibility aliases are read-only; do not edit RigAttachment frames for procedural animation. Force-based tracking may differ from target FK.

Animator normally evaluates between PreAnimation and PreSimulation. Apply post-Animator procedural Transform overlays in PreSimulation; other read times are not universally forbidden. Batch application happens before physics. Establish a fresh baseline and declared multiplication order. Do not repeatedly multiply into the prior overlay when Animator is stopped, throttled, or does not own that channel. Disconnect callbacks and restore only owned state on teardown. Inspect active tracks, IK and physical constraints before diagnosing sign errors.

## CurveAnimation and units

Build the hierarchy from the actual target binding, with body/bone names rather than assumed joint storage paths. Vector3Curve supplies position channels; EulerRotationCurve supplies X/Y/Z scalar rotation channels and explicit RotationOrder; RotationCurve supplies orientation keys. Inspect the actual class before reusing a named child. Set all required channels intentionally; missing-channel defaults and partial-track ownership are not equivalent.

The retrieved EulerRotationCurve reference does not explicitly settle angular units. Do not call a builder `setJointEulerRad` and silently assume radians. In an isolated unparented test object, sample a known single-axis quarter-turn through GetRotationAtTime and compare against a known CFrame rotation, then test a compound rotation for order. Record the engine/version and result. This small API probe does not require a scene edit. Keep time in seconds; scalar tangents use that channel's value units per second. Set RotationOrder when updating an existing curve, not just on creation. Verify the resulting interpolation between keys, especially cubic overshoot and Euler wrap.

Do not label a curve constructor as including event markers unless it implements and verifies the actual marker representation. Use the supported authoring/export route and test marker signals in actual playback. A constructor returning an Instance proves neither binding nor loaded track motion.

## Native IKControl

Parent IKControl to a Humanoid or AnimationController containing an Animator, NOT to the Animator itself. Required fields are Type, ChainRoot, EndEffector and Target. Start disabled, configure the complete control, then enable deliberately. Verify on the actual joint graph.

- Discover each limb chain; ordinarily upper arm to hand or upper leg to foot. Do not include the body root accidentally.
- For contact, prefer a measured palm/sole Attachment as EndEffector and a complete target frame. Distinguish EndEffectorOffset from Offset and verify their composition with a small test before relying on compound offsets.
- Derive a pole from the intended bend and measured limb scale. Attach it to the appropriate moving reference or update its world target. A fixed world pole does not follow a turning torso.
- Tune SmoothTime and Weight to the contact task. Smoothing introduces lag and does not prove a planted foot is stationary. Weight zero is not a full disable: set Enabled false when the control should not solve.
- Higher IK Priority solves later; it is a separate property from AnimationPriority. Define ownership when chains overlap.
- Validate original-target residual, orientation, reach limits, bend-plane continuity and actual contact during blends. IK does not automatically prevent self-collision or maintain every joint limit.

## Quaternions and Blender curve handling

Normalize rotation quaternions and reject zero/nonfinite inputs. q and -q encode the same orientation; shortest-path SLERP usually corrects their sign internally. Sign changes are not inevitably visible 360-degree spins. Scalar quaternion channels, naive interpolation and exporters still need deliberate hemisphere handling and evaluated subframe tests.

On a copied editable action, identify the installed Blender action/slot/channel-bag API rather than assuming action.fcurves exists. Evaluate synchronized four-component samples; if rebaking, write all four components at every chosen time and retain original source data. Merely negating existing values without handling missing channel times or Bezier handles is unsafe. Negate appropriate handle values along with changed components when preserving a compatible curve representation; otherwise rebake and verify. Test the evaluated normalized orientations, not only stored key signs. Preserve intentional multi-turn motion with intermediate keys and an explicit winding design.

## Facial channels and springs

Facial animation is optional and separate from limb repair. Inspect the actual dynamic head's supported FaceControls properties and exporter mapping. Do not assume every R15 head supports FACS or force asymmetric blinking, fixed expression amplitudes, or eye-leading delays on every style. Verify the final facial curves in the same delivery pipeline.

For a critically damped scalar spring with constant target over a step, x is displacement from target, v is velocity, omega is positive angular frequency, and dt is nonnegative: `x_next = (x*(1+omega*dt)+v*dt)*exp(-omega*dt)`; `v_next = (v*(1-omega*dt)-x*omega*omega*dt)*exp(-omega*dt)`. Restore the target offset to position. This does not by itself define a rotation spring: Euler-wise integration is not a universal orientation solver. Recompute changing-target dynamics deliberately and test timestep variation.

## Sources

- [AnimationConstraint](https://create.roblox.com/docs/reference/engine/classes/AnimationConstraint.md)
- [Motor6D](https://create.roblox.com/docs/reference/engine/classes/Motor6D.md)
- [IKControl](https://create.roblox.com/docs/reference/engine/classes/IKControl.md)
- [EulerRotationCurve](https://create.roblox.com/docs/reference/engine/classes/EulerRotationCurve.md)
- [Action](https://docs.blender.org/api/current/bpy.types.Action.html)
