"""Synthetic mathematical fixtures, NOT authentic rig/runtime verification.
Run with: python -m unittest discover -s <absolute scripts directory> -v
"""
import importlib.util
import json
import math
from pathlib import Path
import sys
import unittest

# Resolve the sibling module independently of the caller's working directory.
MODULE_PATH = Path(__file__).resolve().with_name('r15_math.py')
spec = importlib.util.spec_from_file_location('r15_math', MODULE_PATH)
m = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = m
if MODULE_PATH.exists():
    spec.loader.exec_module(m)


def distance(a, b):
    return math.hypot(*(x - y for x, y in zip(a, b)))


class RigidTests(unittest.TestCase):
    def assertVector(self, actual, expected, tol=1e-9):
        self.assertLessEqual(distance(actual, expected), tol)

    def assertRigid(self, actual, expected):
        self.assertVector(actual.translation, expected.translation)
        for a, b in zip(actual.rotation, expected.rotation):
            self.assertVector(a, b)

    def test_identity_point(self):
        self.assertTrue(hasattr(m, 'Rigid'), 'rigid math module must exist')
        self.assertVector(m.Rigid().point((2, 3, 4)), (2, 3, 4))

    def test_multiply_inverse(self):
        a = m.Rigid(m.axis_rotation((1, 2, 3), 0.8), (2, -4, 1))
        self.assertRigid(a @ a.inverse(), m.Rigid())
        self.assertRigid(a.inverse() @ a, m.Rigid())
        self.assertVector(a.inverse().point(a.point((5, 6, 7))), (5, 6, 7))

    def test_known_quarter_turn(self):
        r = m.Rigid(m.axis_rotation((0, 0, 1), math.pi / 2), (1, 2, 3))
        self.assertVector(r.point((1, 0, 0)), (1, 3, 3))
        self.assertVector(r.vector((1, 0, 0)), (0, 1, 0))

    def test_invalid_rotations_rejected(self):
        bad = [((1, 0, 0), (0, 1, 0), (0, 0, -1)),
               ((2, 0, 0), (0, 1, 0), (0, 0, 1)),
               ((1, 0.1, 0), (0, 1, 0), (0, 0, 1)),
               ((math.nan, 0, 0), (0, 1, 0), (0, 0, 1)),
               ((1, 0), (0, 1))]
        for rotation in bad:
            with self.subTest(rotation=rotation), self.assertRaises(ValueError):
                m.Rigid(rotation)
        with self.assertRaises(ValueError):
            m.Rigid(translation=(0, math.inf, 0))

    def test_fk_inverse_nonidentity_frames(self):
        # Independent oblique left/right frames are proper rotations, not reflections.
        p = m.Rigid(m.axis_rotation((1, 4, -2), 1.7), (4, -2, 3))
        for sign in (-1, 1):
            a0 = m.Rigid(m.axis_rotation((sign, 2, -3), 0.9), (sign, 2, 0.3))
            a1 = m.Rigid(m.axis_rotation((2, -sign, 1), -0.7), (0.4, -1, sign))
            t = m.Rigid(m.axis_rotation((1, -2, sign), 0.6), (0.2, 0.4, -0.1))
            child = m.fk(p, a0, t, a1)
            self.assertRigid(m.solve_transform(p, a0, child, a1), t)
            self.assertRigid(child @ a1, p @ a0 @ t)

    def test_world_axis_pre_post_nonidentity(self):
        p = m.Rigid(m.axis_rotation((1, 2, 3), 1.3), (4, 2, 1))
        a0 = m.Rigid(m.axis_rotation((3, -2, 1), -0.7), (1, 0, 2))
        t = m.Rigid(m.axis_rotation((2, 3, -1), 0.8), (0.2, -0.3, 0.1))
        world = (0.3, -0.6, 0.7)
        length = math.hypot(*world)
        world = tuple(x / length for x in world)
        axes = []
        for composition in ('pre', 'post'):
            local = m.world_axis_to_joint_local(world, p, a0, t, composition=composition)
            axes.append(local)
            frame = p @ a0 if composition == 'pre' else p @ a0 @ t
            self.assertVector(frame.vector(local), world)
            delta = m.Rigid(m.axis_rotation(local, 0.17))
            result = p @ a0 @ (delta @ t if composition == 'pre' else t @ delta)
            expected = m.Rigid(m.axis_rotation(world, 0.17)) @ m.Rigid((p @ a0 @ t).rotation)
            for row, target in zip(result.rotation, expected.rotation):
                self.assertVector(row, target)
        self.assertGreater(distance(*axes), 0.1)
        with self.assertRaises(ValueError):
            m.world_axis_to_joint_local(world, p, a0, t, composition='guess')

    def test_json_roundtrip(self):
        a = m.Rigid(m.axis_rotation((2, 3, 1), 0.7), (1, 2, 3))
        self.assertRigid(m.Rigid(**json.loads(json.dumps(a.to_dict(), allow_nan=False))), a)

    def test_large_finite_invalid_matrix_rejected(self):
        with self.assertRaises(ValueError):
            m.Rigid(((1e308, 1e308, 0), (0, 1, 0), (0, 0, 1)))

    def test_pre_post_offsets_have_distinct_pivots(self):
        baseline = m.Rigid(translation=(1, 0, 0))
        delta = m.Rigid(m.axis_rotation((0, 0, 1), math.pi / 2))
        self.assertVector((delta @ baseline).translation, (0, 1, 0))
        self.assertVector((baseline @ delta).translation, (1, 0, 0))

    def test_invalid_axis(self):
        for axis in ((0, 0, 0), (math.inf, 1, 0), (1, 2)):
            with self.assertRaises(ValueError):
                m.axis_rotation(axis, 0.2)
        with self.assertRaises(ValueError):
            m.axis_rotation((1, 0, 0), math.nan)


class BasisTests(unittest.TestCase):
    def basis(self, **kwargs):
        return m.anatomical_basis((0, 0, 0), (0, 2, 0), (-1, 1, 0), (1, 1, 0), **kwargs)

    def test_candidate_not_automatically_front_verified(self):
        result = self.basis()
        self.assertFalse(result['front_verified'])
        self.assertEqual(result['forward'], [0, 0, -1])

    def test_front_witness_required_to_verify(self):
        result = self.basis(front_witness=(0.1, 0, -2))
        self.assertTrue(result['front_verified'])
        json.dumps(result, allow_nan=False)
        for witness in ((0, 0, 1), (1, 0, 0), (0, 0, 0)):
            with self.subTest(witness=witness), self.assertRaises(ValueError):
                self.basis(front_witness=witness)

    def test_turned_scaled_character(self):
        turn = m.Rigid(m.axis_rotation((2, 3, 1), 2.1))
        for scale in (1e-8, 1, 1e8):
            def p(v):
                return turn.point(tuple(scale * x for x in v))
            result = m.anatomical_basis(p((0, 0, 0)), p((0, 2, 0)),
                                       p((-1, 0.8, 0)), p((1, 1.2, 0)),
                                       front_witness=turn.vector((0, 0, -1)))
            self.assertLess(distance(result['forward'], turn.vector((0, 0, -1))), 1e-9)
            self.assertLess(distance(result['right'], turn.vector((1, 0, 0))), 1e-9)

    def test_degenerate_landmarks_rejected(self):
        fixtures = [((0, 0, 0), (0, 0, 0), (-1, 0, 0), (1, 0, 0)),
                    ((0, 0, 0), (0, 1, 0), (0, 0, 0), (0, 0, 0)),
                    ((0, 0, 0), (0, 1, 0), (0, -1, 0), (0, 1, 0)),
                    ((0, 0, 0), (0, 1, 0), (0, 0, 0), (1e-14, 1, 0))]
        for args in fixtures:
            with self.subTest(args=args), self.assertRaises(ValueError):
                m.anatomical_basis(*args)

    def test_swapped_left_right_disagrees_with_witness(self):
        with self.assertRaises(ValueError):
            m.anatomical_basis((0, 0, 0), (0, 2, 0), (1, 1, 0), (-1, 1, 0),
                               front_witness=(0, 0, -1))


class IKTests(unittest.TestCase):
    def check_lengths(self, result, a, b):
        tolerance = max(a, b) * 1e-9
        self.assertAlmostEqual(distance(result['root'], result['mid']), a, delta=tolerance)
        self.assertAlmostEqual(distance(result['mid'], result['end']), b, delta=tolerance)
        self.assertAlmostEqual(result['residual'], distance(result['end'], result['target']),
                               delta=tolerance)
        json.dumps(result, allow_nan=False)

    def test_reachable_triangle(self):
        result = m.two_bone_ik((0, 0, 0), (3, 0, 0), 2, 2, (0, 1, 0))
        self.check_lengths(result, 2, 2)
        self.assertFalse(result['unreachable'])
        self.assertEqual(result['status'], 'reachable')
        self.assertLess(result['residual'], 1e-12)
        self.assertAlmostEqual(result['mid'][0], 1.5)
        self.assertAlmostEqual(result['mid'][1], math.sqrt(1.75))

    def test_unreachable_outer_reports_original_target_residual(self):
        result = m.two_bone_ik((0, 0, 0), (8, 0, 0), 2, 3, (0, 1, 0))
        self.check_lengths(result, 2, 3)
        self.assertTrue(result['unreachable'])
        self.assertEqual(result['status'], 'too_far')
        self.assertAlmostEqual(result['residual'], 3)

    def test_unreachable_inner_preserves_lengths_in_both_orders(self):
        for a, b in ((3, 1), (1, 3)):
            result = m.two_bone_ik((0, 0, 0), (0.5, 0, 0), a, b, (0, 1, 0))
            self.check_lengths(result, a, b)
            self.assertEqual(result['status'], 'too_close')
            self.assertTrue(result['unreachable'])
            self.assertAlmostEqual(result['residual'], 1.5)

    def test_equal_fold_requires_explicit_reach_fallback(self):
        with self.assertRaises(ValueError):
            m.two_bone_ik((0, 0, 0), (0, 0, 0), 2, 2, (0, 1, 0))
        result = m.two_bone_ik((0, 0, 0), (0, 0, 0), 2, 2, (0, 1, 0),
                               fallback_direction=(1, 0, 0))
        self.check_lengths(result, 2, 2)
        self.assertEqual(result['mid'], [0, 2, 0])
        self.assertEqual(result['end'], [0, 0, 0])
        self.assertTrue(result['singular'])
        self.assertFalse(result['unreachable'])

    def test_zero_target_unequal_lengths(self):
        result = m.two_bone_ik((1, 2, 3), (1, 2, 3), 3, 1, (0, 1, 0),
                               fallback_direction=(1, 0, 0))
        self.check_lengths(result, 3, 1)
        self.assertEqual(result['status'], 'too_close')
        self.assertAlmostEqual(result['residual'], 2)

    def test_parallel_pole_requires_usable_fallback(self):
        for kwargs in ({}, {'fallback_bend': (1, 0, 0)}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                m.two_bone_ik((0, 0, 0), (2, 0, 0), 2, 2, (1, 0, 0), **kwargs)
        for kwargs, source in (({'fallback_bend': (0, 0, 1)}, 'fallback'),
                               ({'previous_bend': (0, 1, 0)}, 'previous')):
            result = m.two_bone_ik((0, 0, 0), (2, 0, 0), 2, 2, (1, 0, 0), **kwargs)
            self.check_lengths(result, 2, 2)
            self.assertEqual(result['pole_source'], source)

    def test_projected_pole_continuity_through_alignment(self):
        previous = (0, 1, 0)
        for y in (0.1, 1e-8, 0, -1e-8, -0.1):
            result = m.two_bone_ik((0, 0, 0), (2, 0, 0), 2, 2, (1, y, 0),
                                   previous_bend=previous)
            self.check_lengths(result, 2, 2)
            self.assertGreater(result['mid'][1], 0)
            self.assertLess(distance(result['bend_direction'], previous), 1e-9)
            previous = result['bend_direction']

    def test_rigid_equivariance_and_scale(self):
        reference = m.two_bone_ik((0, 0, 0), (2, 0.3, 0.2), 2, 1.5, (0, 1, 0))
        for scale in (1e-8, 1, 1e8):
            frame = m.Rigid(m.axis_rotation((1, 3, 2), 1.2), (scale, -2*scale, 3*scale))
            def p(v):
                return frame.point(tuple(x * scale for x in v))
            result = m.two_bone_ik(p((0, 0, 0)), p((2, 0.3, 0.2)), 2*scale, 1.5*scale,
                                   frame.vector((0, 1, 0)))
            self.check_lengths(result, 2*scale, 1.5*scale)
            self.assertLess(distance(result['mid'], p(reference['mid'])), scale*1e-8)

    def test_exact_reach_boundaries_are_singular_but_reachable(self):
        for target in ((4, 0, 0), (2, 0, 0)):
            result = m.two_bone_ik((0, 0, 0), target, 3, 1, (0, 1, 0))
            self.check_lengths(result, 3, 1)
            self.assertFalse(result['unreachable'])
            self.assertTrue(result['singular'])

    def test_previous_projection_degenerate_requires_fallback(self):
        with self.assertRaises(ValueError):
            m.two_bone_ik((0, 0, 0), (1, 0, 0), 1, 1, (1, 0, 0),
                          previous_bend=(1, 0, 0))
        result = m.two_bone_ik((0, 0, 0), (1, 0, 0), 1, 1, (1, 0, 0),
                               previous_bend=(1, 0, 0), fallback_bend=(0, 0, 1))
        self.check_lengths(result, 1, 1)
        self.assertEqual(result['pole_source'], 'fallback')

    def test_unrepresentable_world_coordinates_rejected(self):
        with self.assertRaises(ValueError):
            m.two_bone_ik((1e20, 1e20, 1e20), (1e20, 1e20, 1e20), 1, 1,
                          (0, 1, 0), fallback_direction=(1, 0, 0))

    def test_near_equal_fold_stays_finite(self):
        result = m.two_bone_ik((0, 0, 0), (1e-12, 0, 0), 1, 1, (0, 1, 0))
        self.check_lengths(result, 1, 1)
        self.assertLess(result['residual'], 1e-14)

    def test_invalid_inputs_rejected(self):
        for a, b in ((0, 1), (-1, 1), (1, math.inf), (math.nan, 1)):
            with self.subTest(a=a, b=b), self.assertRaises(ValueError):
                m.two_bone_ik((0, 0, 0), (1, 0, 0), a, b, (0, 1, 0))
        for kwargs in ({'relative_tol': 0}, {'relative_tol': math.nan},
                       {'previous_bend': (math.nan, 0, 0)}, {'fallback_direction': (0, 0, 0)}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                m.two_bone_ik((0, 0, 0), (1, 0, 0), 1, 1, (0, 1, 0), **kwargs)


if __name__ == '__main__':
    unittest.main()
