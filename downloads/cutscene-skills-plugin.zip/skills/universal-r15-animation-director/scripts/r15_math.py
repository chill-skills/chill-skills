"""Offline rigid-transform calibration math; Python standard library only.

Conventions: right-handed coordinates, radians, active rotations, column
vectors, row-major 3x3 matrices. A @ B applies B first. Units are caller-defined.
Rigid rejects scale, shear, reflections, nonfinite values; it never repairs them.
A0/A1 are attachment frames (or C0/C1 under this mathematical convention).
The FK equation is a contract, NOT a claim about any live engine evaluation.

This module does not discover a rig, infer anatomical twist, retarget animation,
check collisions, or verify Roblox/Blender behavior. Callers must measure frames
and validate adapters separately. Returned dicts/lists support strict JSON.
"""
from dataclasses import dataclass
import math

__all__ = ['Rigid', 'axis_rotation', 'fk', 'solve_transform',
           'world_axis_to_joint_local', 'anatomical_basis', 'two_bone_ik']

_IDENTITY = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))
_ROTATION_TOL = 1e-9


def _finite(value):
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError('expected finite real number') from exc
    if not math.isfinite(result):
        raise ValueError('expected finite real number')
    return result


def _vec(value, size=3):
    try:
        result = tuple(_finite(x) for x in value)
    except TypeError as exc:
        raise ValueError('expected numeric sequence') from exc
    if len(result) != size:
        raise ValueError(f'expected {size} components')
    return result


def _add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def _sub(a, b):
    return tuple(x - y for x, y in zip(a, b))


def _mul(a, s):
    return tuple(x * s for x in a)


def _dot(a, b):
    return math.fsum(x * y for x, y in zip(a, b))


def _cross(a, b):
    return (a[1]*b[2] - a[2]*b[1], a[2]*b[0] - a[0]*b[2],
            a[0]*b[1] - a[1]*b[0])


def _unit(a):
    a = _vec(a)
    # Scale before normalization to avoid overflow/underflow of finite inputs.
    scale = max(abs(x) for x in a)
    if scale == 0:
        raise ValueError('zero direction is ambiguous')
    scaled = tuple(x / scale for x in a)
    length = math.hypot(*scaled)
    return tuple(x / length for x in scaled)


def _transpose(r):
    return tuple(zip(*r))


def _apply(r, v):
    return tuple(_dot(row, v) for row in r)


@dataclass(frozen=True)
class Rigid:
    """Validated immutable rotation + translation. No scale or affine fallback.

    Rotation rows must be orthonormal and determinant +1 within 1e-9.
    Input lists are copied to tuples. to_dict() produces JSON-ready lists.
    """
    rotation: tuple = _IDENTITY
    translation: tuple = (0.0, 0.0, 0.0)

    def __post_init__(self):
        try:
            r = tuple(_vec(row) for row in self.rotation)
        except TypeError as exc:
            raise ValueError('expected 3x3 rotation') from exc
        if len(r) != 3:
            raise ValueError('expected 3x3 rotation')
        for i in range(3):
            for j in range(3):
                value = _dot(r[i], r[j])
                if not math.isfinite(value) or abs(value - (i == j)) > _ROTATION_TOL:
                    raise ValueError('rotation must be orthonormal')
        if abs(_dot(r[0], _cross(r[1], r[2])) - 1.0) > _ROTATION_TOL:
            raise ValueError('rotation must be proper (determinant +1)')
        object.__setattr__(self, 'rotation', r)
        object.__setattr__(self, 'translation', _vec(self.translation))

    def __matmul__(self, other):
        if not isinstance(other, Rigid):
            return NotImplemented
        columns = _transpose(other.rotation)
        rotation = tuple(tuple(_dot(row, col) for col in columns) for row in self.rotation)
        return Rigid(rotation, self.point(other.translation))

    def inverse(self):
        rotation = _transpose(self.rotation)
        return Rigid(rotation, _mul(_apply(rotation, self.translation), -1.0))

    def vector(self, vector):
        """Rotate a direction without translating it."""
        return _vec(_apply(self.rotation, _vec(vector)))

    def point(self, point):
        return _vec(_add(self.vector(point), self.translation))

    def to_dict(self):
        return {'rotation': [list(row) for row in self.rotation],
                'translation': list(self.translation)}


def axis_rotation(axis, angle):
    """Right-hand axis-angle rotation; axis need not be unit, angle in radians."""
    x, y, z = _unit(axis)
    angle = _finite(angle)
    c, s = math.cos(angle), math.sin(angle)
    d = 1.0 - c
    return ((c+x*x*d, x*y*d-z*s, x*z*d+y*s),
            (y*x*d+z*s, c+y*y*d, y*z*d-x*s),
            (z*x*d-y*s, z*y*d+x*s, c+z*z*d))


def fk(parent, a0, transform, a1):
    """World child = parent @ a0 @ transform @ inverse(a1)."""
    return parent @ a0 @ transform @ a1.inverse()


def solve_transform(parent, a0, child, a1):
    """Recover transform = inverse(a0) @ inverse(parent) @ child @ a1."""
    return a0.inverse() @ parent.inverse() @ child @ a1


def world_axis_to_joint_local(world_axis, parent, a0, baseline, *, composition):
    """Return unit axis for delta @ baseline ('pre') or baseline @ delta ('post').

    The pre frame is parent @ a0; the post frame includes baseline rotation.
    This maps ORIENTATION axes, not a world-space pivot or screw translation.
    For nonzero baseline translation, pre/post pivots differ. A1 does not enter
    this axis map because the offset is inserted before inverse(A1) in FK.
    """
    if composition not in ('pre', 'post'):
        raise ValueError("composition must explicitly be 'pre' or 'post'")
    frame = parent @ a0
    if composition == 'post':
        frame = frame @ baseline
    return _unit(_apply(_transpose(frame.rotation), _unit(world_axis)))


def _tolerance(value):
    value = _finite(value)
    if not 0 < value < 0.01:
        raise ValueError('relative_tol must be positive and less than 0.01')
    return value


def anatomical_basis(pelvis, head, left, right, *, front_witness=None,
                     relative_tol=1e-9):
    """Candidate up/right/forward from labeled world-space landmark positions.

    Forward = up cross right. Right is orthogonalized against up; the proper
    orientation matrix would have columns (right, up, -forward), NOT (R,U,F).
    A front_witness is an independently measured world DIRECTION, not a point.
    It must have a positive normalized projection > relative_tol onto forward.
    Missing witness returns front_verified=False; contradictory/ambiguous
    witnesses raise ValueError rather than silently flipping the basis.
    This only checks consistency; incorrect labels/witnesses remain possible.
    """
    tol = _tolerance(relative_tol)
    pelvis, head, left, right = map(_vec, (pelvis, head, left, right))
    up_raw, right_raw = _vec(_sub(head, pelvis)), _vec(_sub(right, left))
    up_length, right_length = math.hypot(*up_raw), math.hypot(*right_raw)
    scale = max(up_length, right_length)
    if not math.isfinite(scale) or scale == 0 or min(up_length, right_length) <= tol * scale:
        raise ValueError('coincident or scale-degenerate anatomical landmarks')
    up, raw_right = _unit(up_raw), _unit(right_raw)
    forward_raw = _cross(up, raw_right)
    if math.hypot(*forward_raw) <= tol:
        raise ValueError('collinear anatomical landmarks')
    forward = _unit(forward_raw)
    right_axis = _unit(_cross(forward, up))
    witness_dot = None
    if front_witness is not None:
        witness_dot = _dot(forward, _unit(front_witness))
        if witness_dot <= tol:
            raise ValueError('front witness contradicts candidate or is ambiguous')
    return {'origin': list(pelvis), 'up': list(up), 'right': list(right_axis),
            'forward': list(forward), 'front_verified': front_witness is not None,
            'front_witness_dot': witness_dot}


def two_bone_ik(root, target, length1, length2, pole, *, previous_bend=None,
                fallback_direction=None, fallback_bend=None, relative_tol=1e-9):
    """Solve POINTS only, preserving two segment lengths without stretching.

    pole, previous_bend and fallback_bend are world directions (not positions).
    Project the pole perpendicular to root->target; align its sign with the
    projected previous_bend when available. At pole alignment, reuse previous
    projection, then explicit fallback_bend, otherwise reject the ambiguity.
    Pass returned bend_direction as previous_bend on the next small time step.
    This gives local hemisphere continuity, not smoothing or a guarantee across
    arbitrarily large steps, changing constraints or simultaneous singularities.

    Exactly coincident root/target requires fallback_direction even for equal
    lengths. With equal lengths, mid lies along bend_direction and end at root.
    Reach is clamped to [abs(length1-length2), length1+length2]; status/unreachable
    describe the ORIGINAL target, and residual is distance(end, original target).
    Straight/folded results are marked singular; a usable bend is still required
    to carry a defined plane into the next sample. No joint angles, twist,
    anatomical hinge limits, contact orientation or collision solving is done.

    ValueError rejects nonfinite/invalid inputs, unresolved planes/directions,
    extreme length ratios or coordinates unable to represent the solved lengths.
    relative_tol controls angular degeneracy and numerical length verification,
    not reach classification. Inputs already rounded by a caller cannot be fixed.
    """
    tol = _tolerance(relative_tol)
    root, target = _vec(root), _vec(target)
    l1, l2 = _finite(length1), _finite(length2)
    if min(l1, l2) <= 0:
        raise ValueError('segment lengths must be positive')
    scale = max(l1, l2)
    a, b = l1 / scale, l2 / scale
    if min(a, b) <= 32 * math.ulp(1.0):
        raise ValueError('length ratio exceeds supported floating-point precision')
    # Validate supplied fallbacks even when this sample does not need them.
    pole = _unit(pole)
    previous = None if previous_bend is None else _unit(previous_bend)
    fallback = None if fallback_bend is None else _unit(fallback_bend)
    reach_fallback = None if fallback_direction is None else _unit(fallback_direction)
    displacement = _vec(_sub(target, root))
    distance = _finite(math.hypot(*displacement))
    if distance == 0:
        if reach_fallback is None:
            raise ValueError('coincident target requires fallback_direction')
        direction = reach_fallback
    else:
        direction = _unit(displacement)

    def project(vector):
        if vector is None:
            return None
        projected = _sub(vector, _mul(direction, _dot(vector, direction)))
        return None if math.hypot(*projected) <= tol else _unit(projected)

    previous_projected = project(previous)
    bend = project(pole)
    source = 'pole'
    if bend is None:
        bend, source = previous_projected, 'previous'
    if bend is None:
        bend, source = project(fallback), 'fallback'
    if bend is None:
        raise ValueError('ambiguous bend plane: supply nonparallel previous/fallback bend')
    if previous_projected is not None and _dot(bend, previous_projected) < 0:
        bend = _mul(bend, -1)

    minimum, maximum = abs(l1 - l2), _finite(l1 + l2)
    status = 'too_far' if distance > maximum else 'too_close' if distance < minimum else 'reachable'
    reach = min(maximum, max(minimum, distance))
    d = reach / scale
    if reach == 0:
        along, height = 0.0, a
    elif reach == maximum:
        along, height = a, 0.0
    elif reach == minimum:
        along, height = (a if a >= b else -a), 0.0
    else:
        # Difference-of-squares avoids cancellation near the equal-length fold.
        along = 0.5 * (d + (a - b) * (a + b) / d)
        along = min(a, max(-a, along))
        height = math.sqrt(max(0.0, (a - along) * (a + along)))
    mid = _vec(_add(root, _add(_mul(direction, along * scale), _mul(bend, height * scale))))
    end = _vec(_add(root, _mul(direction, reach)))
    actual1 = math.hypot(*_sub(mid, root))
    actual2 = math.hypot(*_sub(end, mid))
    if abs(actual1 - l1) > tol * l1 or abs(actual2 - l2) > tol * l2:
        raise ValueError('coordinates cannot represent solved segment lengths at tolerance')
    residual = _finite(math.hypot(*_sub(end, target)))
    return {'root': list(root), 'mid': list(mid), 'end': list(end),
            'target': list(target), 'bend_direction': list(bend),
            'reach_direction': list(direction), 'pole_source': source,
            'unreachable': status != 'reachable', 'status': status,
            'residual': residual, 'singular': reach == 0 or height <= tol,
            'used_direction_fallback': distance == 0}
