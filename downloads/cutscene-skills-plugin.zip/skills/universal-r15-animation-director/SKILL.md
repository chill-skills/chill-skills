---
name: universal-r15-animation-director
description: 'R15 Roblox animation: measure rig, IK, verify, export.'
version: 1.0.0
metadata:
  hermes:
    tags: [roblox, r15, animation, ik]
    related_skills: [animate-roblox-characters, universal-r6-blender-animation-director, roblox-native-animation-studio]
---

# R15 animation: measured rigs, verified motion

## Most important animation quality requirement

**Generated animations must feel loose, fluid, and highly detailed, with excellent smoothing and intentional easing—not stiff or robotic.**

Prioritize relaxed posing, flowing arcs, purposeful overlap, follow-through, and refined secondary motion. Tune acceleration, deceleration, and settling per action phase rather than applying uniform smoothing everywhere. Preserve readable impacts, deliberate holds, weight, stable contacts, and rig integrity; loose means expressive, not uncontrolled. Detail must serve the action, not add random movement or unnecessary keys. Review moving playback and in-betweens before declaring this requirement met. This is the highest artistic priority, not permission to bypass correctness or verification.

Create, repair, retarget and validate R15 animation in native Studio or Blender. This is the shared R15 correctness gate for `make-anim`, `animate-roblox-characters` and `roblox-animation`; it does not replace their unrelated R6, UI, export-security or media workflows. A skill-maintenance request changes skill files, not the user's scene or published assets.

## When to Use

Use for R15 creation, posing, IK, retargeting, export orientation problems, backwards arms, wrist flips, elbow/knee snapping and animation-skill maintenance. Do not apply R15 anatomy to R6 or route unrelated UI animation through this workflow. The installed directory retains the legacy name `roblox-r15-blender-mega-animator`; the registered skill identifier remains `universal-r15-animation-director` to preserve existing routing.

## Research first

Before implementation, review the relevant current official documentation and record source URLs, supported claims and limitations. For advanced native authoring, load `roblox-native-animation-studio` and its advanced-motion reference alongside this calibration gate. Preserve actual joint classes; Motor6D-only helpers do not establish AnimationConstraint support. Documentation and offline math tests are not engine-playback evidence.

## Required references

- Before posing ANY R15 rig: [joint spaces and calibration](references/r15-calibration-contract.md).
- Native Studio authoring/playback: [native workflow](references/r15-native-studio-and-boxing.md).
- Blender authoring/retargeting: the Blender section of the calibration contract, plus the selected export skill's rig/toolchain references.
- A defect or final acceptance: [diagnosis and acceptance](references/r15-diagnosis-and-acceptance.md).
- Runtime IK, CurveAnimation or quaternion curves: [engine boundaries](references/r15-curve-ik-facs-physics.md).
- Motion design: [motion principles](references/r15-biomechanics-and-rig-spec.md); boxing-specific source cues are in the native workflow.

## Non-negotiable correctness rules

1. **Measure this rig.** Standard R15 has 15 body parts plus HumanoidRootPart. Names/counts alone are not proof of hierarchy, bind frames or anatomical axes. Inspect both Motor6D and AnimationConstraint endpoints; in Blender distinguish control bones from driven/export bones.
2. **Never guess rotation signs.** Neither `+X means elbow flexion` nor `left is the negative of right` is a portable rule. Calibrate each side in its real attachment/rest frame. A rotated character must retain the same anatomical motion.
3. **Preserve full rest frames.** For rigid joint target FK, `Wchild = Wparent * A0 * T * inverse(A1)`. Recover `T = inverse(A0) * inverse(Wparent) * Wchild * A1`. These are matrices, not positions or Euler triples. A0/A1 mean C0/C1 or the two attachment CFrames. Force-based constraints need separate physical tracking checks.
4. **Declare the space and multiplication order of every offset.** World, model/root, parent-part, joint-before-T, joint-after-T, child-part, armature and bone-rest spaces are different. Never write a world part CFrame directly into Pose.CFrame. Never add Euler components as a substitute for composing rotations.
5. **Validate front, not camera direction.** Labeled landmarks yield a candidate basis. Require an independent face/front marker or trustworthy source orientation; toe-center displacement alone is not universal evidence. Reject degeneracy, reflections and contradictory labels rather than auto-flipping the whole rig.
6. **Calibrate before a full clip.** On a disposable clone or evaluated mathematical copy, test neutral, each arm independently, elbow flexion, wrist orientation/twist, each leg, knee flexion, ankle and torso turn. Confirm measured trajectories AND front/side views. Restore all temporary state. A failing/ambiguous probe blocks authoring, not permission to guess.
7. **Solve placement and orientation separately.** A wrist point at its target does not establish palm direction, fist alignment or forearm roll. Preserve a continuous, action-appropriate bend plane; no fixed global elbow/knee hemisphere covers turns, overhead actions or crossed limbs.
8. **One authoritative driver per channel.** Inspect tracks, Animate, IK, constraints, drivers, NLA and procedural callbacks before blaming angle signs. Do not rotate deform bones that constraints override, accumulate offsets every frame or convert a working constraint rig unnecessarily.
9. **Geometry and contacts are measured.** No universal torso dimensions, hand-forward threshold, joint-angle recipe or fixed pole distance guarantees clearance. Point tests cannot certify thick-limb clearance. Solve declared contact features through transitions and inspect actual evaluated in-betweens.
10. **Evidence has levels.** Math tests, manual FK preview, Animator playback, exported/reimported playback and publication are separate. Missing checks are `unverified`, never `pass`. Never present synthetic math fixtures as authentic-rig testing.

## Work sequence

### Inspect and reproduce

For a repair, capture the exact failing rig, clip, time and expected direction; reproduce the first bad pose or transition. Inspect before changing it. Preserve unrelated animation data. For creation, infer sensible motion defaults from the request, identify the exact rig and pipeline, and protect a working copy. Native requests stay native; documentation tasks do not launch Studio or Blender.

Record a compact rig manifest: endpoint graph, full bind frames, root/front witness, scale, body geometry, active animation drivers, control/deform mapping and source/export provenance. Reuse it only while topology, bind frames, scale, importer metadata and driver state are unchanged.

### Calibrate and smoke-test

Follow the calibration contract. Test positive and negative perturbations from the SAME baseline. Use off-axis orientation landmarks for twist, reject negligible response, and preserve oblique axes rather than snapping them to X/Y/Z. Verify isolated limbs and a turned-root pose before a whole animation set. Do not guess IK/FK switch values from a property name.

### Design the motion

Declare loop, timing, root-travel owner, beat sheet, supported/airborne phases, contact frames and output state. Use the existing idle/recovery when extending a set. Choose joint ownership for partial clips explicitly. Design silhouette, balance, support, arcs and gaze before decorative overlap; held or identity channels are legitimate.

For this user's sports-animation sets, preserve the existing serve and make separately named complete jump-only and jump-with-hit clips when requested; retain takeoff, airborne pose, landing and recovery rather than truncating a showcase to its apex. A jump-only clip keeps the striking arm cocked without adding a hit. When a straight forward guide reach is requested, prioritize a visibly extended elbow and aligned wrist outside the chest, not an overhead guide or an inward-curled forearm. Give the reach its own timing and declared aiming space so chest twist does not drag the arm as one rigid unit. Apply these pose preferences to the requested action, not universally to every sport. See the reach procedure in [motion principles](references/r15-biomechanics-and-rig-spec.md).

### Solve and author

Evaluate pelvis/torso, solve required feet/hands, recover joint-local transforms, then orient wrists/feet using measured rest frames. Position-only two-bone IK does not provide segment twist: complete the local reference frames before export. Preserve segment lengths; report unreachable targets against the ORIGINAL target, adjust root/stance or author a release rather than hiding the residual. Re-solve after blending or secondary motion.

Use intentional sparse authoring curves or sampled curves as appropriate. Preserve an editable source. Baking is a representation choice, not a contact solver. For multi-turn motion insert intermediate orientation keys; sign-consistent quaternions alone cannot encode winding.

### Validate and deliver

Use the acceptance reference on evaluated motion, including transition blends, subframes, root turns and loop seams. Pause playback and explicitly set and verify the action/slot and frame before static capture; recheck after capture if the image contradicts measured geometry. Inspect front, side and three-quarter playback. Show an extended reach from a view perpendicular to its direction as well as the front; camera-axis foreshortening can make a straight arm look tucked. Do not use stills or parallel bone axes as proof of smooth motion or anatomical straightness. Reimport/replay the delivered representation on the intended rig when that pipeline is available. Native sequence persistence, editor visibility, local track playback and publication are separate gates. Retain measured residuals and failing timestamps; fix causes, not audit thresholds.

Report changed files/clips, what was actually exercised, maximum residuals where measured, and any unverified engine/export behavior. Do not claim a skill update retroactively repairs existing clips.

## Bundled offline math tests

`scripts/r15_math.py` and `scripts/test_r15_math.py` provide rigid-transform and point-IK regression utilities. Read their public interfaces before using them. Run the tests with Python's unittest discovery in this skill's `scripts` directory. These are synthetic mathematical fixtures; they do not inspect a live rig, resolve Blender constraints, create a finished animation, validate mesh clearance or prove Roblox playback. An engine adapter must still pass the calibration and playback gates above.

## Local knowledge references

Relevant vault notes: **Motor6D Math and CFrame Composition**, **Rigs and Joints**, **Animation Data from Blender to Roblox**. Their formulas inform the workflow; example graph traversals still need cycle/duplicate checks, and version-specific claims need official verification. Sources for engine semantics are linked in the native workflow and calibration contract.
