---
name: blender-cutscene-production
description: "Use for Blender cutscenes. Stage, light, render and verify."
---

# Blender cutscene production

Produce a complete dramatic scene, not disconnected animation demos: calibrated cast performance, readable staging, intentional coverage, set, lighting, moving preview and reproducible editable delivery. In this pack preserve **fwjelaa (FWJ STUDIOS)** attribution.

## Choose the delivery contract

- **Pack-connected authoring:** Blender authors actors and camera through [make-cutscene](../make-cutscene/SKILL.md) and sibling [make-anim](../make-anim/SKILL.md). Roblox still plays exported clips, UI/cues and gameplay return. A Blender movie does not replace that runtime or prove it works.
- **Standalone Blender proof:** an explicitly scoped `.blend` plus rendered preview can demonstrate acting and cinematography without publication. Identify proxy geometry and missing engine tests. An authentic external control rig is a separate calibrated workflow, not an automatic filmset input.
- **Planning only:** deliver source/production notes without claiming a build or render. Do not mutate a connected scene, install software, inspect credentials or upload merely to research a skill.

Read [authoring and render integration](references/authoring-and-render.md) before execution. Resolve the pack location from this skill's folder; never copy another machine's absolute paths. Discover actual tool schemas and Blender version. A failed connection is a blocker, not permission to launch a headless substitute when GUI authoring was requested.

## Collaborators

1. Before blocking, read bundled [scene direction](../cinematic-scene-direction/SKILL.md), [performance editing](../cinematic-performance-editing/SKILL.md) and [research lessons](../make-cutscene/references/movie-research-lessons.md). Use their [direction packet](../cinematic-scene-direction/templates/direction-packet.md) and [edit comparison](../cinematic-performance-editing/templates/edit-comparison.md) for knowledge transitions, reaction-exit conditions and held-view versus cut tests. Do not duplicate their research or copy source-film timings.
2. Route actor work through the [animation bridge](../make-cutscene/references/animation-skill-bridge.md). Load available `animation`, `universal-r15-animation-director`, and for dual-rig delivery `universal-r6-blender-animation-director`. Prefer bundled copies when supplied; otherwise use the bridge's fallback. Directors supplement, not replace, the supported pose-script/export contract.
3. Load available `blender`, `blender-automation`, `blender-rig-animate`, `blender-light-camera` and `blender-render` for the actual task. Read sibling skill files directly if unregistered. These names are expertise routes, not invented tools or mandatory global installs.

## Production gates

1. **Brief and safety:** identify the owned scene/output folder, scope, authorized inputs, rights, style, duration, aspect and delivery. Preserve unrelated Blender data and the real game map. Record assumptions and evidence status in the [production record](templates/production-record.md).
2. **Calibrate:** inspect captured rig/stand/bind identity and source module provenance. Test asymmetric limb motions and turned-root compound poses on the authorized build before full acting. Measure actual endpoint/contact behavior; a familiar body name is not calibration. Keep one declared basis conversion.
3. **Block the whole scene:** establish geography, objectives, stimulus → interpretation → choice → visible response, listener behavior and playable destination. Complete all actors across the full timeline before polish. A meaningful quiet hold is valid; idle noise is not acting.
4. **Solve contact:** plan support intervals, weight transfer, reach, release and recovery. Re-evaluate planted soles and hand/prop targets through in-betweens and camera extrema. Correct root motion and reachable staging before adding keys. Assign grounding results; grounding alone does not lock contacts.
5. **Choose coverage in motion:** frame actual cast/props and delivery masks. Compare a held shared view against a motivated cut before committing. Check eyelines, action phase, screen direction and reaction exits. Do not insert a cut merely because a line or beat changed.
6. **Stage and light:** keep captured set geometry authoritative for engine geography. Add only separately owned, reproducible Blender presentation dressing. Use motivated key/fill/separation and readable silhouettes; test faces/hands against backgrounds at final scale. Document proxy limitations, exposure/view transform, focus and engine. Blur, darkness and effects must not conceal contact failures.
7. **Render progressively:** first camera-accurate stills, then a whole moving blocking preview, then final sequence. Preserve the pack's authored timebase. Render image sequences to revision-specific paths; encode only after checking continuity/count. Recheck the moving result, not just a montage.
8. **Deliver and verify:** reopen the delivered `.blend`, resolve dependencies, replay the preview, and reproduce from source in the authorized environment. Include sources, production manifest, render settings, evidence paths and unresolved defects. For Roblox delivery continue existing export/gates and independent R15/R6 engine tests; do not call standalone proof accepted Roblox playback.

## Completion

Deliver `.blend` + complete moving preview + reproducible actor/camera/presentation sources + evidence record. Mark each gate **planned / implemented / observed / accepted / blocked**. No fabricated render, score, emotional response or gameplay-restoration result. Renderer output alone is not audience comprehension, and a contact sheet is not timing evidence.
