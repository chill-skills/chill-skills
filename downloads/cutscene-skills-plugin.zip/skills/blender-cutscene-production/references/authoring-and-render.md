# Existing authoring integration and render boundary

This is an instruction layer over the inspected pack, not a new importer, renderer CLI or runtime feature. Read [capabilities](../../make-cutscene/references/capabilities.md) and the protected [operational method](../../make-cutscene/CLAUDE.md), including current reconciliation notices. No commands below were executed in Blender during this documentation task.

## Paths and lifecycle

`PACK` is `skills/make-cutscene`, not the shared repository root. Its sibling `skills/make-anim` is a code dependency. [paths.py](../../make-cutscene/kit/paths.py) resolves the work folder from `MAKE_CUTSCENE_WORK`, then config `work_dir`, then `~/make-cutscene`; scene folders are `cutscenes/<Id>`. Keep an explicit work folder for reproducibility. IDs start with an ASCII letter, use ASCII letters/digits/underscore, and are at most 43 characters.

[run.py](../../make-cutscene/kit/run.py) supplies these existing commands, from PACK with the available Python launcher:

```text
py kit/run.py new <Id>
py kit/run.py beats <Id>
py kit/run.py beats <Id> --go
py kit/run.py scene <Id>
py kit/run.py gates <Id>
```

These are invocation forms, not executed checks or a complete unattended pipeline. `new` creates files; `--go` requires the viewer's approval first. Reference/beat authoring and authorized map/rig captures must precede building. Follow the existing method for every transfer part. Never run legacy `check` in no-credential scope: it reads the configured key. `preview` processes a Studio recording; it is **not** a Blender render command. `playtest --set` records a reported outcome; it does not exercise gameplay.

Inside an authorized connected Blender session, after substituting actual resolved paths, the supported entry points are:

```python
# Run inside Blender, not ordinary Python; preserve the user's scene.
import sys
import importlib
sys.path.insert(0, str(pack_path / "kit"))
import filmset
importlib.reload(filmset)
print(filmset.build(str(scene_folder)))
```

`pack_path` and `scene_folder` above must be explicitly resolved `pathlib.Path` values supplied by the caller; this is an invocation fragment, not a ready-to-run standalone script. Inspect the returned report: validation failure can return text rather than raise. Missing actor/camera sources generate placeholders, not finished acting.

[filmset.py](../../make-cutscene/kit/filmset.py) rebuilds `CS_<Id>` from `beats.json`, optional `map.json`, `rigs/`, costume inputs and `anim/*.py`. It clears its `cs_set == <Id>` owned data, rejects conflicting unowned names, switches GUI windows to its scene and writes `<scene_folder>/<Id>.blend` with `bpy.data.libraries.write`. It does not automatically create a final lighting setup or movie. A failed build after clearing can leave a partial live scene while the saved file remains the previous build. Do not report the old file as the new result.

`filmset.export(str(scene_folder))` **calls build again**, then writes actor/Stage clips and `export/framing.json`, `export/scene.json`. Inspect export issues, source freshness and subsequent `scene`/`gates` results. Hand-edited actor/camera changes are lost on rebuild/export. No new `set.py`, lighting hook, foreign-action importer or generic render command is added here.

## Exact actor contract

`anim/<role>.py` defines `build()` returning an **unbuilt** `ak.Anim(NAME, rig=RIG, length=FRAMES, fps=FPS, priority="Action4")`. Filmset injects `ak`, `NAME`, `RIG`, `ROLE`, `FRAMES`, `FPS`, `SHOTS`, `F`, `PLACE`, `BEATS`; `F(seconds)` rounds seconds to the 60 fps grid. Every actor spans the full scene with endpoint keys at `0` and `FRAMES`; initialize every joint with `a.full(...)`. Scene duration remains within the pack's documented limits. Character poses use body-part names and `(x, y, z)` degrees or `(x, y, z, px, py, pz)` degrees/studs—not arbitrary control-bone channels.

[animkit.py](../../make-anim/kit/animkit.py) provides `Anim.key`, `full`, `hold`; ease applies from a key to its next key. `ak.ground` returns a new dictionary: assign `pose = ak.ground(pose, RIG)`. It adjusts the lowest foot height, not both-foot or horizontal locking. `Anim.lock_feet`/`ak.plant` are not a general R15 IK solution.

Use [_r15.py](../../make-anim/anims/_r15.py) for the pack's `plant`, `reach`, `root`, `fk` and orientation helpers. Filmset `load_anim` binds them to the chosen R15-shaped rig during source execution/build and restores the prior binding in `finally`; do not silently reset to stock `R15`. Character-space targets are relative to HumanoidRootPart: X right, Y up, character forward -Z; floor height depends on the selected rig's stand. Place/anchor/world targets must be converted into that character space once. Solve and measure endpoint position, wrist/sole orientation and support drift; clamped IK does not prove reachability. The stock helper's assumptions are not universal physiology.

Captured proportions may produce registered rigs; near-stock captures may use stock geometry. The kit builds stand-in body geometry and coarse costume/accessory proxies. This is a supported authoring representation, **not** an authentic final skinned avatar or a visual-equivalence claim. An external authentic Blender rig belongs to the director's separate calibration/control/export workflow; re-author supported pose scripts or scope/test an adapter before claiming filmset compatibility.

`anim/<role>_R6.py` receives `DERIVED` for overrides. R6 is not accepted merely because derivation or an override exists: re-author meaning-bearing action/contact and test independently. The derived-player route uses stock R6/default stand, not captured R6-player proportions. See the [animation bridge](../../make-cutscene/references/animation-skill-bridge.md).

## Exact camera and time contract

`anim/camera.py` defines `build(cam)` and receives `SHOTS`, `FPS`, `BEATS`. [CamPlan](../../make-cutscene/kit/camtrack.py) supplies:

```text
cam.shot(n)
cam.key(t, eye, look, fov=50.0, roll=0.0, ease="cubic_inout")
```

`t` is seconds; eye/look are anchor-space Roblox studs; FOV is **vertical degrees**, not a Blender lens value. `cam.shot(n)` returns a copy including `start`, `end`, `last`; `last` is that shot's last sampled time. Key time zero and every declared cut exactly. Include the last-frame pose before each cut when a move must continue to that point: `resolved()` makes the preceding key constant through the jump. The camera is held to the scene endpoint. Filmset uses one camera with hard jumps, vertical sensor fit and a 24 mm sensor; camtrack owns lens and basis conversion. Blender camera markers or a multi-camera switch are not this pack's source contract.

The authored domain is inclusive `0..FRAMES`, last time `FRAMES/FPS`. An encoded sequence containing both endpoints has one more image than intervals. Preserve the endpoint for clip/export inspection. Document whether the movie contains every endpoint sample or encodes `0..FRAMES-1` with the endpoint reviewed separately; verify actual count/duration rather than silently changing authoring FPS or truncating action. Do not infer duration from filenames alone.

## Presentation, set and lighting

The captured map is a coarse stand-in, not permission to remodel the live game. Keep required landmarks, scale, actor contact surfaces and camera occlusion consistent. Filmset's color quantization and accessory boxes limit final appearance judgments. A standalone set may be original and fully dressed, but label it standalone rather than pretending it is a faithful map capture.

For a Blender-only polished preview, create a separately named/revisioned **presentation source script** and owned collection after the supported build. This is a proposed project artifact, not an auto-loaded kit hook. Run it explicitly after the final build/export; own/delete only its own objects and data, and never retag unrelated assets. Filmset's cleanup kinds omit lights/worlds: do not rely on its tagging context to manage presentation lights. Keep independent ownership and rerun cleanup. Restore intended camera, source range, frame, color settings and render settings explicitly. Do not alter export rigs or source-camera curves for a prettier render.

Save presentation to a distinct final `.blend`, retaining the supported base file. Record source hashes and inputs for both. Presentation light/material/DOF/compositor changes are not automatically exported to Roblox, and presentation scripts are not automatically covered by the kit's source-freshness checks. Track them separately. Avoid saving unrelated user scenes or assets into the deliverable.

Start with clear silhouette and contact diagnostics. Then establish a motivated key, controlled fill and separation as needed; use real prop/background depth rather than arbitrary camera motion. Test near/far clipping, focus, exposure, noisy shadows and bright highlights across all shots. Inspect available engine/device/node sockets and OCIO settings in the installed Blender; never equate `latest` documentation with installed support.

## Render and verification

1. Confirm authorized connected session and actual Blender version. On connection failure, stop scene execution and report it. If the user requests GUI/add-on recovery, the responsible operator handles that route; do not silently switch to headless.
2. Inspect first/last frames, every cut's outgoing/incoming frames, important contacts, reaction exits and motion extrema with actual delivery aspect and mask. Filmset's legacy multi-frame tool preview may be center-cropped; inspect tool schema and camera-accurate output rather than certifying framing from it.
3. Render a full low-cost blocking sequence; compare held-versus-cut alternatives using the linked editorial worksheet. Review moving playback before expensive lighting or final rendering.
4. Render lossless frames into a fresh revision directory. Set frame step, start/end, FPS/base, resolution/percentage, engine/device, samples, output path/format, color management and active camera explicitly. Check that output saving is enabled where the installed version exposes it. Avoid a stale Sequencer/compositor pipeline replacing intended camera output.
5. Verify the enumerated sequence has no gaps, duplicates or stale files; decode it, check dimensions/count and inspect motion/cut/contact passages. Encode a preview with an actually available encoder or Blender Sequencer, preserving the declared timebase. Do not claim audio exists when none was produced; voice/SFX/J/L-cut intentions remain planning-only in the pack runtime.
6. Reopen the delivered `.blend` in the authorized environment, check dependencies and representative frames, and reproduce from sources. Record logs, actual paths, evidence coverage and skipped checks. A successful save or encode return code alone is insufficient.

Modern animation scripting must respect action slots/channelbags. Blender 5.0 removed legacy `action.fcurves`; this pack already routes curve access through `ak.all_fcurves` and `anim_utils.animdata_get_channelbag_for_assigned_slot`. Do not replace that with legacy snippets or assume foreign actions are compatible.

## Acceptance split

**Blender proof:** reproducible sources, calibrated rig identity, complete scene, editable final blend, moving preview, frame-level and playback observations, known proxy limits.

**Roblox delivery:** all applicable Blender/source work plus current exports/gates, independent R15/R6 dressed-cast playback/framing/contact, authorized installation/publication, normal end/permitted skip/death/interruption and actual camera/control/cleanup verification. Existing review criteria and fix-round limits remain. Blender lighting, props, sound or compositing added for presentation do not imply equivalent runtime features.

## Sources

- [Rendering Animations — Blender Manual](https://docs.blender.org/manual/en/latest/render/output/animation.html): recoverable image-sequence workflow and output-saving caveat.
- [Blender 5.0: Python API](https://developer.blender.org/docs/release_notes/5.0/python_api/): removal of legacy Action access; channelbag/slot alternatives.
- [Command Line Arguments — Blender Manual](https://docs.blender.org/manual/en/latest/advanced/command_line/arguments.html): inclusive render range, output patterns and execution ordering; documentation only, not authorization to launch background Blender.
- [Displays and Views — Blender Manual](https://docs.blender.org/manual/en/latest/render/color_management/displays_views.html): view transforms and output color interpretation. Search retrieved; installed OCIO settings still require discovery.
