# Blender cutscene production record

Production notes only; not new beats.json fields or runtime cue schema. Record actual values and evidence, never fill unchecked boxes with inferred success.

## Identity and scope
- Scene/revision; owner; authorized mutation/output scope:
- Delivery: planning / standalone Blender proof / pack-connected Roblox delivery:
- Resolved PACK, scene folder and presentation output folder:
- Blender version, connected session, engine/device; dependency versions:
- Sources/rights; source file identities/hashes; immutable inputs:
- Proxy versus authentic geometry; known representation limits:
- Linked direction packet and edit-comparison record:

Use the existing [direction packet](../../cinematic-scene-direction/templates/direction-packet.md) and [edit comparison](../../cinematic-performance-editing/templates/edit-comparison.md) for knowledge-state changes, reaction-exit conditions and hold-versus-cut comparisons. Use [research lessons](../../make-cutscene/references/movie-research-lessons.md) as bounded proposals, not accepted timing.

## Calibration and contact
| Role | Rig/capture identity and stand | Control/pose contract | Diagnostic evidence | Remaining limitations |
|---|---|---|---|---|
| | | | | |

- Axis/unit conversion boundary; root/anchor/character spaces:
- Asymmetric limb and turned-root checks; measured endpoint/orientation residuals:
- Support/contact intervals; original targets, reach policy and tolerances:
- Evaluated in-between drift/penetration; fixes and evidence:
- R6 re-authored performance/contact and independent evidence, if required:

## Shot and delivery settings
- Authored FPS/base, inclusive start/end; cut frames and endpoint policy:
- Encoded frame domain, count and actual duration; mapping to source timeline:
- Aspect/resolution/percentage; delivery mask/caption-safe area:
- Active camera identity; vertical FOV contract; focus/clipping:
- Presentation source script and owned data; explicit invocation order:
- Set/geography fidelity; presentation-only differences from Roblox:
- Engine/device/samples; lights/world; exposure/view transform/OCIO:
- Output sequence path/pattern/format; encoder/settings; audio status:

## Evidence ledger
| Check | Build/source identity | Evidence path and coverage | Result/status | Defect or next owner |
|---|---|---|---|---|
| Source contracts and placeholders absent | | | Not tested | |
| Full-scene moving blocking preview | | | Not tested | |
| Hold-versus-cut comparison | | | Not tested | |
| Contacts, keys, midpoints and extrema | | | Not tested | |
| Camera/mask/accessory framing and cut neighbors | | | Not tested | |
| Lighting/focus/color consistency | | | Not tested | |
| Sequence completeness and decoding | | | Not tested | |
| Encoded preview playback | | | Not tested | |
| Delivered blend reopened; dependencies resolved | | | Not tested | |
| Reproduced from actor/camera/presentation sources | | | Not tested | |
| Applicable Roblox gates and independent rig tests | | | Not tested | |
| Actual gameplay handback and cleanup | | | Not tested | |

## Handoff
- Base `.blend`; presentation `.blend`; complete moving preview:
- Actor/camera/beat/capture sources; presentation script; dependency manifest:
- Actual commands/tool invocations and returned results:
- Planned / implemented / observed / accepted / blocked stages:
- Unresolved defects, untested stages and explicit next acceptance owner:
- Method attribution: fwjelaa (FWJ STUDIOS).
