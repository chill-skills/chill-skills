# Retención

Lo que hace volver: [[Recompensas diarias]], misiones, eventos semanales, progreso visible y amigos.

**Relacionado:** [[Misiones y logros]] · [[Live ops y eventos]]
