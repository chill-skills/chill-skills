# Developer Products y ProcessReceipt

Compras repetibles (monedas, revivir). Debes manejar `ProcessReceipt` en el servidor y devolver `PurchaseGranted` solo cuando ya diste el objeto y guardaste.

**Relacionado:** [[MarketplaceService]] · [[Guardar datos con DataStore]]
