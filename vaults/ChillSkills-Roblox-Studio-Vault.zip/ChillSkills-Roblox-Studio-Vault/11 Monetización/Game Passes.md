# Game Passes

Compra única (VIP, x2 monedas). Compruébalo con `UserOwnsGamePassAsync` al entrar.

**Relacionado:** [[MarketplaceService]] · [[Reglas de monetización]]
