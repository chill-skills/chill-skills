# Reglas de monetización

Muestra probabilidades en objetos aleatorios de pago, no engañes con precios, nada de pay-to-win abusivo. Lee las normas de Roblox antes de publicar.

**Relacionado:** [[Huevos y probabilidades]] · [[Game Passes]]
