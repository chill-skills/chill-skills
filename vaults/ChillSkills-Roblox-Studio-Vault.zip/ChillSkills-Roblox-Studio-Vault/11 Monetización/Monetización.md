# Monetización

Índice de **Monetización**.

- [[Developer Products y ProcessReceipt]]
- [[Economía del juego]]
- [[Game Passes]]
- [[Live ops y eventos]]
- [[Marketing y comunidad]]
- [[Miniaturas e icono]]
- [[Reglas de monetización]]
- [[Retención]]

Volver a [[Inicio]]
