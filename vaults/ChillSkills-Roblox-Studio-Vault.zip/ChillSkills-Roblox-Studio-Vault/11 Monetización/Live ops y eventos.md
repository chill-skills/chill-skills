# Live ops y eventos

Actualizaciones frecuentes, eventos de fin de semana, bosses globales con [[MessagingService]].

**Relacionado:** [[Retención]] · [[Lobby y partidas]]
