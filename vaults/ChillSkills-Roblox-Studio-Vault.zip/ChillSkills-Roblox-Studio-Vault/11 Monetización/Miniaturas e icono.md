# Miniaturas e icono

El icono y las miniaturas deciden si alguien entra: personaje grande, emoción clara, poco texto, colores fuertes.

**Relacionado:** [[Publicar el juego]] · [[Marketing y comunidad]]
