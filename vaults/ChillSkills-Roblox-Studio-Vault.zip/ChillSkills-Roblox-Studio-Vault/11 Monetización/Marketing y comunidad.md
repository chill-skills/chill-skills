# Marketing y comunidad

TikTok/Shorts con gancho en 2 s (ver [[SkitKit Story Shorts]]), grupo de Roblox, Discord y códigos en cada update.

**Relacionado:** [[Códigos]] · [[Miniaturas e icono]]
