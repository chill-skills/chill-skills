# Economía del juego

Equilibra cuánto ganas por minuto y cuánto cuesta lo siguiente: el jugador debe poder comprar algo nuevo cada pocos minutos al principio.

**Relacionado:** [[Monedas]] · [[Rebirth]] · [[Matemáticas de juego]]
