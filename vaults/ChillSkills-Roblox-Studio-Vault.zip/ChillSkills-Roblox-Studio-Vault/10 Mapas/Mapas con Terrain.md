# Mapas con Terrain

Editor de Terrain: genera, pinta materiales y agua. Combínalo con Parts para caminos y edificios.

**Relacionado:** [[Workspace]] · [[make-map (fwjelaa)]]
