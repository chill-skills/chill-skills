# Diseño de niveles

Guía al jugador con luz y color, puntos de referencia visibles, nada de pasillos vacíos largos.

**Relacionado:** [[Iluminación]] · [[Obby]]
