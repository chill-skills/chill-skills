# Obby

Fases cortas, dificultad que sube, checkpoints, lava con tag. Cada 10 fases un descanso o premio.

**Relacionado:** [[Checkpoints]] · [[CollectionService]] · [[Puertas y plataformas]]
