# StreamingEnabled

Carga el mapa por zonas cerca del jugador: imprescindible en mapas grandes y móviles. Ojo: en el cliente usa `WaitForChild`.

**Relacionado:** [[Rendimiento en móvil]] · [[Memoria e instancias]]
