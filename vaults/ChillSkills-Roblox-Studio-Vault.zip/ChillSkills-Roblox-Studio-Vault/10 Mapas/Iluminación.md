# Iluminación

Lighting → Technology = Future para sombras bonitas; ClockTime para la hora; luces PointLight con sombras solo donde importe.

**Relacionado:** [[Lighting]] · [[Post-procesado]]
