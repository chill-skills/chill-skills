# Física y vehículos

Usa constraints (HingeConstraint, CylindricalConstraint) para ruedas; VehicleSeat para controles básicos.

**Relacionado:** [[Network ownership]]
