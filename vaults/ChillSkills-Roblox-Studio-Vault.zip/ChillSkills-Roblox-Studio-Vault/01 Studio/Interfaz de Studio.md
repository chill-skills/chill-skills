# Interfaz de Studio

Las ventanas que más vas a usar:
- **Explorer**: el árbol de todo lo que hay en el juego.
- **Properties**: las propiedades del objeto que tienes seleccionado.
- **Output**: errores y `print()`. Ábrela siempre (View → Output).
- **Toolbox**: modelos y audios de la Creator Store (¡revisa scripts raros!).
Truco: View → *Command Bar* para ejecutar Luau al momento.

**Relacionado:** [[Explorer y Properties]] · [[Command Bar]] · [[Modelos gratis con virus]]
