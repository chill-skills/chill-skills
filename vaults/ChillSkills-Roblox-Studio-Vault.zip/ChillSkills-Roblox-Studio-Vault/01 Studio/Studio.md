# Studio

Índice de **Studio**.

- [[Atajos útiles]]
- [[Checklist antes de publicar]]
- [[Command Bar]]
- [[Dónde va cada script]]
- [[Explorer y Properties]]
- [[Interfaz de Studio]]
- [[Modelos gratis con virus]]
- [[Publicar el juego]]
- [[Team Create]]

Volver a [[Inicio]]
