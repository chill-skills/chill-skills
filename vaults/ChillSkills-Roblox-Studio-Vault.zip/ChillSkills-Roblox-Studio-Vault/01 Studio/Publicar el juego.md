# Publicar el juego

1. File → Publish to Roblox.
2. En *Game Settings* pon nombre, descripción, icono y miniaturas.
3. Permissions → Public cuando esté listo.
Antes: prueba en móvil con el emulador (Test → Device). Ver [[Checklist antes de publicar]].

**Relacionado:** [[Miniaturas e icono]]
