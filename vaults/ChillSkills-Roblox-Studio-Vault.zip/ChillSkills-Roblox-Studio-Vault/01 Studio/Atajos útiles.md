# Atajos útiles

- **F**: centrar cámara en lo seleccionado.
- **Ctrl+D**: duplicar. **Ctrl+G**: agrupar en Model.
- **Ctrl+1/2/3/4**: seleccionar, mover, escalar, rotar.
- **F5** Play · **F8** Run · **Shift+F5** parar.

**Relacionado:** [[Interfaz de Studio]]
