# Checklist antes de publicar

- [ ] Sin errores rojos en [[Interfaz de Studio|Output]].
- [ ] Los datos se guardan ([[Guardar datos con DataStore]]).
- [ ] Funciona en móvil ([[UI para móvil]]).
- [ ] Remotes validados en el servidor ([[Validar en el servidor]]).
- [ ] Miniaturas e icono listos ([[Miniaturas e icono]]).
