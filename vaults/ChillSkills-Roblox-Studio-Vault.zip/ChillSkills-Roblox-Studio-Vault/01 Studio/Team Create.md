# Team Create

Para trabajar con amigos a la vez: Home → Collaborate. Cada script se edita con *Drafts*: guarda y pulsa *Commit* para que los demás lo vean. Dales solo los permisos que necesiten.

**Relacionado:** [[Publicar el juego]]
