# Explorer y Properties

Cada objeto (Instance) tiene un **Parent** y propiedades.
- Arrastra en el Explorer para cambiar el Parent.
- `Anchored = true` para que una Part no caiga.
- `CanCollide = false` para atravesarla.
Ver dónde va cada cosa: [[Dónde va cada script]].

**Relacionado:** [[Workspace]]
