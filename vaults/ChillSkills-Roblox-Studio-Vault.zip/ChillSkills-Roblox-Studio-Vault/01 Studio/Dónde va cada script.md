# Dónde va cada script

| Tipo | Dónde | Corre en |
|---|---|---|
| Script | [[ServerScriptService]] | Servidor |
| LocalScript | [[StarterPlayer]] / [[StarterGui]] | Cliente |
| ModuleScript | [[ReplicatedStorage]] o ServerScriptService | Donde lo pidas |
Regla: lo importante (dinero, daño, compras) siempre en el servidor. Ver [[Cliente y servidor]].

**Relacionado:** [[ModuleScripts]]
