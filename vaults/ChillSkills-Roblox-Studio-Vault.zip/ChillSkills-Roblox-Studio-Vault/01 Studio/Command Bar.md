# Command Bar

Ejecuta código en Studio sin darle a Play. Útil para mover 100 partes de golpe:
```lua
for _, p in workspace.Monedas:GetChildren() do p.Color = Color3.new(1,0.8,0) end
```
No sirve para el juego publicado: es solo para editar.

**Relacionado:** [[Interfaz de Studio]]
