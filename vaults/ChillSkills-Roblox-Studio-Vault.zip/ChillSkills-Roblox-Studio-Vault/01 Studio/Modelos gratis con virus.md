# Modelos gratis con virus

Muchos modelos de la Toolbox traen scripts escondidos (backdoors) que dejan a otros controlar tu juego.
- Busca scripts dentro del modelo antes de usarlo.
- Señales malas: `require(123456789)`, `getfenv`, `loadstring`, texto ilegible.
- Mejor: hazlo tú con skills como [[LihFolk Stud Voxel]] o usa modelos de autores verificados.

**Relacionado:** [[Exploits comunes]]
