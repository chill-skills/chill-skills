# MicroProfiler

Ctrl+F6 en el juego: muestra qué consume cada frame. Busca barras altas y script names.

**Relacionado:** [[Rendimiento en móvil]]
