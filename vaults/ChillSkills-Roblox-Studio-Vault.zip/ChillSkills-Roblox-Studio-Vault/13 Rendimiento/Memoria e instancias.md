# Memoria e instancias

Destruye lo que no uses (`:Destroy()`, [[Debris]]), desconecta eventos y no clones miles de partes.

**Relacionado:** [[Eventos y conexiones]]
