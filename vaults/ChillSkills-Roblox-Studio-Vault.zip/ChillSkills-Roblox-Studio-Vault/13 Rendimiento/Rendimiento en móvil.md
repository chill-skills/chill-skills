# Rendimiento en móvil

Menos partes y partículas, StreamingEnabled, texturas pequeñas, sombras solo donde importa.

**Relacionado:** [[StreamingEnabled]] · [[MicroProfiler]] · [[UI para móvil]]
