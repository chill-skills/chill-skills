# Rendimiento

Índice de **Rendimiento**.

- [[Memoria e instancias]]
- [[MicroProfiler]]
- [[Rendimiento en móvil]]

Volver a [[Inicio]]
