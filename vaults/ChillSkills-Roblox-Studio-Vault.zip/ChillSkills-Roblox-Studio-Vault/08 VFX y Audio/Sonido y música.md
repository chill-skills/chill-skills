# Sonido y música

Sonidos en la Part para que suenen en 3D; música en [[SoundService]] con SoundGroups y botón de silenciar en Ajustes.

**Relacionado:** [[Menús de simulador]]
