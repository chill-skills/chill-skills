# Beam y Trail

Beam une dos Attachments (rayos, láser). Trail deja estela al moverse (espadas, dash).

**Relacionado:** [[ParticleEmitter]] · [[Combate y hitboxes]]
