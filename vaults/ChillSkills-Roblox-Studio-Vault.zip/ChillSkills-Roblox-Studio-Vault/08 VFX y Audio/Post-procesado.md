# Post-procesado

En Lighting: Bloom (brillo), ColorCorrection (color), Atmosphere (niebla bonita), SunRays. Poco: si te pasas, se ve borroso.

**Relacionado:** [[Lighting]] · [[Iluminación]]
