# Highlight

Contorno brillante de un modelo: para seleccionar objetos, enemigos, mascotas raras.

**Relacionado:** [[Mascotas]]
