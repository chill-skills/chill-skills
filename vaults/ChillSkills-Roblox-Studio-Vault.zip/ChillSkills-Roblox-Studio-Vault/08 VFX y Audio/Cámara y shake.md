# Cámara y shake

Shake suave con `RenderStepped` y ruido (`math.noise`) en golpes fuertes; nunca marees al jugador.

**Relacionado:** [[RunService]] · [[Combate y hitboxes]]
