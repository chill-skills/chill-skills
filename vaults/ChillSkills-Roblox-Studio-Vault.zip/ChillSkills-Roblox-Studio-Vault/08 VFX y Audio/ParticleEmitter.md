# ParticleEmitter

Chispas, humo, fuego. Claves: Rate, Lifetime, Speed, Size (curva), Transparency (curva), LightEmission. Para explosiones usa `:Emit(30)` en vez de Rate.

**Relacionado:** [[Debris]] · [[vfxmith]]
