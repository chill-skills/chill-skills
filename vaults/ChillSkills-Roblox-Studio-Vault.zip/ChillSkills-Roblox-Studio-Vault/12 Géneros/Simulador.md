# Simulador

Bucle: hacer clic/correr → ganar → mejorar → rebirth. Claves: números que suben, mascotas, muchos menús.

**Relacionado:** [[Monedas]] · [[Rebirth]] · [[Mascotas]] · [[Abreviar números]] · [[+1 Speed]]
