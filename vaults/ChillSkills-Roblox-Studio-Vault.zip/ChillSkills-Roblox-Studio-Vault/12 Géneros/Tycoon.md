# Tycoon

Botones que compran partes de tu base y un dropper que genera dinero. Guarda qué se ha comprado.

**Relacionado:** [[Tienda]] · [[Guardar datos con DataStore]] · [[Economía del juego]]
