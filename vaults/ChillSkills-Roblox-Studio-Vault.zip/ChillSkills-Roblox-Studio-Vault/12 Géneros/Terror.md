# Terror

Iluminación oscura, sonido 3D, sustos con ritmo y un monstruo con pathfinding.

**Relacionado:** [[Iluminación]] · [[Sonido y música]] · [[PathfindingService]]
