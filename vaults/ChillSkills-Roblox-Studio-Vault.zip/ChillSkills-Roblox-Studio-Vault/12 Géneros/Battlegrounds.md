# Battlegrounds

Combate R6 rápido: combos M1, habilidades, dash, ultimates. Las animaciones lo son todo.

**Relacionado:** [[Combate y hitboxes]] · [[R6 vs R15]] · [[Roblox Animations (fwjelaa)]]
