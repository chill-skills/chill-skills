# Roleplay

Casas, trabajos, vehículos y mucha personalización; poco objetivo fijo.

**Relacionado:** [[Física y vehículos]] · [[Inventario]]
