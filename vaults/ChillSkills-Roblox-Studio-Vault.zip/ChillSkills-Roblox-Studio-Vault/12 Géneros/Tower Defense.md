# Tower Defense

Oleadas de enemigos por un camino y torres que compras y mejoras. Enemigos con nodos de camino, no con física.

**Relacionado:** [[Enemigos y spawns]] · [[Economía del juego]]
