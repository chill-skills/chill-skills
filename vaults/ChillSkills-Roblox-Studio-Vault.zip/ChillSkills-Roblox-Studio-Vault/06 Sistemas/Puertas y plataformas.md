# Puertas y plataformas

Puertas con ProximityPrompt + [[TweenService]]; plataformas móviles con PrismaticConstraint o tweens en el servidor.

**Relacionado:** [[Obby]]
