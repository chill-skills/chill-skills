# Inventario

Tabla por jugador `{espadas = {...}, equipado = "Arpón"}` guardada en DataStore. Nunca guardes Instances, guarda ids.

**Relacionado:** [[Tablas]] · [[Guardar datos con DataStore]] · [[Tienda]]
