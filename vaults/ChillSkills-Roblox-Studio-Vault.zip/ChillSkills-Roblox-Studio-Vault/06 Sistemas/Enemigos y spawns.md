# Enemigos y spawns

Plantillas en [[ServerStorage]], clona en puntos de spawn, IA con [[PathfindingService]], bosses con [[Bosses Roblox Studs]].

**Relacionado:** [[OOP con metatables]]
