# Códigos

Tabla de códigos en el servidor `{CHILL2026 = 500}`; guarda cuáles ha usado cada jugador.

**Relacionado:** [[Guardar datos con DataStore]] · [[Marketing y comunidad]]
