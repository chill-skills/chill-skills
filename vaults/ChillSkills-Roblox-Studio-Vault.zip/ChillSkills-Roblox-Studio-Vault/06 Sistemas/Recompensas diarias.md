# Recompensas diarias

Guarda `ultimoDia = os.time()`; si pasaron más de 24 h, da premio y suma racha.

**Relacionado:** [[Guardar datos con DataStore]] · [[Retención]]
