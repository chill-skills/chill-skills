# Tienda

Lista de objetos en un ModuleScript (precio, icono). El cliente pide comprar con un RemoteEvent; el servidor comprueba dinero y lo da. UI con [[Check-UI]].

**Relacionado:** [[ModuleScripts]] · [[RemoteEvents]] · [[Economía del juego]]
