# Misiones y logros

Contadores por jugador (enemigos matados, pasos) que comprueban metas y dan premios o [[BadgeService|insignias]].

**Relacionado:** [[Retención]]
