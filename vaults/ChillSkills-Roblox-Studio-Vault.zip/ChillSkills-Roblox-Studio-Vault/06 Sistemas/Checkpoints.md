# Checkpoints

SpawnLocation por fase; guarda la fase en DataStore y teletransporta al aparecer.

**Relacionado:** [[Obby]] · [[Guardar datos con DataStore]]
