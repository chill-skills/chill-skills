# Lobby y partidas

Lobby en un place y partidas en otro con [[TeleportService]]; o rondas en el mismo servidor con un bucle de estados (Espera → Juego → Fin).

**Relacionado:** [[Live ops y eventos]]
