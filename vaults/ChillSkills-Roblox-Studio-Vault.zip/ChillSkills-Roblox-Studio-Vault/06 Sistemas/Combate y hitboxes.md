# Combate y hitboxes

Hitbox en el servidor con `workspace:GetPartBoundsInBox` o raycasts; daño solo en el servidor; cooldown por arma. Animaciones con [[Roblox Animations (fwjelaa)]].

**Relacionado:** [[Workspace]] · [[Validar en el servidor]] · [[Animator y AnimationTrack]]
