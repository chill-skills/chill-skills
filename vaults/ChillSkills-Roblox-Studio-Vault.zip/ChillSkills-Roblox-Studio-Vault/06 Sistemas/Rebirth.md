# Rebirth

Reinicia monedas a cambio de un multiplicador permanente. Precio que sube: `base * 2^rebirths`.

**Relacionado:** [[Economía del juego]] · [[Simulador]]
