# Trading

Las dos partes confirman en el servidor; bloquea los objetos durante el intercambio y guarda los dos datos a la vez ([[Session locking]]).

**Relacionado:** [[Inventario]]
