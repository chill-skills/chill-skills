# +1 Speed

Cada paso suma +1 de velocidad: el servidor mide distancia recorrida y sube WalkSpeed y un stat. Cintas con [[Folk Treadmills]].

**Relacionado:** [[StarterPlayer]] · [[Simulador]]
