# Huevos y probabilidades

Tabla de pesos `{Común=60, Raro=30, Épico=9, Legendario=1}`. Si se compra con Robux, Roblox obliga a mostrar las probabilidades.

**Relacionado:** [[Mascotas]] · [[Developer Products y ProcessReceipt]] · [[Reglas de monetización]]
