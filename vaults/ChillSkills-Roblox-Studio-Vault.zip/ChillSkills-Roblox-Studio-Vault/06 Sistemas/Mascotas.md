# Mascotas

Modelo que sigue al jugador (AlignPosition o CFrame en el cliente), multiplicador en el servidor. Modelos con [[LihFolk Stud Voxel]].

**Relacionado:** [[OOP con metatables]] · [[Huevos y probabilidades]] · [[PhysicsService]]
