# Monedas en el mapa

Monedas con tag "Moneda" ([[CollectionService]]). El servidor detecta `Touched`, valida distancia y suma; reaparecen con `task.delay`.

**Relacionado:** [[Validar en el servidor]] · [[Monedas]]
