# Monedas

Fuente única de dinero en el servidor; el cliente solo pide. Guarda con [[Guardar datos con DataStore]] y muestra con [[Leaderstats]].

**Relacionado:** [[Economía del juego]] · [[Monedas en el mapa]]
