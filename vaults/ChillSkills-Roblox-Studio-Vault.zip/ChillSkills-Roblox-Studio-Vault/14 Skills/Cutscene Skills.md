# Cutscene Skills

10 skills de fwjelaa: cutscenes, dirección de escenas, animaciones R6/R15 y mapas.

La encuentras en **Chill Skills**.

**Relacionado:** [[Juegos con historia]] · [[Publicar animaciones]] · [[make-map (fwjelaa)]]
