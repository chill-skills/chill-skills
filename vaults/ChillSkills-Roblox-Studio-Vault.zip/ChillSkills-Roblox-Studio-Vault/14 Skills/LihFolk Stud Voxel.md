# LihFolk Stud Voxel

Modelos vóxel estilo LEGO (mascotas, bosses, vehículos) con rig y animaciones en Luau.

La encuentras en **Chill Skills**.

**Relacionado:** [[Mascotas]] · [[Motor6D y rigs]]
