# Bosses Roblox Studs

Yeti, Tiburón, Tiburón Robot y Kraken listos con animaciones y VFX.

La encuentras en **Chill Skills**.

**Relacionado:** [[Enemigos y spawns]] · [[Motor6D y rigs]]
