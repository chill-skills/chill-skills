# model-create

Escribe `/model-create pájaro` y sale un modelo de cajas con rig, animaciones y VFX.

La encuentras en **Chill Skills**.

**Relacionado:** [[Motor6D y rigs]]
