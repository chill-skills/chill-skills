# make-map (fwjelaa)

Construye mapas caminables en Studio y los comprueba con capturas y test de paseo.

La encuentras en **Chill Skills**.

**Relacionado:** [[Mapas con Terrain]] · [[Diseño de niveles]]
