# Check-UI

Sistema de diseño de UI de simulador: tienda, códigos, rebirth, ajustes, diarias.

La encuentras en **Chill Skills**.

**Relacionado:** [[Menús de simulador]] · [[UI para móvil]]
