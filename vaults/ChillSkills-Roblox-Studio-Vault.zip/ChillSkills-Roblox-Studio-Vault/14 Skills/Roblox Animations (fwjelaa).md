# Roblox Animations (fwjelaa)

`/make-anim`: animaciones desde un clip o descripción, verificadas frame a frame.

La encuentras en **Chill Skills**.

**Relacionado:** [[Battlegrounds]] · [[R6 vs R15]] · [[Eventos de animación]]
