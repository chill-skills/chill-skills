# Roblox Studio MCP

Conecta Claude con Roblox Studio para leer y editar tu juego.

La encuentras en **Chill Skills**.

**Relacionado:** [[Interfaz de Studio]]
