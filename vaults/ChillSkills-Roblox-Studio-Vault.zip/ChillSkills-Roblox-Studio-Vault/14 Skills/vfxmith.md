# vfxmith

Efectos VFX de Roblox desde una descripción, revisados por paneles.

La encuentras en **Chill Skills**.

**Relacionado:** [[ParticleEmitter]] · [[Beam y Trail]]
