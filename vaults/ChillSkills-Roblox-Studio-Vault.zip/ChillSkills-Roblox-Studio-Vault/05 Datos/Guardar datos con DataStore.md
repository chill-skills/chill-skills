# Guardar datos con DataStore

```lua
local store = DataStoreService:GetDataStore("Datos_v1")
Players.PlayerAdded:Connect(function(p)
  local ok, data = pcall(store.GetAsync, store, p.UserId)
  data = ok and data or {Monedas = 0}
end)
Players.PlayerRemoving:Connect(function(p) pcall(store.SetAsync, store, p.UserId, datos[p]) end)
game:BindToClose(function()
  -- guarda a todos
end)
```
Mejor aún: [[UpdateAsync vs SetAsync]] y [[Session locking]].

**Relacionado:** [[DataStoreService]] · [[pcall y errores]] · [[Leaderstats]]
