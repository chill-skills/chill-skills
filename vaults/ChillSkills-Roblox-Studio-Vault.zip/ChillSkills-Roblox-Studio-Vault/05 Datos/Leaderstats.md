# Leaderstats

Carpeta llamada `leaderstats` dentro del jugador → sale en la tabla de arriba.
```lua
local ls = Instance.new("Folder"); ls.Name = "leaderstats"; ls.Parent = player
local m = Instance.new("IntValue"); m.Name = "Monedas"; m.Parent = ls
```

**Relacionado:** [[Players]] · [[Monedas]] · [[Guardar datos con DataStore]]
