# Session locking

Marca los datos como "en uso por el servidor X" al cargar y libéralos al salir. Así, si alguien entra en otro servidor muy rápido, no se duplican objetos. Librerías como ProfileStore lo hacen por ti.

**Relacionado:** [[Guardar datos con DataStore]] · [[Trading]]
