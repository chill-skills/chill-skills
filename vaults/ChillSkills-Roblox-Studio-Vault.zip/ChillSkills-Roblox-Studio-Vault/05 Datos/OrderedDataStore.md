# OrderedDataStore

Para rankings globales (top 100 de monedas): `GetOrderedDataStore("TopMonedas")` y `GetSortedAsync(false, 100)`. Actualízalo cada pocos minutos, no cada segundo.

**Relacionado:** [[Leaderstats]] · [[Live ops y eventos]]
