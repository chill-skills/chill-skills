# Datos en Studio

Para probar DataStores en Studio: Game Settings → Security → *Enable Studio Access to API Services*. Usa un nombre distinto (`Datos_test`) para no romper los datos reales.

**Relacionado:** [[Guardar datos con DataStore]]
