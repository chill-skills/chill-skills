# UpdateAsync vs SetAsync

`SetAsync` sobrescribe a ciegas. `UpdateAsync` lee lo que hay y decide: evita perder datos si dos servidores guardan a la vez.

**Relacionado:** [[Guardar datos con DataStore]] · [[Session locking]]
