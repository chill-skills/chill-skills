# 🌌 Chill Skills · Roblox Studio Vault

Tu segundo cerebro para hacer juegos de Roblox, en español. Cada nota está enlazada con otras: abre la **vista de grafo** (Ctrl+G) y verás la galaxia.

## Secciones
- [[Studio]]
- [[Luau]]
- [[Servicios]]
- [[Red y Seguridad]]
- [[Datos en Studio]]
- [[Sistemas]]
- [[UI para móvil]]
- [[VFX y Audio]]
- [[Animación]]
- [[Mapas con Terrain]]
- [[Monetización]]
- [[Géneros]]
- [[Rendimiento en móvil]]
- [[Skills]]
- [[Plantillas]]

## Empezar
1. [[Interfaz de Studio]] → [[Dónde va cada script]] → [[Cliente y servidor]]
2. Tu primer sistema: [[Monedas]] + [[Leaderstats]] + [[Guardar datos con DataStore]]
3. Antes de publicar: [[Checklist antes de publicar]]

## Con Claude
Abre esta carpeta en la pestaña **Code** de la app de Claude. Lee [[CLAUDE]] y usa estas notas para ayudarte.

[[Créditos]]
