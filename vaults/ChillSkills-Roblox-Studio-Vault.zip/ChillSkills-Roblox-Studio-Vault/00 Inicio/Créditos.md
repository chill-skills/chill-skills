# Créditos

Vault original de **Chill Skills** (texto en español escrito para este vault).
Tema de Obsidian *fwjelaa's Infinite Void* y plugin *fwjelaa Graph* de **fwjelaa (FWJ STUDIOS)**, CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ · https://discord.gg/GgV7TWpwd9
¿Quieres más? El [[fwjelaa vault]] tiene 1.400+ notas.
