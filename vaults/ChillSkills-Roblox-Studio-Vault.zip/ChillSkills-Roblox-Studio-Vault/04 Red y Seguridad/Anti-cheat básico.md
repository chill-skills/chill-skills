# Anti-cheat básico

Comprobaciones baratas en el servidor cada segundo: velocidad real del personaje, altura imposible, teletransportes. Si algo falla, devuélvelo a una posición válida en vez de expulsar al momento (hay lag).

**Relacionado:** [[Exploits comunes]] · [[Network ownership]]
