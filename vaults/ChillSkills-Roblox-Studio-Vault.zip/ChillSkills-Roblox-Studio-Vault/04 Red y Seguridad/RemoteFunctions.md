# RemoteFunctions

Pregunta y respuesta (`InvokeServer` → `OnServerInvoke`). Evita `InvokeClient`: un hacker puede dejar al servidor esperando para siempre.

**Relacionado:** [[RemoteEvents]]
