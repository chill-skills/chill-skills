# Cliente y servidor

El **servidor** es la verdad: guarda dinero, daño y compras. El **cliente** (el PC/móvil del jugador) dibuja, recibe teclas y puede ser hackeado.
Regla de oro: *nunca confíes en el cliente*. Se comunican con [[RemoteEvents]] y [[RemoteFunctions]].

**Relacionado:** [[Validar en el servidor]] · [[Dónde va cada script]]
