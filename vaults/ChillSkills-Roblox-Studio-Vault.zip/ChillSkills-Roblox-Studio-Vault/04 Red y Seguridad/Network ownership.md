# Network ownership

Las piezas sueltas las simula quien está más cerca (a veces el cliente). Para objetos importantes (bosses, puertas) usa `part:SetNetworkOwner(nil)` para que el servidor mande.

**Relacionado:** [[Anti-cheat básico]] · [[Física y vehículos]]
