# Rate limiting

Limita cuántas veces por segundo puede usar un remote cada jugador:
```lua
local ultimo = {}
if os.clock() - (ultimo[player] or 0) < 0.3 then return end
ultimo[player] = os.clock()
```

**Relacionado:** [[RemoteEvents]] · [[Exploits comunes]]
