# RemoteEvents

Mensaje en una dirección.
```lua
-- cliente
Remotes.Atacar:FireServer(objetivo)
-- servidor
Remotes.Atacar.OnServerEvent:Connect(function(player, objetivo) ... end)
```
El primer argumento en el servidor siempre es el `player` real (no se puede falsificar).

**Relacionado:** [[Validar en el servidor]] · [[Rate limiting]] · [[ReplicatedStorage]]
