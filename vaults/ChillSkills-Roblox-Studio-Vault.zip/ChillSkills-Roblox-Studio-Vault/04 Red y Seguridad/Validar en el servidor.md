# Validar en el servidor

Comprueba TODO lo que llega del cliente:
- ¿El tipo es correcto? (`typeof(x) == "Instance"`)
- ¿Está cerca? (distancia con [[Matemáticas de juego]])
- ¿Tiene dinero / cooldown?
```lua
if (char.HumanoidRootPart.Position - moneda.Position).Magnitude > 12 then return end
```

**Relacionado:** [[RemoteEvents]] · [[Exploits comunes]] · [[Rate limiting]]
