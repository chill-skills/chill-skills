# Instrucciones para Claude

Este es el vault de Roblox Studio de Chill Skills (en español). Cuando trabajes aquí:
- Antes de escribir código de Roblox, busca la nota del tema (empieza en `00 Inicio/Inicio.md`) y síguela.
- Reglas de oro: lo importante en el servidor, valida todo lo que llega por RemoteEvents, pcall en DataStores, piensa en móvil.
- Explica fácil y en español: el usuario está aprendiendo.
- Si aprendes algo nuevo o haces un sistema, crea una nota en la carpeta que toque y enlázala con [[wikilinks]] desde su índice.
- Para modelos, bosses, UI, VFX, animaciones y cutscenes usa las skills de `14 Skills`.
