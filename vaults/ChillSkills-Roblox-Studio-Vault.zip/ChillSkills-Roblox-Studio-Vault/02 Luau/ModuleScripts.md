# ModuleScripts

Código reutilizable. Un ModuleScript devuelve una tabla:
```lua
local Config = {}
Config.PrecioEspada = 250
return Config
```
Y se usa con `local Config = require(game.ReplicatedStorage.Config)`. Organiza tus [[Sistemas]] así.

**Relacionado:** [[Dónde va cada script]] · [[OOP con metatables]]
