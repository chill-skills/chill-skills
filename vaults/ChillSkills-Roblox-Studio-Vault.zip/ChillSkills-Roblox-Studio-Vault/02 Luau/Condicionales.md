# Condicionales

```lua
if monedas >= 100 then comprar()
elseif monedas > 0 then print("Te falta")
else print("Sin dinero") end
```
`and`, `or`, `not`. Truco: `local x = valor or 0` (valor por defecto).

**Relacionado:** [[Variables y tipos]]
