# Type checking

Pon `--!strict` arriba del script y anota tipos: `local vida: number = 100`. Studio te avisa de errores antes de jugar. Tipos propios: `type Mascota = {nombre: string, nivel: number}`.

**Relacionado:** [[Variables y tipos]]
