# Eventos y conexiones

```lua
local con = part.Touched:Connect(function(hit) ... end)
con:Disconnect() -- cuando ya no lo necesites
```
Eventos típicos: `Touched`, `PlayerAdded`, `Changed`, `Heartbeat` ([[RunService]]). Desconecta para evitar fugas de memoria ([[Memoria e instancias]]).

**Relacionado:** [[Players]]
