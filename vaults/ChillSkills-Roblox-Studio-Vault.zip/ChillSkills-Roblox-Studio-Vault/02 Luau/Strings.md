# Strings

`..` une textos. `string.format("%d monedas", n)`. `string.upper`, `string.split(s, ",")`. Interpolación: `` `Hola {jugador.Name}` ``. Para números grandes ver [[Abreviar números]].
