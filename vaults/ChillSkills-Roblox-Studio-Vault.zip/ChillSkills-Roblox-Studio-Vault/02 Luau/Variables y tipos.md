# Variables y tipos

```lua
local monedas = 0          -- number
local nombre = "Kraken"    -- string
local vivo = true          -- boolean
local nada = nil
```
Usa siempre `local`. Tipos de Roblox: `Vector3`, `CFrame`, `Color3`, `UDim2`, `Instance`. Ver [[Type checking]].

**Relacionado:** [[Tablas]] · [[Funciones]]
