# Abreviar números

Los simuladores muestran 1.2K, 3.4M:
```lua
local function abreviar(n)
  local s = {"","K","M","B","T"}; local i = 1
  while n >= 1000 and i < #s do n /= 1000; i += 1 end
  return string.format(i==1 and "%d" or "%.1f", n)..s[i]
end
```

**Relacionado:** [[Strings]] · [[Simulador]]
