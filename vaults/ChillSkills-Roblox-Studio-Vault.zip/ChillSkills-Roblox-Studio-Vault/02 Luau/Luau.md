# Luau

Índice de **Luau**.

- [[Abreviar números]]
- [[Bucles]]
- [[Condicionales]]
- [[Eventos y conexiones]]
- [[Funciones]]
- [[Matemáticas de juego]]
- [[ModuleScripts]]
- [[OOP con metatables]]
- [[Strings]]
- [[Tablas]]
- [[Type checking]]
- [[Variables y tipos]]
- [[pcall y errores]]
- [[task library]]

Volver a [[Inicio]]
