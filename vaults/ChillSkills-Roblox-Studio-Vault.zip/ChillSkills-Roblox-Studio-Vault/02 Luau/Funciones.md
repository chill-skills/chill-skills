# Funciones

```lua
local function sumar(a: number, b: number): number
  return a + b
end
```
Las funciones son valores: puedes guardarlas en [[Tablas]] o pasarlas a [[Eventos y conexiones]].

**Relacionado:** [[Variables y tipos]]
