# pcall y errores

Las llamadas a internet (DataStore, Marketplace) pueden fallar:
```lua
local ok, res = pcall(function() return store:GetAsync(key) end)
if not ok then warn(res) end
```
Imprescindible en [[Guardar datos con DataStore]].

**Relacionado:** [[DataStoreService]]
