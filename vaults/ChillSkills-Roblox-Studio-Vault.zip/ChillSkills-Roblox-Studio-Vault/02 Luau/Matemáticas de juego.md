# Matemáticas de juego

- Distancia: `(a.Position - b.Position).Magnitude`.
- Dirección: `(b - a).Unit`.
- `math.clamp(x, min, max)`, `math.random(1, 10)` (mejor `Random.new()`).
- Curva de precios: `precio = base * 1.15 ^ nivel`.

**Relacionado:** [[Economía del juego]] · [[Combate y hitboxes]]
