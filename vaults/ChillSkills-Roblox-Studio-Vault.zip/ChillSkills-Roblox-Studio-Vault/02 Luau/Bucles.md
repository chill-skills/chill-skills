# Bucles

```lua
for i = 1, 10 do print(i) end
for _, jugador in game.Players:GetPlayers() do print(jugador.Name) end
while true do task.wait(1) end -- ¡siempre con wait!
```
Un `while true` sin espera congela el juego. Ver [[task library]].

**Relacionado:** [[Tablas]]
