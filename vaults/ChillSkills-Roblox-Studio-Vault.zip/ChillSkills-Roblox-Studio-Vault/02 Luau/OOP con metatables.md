# OOP con metatables

```lua
local Mascota = {}; Mascota.__index = Mascota
function Mascota.new(nombre) return setmetatable({nombre=nombre,nivel=1}, Mascota) end
function Mascota:subir() self.nivel += 1 end
```
Útil para [[Mascotas]] y [[Enemigos y spawns]].

**Relacionado:** [[Tablas]] · [[ModuleScripts]]
