# task library

- `task.wait(s)`: espera (mejor que `wait`).
- `task.spawn(f)`: corre algo en paralelo.
- `task.delay(s, f)`: lo corre más tarde.
- `task.defer(f)`: al final del frame.

**Relacionado:** [[Bucles]] · [[Eventos y conexiones]]
