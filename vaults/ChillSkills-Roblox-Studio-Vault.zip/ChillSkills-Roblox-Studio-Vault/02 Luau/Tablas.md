# Tablas

Lista: `local frutas = {"pera","uva"}` → `frutas[1]`.
Diccionario: `local stats = {Monedas = 10, Nivel = 2}` → `stats.Monedas`.
Recorrer: `for clave, valor in stats do ... end`.
`table.insert`, `table.remove`, `table.find`, `#lista` (longitud). Base de [[OOP con metatables]] e [[Inventario]].

**Relacionado:** [[Bucles]]
