# R6 vs R15

R6: estilo clásico, más fácil de animar, típico de battlegrounds. R15: más articulado y realista.

**Relacionado:** [[Motor6D y rigs]] · [[Roblox Animations (fwjelaa)]]
