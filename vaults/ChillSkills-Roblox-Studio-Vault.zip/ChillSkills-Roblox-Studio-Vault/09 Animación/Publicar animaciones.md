# Publicar animaciones

Las animaciones son assets: si el juego es de un grupo, súbelas al grupo o no se reproducirán.

**Relacionado:** [[Animator y AnimationTrack]] · [[Cutscene Skills]]
