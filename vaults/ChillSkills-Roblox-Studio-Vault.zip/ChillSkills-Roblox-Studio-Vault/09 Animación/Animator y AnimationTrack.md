# Animator y AnimationTrack

`humanoid.Animator:LoadAnimation(anim)` → track; `:Play()`, `:Stop()`, `.Looped`, `:AdjustSpeed()`. Carga una vez y reutiliza.

**Relacionado:** [[Prioridades de animación]] · [[Combate y hitboxes]]
