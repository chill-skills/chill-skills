# Eventos de animación

Marcadores (`GetMarkerReachedSignal("Golpe")`) para sincronizar daño, sonidos y VFX con el frame exacto.

**Relacionado:** [[Animator y AnimationTrack]] · [[Combate y hitboxes]] · [[ParticleEmitter]]
