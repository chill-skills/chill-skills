# Motor6D y rigs

Las articulaciones del personaje. R6 = 6 partes, R15 = 15. Para armas o bosses, el rig propio con Motor6D.

**Relacionado:** [[R6 vs R15]] · [[Bosses Roblox Studs]]
