# Prioridades de animación

Core < Idle < Movement < Action (1-4). Los ataques en Action para que pisen al correr.

**Relacionado:** [[Animator y AnimationTrack]]
