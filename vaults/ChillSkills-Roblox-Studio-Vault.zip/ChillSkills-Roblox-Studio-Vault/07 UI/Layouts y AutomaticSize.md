# Layouts y AutomaticSize

UIListLayout / UIGridLayout ordenan solos; `AutomaticSize` hace que un Frame crezca con su contenido; UIPadding para márgenes.

**Relacionado:** [[ScreenGui y estructura]] · [[Tienda]]
