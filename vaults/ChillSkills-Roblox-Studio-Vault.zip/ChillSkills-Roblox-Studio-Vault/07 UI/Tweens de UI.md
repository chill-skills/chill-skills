# Tweens de UI

Abre menús con un tween de tamaño 0 → 1 y `Enum.EasingStyle.Back`. Rápido (0.2–0.3 s).

**Relacionado:** [[TweenService]] · [[Notificaciones]]
