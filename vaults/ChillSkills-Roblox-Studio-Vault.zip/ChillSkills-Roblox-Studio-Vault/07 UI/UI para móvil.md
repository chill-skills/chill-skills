# UI para móvil

Más de la mitad juega en móvil: botones grandes (mín. ~44 px), UIScale según tamaño de pantalla, nada pegado a las esquinas (botón de salto y joystick).

**Relacionado:** [[ContextActionService]] · [[ScreenGui y estructura]] · [[Check-UI]]
