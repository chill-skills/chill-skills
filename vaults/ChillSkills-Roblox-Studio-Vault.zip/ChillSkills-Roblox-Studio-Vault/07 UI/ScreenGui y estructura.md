# ScreenGui y estructura

ScreenGui → Frame → botones. Usa `Scale` en UDim2 (0.5 = mitad de pantalla) en vez de píxeles. Un LocalScript por menú.

**Relacionado:** [[StarterGui]] · [[UI para móvil]]
