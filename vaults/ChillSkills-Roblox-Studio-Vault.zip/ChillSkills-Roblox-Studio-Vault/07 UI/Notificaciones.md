# Notificaciones

Cola de avisos arriba de la pantalla ("+50 monedas"): un solo LocalScript los muestra uno tras otro con tweens.

**Relacionado:** [[Tweens de UI]] · [[Monedas]]
