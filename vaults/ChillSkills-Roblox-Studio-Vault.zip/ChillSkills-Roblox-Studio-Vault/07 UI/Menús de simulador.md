# Menús de simulador

Los 5 clásicos: Tienda, Códigos, Rebirth, Ajustes, Recompensas diarias. Estilo listo con [[Check-UI]].

**Relacionado:** [[Tienda]] · [[Códigos]] · [[Rebirth]] · [[Recompensas diarias]]
