# MarketplaceService

`game:GetService("MarketplaceService")`

Game Passes y Developer Products.
```lua
MarketplaceService:PromptGamePassPurchase(player, id)
```

**Relacionado:** [[Game Passes]] · [[Developer Products y ProcessReceipt]]
