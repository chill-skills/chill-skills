# ServerStorage

`game:GetService("ServerStorage")`

Objetos solo del servidor (no se replican): plantillas de enemigos, armas, mapas.
```lua
local enemigo = game.ServerStorage.Enemigos.Kraken:Clone()
```

**Relacionado:** [[Enemigos y spawns]]
