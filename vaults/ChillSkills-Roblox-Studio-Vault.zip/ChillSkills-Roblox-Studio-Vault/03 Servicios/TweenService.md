# TweenService

`game:GetService("TweenService")`

Animar propiedades suavemente (posición, tamaño, color, transparencia).
```lua
TweenService:Create(part, TweenInfo.new(1), {Position = destino}):Play()
```

**Relacionado:** [[Tweens de UI]] · [[Puertas y plataformas]]
