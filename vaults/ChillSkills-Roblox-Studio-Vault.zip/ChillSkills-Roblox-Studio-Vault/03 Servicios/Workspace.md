# Workspace

`game:GetService("Workspace")`

El mundo 3D: todo lo que se ve. `workspace.Gravity`, `workspace:Raycast()`.
```lua
local r = workspace:Raycast(origen, direccion*100)
```

**Relacionado:** [[Mapas con Terrain]] · [[Combate y hitboxes]]
