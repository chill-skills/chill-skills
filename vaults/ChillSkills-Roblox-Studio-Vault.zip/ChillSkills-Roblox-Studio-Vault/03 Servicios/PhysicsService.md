# PhysicsService

`game:GetService("PhysicsService")`

Grupos de colisión: que los jugadores no choquen entre sí, o con mascotas.
```lua
PhysicsService:RegisterCollisionGroup("Jugadores")
```

**Relacionado:** [[Mascotas]]
