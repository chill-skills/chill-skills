# BadgeService

`game:GetService("BadgeService")`

Dar insignias por logros.
```lua
BadgeService:AwardBadge(player.UserId, badgeId)
```

**Relacionado:** [[Misiones y logros]]
