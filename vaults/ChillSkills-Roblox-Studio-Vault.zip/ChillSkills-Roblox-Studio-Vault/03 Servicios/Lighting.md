# Lighting

`game:GetService("Lighting")`

Hora del día, niebla, sombras y post-procesado (Bloom, ColorCorrection, Atmosphere).
```lua
Lighting.ClockTime = 18
```

**Relacionado:** [[Iluminación]] · [[Post-procesado]]
