# ReplicatedStorage

`game:GetService("ReplicatedStorage")`

Cosas que ven cliente y servidor: ModuleScripts compartidos, RemoteEvents, modelos que clonas.
```lua
local Remotes = game.ReplicatedStorage.Remotes
```

**Relacionado:** [[RemoteEvents]] · [[ModuleScripts]]
