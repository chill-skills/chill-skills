# Players

`game:GetService("Players")`

Los jugadores conectados. `PlayerAdded`, `PlayerRemoving`, `GetPlayers()`.
```lua
game.Players.PlayerAdded:Connect(function(p) print(p.Name) end)
```

**Relacionado:** [[Leaderstats]] · [[Guardar datos con DataStore]]
