# ContextActionService

`game:GetService("ContextActionService")`

Acciones con botón táctil automático en móvil.
```lua
CAS:BindAction("Atacar", f, true, Enum.KeyCode.F)
```

**Relacionado:** [[UI para móvil]] · [[Combate y hitboxes]]
