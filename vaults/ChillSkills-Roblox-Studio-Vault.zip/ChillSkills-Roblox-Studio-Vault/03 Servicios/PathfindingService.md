# PathfindingService

`game:GetService("PathfindingService")`

Calcula caminos para NPCs que esquivan paredes.
```lua
local path = PathfindingService:CreatePath(); path:ComputeAsync(a, b)
```

**Relacionado:** [[Enemigos y spawns]]
