# HttpService

`game:GetService("HttpService")`

JSON (`JSONEncode/Decode`) y GUIDs. Peticiones web solo si activas HTTP en Game Settings.
```lua
local id = HttpService:GenerateGUID(false)
```

**Relacionado:** [[Trading]]
