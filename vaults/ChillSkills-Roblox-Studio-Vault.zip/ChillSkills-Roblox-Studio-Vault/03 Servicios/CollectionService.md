# CollectionService

`game:GetService("CollectionService")`

Etiquetas (tags) para tratar muchos objetos igual: todas las "Lava", todas las "Moneda".
```lua
for _, p in CollectionService:GetTagged("Lava") do ... end
```

**Relacionado:** [[Monedas en el mapa]] · [[Obby]]
