# MessagingService

`game:GetService("MessagingService")`

Mensajes entre servidores (anuncios globales, eventos).
```lua
MessagingService:PublishAsync("Evento", "¡Boss!")
```

**Relacionado:** [[Live ops y eventos]]
