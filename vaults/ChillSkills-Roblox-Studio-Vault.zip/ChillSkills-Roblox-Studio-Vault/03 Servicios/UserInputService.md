# UserInputService

`game:GetService("UserInputService")`

Teclado, ratón, táctil y mando en el cliente.
```lua
UIS.InputBegan:Connect(function(i,gp) if not gp and i.KeyCode==Enum.KeyCode.E then ... end end)
```

**Relacionado:** [[ContextActionService]] · [[Combate y hitboxes]]
