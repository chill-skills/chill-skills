# RunService

`game:GetService("RunService")`

Bucles por frame: `Heartbeat` (servidor y cliente), `RenderStepped` (solo cliente, cámara).
```lua
RunService.Heartbeat:Connect(function(dt) ... end)
```

**Relacionado:** [[Cámara y shake]] · [[Memoria e instancias]]
