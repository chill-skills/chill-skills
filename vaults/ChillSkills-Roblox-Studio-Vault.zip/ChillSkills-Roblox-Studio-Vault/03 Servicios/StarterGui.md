# StarterGui

`game:GetService("StarterGui")`

Las interfaces (ScreenGui) que se copian a cada jugador al aparecer.
```lua
-- pon ResetOnSpawn = false en menús que no deban resetearse
```

**Relacionado:** [[ScreenGui y estructura]] · [[UI para móvil]]
