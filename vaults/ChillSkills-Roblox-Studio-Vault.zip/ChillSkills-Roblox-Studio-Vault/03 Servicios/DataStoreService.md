# DataStoreService

`game:GetService("DataStoreService")`

Guardar datos entre partidas.
```lua
local store = game:GetService("DataStoreService"):GetDataStore("Datos")
```

**Relacionado:** [[Guardar datos con DataStore]] · [[UpdateAsync vs SetAsync]] · [[Session locking]]
