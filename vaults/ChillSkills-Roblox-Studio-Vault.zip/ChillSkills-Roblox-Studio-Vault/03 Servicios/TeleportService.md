# TeleportService

`game:GetService("TeleportService")`

Mandar jugadores a otro lugar (place) del juego: lobby → partida.
```lua
TeleportService:TeleportAsync(placeId, {player})
```

**Relacionado:** [[Lobby y partidas]]
