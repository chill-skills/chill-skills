# Debris

`game:GetService("Debris")`

Borra objetos tras X segundos sin bloquear.
```lua
Debris:AddItem(efecto, 2)
```

**Relacionado:** [[ParticleEmitter]] · [[Memoria e instancias]]
