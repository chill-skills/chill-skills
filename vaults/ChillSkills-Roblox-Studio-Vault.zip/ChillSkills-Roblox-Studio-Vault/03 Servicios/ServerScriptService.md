# ServerScriptService

`game:GetService("ServerScriptService")`

Scripts del servidor. Los clientes no pueden ver ni robar este código.
```lua
-- aquí van los Scripts de datos, compras y combate
```

**Relacionado:** [[Dónde va cada script]] · [[Cliente y servidor]]
