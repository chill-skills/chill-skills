# Servicios

Índice de **Servicios**.

- [[BadgeService]]
- [[CollectionService]]
- [[ContextActionService]]
- [[DataStoreService]]
- [[Debris]]
- [[HttpService]]
- [[Lighting]]
- [[MarketplaceService]]
- [[MessagingService]]
- [[PathfindingService]]
- [[PhysicsService]]
- [[Players]]
- [[ReplicatedStorage]]
- [[RunService]]
- [[ServerScriptService]]
- [[ServerStorage]]
- [[SoundService]]
- [[StarterGui]]
- [[StarterPlayer]]
- [[TeleportService]]
- [[TweenService]]
- [[UserInputService]]
- [[Workspace]]

Volver a [[Inicio]]
