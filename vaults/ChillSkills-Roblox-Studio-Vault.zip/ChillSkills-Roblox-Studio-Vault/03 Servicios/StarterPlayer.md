# StarterPlayer

`game:GetService("StarterPlayer")`

Scripts del jugador: StarterPlayerScripts (una vez) y StarterCharacterScripts (cada vez que aparece).
```lua
-- WalkSpeed por defecto: StarterPlayer.CharacterWalkSpeed
```

**Relacionado:** [[Dónde va cada script]] · [[+1 Speed]]
