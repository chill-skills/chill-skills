# SoundService

`game:GetService("SoundService")`

Sonidos globales y SoundGroups para controlar volumen de música y efectos.
```lua
-- usa SoundGroups: Música, Efectos, UI
```

**Relacionado:** [[Sonido y música]]
