---
cssclasses: [vault-hub]
tags: [hub]
---
# Scripting y Seguridad · Roblox Vault

Luau de verdad: arquitectura cliente-servidor, RemoteEvents seguros, DataStores sin perder datos, anti-exploit, depuración, rendimiento, matemáticas de juego y recetas listas para copiar.

**204 notas** sacadas del *fwjelaa vault* (ver [[Créditos y licencia]]). Las notas están en inglés; Claude te las explica en español si se lo pides.

## Empieza por aquí
- [[Buffers and Binary Data]]
- [[Client Prediction and Reconciliation for Combat]]
- [[Data Loss Prevention and Recovery]]
- [[Anti-Exploit Start Here]]
- [[Debugging Start Here]]
- [[Luau Cookbook Start Here]]
- [[Advanced Luau Start Here]]
- [[Multiplayer Services Start Here]]
- [[Automated Luau Checks - fwjelaa Hook and Audit]]
- [[Core Concepts Start Here]]
- [[Engine Reference Cards Start Here]]
- [[Game Math Start Here]]

## Cómo usarlo con Claude
1. Abre esta carpeta en la pestaña **Code** de la app de Claude (o `claude` en la terminal).
2. Pregunta lo que quieras: Claude lee [[CLAUDE]] y busca en estas notas antes de responder.
3. Skills que combinan con este vault:
   - roblox-luau y roblox-dev-skill (Chill Skills)
   - fwjelaa-secure-remotes, fwjelaa-datastore-safety, fwjelaa-anti-exploit-review (fwjelaa vault)

Hecho para **Chill Skills**.
