# Estudios Vault — instrucciones para Claude

Este vault tiene mis apuntes del instituto.
- Cada asignatura tiene su carpeta en `Asignaturas/` y una nota índice con el mismo nombre.
- Cuando te pida apuntes de un tema, crea una nota con la plantilla `Plantillas/Apuntes.md` y enlázala en el índice de la asignatura.
- Cuando te pida repasar, hazme 5 preguntas tipo examen usando mis apuntes, no inventes temario.
- Los exámenes van en [[Calendario de exámenes]].
- Explica fácil, con ejemplos. Español.
