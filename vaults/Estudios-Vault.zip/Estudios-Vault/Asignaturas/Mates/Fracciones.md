# Fracciones
- Sumar: mismo denominador → sumas arriba. 1/4 + 2/4 = 3/4
- Distinto denominador → mínimo común múltiplo.
- Multiplicar: arriba por arriba, abajo por abajo.
Ver [[Asignaturas/Mates/Mates]]
