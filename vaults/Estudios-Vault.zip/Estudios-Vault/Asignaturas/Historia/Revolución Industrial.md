# Revolución Industrial
**Cuándo:** finales del s. XVIII · **Dónde:** Gran Bretaña

## Claves
- Máquina de vapor (1769)
- Fábricas y ciudades
- Ferrocarril (1804)

**Pregunta de examen:** ¿Por qué empezó en Gran Bretaña?
Ver [[Asignaturas/Historia/Historia]] · [[Calendario de exámenes]]
