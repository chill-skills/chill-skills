# Past simple
- Regulares: +ed (play → played)
- Irregulares: go → went, see → saw
Ver [[Asignaturas/Inglés/Inglés]]
