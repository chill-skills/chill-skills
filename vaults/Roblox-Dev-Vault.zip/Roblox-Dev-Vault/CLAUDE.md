# Roblox Dev Vault — instrucciones para Claude

Este vault es el cerebro de mis juegos de Roblox. Cuando trabajes aquí:
- Cada juego tiene su carpeta en `Juegos/` con un `GDD.md` (documento de diseño).
- Las ideas nuevas van a `Ideas/` usando la plantilla `Plantillas/Idea.md`.
- Los bugs van a `Bugs/` con la plantilla `Plantillas/Bug.md`. Cuando se arreglen, cambia `estado: arreglado`.
- Cada actualización publicada se apunta en `Updates/` (una nota por versión).
- Enlaza siempre las notas con [[wikilinks]] para que se vean en el grafo.
- Escribe en español, corto y claro. No borres notas: mueve las viejas a `Archivo/`.
