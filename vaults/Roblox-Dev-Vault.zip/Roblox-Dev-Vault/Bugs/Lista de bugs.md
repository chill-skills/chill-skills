# 🐞 Bugs
- [ ] El Kraken atraviesa las rocas → [[Juegos/Kraken Quest/Boss Kraken]]
- [ ] La tienda no guarda las compras al salir → [[Juegos/Kraken Quest/Tienda]]
- [x] El botón de cerrar no funciona en móvil
