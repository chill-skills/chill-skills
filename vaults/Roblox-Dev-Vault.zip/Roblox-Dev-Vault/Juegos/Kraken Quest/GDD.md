---
tipo: juego
estado: en desarrollo
---
# Kraken Quest — GDD

**Idea:** un juego de bosses en una isla. Derrota al [[Juegos/Kraken Quest/Boss Kraken|Kraken]] antes de que inunde todo.

## Bucle de juego
1. Explorar la isla y juntar conchas.
2. Mejorar armas en la [[Juegos/Kraken Quest/Tienda|tienda]].
3. Pelear contra el boss.

## Monetización
- Pase VIP x2 conchas
- Skins de arma

Relacionado: [[Skills que uso]] · [[Bugs/Lista de bugs]]
