---
tipo: juego
estado: idea
---
# Speed Simulator — GDD
Juego +1 Speed: cada paso suma velocidad. Cintas de correr de Común a Secreta ([[Juegos/Speed Simulator/Cintas]]).

Relacionado: [[Ideas/Ideas sueltas]]
