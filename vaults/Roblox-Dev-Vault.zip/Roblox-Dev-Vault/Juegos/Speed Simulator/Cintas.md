# Cintas
- Común x1 · Rara x2 · Épica x5 · Legendaria x10 · Mítica x25 · Secreta x100
Hechas con la skill **Folk Treadmills**. Ver [[Juegos/Speed Simulator/GDD]]
