---
cssclasses: [vault-hub]
tags: [hub]
---
# Mundos, Arte y UI · Roblox Vault

Construir mundos bonitos: mapas, iluminación, VFX y sonido, interfaces, modelado 3D y vóxel, materiales, generación procedural y físicas.

**183 notas** sacadas del *fwjelaa vault* (ver [[Créditos y licencia]]). Las notas están en inglés; Claude te las explica en español si se lo pides.

## Empieza por aquí
- [[Art Budgets - Triangles Draw Calls Memory]]
- [[Ambient Soundscapes - Layer Stacks, Overlapping Zones and Voice Pools]]
- [[Accessibility]]
- [[Glossy Icon Style - Owner Reference]]
- [[Bezier Curves and Splines for Modellers]]
- [[Materials and Surfaces Start Here]]
- [[Voxel Modelling Start Here]]
- [[Untextured Stylised Modelling Start Here]]
- [[Modelling Nuance Start Here]]
- [[Procedural Generation Start Here]]
- [[Physics and Vehicles Start Here]]

## Cómo usarlo con Claude
1. Abre esta carpeta en la pestaña **Code** de la app de Claude (o `claude` en la terminal).
2. Pregunta lo que quieras: Claude lee [[CLAUDE]] y busca en estas notas antes de responder.
3. Skills que combinan con este vault:
   - make-map (fwjelaa), LihFolk Stud Voxel, Bosses Roblox Studs, Check-UI y vfxmith (Chill Skills)

Hecho para **Chill Skills**.
