# Instrucciones para Claude (Animación y Cutscenes)

Este es un vault de Obsidian con notas sobre Roblox (animación y cutscenes). Cuando trabajes aquí:
- Antes de responder o escribir código, busca en las notas (empieza por `000 Inicio.md` y las notas "Start Here") y cita qué nota usaste.
- Responde en español aunque las notas estén en inglés. Explica fácil, el usuario es joven y está aprendiendo.
- Si una nota dice que algo no está verificado, dilo. Si la nota es de 2026 y algo pudo cambiar, avisa de comprobarlo en la documentación de Roblox.
- No borres ni reescribas notas existentes. Si aprendes algo nuevo, crea una nota en `Mis notas/` y enlázala con [[wikilinks]].
- Skills útiles: make-anim y make-cutscene (Cutscene Skills de fwjelaa); universal-r6-blender-animation-director / universal-r15-animation-director; cinematic-scene-direction y cinematic-performance-editing.
