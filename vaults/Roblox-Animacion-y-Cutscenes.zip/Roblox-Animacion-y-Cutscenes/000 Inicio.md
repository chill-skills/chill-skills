---
cssclasses: [vault-hub]
tags: [hub]
---
# Animación y Cutscenes · Roblox Vault

Todo sobre animar en Roblox: objetos de animación, rigs y Motor6D, importar desde Blender, el oficio de animar para juegos, IK y movimiento procedural, sistemas de combate (combos, habilidades, enemigos, cámaras) y game feel.

**139 notas** sacadas del *fwjelaa vault* (ver [[Créditos y licencia]]). Las notas están en inglés; Claude te las explica en español si se lo pides.

## Empieza por aquí
- [[Animation Start Here]]
- [[Game Feel Start Here]]
- [[Skeleton Library]]

## Cómo usarlo con Claude
1. Abre esta carpeta en la pestaña **Code** de la app de Claude (o `claude` en la terminal).
2. Pregunta lo que quieras: Claude lee [[CLAUDE]] y busca en estas notas antes de responder.
3. Skills que combinan con este vault:
   - make-anim y make-cutscene (Cutscene Skills de fwjelaa)
   - universal-r6-blender-animation-director / universal-r15-animation-director
   - cinematic-scene-direction y cinematic-performance-editing

Hecho para **Chill Skills**.
