# Hice un juego de Roblox con IA
**Gancho (0–2 s):** "Le pedí a una IA que me hiciera un juego de Roblox… y mira esto."
1. Le pido el boss Kraken → sale en 30 s
2. Le pido la tienda → UI lista
3. Lo pruebo con mis amigos
**Final:** "¿Qué boss le pido ahora?"

Idea: [[Ideas/Banco de ideas]] · Publicado: [[Publicados]]
