# 💡 Banco de ideas
- Hice un juego de Roblox con IA en 1 día → [[Guiones/Hice un juego de Roblox con IA]]
- Mi PC antes y después de optimizarlo
- 3 skills de Claude que nadie conoce
