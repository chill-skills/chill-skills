# Mis notas
Aquí van tus notas y las que cree Claude. Enlázalas con [[000 Inicio]].
