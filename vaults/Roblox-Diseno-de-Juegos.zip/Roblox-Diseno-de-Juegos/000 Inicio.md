---
cssclasses: [vault-hub]
tags: [hub]
---
# Diseño de Juegos · Roblox Vault

Cómo diseñar juegos de Roblox que la gente juegue: géneros, economía, retención, live ops, monetización, miniaturas, marketing y análisis de los juegos más top y virales.

**216 notas** sacadas del *fwjelaa vault* (ver [[Créditos y licencia]]). Las notas están en inglés; Claude te las explica en español si se lo pides.

## Empieza por aquí
- [[Balancing with Spreadsheets and Data]]
- [[Top Games Case Studies Start Here]]
- [[Level Design Start Here]]
- [[Lobby and Hub Design]]
- [[Genre Systems Start Here]]
- [[Economy Design Start Here]]
- [[Live Ops Deep Dive Start Here]]
- [[Viral and Trend Teardowns Start Here]]
- [[High-Craft Teardowns Start Here]]
- [[Thumbnails and CTR Start Here]]
- [[Monetization Overview]]
- [[Marketing and Growth Start Here]]
- [[Player QoL Start Here]]
- [[Narrative Start Here]]
- [[Lessons Learned Index]]

## Cómo usarlo con Claude
1. Abre esta carpeta en la pestaña **Code** de la app de Claude (o `claude` en la terminal).
2. Pregunta lo que quieras: Claude lee [[CLAUDE]] y busca en estas notas antes de responder.
3. Skills que combinan con este vault:
   - fwjelaa-trend-game y /fwjelaa:council (fwjelaa vault)
   - roblox-game (Chill Skills)

Hecho para **Chill Skills**.
