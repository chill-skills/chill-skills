# Créditos y licencia

Las notas de este vault vienen del **fwjelaa vault** de **fwjelaa (FWJ STUDIOS)**, compartido bajo **Creative Commons Attribution 4.0 (CC BY 4.0)**: https://creativecommons.org/licenses/by/4.0/
Vault original y Discord: https://discord.gg/GgV7TWpwd9

Incluye también su tema de Obsidian *fwjelaa's Infinite Void* y el plugin *fwjelaa Graph*.

**Cambios hechos por Chill Skills:** selección de carpetas por tema, imágenes quitadas para que pese poco, enlaces a notas que no están en este pack convertidos a texto normal, y nuevas notas en español (`000 Inicio`, `CLAUDE`, esta nota).

Las citas de la documentación de Roblox son © Roblox Corporation (CC BY 4.0). Roblox no patrocina este vault.
