# Instrucciones para Claude (Diseño de Juegos)

Este es un vault de Obsidian con notas sobre Roblox (diseño de juegos). Cuando trabajes aquí:
- Antes de responder o escribir código, busca en las notas (empieza por `000 Inicio.md` y las notas "Start Here") y cita qué nota usaste.
- Responde en español aunque las notas estén en inglés. Explica fácil, el usuario es joven y está aprendiendo.
- Si una nota dice que algo no está verificado, dilo. Si la nota es de 2026 y algo pudo cambiar, avisa de comprobarlo en la documentación de Roblox.
- No borres ni reescribas notas existentes. Si aprendes algo nuevo, crea una nota en `Mis notas/` y enlázala con [[wikilinks]].
- Skills útiles: fwjelaa-trend-game y /fwjelaa:council (fwjelaa vault); roblox-game (Chill Skills).
